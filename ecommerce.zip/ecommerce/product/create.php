<div class="card">
    <div class="card-header">
<h4>
    insert Image<a href="<?base_url('product')?>">BACK</a>
</h4>
</div>

<div class ="card-body">
<form action="base_url('product/add')?>"method="POST" enctype="multipart/form-data">
        	<div class="row">
        		<div class="col-12">
        			<div class="form-group">
		        		<label>Product Name</label>
		        		<input type="text" name="name" class="form-control" placeholder="Enter Product Name">
		        	</div>
        		</div>
        		<div class="col-12">
        			<div class="form-group">
		        		<label>Product Description</label>
		        		<textarea class="form-control" name="description" placeholder="Enter product desc"></textarea>
		        	<small><?php echo form_error('description');?></small>
                    </div>
        		</div>
            <div class="col-12">
              <div class="form-group">
                <label>Product Qty</label>
                <input type="number" name="quantity" class="form-control" placeholder="Enter Product Quantity">
                <small><?php echo form_error('quantity');?></small>

              </div>
            </div>
        		<div class="col-12">
        			<div class="form-group">
		        		<label>Product Price</label>
		        		<input type="number" name="price" class="form-control" placeholder="Enter Product Price">
                        <small><?php echo form_error('price');?></small>

		        	</div>
        		</div>
        		<div class="col-12">
        			<div class="form-group">
		        		<label>Product Keywords <small>(eg: apple, iphone, mobile)</small></label>
		        		<input type="text" name="keywords" class="form-control" placeholder="Enter Product Keywords">
		        	</div>
        		</div>
        		<div class="col-12">
        			<div class="form-group">
		        		<label>Product Image <small>(format: jpg, jpeg, png)</small></label>
		        		<input type="file" name="prod_image" class="form-control">
                        <small><?php if(isset($error)){ echo $error;}?></small>
		        	</div>

        		</div>
        		<input type="hidden" name="add_product" value="1">
        		<div class="col-12">
                <div class="form-group">
        			<button type="submit" name="product_save"class="btn btn-primary add-product">Add Product</button>
        		</div>
        	</div>
        	
        </form>
        </div>
        	</div>