

<div class="container">
	<div class="row justify-content-center" style="margin:100px 0;">
		<div class="col-md-4">
			
            <form method="post" action="<?= base_url() ?>register/index">
			  <div class="form-group">
			    <label for="cust_name">Name</label>
                <td width="329"><input type="text" name="cust_name"/></td>
			  </div>
			  <div class="form-group">
			    <label for="email">Email address</label>
                <td><input type="email" name="cust_email"/></td>
			    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
			  </div>
			  <div class="form-group">
			    <label for="password">Password</label>
                <td><input type="password" name="cust_password"/></td>
			  </div>
			  <div class="form-group">
			    <label for="address">Confirm addresss</label>
                <td><input type="text" name="cust_address"/></td>
			  </div>
              <div class="form-group">
			    <label for="contact">Confirm contact</label>
                <td><input type="text" name="cust_contact"/></td>
			  </div>
              <input type="submit" name="save" value="Save Data"/>
    	</form>
		</div>
	</div>
</div>







<script type="text/javascript" src="./js/main.js"></script>
