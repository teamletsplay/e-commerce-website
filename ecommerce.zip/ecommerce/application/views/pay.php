
	<link rel="stylesheet" type="text/css" href="assets/css/payment.css">

	<div class="container">
		
	
	</header>
	<div class="container">

			<form action="<?php echo base_url('InitController')?>" method="post">
                 <H3>DELIVERY ADDRESS</H3>
				 <h3></h3>


				Full name
				
				<input type="text" name="fullname" placeholder="Enter name" >
				Email
				<input type="text" name="email" placeholder="Enter email">

				Address
				<input type="text" name="address" placeholder="Enter address">
				
				City
				<input type="text" name="city" placeholder="Enter City">
			    
			<!--<div id="zip">-->
				
					<label>
						State
						<input type="text" name="state" placeholder="Enter State">
						
					</label>
						<label>
						Zip code   <input type="text"  placeholder="Zip code" name="zipcode">
					</label>
			<!----	</div> -->
				
	<!----		</form> -->

	           
				<input type="submit" name="" value="Proceed to Next">

			</form>
		
	</div>
</body>
</html>