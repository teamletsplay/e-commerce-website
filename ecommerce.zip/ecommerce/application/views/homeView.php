<!-- Home section --> 
<section id="home" class="home pt-5 overflow-hidden">
      <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-indicators">
          <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
          <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button> 
        </div>
        <div class="carousel-inner">
          <div class="carousel-item active">
            <div class="home-banner home-banner-1">
              <div class="home-banner-text">
                <h1>Laptops</h1>
                <h2>20% Discount For This Season</h2>
                <a href="<?php echo base_url('product123')?>" class="btn btn-danger text-uppercase mt-4">Our Products</a>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <div class="home-banner home-banner-2">
              <div class="home-banner-text">
                <h1>SHOPPERS</h1>
                <h2>New Summer Wear</h2>
                <a href="<?php echo base_url('product123')?>" class="btn btn-danger text-uppercase mt-4">Our Products</a>
              </div>
            </div>
          </div> 
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true">
            <span class="ti-angle-left slider-icon"></span>
          </span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true">
            <span class="ti-angle-right slider-icon"></span>
          </span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>

      <!-- Offer section -->
      <div class="offers">
        <div class="container">
          <div class="row">
            <!-- Offer Box One -->
            <div class="col-sm-6 col-lg-4 mb-lg-0 mb-4">
              <a href="<?php echo base_url('product123')?>">
                <div class="offer-box text-center position-relative">
                  <div class="offer-inner">
                    <div class="offer-image position-relative overflow-thidden">
                      <img decoding="async" src="assets/images/offer1.jpg" alt="Offers" class="img-fluid">
                      <div class="offer-overlay"></div>
                    </div>
                    <div class="offer-info">
                      <div class="offer-info-inner">
                        <p class="heading-bigger text-capitalize">Sale 30%</p>
                        <p class="offer-title-1 text-uppercase font-weight-bold">Don't Miss This Chance</p>
                        <button type="button" class="btn btn-outline-danger text-uppercase mt-4">Shop Now</button>
                      </div> 
                    </div>
                  </div>
                </div>
              </a>
            </div>
            <!-- offer Box Two -->
            <div class="col-sm-6 col-lg-4 mb-lg-0 mb-4 d-flex flex-column justify-content-between">
              <a href="<?php echo base_url('product123')?>">
                <div class="offer-box text-center position-relative mb-4 mb-sm-0 mb-lg-0">
                  <div class="offer-inner">
                    <div class="offer-image position-relative overflow-hidden">
                      <img decoding="async" src="assets/images/offer2%20(1).jpg" alt="Offers" class="img-fluid">
                      <div class="offer-overlay"></div>
                    </div>
                    <div class="offer-info">
                      <div class="offer-info-inner">
                        <p class="heading-bigger text-capitalize">Sale 70%</p>
                        <p class="offer-title-1 text-uppercase font-weight-bold">Don't Miss This Chance</p>
                        <button type="button" class="btn btn-outline-danger text-uppercase mt-4">Shop Now</button>
                      </div> 
                    </div>
                  </div>
                </div>
              </a>
              <a href="<?php echo base_url('product123')?>">
                <div class="offer-box text-center position-relative">
                  <div class="offer-inner">
                    <div class="offer-image position-relative overflow-hidden">
                      <img decoding="async" src="assets/images/offer4%20(2).jpeg" alt="Offers" class="img-fluid">
                      <div class="offer-overlay"></div>
                    </div>
                    <div class="offer-info">
                      <div class="offer-info-inner">
                        <p class="heading-bigger text-capitalize">Sale 50%</p>
                        <p class="offer-title-1 text-uppercase font-weight-bold">Don't Miss This Chance</p>
                        <button type="button" class="btn btn-outline-danger text-uppercase mt-4">Shop Now</button>
                      </div> 
                    </div>
                  </div>
                </div>
              </a>
            </div>

            <!-- offer Box Three -->
            <div class="col-sm-6 col-lg-4 mb-lg-0 mb-4">
              <a href="<?php echo base_url('product123')?>">
                <div class="offer-box text-center position-relative">
                  <div class="offer-inner">
                    <div class="offer-image position-relative overflow-hidden">
                      <img decoding="async" src="assets/images/offer5%20(1).jpeg" alt="Offers" class="img-fluid">
                      <div class="offer-overlay"></div>
                    </div>
                    <div class="offer-info">
                      <div class="offer-info-inner">
                        <p class="heading-bigger text-capitalize">Sale 25%</p>
                        <p class="offer-title-1 text-uppercase font-weight-bold">Don't Miss This Chance</p>
                        <button type="button" class="btn btn-outline-danger text-uppercase mt-4">Shop Now</button>
                      </div> 
                    </div>
                  </div>
                </div>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
       

    <!-- Products section -->
     <section id="products" class="products">
       <div class="container">
         <div class="row">
           <div class="col-sm-12">
             <div class="headline text-center mb-5">
               <h2 class="pb-3 position-relative d-inline-block">FEATURED PRODUCTS</h2>
             </div>
           </div>
         </div>
         <div class="row">
          <div class="col-sm-6 col-lg-4">
            <a href="#" class="d-block text-center mb-4">
              <div class="product-list">
                <div class="product-image position-relative"> 
                    <span class="sale">Sale</span>
                    <img decoding="async" src="assets/images/p1.jpg" alt="products" class="img-fluid product-image-first">
                    <img decoding="async" src="assets/images/p3.jpg" alt="products" class="img-fluid product-image-secondary"> 
                </div>
                <div class="product-name pt-3">
                  <h3 class="text-capitalize">Winter Long Sleeve Black White</h3>
                  <p class="mb-0 amount">RS400.00 <del>RS580.00</del></p>
                  <div class="py-1">
                      <span class="ti-star"></span>
                      <span class="ti-star"></span>
                      <span class="ti-star"></span>
                      <span class="ti-star"></span>
                      <span class="ti-star"></span>
                  </div>
                  <div class="content">
                  <div class="featured-content-list">
                  <button type="button" data-name="Winter_Long_Sleeve_Black_White" data-price="400" class="default-btn border-radius-5">Add to cart</button>
                  </div>
                </div>
                 </div>
              </div>
            </a> 
          </div>
          <div class="col-sm-6 col-lg-4">
            <a href="#" class="d-block text-center mb-4">
              <div class="product-list">
                <div class="product-image position-relative">  
                    <img decoding="async" src="assets/images/p2.jpg" alt="products" class="img-fluid product-image-first">
                    <img decoding="async" src="assets/images/p4.jpg" alt="products" class="img-fluid product-image-secondary"> 
                </div>
                <div class="product-name pt-3">
                  <h3 class="text-capitalize">women totes lady handbag</h3>
                  <p class="mb-0 amount">RS300.00</p>
                  <div class="py-1">
                      <span class="ti-star active"></span>
                      <span class="ti-star active"></span>
                      <span class="ti-star active"></span>
                      <span class="ti-star"></span>
                      <span class="ti-star"></span>
                  </div>
                  <div class="featured-content-list">
                  <button type="button" data-name="women_totes_lady_handbag" data-price="300" class="default-btn border-radius-5">Add to cart</button>
                  </div>
                </div>
              </div>
            </a> 
          </div>
          <div class="col-sm-6 col-lg-4">
            <a href="#" class="d-block text-center mb-4">
              <div class="product-list">
                <div class="product-image position-relative">  
                    <img decoding="async" src="assets/images/p4.jpg" alt="products" class="img-fluid product-image-first">
                    <img decoding="async" src="assets/images/p6.jpg" alt="products" class="img-fluid product-image-secondary"> 
                </div>
                <div class="product-name pt-3">
                  <h3 class="text-capitalize">Lace water dress</h3>
                  <p class="mb-0 amount">RS600.00</p>
                  <div class="py-1">
                      <span class="ti-star active"></span>
                      <span class="ti-star active"></span>
                      <span class="ti-star active"></span>
                      <span class="ti-star active"></span>
                      <span class="ti-star active"></span>
                  </div>
                  <div class="featured-content-list">
                  <button type="button" data-name="Lace_water_dress" data-price="600" class="default-btn border-radius-5">Add to cart</button>
                  </div>
                </div>
              </div>
            </a> 
          </div>
          <div class="col-sm-6 col-lg-4">
            <a href="#" class="d-block text-center mb-4">
              <div class="product-list">
                <div class="product-image position-relative">  
                    <img decoding="async" src="assets/images/p10.jpg" alt="products" class="img-fluid product-image-first">
                    <img decoding="async" src="assets/images/p8.jpg" alt="products" class="img-fluid product-image-secondary"> 
                </div>
                <div class="product-name pt-3">
                  <h3 class="text-capitalize">Elegant Formal Party Dress</h3>
                  <p class="mb-0 amount">RS500.00</p>
                  <div class="py-1">
                      <span class="ti-star active"></span>
                      <span class="ti-star active"></span>
                      <span class="ti-star"></span>
                      <span class="ti-star"></span>
                      <span class="ti-star"></span>
                  </div>
                  <div class="featured-content-list">

                  <button type="button" data-name="Elegant_Formal_Party_Dress" data-price="500" class="default-btn border-radius-5">Add to cart</button>
                </div>
              </div>
              </div>
            </a> 
          </div>
          <div class="col-sm-6 col-lg-4">
            <a href="#" class="d-block text-center mb-4">
              <div class="product-list">
                <div class="product-image position-relative">
                    <span class="sale">Sale</span>  
                    <img decoding="async" src="assets/images/p8.jpg" alt="products" class="img-fluid product-image-first">
                    <img decoding="async" src="assets/images/p10.jpg" alt="products" class="img-fluid product-image-secondary"> 
                </div>
                <div class="product-name pt-3">
                  <h3 class="text-capitalize">Mini Dress Ladies Sleeve</h3>
                  <p class="mb-0 amount">RS600.00</p>
                  <div class="py-1">
                      <span class="ti-star active"></span>
                      <span class="ti-star active"></span>
                      <span class="ti-star active"></span>
                      <span class="ti-star"></span>
                      <span class="ti-star"></span>
                  </div>
                  <div class="featured-content-list">

                  <button type="button" data-name="Mini_Dress_Ladies_Sleeve" data-price="600" class="default-btn border-radius-5">Add to cart</button>
                  </div>
                 </div>
              </div>
            </a> 
          </div>
          <div class="col-sm-6 col-lg-4">
            <a href="#" class="d-block text-center mb-4">
              <div class="product-list">
                <div class="product-image position-relative">  
                    <img decoding="async" src="assets/images/p1.jpg" alt="products" class="img-fluid product-image-first">
                    <img decoding="async" src="assets/images/p2.jpg" alt="products" class="img-fluid product-image-secondary"> 
                </div>
                <div class="product-name pt-3">
                  <h3 class="text-capitalize">Winter Long Sleeve Black White </h3>
                  <p class="mb-0 amount">RS500.00</p>
                  <div class="py-1">
                      <span class="ti-star active"></span>
                      <span class="ti-star active"></span>
                      <span class="ti-star active"></span>
                      <span class="ti-star active"></span>
                      <span class="ti-star"></span>
                  </div>
                  <div class="featured-content-list">
                  <button type="button" data-name="Winter_Long_Sleeve_Black_White" data-price="500" class="default-btn border-radius-5">Add to cart</button>
                  </div>
                </div>
              </div>
              </div>
            </a> 
          </div>
        </div>

        
          
             
             
                
                   
          
 </div>
        <!-- UP to 75% Off -->
        <div class="overflow-hidden my-5">
          <div class="row">
            <div class="col-sm-12 up_to_off">
              <img decoding="async" src="assets/images/lg.jpg" alt="offers" class="img-fluid w-100"> 
              <div class="up_to_content">
                <h2>UP TO 75% OFF SPORTSALE!</h2>
              </div>
            </div>
          </div>
        </div>
       </div>
     </section>

    <!-- Special section -->
     <section id="special" class="special">
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <div class="headline text-center mb-5">
              <h2 class="pb-3 position-relative d-inline-block">SUMMER SALE</h2>
            </div>
          </div>

          <div class="col-sm-12 col-lg-7 text-center text-lg-start">
            <div class="countdown-container">
              <h2 class="text-uppercase">Women Floral Embroidery</h2>
              <p class="my-4">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>
              <ul class="list-unstyled countdown-counter">
                <li><span class="fs-1 d-block" id="days">00</span> Days</li>
                <li><span class="fs-1 d-block" id="hours">00</span> Hr</li>
                <li><span class="fs-1 d-block" id="min">00</span> Min</li>
                <li><span class="fs-1 d-block" id="sec">00</span> Sec</li>
              </ul>
              <span class="countdown-price h3 d-block mb-4">RS1420.00 <del>RS1670.00</del></span>
              <div class="featured-content-list">

              <button type="button" data-name="Winter_Long_Sleeve_Black_White" data-price="500" class="default-btn border-radius-5">Add to cart</button>
            </div>
          </div>
          </div>
          <div class="col-sm-12 col-lg-5">
            <div class="special-img position-relative">
              <span class="">Sale</span>
              <img decoding="async" src="assets/images/p7.jpg" class="img-fluid">
            </div>
          </div>
        </div>
      </div>
     </section>


    <!-- Testimonial section -->
    <section id="testimonial" class="testimonial">
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <div class="headline text-center mb-5">
              <h2 class="pb-3 position-relative d-inline-block">Testimonials</h2>
            </div>
          </div>
          <div class="col-sm-12 col-lg-8 offset-lg-2 text-center">
            <div id="carouselExampleIndicatorsTwo" class="carousel slide" data-bs-ride="carousel">
              <div class="carousel-indicators">
                <button type="button" data-bs-target="#carouselExampleIndicatorsTwo" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                <button type="button" data-bs-target="#carouselExampleIndicatorsTwo" data-bs-slide-to="1" aria-label="Slide 2"></button> 
              </div>
              <div class="carousel-inner">
                <div class="carousel-item active">
                   <div class="testimonial-wrapper">
                     <div class="row">
                       <div class="col-sm-12">
                         <img decoding="async" src="assets/images/user.png" alt="" class="img-fluid">
                       </div>
                       <div class="username">
                          <h3> MASCARENHAS, Co-Founder / CEO</h3>
                          <span>DIGITAL SHOPPERS.</span>
                          <p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>
                      </div>
                     </div>
                   </div>
                </div>
                <div class="carousel-item">
                  <div class="testimonial-wrapper">
                    <div class="row">
                      <div class="col-sm-12">
                        <img decoding="async" src="assets/images/user2.png" alt="" class="img-fluid">
                      </div>
                      <div class="username">
                         <h3> JADEN MASCARENHAS, Co-Founder / CEO</h3>
                         <span>DIGITAL SHOPPERS..</span>
                         <p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>
                     </div>
                    </div>
                  </div>
                </div> 
              </div>
              <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicatorsTwo" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true">
                  <span class="ti-angle-left slider-icon"></span>
                </span>
                <span class="visually-hidden">Previous</span>
              </button>
              <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicatorsTwo" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true">
                  <span class="ti-angle-right slider-icon"></span>
                </span>
                <span class="visually-hidden">Next</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </section> 

  
   
<!-- Scroll Backt To Top --> 
<div id="scrollUp" title="Scroll To Top">
  <a href="#home"><span class="ti-arrow-up fs-4 text-white"></span></a>
</div>


  
   <!-- Bootstrap 5 js -->
<script src="assets/js/bootstrap.min.js"></script>  


<!-- Main JS -->
<script src="js/main.js"></script>
<script src="https://code.jquery.com/jquery-3.6.3.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/script.js"></script>
