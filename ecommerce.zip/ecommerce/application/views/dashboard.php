Welcome to Dashboard

<?php 
if($this->session->userdata('UserLoginSession'))
{
    $udata = $this->session->userdata('UserLoginSession');
    echo 'Welcome'.' '.$udata['email'];
}
else
{
    redirect(base_url('login/login'));
}



 ?>
 <a href="<?=base_url('login/logout')?>">Logout</a>