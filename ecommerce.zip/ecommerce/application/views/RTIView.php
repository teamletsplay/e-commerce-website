<div class="p-3 copyright">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-12 col-lg-6 p-1 p-lg-3 text-center text-lg-start">
              <p class="my-0">Copyright © 2023 <a href="#">SHOPPPER'S STOP</a> All Rights Reserved</p>
          </div>
          <div class="col-12 col-lg-6 p-1 p-lg-3 text-center text-lg-end">
              <p>Designed by <a href="#" target=" _blank">JADEN MASCARENHAS</a>.</p>
          </div>
        </div>
      </div>
    </div>
  </footer>