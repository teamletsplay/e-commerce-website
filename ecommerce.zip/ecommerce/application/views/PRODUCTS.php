
</section>
      <section>
         <div class="featured-area pt-100 pb-70">
            <div class="container">
               <div class="tab featured-tab-area">
                  <div class="row justify-content-center">

                     <div class="col-lg-4 col-md-8">
                        <ul class="tabs active">
                           <li class="">
                              <a href="#">
                                 All
                              </a>
                           </li>
                           <li class="">
                              <a href="#">
                                 Men
                              </a>
                           </li>
                           <li class="">
                              <a href="#">
                                 Women
                              </a>
                           </li>
                           <li class="">
                              <a href="#">
                                 Watch
                              </a>
                           </li>
                        </ul>
                     </div>
                  </div>
                  <div class="tab_content current active pt-45">
                     
                     <div class="tabs_item current">
                        <div class="row justify-content-center">
                           <div class="col-lg-3 col-md-6">
                              <div class="featured-item">
                                 <div class="featured-item-img">
                                    <a href="#">
                                       <img src="images/men-1.jpg" alt="Images">
                                    </a>
                                 </div>
                                 <div class="content">
                                    <h3><a href="#">Oxford Shirts</a></h3>
                                    <hr>
                                    <div class="content-in">
                                       <h4>₹ 1200 </h4>
                                       <span>(4.9)<i class="fa fa-star"></i></span>
                                    </div>
                                    <hr>
                                    <div class="featured-content-list">
                                       <button type="button" data-name="Oxford" data-price="1200" class="default-btn border-radius-5"> Add to cart</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-lg-3 col-md-6">
                              <div class="featured-item">
                                 <div class="featured-item-img">
                                    <a href="#">
                                       <img src="images/women-1.jpg" alt="Images">
                                    </a>
                                 </div>
                                 <div class="content">
                                    <h3><a href="#">Tunic </a></h3>
                                    <hr>
                                    <div class="content-in">
                                       <h4>₹ 459 </h4>
                                       <span>(4.4)<i class="fa fa-star"></i></span>
                                    </div>
                                    <hr>
                                    <div class="featured-content-list">
                                       <button type="button" data-name="Tunic" data-price="459" class="default-btn border-radius-5">Add to cart</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-lg-3 col-md-6">
                              <div class="featured-item">
                                 <div class="featured-item-img">
                                    <a href="#">
                                       <img src="images/watch-1.jpg" alt="Images">
                                    </a>
                                 </div>
                                 <div class="content">
                                    <h3><a href="#">Huawei Watch Buds	</a></h3>
                                    <hr>
                                    <div class="content-in">
                                       <h4>₹ 4059 </h4>
                                       <span>(4.4)<i class="fa fa-star"></i></span>
                                    </div>
                                    <hr>
                                    <div class="featured-content-list">
                                       <button type="button" data-name="Huawei" data-price="4059" class="default-btn border-radius-5">Add to cart</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-lg-3 col-md-6">
                              <div class="featured-item">
                                 <div class="featured-item-img">
                                    <a href="#">
                                       <img src="images/men-2.jpg" alt="Images">
                                    </a>
                                 </div>
                                 <div class="content">
                                    <h3><a href="#">Short-Sleeve Shirt</a></h3>
                                    <hr>
                                    <div class="content-in">
                                       <h4>₹ 800 </h4>
                                       <span>(4.9)<i class="fa fa-star"></i></span>
                                    </div>
                                    <hr>
                                    <div class="featured-content-list">
                                       <button type="button" data-name="Short-Sleeve" data-price="800" class="default-btn border-radius-5">Add to cart</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-lg-3 col-md-6">
                              <div class="featured-item">
                                 <div class="featured-item-img">
                                    <a href="#">
                                       <img src="images/women-2.jpg" alt="Images">
                                    </a>
                                 </div>
                                 <div class="content">
                                    <h3><a href="#">Culotte dress</a></h3>
                                    <hr>
                                    <div class="content-in">
                                       <h4>₹ 2459 </h4>
                                       <span>(4.4)<i class="fa fa-star"></i></span>
                                    </div>
                                    <hr>
                                    <div class="featured-content-list">
                                       <button type="button" data-name="Culotte" data-price="2459" class="default-btn border-radius-5">Add to cart</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-lg-3 col-md-6">
                              <div class="featured-item">
                                 <div class="featured-item-img">
                                    <a href="#">
                                       <img src="images/watch-2.jpg" alt="Images">
                                    </a>
                                 </div>
                                 <div class="content">
                                    <h3><a href="#">Fire Boltt Dazzle </a></h3>
                                    <hr>
                                    <div class="content-in">
                                       <h4>₹ 1999 </h4>
                                       <span>(4.4)<i class="fa fa-star"></i></span>
                                    </div>
                                    <hr>
                                    <div class="featured-content-list">
                                       <button type="button" data-name="FireBoltt" data-price="1999" class="default-btn border-radius-5">Add to cart</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-lg-3 col-md-6">
                              <div class="featured-item">
                                 <div class="featured-item-img">
                                    <a href="#">
                                       <img src="images/men-3.jpg" alt="Images">
                                    </a>
                                 </div>
                                 <div class="content">
                                    <h3><a href="#">Cuban Collar Shirt</a></h3>
                                    <hr>
                                    <div class="content-in">
                                       <h4>₹ 499 </h4>
                                       <span>(4.9)<i class="fa fa-star"></i></span>
                                    </div>
                                    <hr>
                                    <div class="featured-content-list">
                                       <button type="button" data-name="CubanCollar" data-price="499" class="default-btn border-radius-5">Add to cart</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-lg-3 col-md-6">
                              <div class="featured-item">
                                 <div class="featured-item-img">
                                    <a href="#">
                                       <img src="images/women-3.jpg" alt="Images">
                                    </a>
                                 </div>
                                 <div class="content">
                                    <h3><a href="#">Babydoll</a></h3>
                                    <hr>
                                    <div class="content-in">
                                       <h4>₹ 1159 </h4>
                                       <span>(4.0)<i class="fa fa-star"></i></span>
                                    </div>
                                    <hr>
                                    <div class="featured-content-list">
                                       <button type="button" data-name="Babydoll" data-price="1159" class="default-btn border-radius-5">Add to cart</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-lg-3 col-md-6">
                              <div class="featured-item">
                                 <div class="featured-item-img">
                                    <a href="#">
                                       <img src="images/watch-3.jpg" alt="Images">
                                    </a>
                                 </div>
                                 <div class="content">
                                    <h3><a href="#">Google Pixel</a></h3>
                                    <hr>
                                    <div class="content-in">
                                       <h4>₹ 2059 </h4>
                                       <span>(4.4)<i class="fa fa-star"></i></span>
                                    </div>
                                    <hr>
                                    <div class="featured-content-list">
                                       <button type="button" data-name="Google" data-price="2059" class="default-btn border-radius-5">Add to cart</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-lg-3 col-md-6">
                              <div class="featured-item">
                                 <div class="featured-item-img">
                                    <a href="#">
                                       <img src="images/men-4.jpg" alt="Images">
                                    </a>
                                 </div>
                                 <div class="content">
                                    <h3><a href="#">T-shirt</a></h3>
                                    <hr>
                                    <div class="content-in">
                                       <h4>₹ 700 </h4>
                                       <span>(3.9)<i class="fa fa-star"></i></span>
                                    </div>
                                    <hr>
                                    <div class="featured-content-list">
                                       <button type="button" data-name="T-shirt" data-price="700" class="default-btn border-radius-5">Add to cart</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-lg-3 col-md-6">
                              <div class="featured-item">
                                 <div class="featured-item-img">
                                    <a href="#">
                                       <img src="images/women-4.jpg" alt="Images">
                                    </a>
                                 </div>
                                 <div class="content">
                                    <h3><a href="#">Wrap around</a></h3>
                                    <hr>
                                    <div class="content-in">
                                       <h4>₹ 4059 </h4>
                                       <span>(4.4)<i class="fa fa-star"></i></span>
                                    </div>
                                    <hr>
                                    <div class="featured-content-list">
                                       <button type="button" data-name="Wrap" data-price="4059" class="default-btn border-radius-5">Add to cart</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-lg-3 col-md-6">
                              <div class="featured-item">
                                 <div class="featured-item-img">
                                    <a href="#">
                                       <img src="images/watch-4.jpg" alt="Images">
                                    </a>
                                 </div>
                                 <div class="content">
                                    <h3><a href="#">titan Power</a></h3>
                                    <hr>
                                    <div class="content-in">
                                       <h4>₹ 459 </h4>
                                       <span>(4.4)<i class="fa fa-star"></i></span>
                                    </div>
                                    <hr>
                                    <div class="featured-content-list">
                                       <button type="button" data-name="titan" data-price="459" class="default-btn border-radius-5">Add to cart</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="tabs_item">
                        <div class="row justify-content-center">
                           <div class="col-lg-3 col-md-6">
                              <div class="featured-item">
                                 <div class="featured-item-img">
                                    <a href="#">
                                       <img src="images/men-1.jpg" alt="Images">
                                    </a>
                                 </div>
                                 <div class="content">
                                    <h3><a href="#">Oxford Shirts</a></h3>
                                    <hr>
                                    <div class="content-in">
                                       <h4>₹ 1200 </h4>
                                       <span>(4.9)<i class="fa fa-star"></i></span>
                                    </div>
                                    <hr>
                                    <div class="featured-content-list">
                                       <button type="button" data-name="Oxford" data-price="1200" class="default-btn border-radius-5">Add to cart</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-lg-3 col-md-6">
                              <div class="featured-item">
                                 <div class="featured-item-img">
                                    <a href="#">
                                       <img src="images/men-2.jpg" alt="Images">
                                    </a>
                                 </div>
                                 <div class="content">
                                    <h3><a href="#">Short-Sleeve Shirt</a></h3>
                                    <hr>
                                    <div class="content-in">
                                       <h4>₹ 800 </h4>
                                       <span>(4.9)<i class="fa fa-star"></i></span>
                                    </div>
                                    <hr>
                                    <div class="featured-content-list">
                                       <button type="button" data-name="Short-Sleeve" data-price="800" class="default-btn border-radius-5">Add to cart</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-lg-3 col-md-6">
                              <div class="featured-item">
                                 <div class="featured-item-img">
                                    <a href="#">
                                       <img src="images/men-3.jpg" alt="Images">
                                    </a>
                                 </div>
                                 <div class="content">
                                    <h3><a href="#">Cuban Collar Shirt</a></h3>
                                    <hr>
                                    <div class="content-in">
                                       <h4>₹ 499 </h4>
                                       <span>(4.9)<i class="fa fa-star"></i></span>
                                    </div>
                                    <hr>
                                    <div class="featured-content-list">
                                       <button type="button" data-name="Cuban" data-price="499" class="default-btn border-radius-5">Add to cart</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-lg-3 col-md-6">
                              <div class="featured-item">
                                 <div class="featured-item-img">
                                    <a href="#">
                                       <img src="images/men-4.jpg" alt="Images">
                                    </a>
                                 </div>
                                 <div class="content">
                                    <h3><a href="#">T-shirt</a></h3>
                                    <hr>
                                    <div class="content-in">
                                       <h4>₹ 700 </h4>
                                       <span>(3.9)<i class="fa fa-star"></i></span>
                                    </div>
                                    <hr>
                                    <div class="featured-content-list">
                                       <button type="button" data-name="T-shirt" data-price="700" class="default-btn border-radius-5">Add to cart</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="tabs_item">
                        <div class="row justify-content-center">
                           <div class="col-lg-3 col-md-6">
                              <div class="featured-item">
                                 <div class="featured-item-img">
                                    <a href="#">
                                       <img src="images/women-1.jpg" alt="Images">
                                    </a>
                                 </div>
                                 <div class="content">
                                    <h3><a href="#">Tunic </a></h3>
                                    <hr>
                                    <div class="content-in">
                                       <h4>₹ 459 </h4>
                                       <span>(4.4)<i class="fa fa-star"></i></span>
                                    </div>
                                    <hr>
                                    <div class="featured-content-list">
                                       <button type="button" data-name="Tunic" data-price="459" class="default-btn border-radius-5">Add to cart</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-lg-3 col-md-6">
                              <div class="featured-item">
                                 <div class="featured-item-img">
                                    <a href="#">
                                       <img src="images/women-2.jpg" alt="Images">
                                    </a>
                                 </div>
                                 <div class="content">
                                    <h3><a href="#">Culotte dress</a></h3>
                                    <hr>
                                    <div class="content-in">
                                       <h4>₹ 2459 </h4>
                                       <span>(4.4)<i class="fa fa-star"></i></span>
                                    </div>
                                    <hr>
                                    <div class="featured-content-list">
                                       <button type="button" data-name="Culotte" data-price="2459" class="default-btn border-radius-5">Add to cart</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-lg-3 col-md-6">
                              <div class="featured-item">
                                 <div class="featured-item-img">
                                    <a href="#">
                                       <img src="img/women-3.jpg" alt="Images">
                                    </a>
                                 </div>
                                 <div class="content">
                                    <h3><a href="#">Babydoll</a></h3>
                                    <hr>
                                    <div class="content-in">
                                       <h4>₹ 1159 </h4>
                                       <span>(4.0)<i class="fa fa-star"></i></span>
                                    </div>
                                    <hr>
                                    <div class="featured-content-list">
                                       <button type="button" data-name="Babydoll" data-price="1159" class="default-btn border-radius-5">Add to cart</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-lg-3 col-md-6">
                              <div class="featured-item">
                                 <div class="featured-item-img">
                                    <a href="#">
                                       <img src="images/women-4.jpg" alt="Images">
                                    </a>
                                 </div>
                                 <div class="content">
                                    <h3><a href="#">Wrap around</a></h3>
                                    <hr>
                                    <div class="content-in">
                                       <h4>₹ 4059 </h4>
                                       <span>(4.4)<i class="fa fa-star"></i></span>
                                    </div>
                                    <hr>
                                    <div class="featured-content-list">
                                       <button type="button" data-name="Wrap" data-price="4059" class="default-btn border-radius-5">Add to cart</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     
                     <div class="tabs_item">
                        <div class="row justify-content-center">
                           <div class="col-lg-3 col-md-6">
                              <div class="featured-item">
                                 <div class="featured-item-img">
                                    <a href="#">
                                       <img src="images/watch-1.jpg" alt="Images">
                                    </a>
                                 </div>
                                 <div class="content">
                                    <h3><a href="#">Huawei Watch Buds	</a></h3>
                                    <hr>
                                    <div class="content-in">
                                       <h4>₹ 4059 </h4>
                                       <span>(4.4)<i class="fa fa-star"></i></span>
                                    </div>
                                    <hr>
                                    <div class="featured-content-list">
                                       <button type="button" data-name="Huawei" data-price="4059" class="default-btn border-radius-5">Add to cart</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-lg-3 col-md-6">
                              <div class="featured-item">
                                 <div class="featured-item-img">
                                    <a href="#">
                                       <img src="images/watch-2.jpg" alt="Images">
                                    </a>
                                 </div>
                                 <div class="content">
                                    <h3><a href="#">Fire Boltt Dazzle </a></h3>
                                    <hr>
                                    <div class="content-in">
                                       <h4>₹ 1999 </h4>
                                       <span>(4.4)<i class="fa fa-star"></i></span>
                                    </div>
                                    <hr>
                                    <div class="featured-content-list">
                                       <button type="button" data-name="FireBoltt" data-price="1999" class="default-btn border-radius-5">Add to cart</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-lg-3 col-md-6">
                              <div class="featured-item">
                                 <div class="featured-item-img">
                                    <a href="#">
                                       <img src="img/watch-3.jpg" alt="Images">
                                    </a>
                                 </div>
                                 <div class="content">
                                    <h3><a href="#">Google Pixel</a></h3>
                                    <hr>
                                    <div class="content-in">
                                       <h4>₹ 2059 </h4>
                                       <span>(4.4)<i class="fa fa-star"></i></span>
                                    </div>
                                    <hr>
                                    <div class="featured-content-list">
                                       <button type="button" data-name="Google" data-price="2059" class="default-btn border-radius-5">Add to cart</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-lg-3 col-md-6">
                              <div class="featured-item">
                                 <div class="featured-item-img">
                                    <a href="#">
                                       <img src="images/watch-4.jpg" alt="Images">
                                    </a>
                                 </div>
                                 <div class="content">
                                    <h3><a href="#">titan Power</a></h3>
                                    <hr>
                                    <div class="content-in">
                                       <h4>₹ 459 </h4>
                                       <span>(4.4)<i class="fa fa-star"></i></span>
                                    </div>
                                    <hr>
                                    <div class="featured-content-list">
                                       <button type="button" data-name="titan" data-price="459" class="default-btn border-radius-5">Add to cart</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>

                     <p id="not_found"></p>
                  </div>
               </div>
            </div>
         </div>
      </section>
    
  
   <!-- Bootstrap 5 js -->
<script src="assets/js/bootstrap.min.js"></script>  


<!-- Main JS -->
<script src="js/main.js"></script>
<script src="https://code.jquery.com/jquery-3.6.3.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/script.js"></script>
