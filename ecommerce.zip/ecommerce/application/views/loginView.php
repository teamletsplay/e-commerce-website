<style>
    body{
        background-color: #e9e9ea;
        display: grid ;
        place-items: center;
        overflow-x:hidden
       
    }
    #input 
{
    width: 35em;
    height: 3em;
    padding: 2px 50px;
    background-color: rgb(241, 241, 241);
    border: none;
    border-radius: 5px;
}
    .container1{
        background-color: #f6f6f6;
         max-width: 100%;
         width: 50%;
         place-items: center;
         display:grid;
         grid-template-columns: 1fr 1.3fr;
       }
       
       .l1{
         background-color: #2874f0;
         padding: 3rem 2rem;
       }
       
       .r1{
       
         padding: 3rem 2rem;
       }
       
       .heading1{
        color: #fff;
        font-weight: 700;
        margin-bottom: 2rem;
        margin-top: 2rem;

       }
       
       .heading__desc1 {
        color: #ebebeb;
         font-size: 1.2rem;
       }
       
       .email1, .password1{
        margin-bottom: 20px;
       }
       .login-group1 input{
         padding: 10px;
         border: none;
         width: 100%;
         border-bottom: 1px solid #878787;
         outline: none;
       }
    
       .btn1{
        display: flex;
        align-items: center;
        justify-content: center;
       }
       button{
        /* background-color: #00e600; */
        background-color: #fb641b;
        color: white;
        font-weight: 700;
        padding: 15px;
        border: none;
        border-radius: 3px;
        width: 100%;
        cursor: pointer;
       }
    
       .logoimage{
        margin-top: 350px;
        display: flex;
        justify-content: center;
        align-items: center;
        /* background-color: #000000; */
       }
       .logoimage img{
        height: 120px;
       }
    
       .checkbox{
        display: flex;
        margin-top: 20px;
       }
       .checkbox span{
        margin-left: 10px;
        font-family: 'Times New Roman', Times, serif;
       }
       .signup_link1{
        margin-top: 30px;
        color: #2874f0;
        display: flex;
        justify-content: center;
        align-items: center;
    }
    .signup_link1 a{
        color: #0061fc;
        text-decoration: none;
       }
       .contact1{
           padding:4rem 0;
           background-color:var(--bg--white);
       }
       .contact1 .info li p a{
           font-size: 1rem;
           display:inline-block;
           margin:0.75rem 0;
           color:var(--text-black);
       } 
       .contact1 .form-group{
           margin-bottom:1.5rem;
       }
       .contact1 .form-control{
           height:3.75rem;
           padding:0.375rem 1.1875rem;
           border:none;
           font-size: 1rem;
           box-shadow: 0 0.1875rem 1.25rem 0 rgb(0 0 0 / 12%);
       }
       .contact1 .textarea{
           width:100%;
           border-radius: 0.25rem;
           padding:0.75rem 1.1875rem;
           border:none;
           font-size: 1rem;
           margin-top:0.3125rem;
           box-shadow: 0 0.1875rem 1.25rem 0 rgb(0 0 0 / 12%);;
       }
       .contact1 .textarea:focus{
           outline:none;
           border:none;
       }
       
       /* Footer CSS */
       .copyright{
           background: var(--bg-danger);
       }
       .copyright p,
       .copyright a{
           color:var(--text-white);
       }</style>
</head>

<body>
    
        
<?php echo validation_errors(); ?>


    <div class="container1">
     <div class="l1">
            <h1 class="heading1">LOGIN</h1>
            <p class="heading__desc1">LET THE JOURNEY BEGIN!......                               To Get access to your Orders, Wishlist and Recommendations</p>
            <div class="logoimage">
                <img src="images/logo.png" alt="SHOPPERS">
               
            </div>
        </div>

    <div class="r1">
    <form method="post" autocomplete="off" action="<?=base_url('login/loginnow')?>">

            <div class="login-group1">
                <div class="email1">
                    <label class="label" for="email">Email</label>
                    <input type="email" name="email" id="email" placeholder="Enter your email.."required>
                </div>
                <div class="password1">
                    <label class="label" for="password">Password</label>
                    <input type="password" name="password" id="password" placeholder="Enter your password.."required>
                </div>
                <div class="btn1">
                <input type="hidden" name="login" value="1">
              <input type="submit" class="btn btn-primary" style="float:right;" Value="Login">
                </div>
            </div>
            <div class="signup1">
                <div class="checkbox">
                    <input type="checkbox" name="checkbox" id="checkbox">
                    <span>Accept Terms and Conditions</span>
                </div>
                <div class="signup_link1">
                    New to SHOPPERS? &nbsp; <a href="Customers">Create an account</a>
                </div>
    
                <?php
						if($this->session->flashdata('error')) {	?>
						 <p class="text-danger text-center" style="margin-top: 10px;"> <?=$this->session->flashdata('error')?></p>
						<?php } ?>
						
						</form>
					  </div>
					</div>
				</div>
				<div class="col-md-4"></div>
			</div>
		</div>
        <?php echo form_close();?>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
            </div>
        </div>
    </div>
</div>


    <!-- Contact section -->
    <form method="post" action="<?= base_url() ?>login">

    <section id="contact">
        <div class="contact1">
          <div class="container">
            <div class="mb-5 text-center">
                <h5>Let’s Start a Conversation!</h5>
                <h2 class="fw-bold">Contact Us</h2>
            </div>
  
            <div class="row">
              <div class="col-lg-5 col-md-5">
                  <h4 class="fw-bold">Contact Info</h4>
                  <ul class="info list-unstyled">
                    <li class="d-flex align-items-center"> 
                        <span class="pe-3 ti-location-pin fs-5"></span>
                        <p><a href="">Lorem ipsum dolor sit amet, consectetur.</a></p>
                    </li>
                    <li class="d-flex align-items-center">
                        <span class="pe-3 ti-mobile fs-5"></span>
                        <p><a href="">+91 999-999-9999</a></p>
                    </li>
                    <li class="d-flex align-items-center">
                        <span class="pe-3 ti-envelope fs-5"></span>
                        <p><a href="">SHOPPERSSTOP.in</a></p>
                    </li> 
                  </ul>
              </div>
              <div class="col-lg-7 col-md-7 pt-lg-0 pt-md-0 pt-4">
                  <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                            <input type="text" class="form-control" name="help_name" id="name" placeholder="Your name.. ">
                        
                          </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                            <input type="email" class="form-control" name="help_email" id="email" placeholder="Email address">
                        </div>
                      </div>
                      <div class="col-md-12">
                        <div class="form-group">
                            <input class="textarea" name="help_message" cols="30" rows="4" id="message" placeholder="Enter your message">
                        </div>
                      </div>
                      <div class="col-md-12"> 
                      <input type="submit"name="save" id="contact-submit"value="SEND MESSAGE"button class="btn btn-danger"><span class="ti-rocket pe-2 fs-5"></span> </button>
                        </div>
                    </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>
      <script type="text/javascript" src="js/mainlogin.js"></script>
