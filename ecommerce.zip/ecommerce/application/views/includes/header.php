<!DOCTYPE html>
<html>
<head>
    <title></title>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Themify Icons -->
    <link rel="stylesheet" href="5546YEEcss/themify-icons.css">  

    <!-- Bootstrap 5 CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css"> 

    <!-- Style css -->
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/style1.css">


    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.6.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  
+<STYle>
button
  {
    /* background-color: #00e600; */
    background-color: #fb641b;
    color: white;
    font-weight: 700;
    padding: 15px;
    border: none;
    border-radius: 3px;
    width: 100%;
    cursor: pointer;
   }</STYle>


    <title>VP Nuvem - <?php echo $title;?></title>
  </head>
  <body>
  
