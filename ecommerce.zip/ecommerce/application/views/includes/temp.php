
<?php $this->load->view('includes/header'); ?>

<?php $this->load->view($maincontent); ?>

<?php $this->load->helper('url'); ?>