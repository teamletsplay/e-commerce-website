<?php $this->load->view('includes/header'); ?>

<?php $this->load->view('includes/navbar'); ?>

<?php $this->load->view($maincontent); ?>