<?php $this->load->view('includes/header'); ?>

<?php $this->load->view('includes/navbar'); ?>

<?php $this->load->view($maincontent); ?>

<?php $this->load->view('includes/footer'); ?>
<?php $this->load->helper('url'); ?>