<body data-bs-spy="scroll" data-bs-target=".navbar">

    <!-- Navigation section -->
    <section id="header">
      <nav class="navbar navbar-expand-lg bg-primary fixed-top">
        <div class="container">
          <a class="navbar-brand" href="<?php echo base_url('InitController')?>">
            <img decoding="async" src="assets/images/logo.png" class="img-fluid">
          </a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="ti-align-justify navbar-toggler-icon"></span>
              </div>
              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                </ul>
                
             
                <div id="search">
                  <i class="fas fa-search search"></i>
                  <input type="text" id="input" name="searchBox" placeholder="Search for Clothing and Accessories">
              </div>
              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                </ul>
                
             </div>
            <!-- <span class="navbar-toggler-icon"></span> -->
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
              <div id="user4">
              <button type="button" class="btn btn-primary my-2 my-sm-0"data-toggle="modal"
              data-target="#staticBackdrop"> 
               <i class="fas fa-shopping-cart total-count"Style='font-size:30px'></i>
           </button>
          </div>
           <div id="user">
           <a href="<?php echo base_url('login')?>"> <i class="fa fa-users"style='font-size:36px'></i> </a>
           </div>
           <div id="user3">
           <a href="<?php echo base_url('admin')?>"> <i class="fa fa-history"style="font-size:36px"></i> </a>
           </div>
           <div id="user2">
            <a href="#contact"> <i class="fa fa-mobile"style='font-size:36px'></i> </a>
           </div>
              </li>
           </div>
            </ul>
          </div>
        </div>
       
      </nav>
    </section>
      
      <!-- Modal -->
      <div class="modal fade" id="staticBackdrop" data-backdrop="static" data-keyboard="false" tabindex="-1"
         aria-labelledby="staticBackdropLabel" aria-hidden="true">
         <div class="modal-dialog modal-dialog-centered"style="max-width:600px; max-height:1000px;">
            <div class="modal-content">
               <div class="modal-header">
                  <h5 class="modal-title" id="staticBackdropLabel">Your Cart</h5>
                  
               </div>
               <div class="modal-body">
                  <table class="show-cart table">
        
                  </table>
                  <div class="grand-total">Total price: ₹<span class="total-cart"></span></div>
                </div>
                <div class="modal-footer">
                   <a href="<?php echo base_url('payment')?>" class="btn btn-danger text-uppercase mt-4">CHECKOUT</a>
                   <button type="button" class="btn btn-secondary" data-dismiss="modal">CLOSE</button>
                </div>
            </div>
         </div>
      </div>
   <!-- Bootstrap 5 js -->
<script src="assets/js/bootstrap.min.js"></script>  

<!-- Main JS -->
<script src="js/main.js"></script>
<script src="https://code.jquery.com/jquery-3.6.3.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/script.js"></script>