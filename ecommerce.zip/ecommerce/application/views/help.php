<!DOCTYPE html>
<html lang="en">
<head>
  <title>View Ajax</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<?php session_start(); ?>
<?php include_once("application/admin/templates/top.php"); ?>
<?php include_once("application/admin//templates/navbar.php"); ?>
<div class="container-fluid">
  <div class="row">
    
    <?php include "application/admin//templates/sidebar.php"; ?>


      <div class="row">
      	<div class="col-10">
      		<h2>Manage customer problems</h2>
      	</div>
      	<div class="col-2">
      		
      	</div>
      </div>
      
      <div class="table-responsive">
        <table class="table table-striped table-sm">
        <thead>
      <tr>
		<th>Sl No</th>
        <th>Name</th>
        <th>Email</th>
        <th>problem</th>
      </tr>
    </thead>
    <tbody id="table">
      
    </tbody>
  </table>
</div>
<script>
	$.ajax({
		url: "<?php echo base_url("application/controller/Crud/viewajax");?>",
		type: "POST",
		cache: false,
		success: function(data){
			//alert(data);
			$('#table').html(data); 
		}
	});
</script>
          
  
        </table>
      </div>
    </main>
  </div>
</div>



<script type="text/javascript" src="application/admin/js/help.js"></script>