<style>	  
.cinfo {
    font-size: 48px;
    display: inline-block;
    margin-bottom: 10px;
    color: #0568ae;
	
}
.contact .contact-info {
  margin-bottom: 20px;
  text-align: center;
}

.centera {
	text-align: center;
}

.border-right {
    border-right: 1px solid #ddd;
}

.contactheader{
	    font-size: 18px;
    margin-bottom: 15px;
    font-weight: bold;
    text-transform: uppercase;
    color: #666;
}

.contactinfolink {
	text-decoration: none;
	color:#000;
	font-size:1.1em;
}
.contactinfolink:hover{
	 color: #0568ae;
}
</style>

<div class="container px-4 py-5" id="featured-3">
    <h2 class="pb-2 border-bottom">Contact Us</h2>
	
	
	 
  <!-- ======= Contact Section ======= -->
   
       
          <p style="text-align:center;font-weight:bold;">Office Timings: 10:00am to 1:00pm & 2:30pm to 5:30pm &nbsp;| Closed on Sundays and Second Saturdays</p>
      <br />
      

 
	

  </div>
