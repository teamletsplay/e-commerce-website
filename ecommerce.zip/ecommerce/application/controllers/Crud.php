<?php
class Crud extends CI_Controller 
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper('url'); 
		$this->load->database();
		$this->load->model('Crud_model');
	}
	public function index()
	{
		$this->load->view('help');
	}
	
	public function viewajax()
	{
				$data=$this->Crud_model->display_records();
				$i=1;
				foreach($data as $row)
				{
					  echo "<tr>";
					  echo "<td>".$i."</td>";
					  echo "<td>".$row->help_name."</td>";
					  echo "<td>".$row->help_email."</td>";
					  echo "<td>".$row->help_message."</td>";
					  echo "</tr>";
					  $i++;
				}
	}
}