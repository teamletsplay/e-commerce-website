<?php

class loginadmin extends CI_Controller {

    function index() { 
		$data['error'] = 0;
		$data['title'] = "login";
		$this->load->database(); 
		$data['maincontent']="admin/login.php";
        $this->load->view('includes/temp_login', $data); 
		log_message("debug", "initController - LoginPage.php");        
	}
}