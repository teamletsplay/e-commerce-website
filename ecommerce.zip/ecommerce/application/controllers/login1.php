<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class login1 extends CI_Controller {

	public function __construct()
	{
	/*call CodeIgniter's default Constructor*/
	parent::__construct();
	
	/*load database libray manually*/
	$this->load->database();
	$this->load->library('form_validation');
	$this->load->library('session');
	$this->load->helper('form');
	/*load Model*/
	$this->load->model('User_model');
	$this->load->model('help_model');

	}

    
		public function index()
	{
        $this->load->view('includes/navbar1');   
		$this->load->view('loggedin'); 
		if($this->input->post('save'))
		{
			$data=array(
					'help_name'=>$this->input->post('help_name') ,
					'help_email'=>$this->input->post('help_email'),
					'help_message'=>$this->input->post('help_message')
			);
				   
		
					$response=$this->help_model->saverecords($data);
					if($response==true){
							echo "Records Saved Successfully";
					}
					else{
							echo "Insert error !";
					}
				}
    }
}