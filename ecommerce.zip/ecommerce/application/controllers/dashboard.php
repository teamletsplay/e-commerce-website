<?php
defined('BASEPATH') OR exit('No direct script access aloowed');

class dashboard extends CI_Controller {


	public function __construct()
	{
	/*call CodeIgniter's default Constructor*/
	parent::__construct();
	
	/*load database libray manually*/
	$this->load->database();
	
	/*load Model*/
	$this->load->model('help_model');
    }
        /*Insert*/
    function index() {       
		
		$data['error'] = 0;
		$data['title'] = "Home";
		
		$data['maincontent']="homeView";
        $this->load->helper(array('form','url')); 
        $this->load->view('includes/navbar1');   
        $this->load->view('home');         
        $this->load->view('includes/footer');         

        log_message("debug", "initController - LoginPage.php");
		if($this->input->post('save'))
		{
			$data=array(
					'help_name'=>$this->input->post('help_name') ,
					'help_email'=>$this->input->post('help_email'),
					'help_message'=>$this->input->post('help_message')
			);
				   
		
					$response=$this->help_model->saverecords($data);
					if($response==true){
							echo "Records Saved Successfully";
					}
					else{
							echo "Insert error !";
					}
				}
    }
	
	
	//function your_order() {
	//	$data['error'] = 0;
	//	$data['title'] = "orders";
	//	$data['maincontent']="orderView";
      //  $this->load->view('includes/template', $data);         
        //log_message("debug", "initController - LoginPage.php");
	//}
	
	//
	
    
	
	
	
	
	
	
	
	
	
	function contactUs() {       
		
		$data['error'] = 0;
		$data['title'] = "Contact Us";
		$data['maincontent']="contactUsView";
        $this->load->view('includes/template', $data);         
        log_message("debug", "initController - LoginPage.php");
    }
	
	
	function RTI() {       
		
		$data['error'] = 0;
		$data['title'] = "RTI";
		$data['maincontent']="RTIView";
        $this->load->view('includes/template', $data);         
        log_message("debug", "initController - LoginPage.php");
    }
	
	
	
	
	
	

}