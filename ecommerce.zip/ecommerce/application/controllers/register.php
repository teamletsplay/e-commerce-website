<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class register extends CI_Controller 
{
	public function __construct()
	{
	/*call CodeIgniter's default Constructor*/
	parent::__construct();
	
	/*load database libray manually*/
	$this->load->database();
	
	/*load Model*/
	$this->load->model('login_model');
    }
        /*Insert*/
	public function index()
	{
		/*load registration view form*/
        $this->load->view('template/header'); 
		$this->load->view('RegisterView'); 
        $this->load->view('template/footer'); 
		/*Check submit button */
		if($this->input->post('save'))
{
		    $data['cust_name']=$this->input->post('cust_name');
            $data['cust_email']=$this->input->post('cust_email');
            $data['cust_password']=$this->input->post('cust_password');
            $data['cust_address']=$this->input->post('cust_address');
            $data['cust_contact']=$this->input->post('cust_contact');
           

			$response=$this->login_model->savereg($data);
			if($response==true){
			        echo "Records Saved Successfully";
			}
			else{
					echo "Insert error !";
			}
		}
	}
	
}
?>