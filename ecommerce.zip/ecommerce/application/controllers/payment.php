<?php

class payment extends CI_Controller {

    function index() { 
		$data['error'] = 0;
		$data['title'] = "pay";
		$this->load->database(); 
		$data['maincontent']="pay";
        $this->load->view('includes/temp', $data); 
		log_message("debug", "initController - LoginPage.php");        
	}
}