<?php

defined('BASEPATH') OR exit('No direct script access allowed');


class admin extends CI_Controller {

public function index()
	{
		$this->load->view('views/template/header'); 
		$this->load->view('product/create'); 
		$this->load->view('template/footer'); 
	}
	
public function edit()
{
	$this->load->view('views/template/header'); 
	$this->load->view('product/edit'); 
	$this->load->view('includes/template', $data);         
}

public function __construct()
{
	parent::__construct();
	$this->load->library('form_validation');
	$this->load->helper('form');

}
public function store()
{
	$this->form_validation->set_rules('name','Product Name','required'); 
	$this->form_validation->set_rules('description','Description','required'); 
	$this->form_validation->set_rules('quantity','Quantity','required'); 

	$this->form_validation->set_rules('keyword','Keyword','required'); 

	$this->form_validation->set_rules('price','Product Price','required'); 

if($this->form_validation->run())
{
$config = [
	'upload_path' =>'./images/',
	'allowed_types' => 'gif|jpg|png',
	'file_name' => $new_name,
];
$this ->load->library('upload',$config);
if ( ! $this->upload->do_upoad('userfile'))
{
		$imageError = array('imageError' => $this->upload->display_errors());

		$this->load->view('template/header'); 
		$this->load->view('product/create',$ImageError); 
		$this->load->view('template/footer'); 
}
else
{
		$prod_filename =$this->upload->data('file_name');
		$data =[
			'name'=> $this->upload->data('name'),
			'description'=> $this->upload->data('description'),
			'price'=> $this->upload->data('price'),
			'keyword'=> $this->upload->data('keyword'),
			'quantity'=> $this->upload->data('quantity'),
            'image'=> $prod_filename

		];
		$product =  new ProductModel;
		$res =$product->insertProduct($data);
		$this->session->set_flashdata('status','Product inserted ...' );
		redirect(base_url('product'));
}
}
else {
	{
		$this->index();
	}
}
}
}
