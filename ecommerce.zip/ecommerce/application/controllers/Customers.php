<?php 
class Customers extends CI_Controller 
{
	public function __construct()
	{
	/*call CodeIgniter's default Constructor*/
	parent::__construct();
	
	/*load database libray manually*/
	$this->load->database();
	
	/*load Model*/
	$this->load->model('Customers_model');
	}
        /*Insert*/
	public function index()
	{
		/*load registration view form*/
		$this->load->view('template/header'); 
		$this->load->view('give');

	
		/*Check submit button */
		if($this->input->post('save'))
		{
		    $data['first_name']=$this->input->post('first_name');
			$data['last_name']=$this->input->post('last_name');
			$data['email']=$this->input->post('email');
            $data['address1']=$this->input->post('address1');
			$data['address2']=$this->input->post('address2');

            $data['mobile']=$this->input->post('mobile');
            $data['password']=$this->input->post('password');


			$response=$this->Customers_model->saverecords($data);
			if($response==true){
				$this->session->set_flashdata('success','Successfully User Created');
			}
			else{
					echo "Insert error !";
			}
		}
	}
	
}
?>