<?php
defined('BASEPATH') OR exit('No direct script access aloowed');

class insert_data extends CI_Controller {


	public function __construct()
	{
	/*call CodeIgniter's default Constructor*/
	parent::__construct();
	
	/*load database libray manually*/
    $this->load->helper('url'); 
    $this->load->database();
    $this->load->model('cart_model');
	
	/*load Model*/
    }
        /*Insert*/
          
public function insert_data() {
    // Retrieve data from the POST request
    $name = $this - > input - > post('name');
    $count = $this - > input - > post('count');
    // Insert data into the database
    $this->cart_model->saverecords($name,$count);	
    // Send a response back to the JavaScript file
    if ($this - > db - > affectedRows() > 0) {
        echo 'Data inserted successfully';
    } else {
        echo 'Data Insert failed';
    }
}
}