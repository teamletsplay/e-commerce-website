<?php

class product123 extends CI_Controller {

function index() {       
    
    $data['error'] = 0;
    $data['title'] = "Home";
    $this->load->database(); 
    $data['maincontent']="PRODUCTS";
    $this->load->view('includes/template', $data);         
    
}
}
