<?php

class RentalItemModel extends CI_Model{
    
    public $item;
    public $quantity;    
    public $price;
    public $rentalitemsid;
    public $cmobileno;
    public $rentalclientlink;
    public $regno;
    public $imageurl;
    public $imageurldp;
    

function bookRentalItem($todate, $fromdate, $cmobileno, $mmobileno, $rentalclientlinkid) {

    
        date_default_timezone_set('Asia/Kolkata');
        $timestamp = date('Y-m-d H:i:s');
        
        $data = array('bto' => $todate, 'bfrom' => $fromdate, 'cmobileno' => $cmobileno, 'mmobileno' => $mmobileno, 'bookingdate'=>$timestamp,'rentalclientlinkid' => $rentalclientlinkid);

        $this->db->insert('rentalclientcustomerlink', $data);

        $id = $this->db->insert_id();
        return $id;
    }

}