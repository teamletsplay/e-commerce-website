<?php

class SubClientModel extends CI_Model {

    public $subclientmobileno;
    public $citystateModel;
    public $fullname;
    public $lat;
    public $lon;
    public $categoryModel;
    public $phoneno;
    public $emailid;
    public $website;
    public $addr1;
    public $addr2;
    public $opentime;
    public $closetime;
    public $bookingnos;
    public $bookinginterval;
    public $alternatestatus;
    public $clientavailability;
    public $bookingModel;
    public $rating;
    public $reviewers;
    public $reservedschedule;
    public $startToken;
    public $caupdate;
    public $scheduleClient;
    public $notes;
    public $salonsubclientlinkid;
	public $breaktime;
	public $breakintervaltime;
    
    function updatecaupdate() {
        
        date_default_timezone_set('Asia/Kolkata');
        $todaysdate = date('Y-m-d');

        $sql = "update subclientprofile 
                set caupdate = ?
                where caupdate < curdate();";

        $query = $this->db->query($sql, array($todaysdate));
    }

    function updateClientSchedule($scmobileno) {

        $sql = "select * from subclientprofile sc
                left outer join clientsublink csl on sc.scmobileno = csl.scmobileno
                where sc.scmobileno=?";

        $query = $this->db->query($sql, array($scmobileno));

        $dataaa = array();

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $reservedScheduleDays = ($row->reservedschedule) * 7;
                $caupdate = $row->caupdate;
                array_push($dataaa, array("cmobileno" => $row->cmobileno, "bookingnos" => $row->bookingnossc, "alternatestatus" => $row->alternatestatussc, "days" => $row->Days));
            }
        }

        $data = array();
		date_default_timezone_set("Asia/Calcutta");
        $now = time(); // or your date as well
        $your_date = strtotime($caupdate) + $reservedScheduleDays;
        $datediff = $now - $your_date;

        $eligibleFlag = 0;
        if ($datediff > 0) {
            $eligibleFlag = 1;
        }

        if ($eligibleFlag) {
            echo $eligibleFlag . $scmobileno . $reservedScheduleDays;
            $j = 1;
            for ($i = 1; $i <= $reservedScheduleDays; $i++) {
                echo "i=" . $i;
                if ($i % 8 == 0) {
                    $j = 1;
                }
                foreach ($dataaa as $key => $value) {
                    if (strpos($value['days'], strval($j)) !== false) {

                        $date = date('Y-m-d', strtotime("+1 day", strtotime($caupdate)));
                        echo "SK" . $scmobileno . $i . $date;
                        $caupdate = $date;
                        $cmobileno = $value['cmobileno'];
                        $alternatestatus = $value['alternatestatus'];
                        if ($alternatestatus == 'Y') {
                            $availability = (int) ($value['bookingnos'] / 2);
                        } else {
                            $availability = $value['bookingnos'];
                        }
                        $total = $availability;
                        $status = 'F';
                        array_push($data, array("scmobileno" => $scmobileno, "date" => $date, "cmobileno" => $cmobileno, "status" => $status, "availability" => $availability, "total" => $total));
                    }
                }
                $j++;
            }
            $this->db->insert_batch('clientschedule', $data);

            $this->db->set('caupdate', $date); //value that used to update column  
            $this->db->where('scmobileno', $scmobileno); //which row want to upgrade  
            $this->db->update('subclientprofile');  //table name
        }
    }

    function getClientScheduleData($scmobileno) {
        $sql = "select * from clientschedule
                where scmobileno = ?";

        $query = $this->db->query($sql, array($scmobileno));

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
        }
        return $data;
    }

    function getLiveStatus($scmobileno, $todaysDate) {
        $sql = "select * from livestatus
                where scmobileno = ? and appointmentdate = ?";

        $query = $this->db->query($sql, array($scmobileno, $todaysDate));
        $data = null;
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
        }
        return $data;
    }
    
    function resetLiveStatus($livestatusid)
    {
        $this->db->delete('livestatus', array('livestatusid' => $livestatusid));
        if ($this->db->affected_rows() > 0)
            return 1; //Live  deleted
        else
            return 0; //Some problem in mysql or trying to delete it again
        
    }

    function updateLiveStatus($cmobileno, $scmobileno, $todaysDate, $tokeno) {
        $sql = "select * from livestatus
                where scmobileno = ? and appointmentdate = ?";
        $firstStart = 1;
        $query = $this->db->query($sql, array($scmobileno, $todaysDate));
        $data = null;
        $livestatusid = -1;
        $liveStatus = new LiveStatusModel();
        if ($query->num_rows() > 0) {
            $firstStart = 0;

            foreach ($query->result() as $row) {
                $livestatusid = $row->livestatusid;
                $liveStatus->livestatusid = $row->livestatusid;
                $liveStatus->appointmentdate = $row->appointmentdate;
                $liveStatus->scmobileno = $row->scmobileno;
                $liveStatus->currentbookingno = $row->currentbookingno;
                $liveStatus->livestatusts = $row->livestatusts;
            }
        }

        date_default_timezone_set('Asia/Kolkata');
        $timestamp = date('Y-m-d H:i:s');

        if ($firstStart) {//Add record into the database 
            $data = array('scmobileno' => $scmobileno,
                'appointmentdate' => $todaysDate, 'currentbookingno' => $tokeno,
                'livestatusts' => $timestamp);

            $this->db->insert('livestatus', $data);
            $liveStatus->livestatusid = $this->db->insert_id();
            $liveStatus->appointmentdate = $todaysDate;
                $liveStatus->scmobileno = $scmobileno;
                $liveStatus->currentbookingno = $tokeno;
                $liveStatus->livestatusts = $timestamp;
                        
        } else if($tokeno>($liveStatus->currentbookingno)){
            $sql = "UPDATE livestatus 
                SET currentbookingno= ?,livestatusts = ?
                WHERE livestatusid = ? ";

            $query = $this->db->query($sql, array($tokeno, $timestamp, $livestatusid));
            $liveStatus->currentbookingno = $tokeno;
            $liveStatus->livestatusts = $timestamp;
        }
        else if(($tokeno<$liveStatus->currentbookingno)){
        }
            
        return $liveStatus;
    }
	
	
	
	function updateClientAvailabilityArduino($cmobileno,$scmobileno,$status){                       
		
		$sql = "select * from clientavailability
                where cmobileno=? and scmobileno = ? and date = ?";
		date_default_timezone_set('Asia/Kolkata');
		$todaysDate = date('Y-m-d');	
		echo $todaysDate;

//Check the client position. Which is todays day and also TIME and Get TOTAL nos.		

        $query = $this->db->query($sql, array($cmobileno, $scmobileno, $todaysDate));
        $recordExist = 0;
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $recordExist = 1;
            }
        }
		
		
		
		$sql = "select * from clientsublink
                where cmobileno = ? and scmobileno = ?";
				
		$total=0;
		$offlineavail = 0;
		$availability=0;
        $query = $this->db->query($sql, array($cmobileno, $scmobileno));        
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $total = $row->bookingnossc;
            }
        }
		
		if($status == 'C')
		{
			$total=0;
			$offlineavail=0;
			$availability=0;
		}
		else if($status == 'H' || $status == 'S')
		{
			$total = $total/2;
			$offlineavail = $total/2;
			$availability = $offlineavail;
			
		}else if($status=='F')
		{
			$total = $total;
			$offlineavail = $total/2;
			$availability = $offlineavail;
			
		}
				
		
		$availability = $total;		
		if($recordExist == 1)
	   { 		   
		   $sql = "update clientavailability set status=? where scmobileno =? and date=?";
		   $sql2 = "update clientschedule set status=? where scmobileno =? and date=?";
           $query = $this->db->query($sql, array($status,$scmobileno,$todaysDate));
		   $query = $this->db->query($sql2, array($status,$scmobileno,$todaysDate));
		   return 7;
	   }
	   else
	   {
        $data = array('cmobileno' => $cmobileno,
                'scmobileno' => $scmobileno, 
				'date' => $todaysDate,
                'status' => $status,
				'availability' => $availability,
				'offlineavail' => $offlineavail,
				'total' => $total);

            $this->db->insert('clientavailability', $data);
			$this->db->insert('clientschedule', $data);
			return 9;
	   }  
           
        
        
    }
	
	
    
    function updateClientAvailability($json, $scmobileno){
        $clientAvailabilityModel = json_decode($json);
        $data=array();
        for($i=0;$i<sizeof($clientAvailabilityModel);$i++)
        {
             $data[$i] = array (
                 
                      'scmobileno' => $scmobileno,
                      'date' => $clientAvailabilityModel[$i]->bookingdate,
                      'status' => $clientAvailabilityModel[$i]->status,
                      'availability' => $clientAvailabilityModel[$i]->availability,
					  'offlineavail' => $clientAvailabilityModel[$i]->offlineavail,
                      'total' => $clientAvailabilityModel[$i]->total,
                      'cmobileno' => $clientAvailabilityModel[$i]->clientid
                  
            );
        }
        
        $sofCAM = sizeof($clientAvailabilityModel);    
       
   
        
        $this->db->insert_batch('clientavailability', $data);
        if ($this->db->affected_rows() > 0)
        {
            $caupdate = $clientAvailabilityModel[$sofCAM-1]->bookingdate;            
            $weekday = date('w', strtotime($caupdate));
           
            
            
            if($weekday!=0)
            {
                $diff = 7- $weekday;
                $caupdate = date('Y-m-d', strtotime($caupdate. ' + '.$diff.' days'));
               
               
            }
            
            $sql = "update subclientprofile set caupdate=? where scmobileno =?";
            $query = $this->db->query($sql, array($caupdate,$scmobileno));
        
            return $this->db->insert_id();
        }
        else
        {
            return 0;
        }
        
    }

}
