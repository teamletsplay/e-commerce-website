<?php

class ClientAvailabilityModel extends CI_Model {

    public $clientavailabilityid;
    public $clientid;
    public $scmobileno;
    public $date;
    public $month;
    public $status;
    public $availability;
    public $total;
    public $color;
    public $bookingdate;
    public $day;
	public $opentime;
	public $closetime;
	public $bookingintervalsc;
	public $starttokensc;
	public $alternatestatussc;
	public $breaktime;
	public $breakintervaltime;

    public function getAvailabilityList($cmobileno,$scmobileno) {
        
        date_default_timezone_set('Asia/Kolkata');
        $currentdate = date('Y-m-d');
        $sql = "select * from clientavailability ca
				left outer join clientsublink csl on csl.cmobileno = ca.cmobileno and ca.scmobileno=csl.scmobileno
                WHERE ca.cmobileno=? and  ca.scmobileno=? and ca.date >=?				
                order by ca.date";

        $query = $this->db->query($sql, array($cmobileno,$scmobileno,$currentdate));

        $clientAvailability = array();
        $i = 0;
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $clientAvailability[$i] = new ClientAvailabilityModel();
                $clientAvailability[$i]->availability = $row->availability;
                $clientAvailability[$i]->clientavailabilityid = $row->clientavailabilityid;
                $clientAvailability[$i]->clientid = $row->cmobileno;
                $clientAvailability[$i]->scmobileno = $row->scmobileno;
                $date = $row->date;
                $convert_date = strtotime($date);  
                $clientAvailability[$i]->bookingdate = $date;
                $clientAvailability[$i]->date = date('j',$convert_date);
                $clientAvailability[$i]->month = date('M',$convert_date);
                $clientAvailability[$i]->status = $row->status;
                $clientAvailability[$i]->total = $row-> total; 
				$clientAvailability[$i]->opentime = $row->opentimesc;
				$clientAvailability[$i]->closetime = $row->closetimesc;
				$clientAvailability[$i]->bookingintervalsc = $row->bookingintervalsc;
				$clientAvailability[$i]->starttokensc = $row->starttokensc;
				$clientAvailability[$i]->alternatestatussc = $row->alternatestatussc;
				$clientAvailability[$i]->breaktime = $row->breaktime;
				$clientAvailability[$i]->breakintervaltime = $row->breakintervaltime;
				
				
				
				
                if($row->total !=0)
                {
	                $per = ($row->availability/(($row->total)/2))*100;
	        }
	        else
	        {
	        	$per=0;
	        } 
	               
                
                if($per>=50)
                {
                    $clientAvailability[$i]->color = "#70b0ef";
                }
                else if($per < 50 && $per >0)
                {
                    $clientAvailability[$i]->color = "#c78118";// "#efc86e";
                }
                else
                {
                    $clientAvailability[$i]->color = "#db151f";
                }
                $i++;
            }
        }
        return $clientAvailability;
    }

}
