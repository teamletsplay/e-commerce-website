<?php



class ClientModel extends CI_Model {



    public $loginModel;

    public $citystateModel;

    public $cmobileno;

    public $client;

    public $fullname;

    public $lat;

    public $lon;

    public $categoryModel;

    public $phoneno;

    public $emailid;

    public $website;

    public $addr1;

    public $addr2;

    public $opentime;

    public $closetime;

    public $bookingnos;

    public $bookinginterval;

    public $alternatestatus;

    public $clientavailability;

    public $bookingModel;

    public $rating;

    public $reviewers;

    public $subClient;

    public $startToken;

    public $retalItems;
	
	public $about;
	
	public $discount;





     public function getListOfRentalItemsByCategory($todate,$fromdate,$categoryid,$city)

    {

        $sql = "select * from clientprofile cp 

left outer join clientcategoryconnect ccc on ccc.clientcategoryconnectid = cp.clientcategoryconnectid 

left outer join citystate cs on cs.citystateid = cp.citystateid 

left outer join rentalclientlink rcl on rcl.cmobileno = cp.cmobileno 

left outer join rentalitems ri on ri.rentalitemsid = rcl.rentalitemsid 

where cs.city=? and ri.categoryclientconnectid=? and 

rcl.rentalclientlink not in ( 

select DISTINCT rccl.rentalclientlinkid from rentalclientcustomerlink rccl 

left outer join rentalclientlink rcll on rcll.rentalclientlink=rccl.rentalclientlinkid 

left outer join rentalitems ri on ri.rentalitemsid=rcll.rentalitemsid 

where ri.categoryclientconnectid=? and 

((rccl.bfrom BETWEEN ? and ?) OR (rccl.bto BETWEEN ? and ?)))";



        $query = $this->db->query($sql, array($city,$categoryid,$categoryid,$fromdate,$todate,$fromdate,$todate));

        $client = array();

        $i=0;

        if ($query->num_rows() > 0) {

            foreach ($query->result() as $row) {

                $client[$i] = new ClientModel(); 

                $client[$i]->addr1 = $row->addr1;

                        $client[$i]->addr2 = $row->addr2;

                        

                    

                       // $client[$i]->categoryModel

                       // $client[$i]->citystateModel

                        $client[$i]->cmobileno = $row->cmobileno;

                        $client[$i]->emailid = $row->emailid;                       

                        $client[$i]->fullname = $row->fullname;

                        $client[$i]->client = $row->client;

                        $client[$i]->lat = $row->lat;

                        $client[$i]->lon = $row->lon;

                        $client[$i]->phoneno = $row->phoneno;

                        

                        $rentalItem = new RentalItemModel();

                        $rentalItem->item = $row->item;

                                $rentalItem->price = $row->price;

                                $rentalItem->regno = $row->regno;

                                $rentalItem->imageurl = $row->imageurl; 

                                //$rentalItem->quantity

                                $rentalItem->rentalclientlink=$row->rentalclientlink;

                                $rentalItem->rentalitemsid = $row->rentalitemsid;

                                

                        

                        $client[$i]->retalItems = $rentalItem;

                        $i++;

            }

        }

        return $client;

    }



    public function getAll($citystateid) {

        $sql = "select * from clientprofile cp

                left outer join clientsublink csl on csl.cmobileno = cp.cmobileno               

                left outer join subclientprofile scp on scp.scmobileno = csl.scmobileno                

                left outer join citystate cs on cs.citystateid=cp.citystateid

                left outer join login l on cp.cmobileno=l.mobileno

		left outer join clientcategoryconnect ccc on ccc.clientcategoryconnectid=scp.clientcategoryconnectidsc

	        left outer join clientcategory cc on cc.clientcatid=ccc.clientcatid

                left outer join clientsubcategory csc on csc.clientsubcatid = ccc.clientsubcatid                

                where cs.city=? and cp.clientcategoryconnectid NOT IN (16,17,18)

                order by cp.cmobileno,cp.clientcategoryconnectid";



        $query = $this->db->query($sql, array($citystateid));



        $this->load->model('ClientModel');

        $this->load->model('SubClientModel');

        $categoryList = array();

        $doctorList = array();

        $salonList = array();

        $rentList = array();

        $essentials = array();



        $client = array();

        $subClient = array();

        $i = -1;

        $z = 0;

        $s = -1;

        $cl = 0;

        $rowsCount = 0;

        $clientt = array();



        $rentalCategoryList = array();





        if ($query->num_rows() > 0) {

            foreach ($query->result() as $row) {



                if ($i != -1 && $client[$i] != null && $client[$i]->cmobileno == $row->cmobileno && ($row->clientcatid == 1 || $row->clientcatid == 2 )) {

                    

                    

                        

                    $subClient[$z] = new SubClientModel();

                    $subClient[$z]->addr1 = $row->addr1sc;

                    $subClient[$z]->addr2 = $row->addr2sc;
                    $subClient[$z]->notes = $row->notes;

                    $subClient[$z]->alternatestatus = $row->alternatestatussc;

                    //  $subClient[$z]->bookingModel

                    $subClient[$z]->bookinginterval = $row->bookingintervalsc;

                    $subClient[$z]->bookingnos = $row->bookingnossc;







                    $this->load->model('CategoryModel');

                    $categorymodel = new CategoryModel();

                    $categorymodel->categoryid = $row->clientcategoryconnectidsc;

                    $categorymodel->category = $row->category;
				

                    $categorymodel->subcategory = $row->subcategory;

                    $subClient[$z]->categoryModel = $categorymodel;







                    //$subClient[$z]->clientavailability

                    $subClient[$z]->closetime = $row->closetimesc;

                    $subClient[$z]->emailid = $row->emailidsc;

                    $subClient[$z]->fullname = $row->fullnamesc;

                    $subClient[$z]->lat = $row->latsc;

                    $subClient[$z]->lon = $row->lonsc;

                    $subClient[$z]->opentime = $row->opentimesc;

                    $subClient[$z]->phoneno = $row->phonenosc;

                    $subClient[$z]->rating = $row->ratingsc;

                    $subClient[$z]->reviewers = $row->reviewerssc;

                    $subClient[$z]->subclientmobileno = $row->scmobileno;

                    $subClient[$z]->website = $row->websitesc;

                    $z++;

                } else if ($row->clientcatid == 1 || $row->clientcatid == 2) {

                    if ($i != -1) {

                        $client[$i]->subClient = $subClient;

                      





                if ($client[$i]->categoryModel->category == 'Doctor Clinic') {

                    array_push($doctorList, $client[$i]);

                } else if ($client[$i]->categoryModel->category == 'Salon') {

                    array_push($salonList, $client[$i]);

                }

                    }

                    $i++;

                    $z = 0;

                    unset($subClient);

                    $client[$i] = new ClientModel();

                   

                    $client[$i]->cmobileno = $row->cmobileno;

                    $client[$i]->addr1 = $row->addr1;

                    $client[$i]->addr2 = $row->addr2;

                    $client[$i]->alternatestatus = $row->alternatestatus;

                    $client[$i]->bookinginterval = $row->bookinginterval;

                    $client[$i]->bookingnos = $row->bookingnos;




				$sqlll = "select * from clientprofile cp
left outer join clientcategoryconnect ccc on ccc.clientcategoryconnectid = cp.clientcategoryconnectid
left outer join clientsubcategory csc on csc.clientsubcatid = ccc.clientsubcatid
left outer join clientcategory c on c.clientcatid = ccc.clientcatid
where cp.cmobileno = ?";


        $queryy = $this->db->query($sqlll, array($client[$i]->cmobileno));



        if ($queryy->num_rows() > 0) {

            foreach ($queryy->result() as $roww) {
				$this->load->model('CategoryModel');

                    $categorymodel = new CategoryModel();

                    $categorymodel->categoryid = $roww->clientcategoryconnectid;

                    $categorymodel->category = $roww->category;

                    $categorymodel->subcategory = $roww->subcategory;

                    $client[$i]->categoryModel = $categorymodel;
				
			}
			
		}


                    



                    /*

                      $this->load->model('BookingModel');

                      $bookingmodel = new BookingModel();

                      $bookingmodel->applicationdate = $row->applicationdate;

                      $bookingmodel->bookingdate=$row->bookingdate;

                      $bookingmodel->bookingid=$row->bookingid;

                      $bookingmodel->bookingno=$row->bookingno;

                      $bookingmodel->bookingtime=$row->bookingtime;

                      //$bookingmodel->membertreeModel

                      //$bookingmodel->clientModel

                      $bookingmodel->mmobileno = $row->mmobileno;

                      $bookingmodel->note=$row->note;

                     */



                    $cmobileno = $row->mobileno;

                    $this->load->model('ClientAvailabilityModel');

                    $clientAvailabilityModel = array();

                    $sqlca = "select * from clientprofile cp

                left outer join clientavailability ca on cp.cmobileno=ca.scmobileno                                                    

                where cp.citystateid=? && cp.cmobileno=?";



                    $j = 0;

                    $queryca = $this->db->query($sqlca, array($citystateid, $cmobileno));

                    if ($queryca->num_rows() > 0) {

                        foreach ($queryca->result() as $rowca) {

                            $clientAvailabilityModel[$j] = new ClientAvailabilityModel();

                            $clientAvailabilityModel[$j]->clientavailabilityid = $rowca->clientavailabilityid;

                            $clientAvailabilityModel[$j]->cmobileno = $rowca->cmobileno;

                            $clientAvailabilityModel[$j]->date = $rowca->date;

                            $clientAvailabilityModel[$j]->status = $rowca->status;

                            $j++;

                        }

                    }



                    $client[$i]->clientavailability = $clientAvailabilityModel;





                    $this->load->model('ClientAvailabilityModel');

                    $bookingModel = array();

                    $sqlca = "select * from clientprofile cp

                left outer join booking b on cp.cmobileno=b.cmobileno                                                            

                where cp.citystateid=? && cp.cmobileno=?";



                    $k = 0;

                    $queryca = $this->db->query($sqlca, array($citystateid, $cmobileno));

                    if ($queryca->num_rows() > 0) {

                        foreach ($queryca->result() as $rowca) {

                            $bookingModel[$k] = new BookingModel();

                            $bookingModel[$k]->applicationdate = $rowca->applicationdate;

                            $bookingModel[$k]->bookingdate = $rowca->bookingdate;

                            $bookingModel[$k]->bookingid = $rowca->bookingid;

                            $bookingModel[$k]->bookingno = $rowca->bookingno;

                            $bookingModel[$k]->bookingtime = $rowca->bookingtime;

                            $bookingModel[$k]->mmobileno = $rowca->mmobileno;

                            $bookingModel[$k]->note = $rowca->note;

                            $k++;

                            //$bookingModel[$k]->clientModel

                            //$bookingModel[$k]->membertreeModel

                        }

                    }



                    $client[$i]->bookingModel = $bookingModel;







                    $this->load->model('CityStateModel');

                    $citystatemodel = new CityStateModel();

                    $citystatemodel->city = $row->city;

                    $citystatemodel->pincode = $row->citystateid;

                    $citystatemodel->state = $row->state;

                    $client[$i]->citystateModel = $citystatemodel;





                    $client[$i]->client = $row->client;

                    $client[$i]->closetime = $row->closetime;

                    $client[$i]->emailid = $row->emailid;

                    $client[$i]->fullname = $row->fullname;

                    $client[$i]->lat = $row->lat;

                    $client[$i]->lon = $row->lon;

                    $client[$i]->rating = $row->rating;

                    $client[$i]->reviewers = $row->reviewers;





                    $this->load->model('LoginModel');

                    $loginmodel = new LoginModel();

                    $loginmodel->active = $row->active;

                    $loginmodel->attempt = $row->attempt;

                    $loginmodel->otp = $row->otp;

                    $loginmodel->password = null;

                    $loginmodel->type = $row->type;

                    $loginmodel->username = $row->mobileno;

                    $client[$i]->loginModel = $loginmodel;





                    $client[$i]->opentime = $row->opentime;

                    $client[$i]->phoneno = $row->phoneno;

                    $client[$i]->website = $row->website;





                    if ($row->scmobileno != NULL) {

                       

                        

                        $subClient = array();

                        $subClient[$z] = new SubClientModel();

                        $subClient[$z]->addr1 = $row->addr1sc;

                        $subClient[$z]->addr2 = $row->addr2sc;
                        $subClient[$z]->notes = $row->notes;

                        $subClient[$z]->alternatestatus = $row->alternatestatussc;

                        //  $subClient[$z]->bookingModel

                        $subClient[$z]->bookinginterval = $row->bookingintervalsc;

                        $subClient[$z]->bookingnos = $row->bookingnossc;

                        $this->load->model('CategoryModel');

                        $categorymodel = new CategoryModel();

                        $categorymodel->categoryid = $row->clientcategoryconnectidsc;

                        $categorymodel->category = $row->category;

                        $categorymodel->subcategory = $row->subcategory;

                        $subClient[$z]->categoryModel = $categorymodel;

                        //$subClient[$z]->clientavailability

                        $subClient[$z]->closetime = $row->closetimesc;

                        $subClient[$z]->emailid = $row->emailidsc;

                        $subClient[$z]->fullname = $row->fullnamesc;

                        $subClient[$z]->lat = $row->latsc;

                        $subClient[$z]->lon = $row->lonsc;

                        $subClient[$z]->opentime = $row->opentimesc;

                        $subClient[$z]->phoneno = $row->phonenosc;

                        $subClient[$z]->rating = $row->ratingsc;

                        $subClient[$z]->reviewers = $row->reviewerssc;

                        $subClient[$z]->subclientmobileno = $row->scmobileno;

                        $subClient[$z]->website = $row->websitesc;

                        $z++;

                    }

                }

            }

        }

        $client[$i]->subClient = $subClient;

       

                 





                if ($client[$i]->categoryModel->category == 'Doctor Clinic') {

                    array_push($doctorList, $client[$i]);

                } else if ($client[$i]->categoryModel->category == 'Salon') {

                    array_push($salonList, $client[$i]);

                }











        //RENTAL Working...

        $sql = "select * from clientprofile cp

left outer join rentalclientcategorylink rccl on rccl.cmobileno = cp.cmobileno

left outer join clientcategoryconnect ccc on ccc.clientcategoryconnectid = rccl.categoryclientconnectidrccl

left outer join clientcategory cc on cc.clientcatid=ccc.clientcatid

left outer join clientsubcategory csc on csc.clientsubcatid = ccc.clientsubcatid     

left outer join citystate cs on cs.citystateid=cp.citystateid

left outer join login l on cp.cmobileno=l.mobileno

where cs.city=? and cc.clientcatid=3

order by rccl.categoryclientconnectidrccl";



        $query = $this->db->query($sql, array($citystateid));

        $totalrecords = $query->num_rows();

        if ($query->num_rows() > 0) {

            foreach ($query->result() as $row) {

                $rowsCount++;

                if ($s == -1 || $rentalCategoryList[$cl]->categoryid == $row->clientcategoryconnectid) {

                    $s++;

                    //   echo nl2br("\ns" . $s . "i:" . $i);

                    //  echo nl2br("\ncccid" . $row->clientcategoryconnectid);

                    // echo nl2br("\SubcategoryCurrentDb" . $row->clientcategoryconnectid);

                    //   echo nl2br("\ncl" . $cl);

                    if ($s == 0) {

                        $rentalCategoryList[$cl] = new CategoryModel();

                        $rentalCategoryList[$cl]->category = $row->category;

                        $rentalCategoryList[$cl]->categoryid = $row->clientcategoryconnectid;

                        $rentalCategoryList[$cl]->subcategory = $row->subcategory;

                    }









                    //  echo nl2br("\Subcategoryid" . $rentalCategoryList[$cl]->categoryid);

                    //  $clientt = array();

                    $clientt[$s] = new ClientModel();

                    $cmobileno = $row->cmobileno;

                    $clientt[$s]->cmobileno = $row->cmobileno;

                    $clientt[$s]->addr1 = $row->addr1;

                    $clientt[$s]->addr2 = $row->addr2;

                    $clientt[$s]->alternatestatus = $row->alternatestatus;

                    $clientt[$s]->bookinginterval = $row->bookinginterval;

                    $clientt[$s]->bookingnos = $row->bookingnos;



                    $this->load->model('CategoryModel');

                    $categorymodel = new CategoryModel();

                    $categorymodel->categoryid = $row->clientcategoryconnectid;

                    $categorymodel->category = $row->category;

                    $categorymodel->subcategory = $row->subcategory;

                    $clientt[$s]->categoryModel = $categorymodel;



                    $this->load->model('CityStateModel');

                    $citystatemodel = new CityStateModel();

                    $citystatemodel->city = $row->city;

                    $citystatemodel->pincode = $row->citystateid;

                    $citystatemodel->state = $row->state;

                    $clientt[$s]->citystateModel = $citystatemodel;





                    $clientt[$s]->client = $row->client;

                    //    echo nl2br("\nClient" . $row->client);

                    $clientt[$s]->closetime = $row->closetime;

                    $clientt[$s]->emailid = $row->emailid;

                    $clientt[$s]->fullname = $row->fullname;

                    $clientt[$s]->lat = $row->lat;

                    $clientt[$s]->lon = $row->lon;

                    $clientt[$s]->rating = $row->rating;

                    $clientt[$s]->reviewers = $row->reviewers;





                    $this->load->model('LoginModel');

                    $loginmodel = new LoginModel();

                    $loginmodel->active = $row->active;

                    $loginmodel->attempt = $row->attempt;

                    $loginmodel->otp = $row->otp;

                    $loginmodel->password = null;

                    $loginmodel->type = $row->type;

                    $loginmodel->username = $row->mobileno;

                    $clientt[$s]->loginModel = $loginmodel;





                    $clientt[$s]->opentime = $row->opentime;

                    $clientt[$s]->phoneno = $row->phoneno;

                    $clientt[$s]->website = $row->website;

                    if ($rowsCount == ($totalrecords)) {



                        $rentalCategoryList[$cl]->clientlist = $clientt;

                        //        echo nl2br("\nThE ENDDDD");

                    }

                } else {

                    $rentalCategoryList[$cl]->clientlist = $clientt;

                    $cl++;

                    $s = 0;

                    //     echo nl2br("\nCompleted with one subcaegoty");

                    /*  for ($cc = 0; $cc < sizeof($clientt); $cc++) {

                      echo nl2br("\n" . $clientt[$cc]->client);

                      } */

                    //  echo nl2br("\ns" . $s . "i:" . $i);

                    //   echo nl2br("\ncl" . $cl);

                    //   echo nl2br("\ncccid" . $row->clientcategoryconnectid);



                    $rentalCategoryList[$cl] = new CategoryModel();

                    $rentalCategoryList[$cl]->category = $row->category;

                    $rentalCategoryList[$cl]->categoryid = $row->clientcategoryconnectid;

                    $rentalCategoryList[$cl]->subcategory = $row->subcategory;

                    //   echo nl2br("\nSubcategoryCurrentDb" . $row->clientcategoryconnectid);

                    //   echo nl2br("\nSubcategoryid" . $rentalCategoryList[$cl]->categoryid);

                    $clientt = array();

                    $clientt[$s] = new ClientModel();

                    $clientt[$s]->cmobileno = $row->cmobileno;

                    $clientt[$s]->addr1 = $row->addr1;

                    $clientt[$s]->addr2 = $row->addr2;

                    $clientt[$s]->alternatestatus = $row->alternatestatus;

                    $clientt[$s]->bookinginterval = $row->bookinginterval;

                    $clientt[$s]->bookingnos = $row->bookingnos;



                    $this->load->model('CategoryModel');

                    $categorymodel = new CategoryModel();

                    $categorymodel->categoryid = $row->clientcategoryconnectid;

                    $categorymodel->category = $row->category;

                    $categorymodel->subcategory = $row->subcategory;

                    $clientt[$s]->categoryModel = $categorymodel;



                    $this->load->model('CityStateModel');

                    $citystatemodel = new CityStateModel();

                    $citystatemodel->city = $row->city;

                    $citystatemodel->pincode = $row->citystateid;

                    $citystatemodel->state = $row->state;

                    $clientt[$s]->citystateModel = $citystatemodel;





                    $clientt[$s]->client = $row->client;

                    //   echo nl2br("\nClient" . $row->client);

                    $clientt[$s]->closetime = $row->closetime;

                    $clientt[$s]->emailid = $row->emailid;

                    $clientt[$s]->fullname = $row->fullname;

                    $clientt[$s]->lat = $row->lat;

                    $clientt[$s]->lon = $row->lon;

                    $clientt[$s]->rating = $row->rating;

                    $clientt[$s]->reviewers = $row->reviewers;





                    $this->load->model('LoginModel');

                    $loginmodel = new LoginModel();

                    $loginmodel->active = $row->active;

                    $loginmodel->attempt = $row->attempt;

                    $loginmodel->otp = $row->otp;

                    $loginmodel->password = null;

                    $loginmodel->type = $row->type;

                    $loginmodel->username = $row->mobileno;

                    $clientt[$s]->loginModel = $loginmodel;





                    $clientt[$s]->opentime = $row->opentime;

                    $clientt[$s]->phoneno = $row->phoneno;

                    $clientt[$s]->website = $row->website;



                    if ($rowsCount == ($totalrecords)) {

                        //      echo "THE END";

                        $rentalCategoryList[$cl]->clientlist = $clientt;

                    }

                }

            }

        }


  //Salon Working....
        $sql = "select * from clientprofile cp
left outer join saloncategorylink scl on scl.cmobileno = cp.cmobileno
left outer join clientcategoryconnect ccc on ccc.clientcategoryconnectid = cp.clientcategoryconnectid
left outer join salonsubclientlink sscl on sscl.saloncategorylinkid = scl.saloncategorylinkid
left outer join saloncategory sc on sc.saloncategoryid = scl.saloncategoryid
left outer join citystate cs on cs.citystateid=cp.citystateid
left outer join subclientprofile scp on scp.scmobileno = sscl.scmobileno
where ccc.clientcatid = ? and cs.city=?
order by cp.cmobileno, scl.saloncategoryid";



        $query = $this->db->query($sql, array(2, $citystateid));

        $i = -1;
        $z = 0;
        $c = 0;
        unset($client);

        $category = array();


        if ($query->num_rows() > 0) {

            foreach ($query->result() as $row) {



                if ($i != -1 && $client[$i] != null && $client[$i]->cmobileno == $row->cmobileno) {

                    //Code for category
                    if ($category[$c]->categoryid != $row->saloncategoryid) {
                        $c++;
                        $category[$c] = new CategoryModel();
                        $category[$c]->categoryid = $row->saloncategoryid;
                        $category[$c]->category = $row->saloncategory;
                        $category[$c]->enable = false;
                    }

                    $subClient[$z] = new SubClientModel();
                    $subClient[$z]->fullname = $row->fullnamesc;
                    $categorymodel = new CategoryModel();
                        $categorymodel->category = $row->saloncategory;
                        $categorymodel->categoryid = $row->saloncategoryid;
                        $categorymodel->updatedate = $row->duration;
                        $subClient[$z]->categoryModel = $categorymodel;
                    $z++;
                } else {

                    if ($i == -1) {
                        $z = 0;
                        $c = 0;
                        unset($subClient);
                        $i++;
                        $client[$i] = new ClientModel();
                        $client[$i]->cmobileno = $row->cmobileno;
                        $client[$i]->fullname = $row->fullname;
                        $client[$i]->addr1 = $row->addr1;
                        $client[$i]->addr2 = $row->addr2;
                        $client[$i]->emailid = $row->emailid;
                        $client[$i]->client = $row->client;
                        $client[$i]->lat = $row->lat;
                        $client[$i]->lon = $row->lon;
                        $client[$i]->phoneno = $row->phoneno;
                        $client[$i]->reviewers = $row->reviewers;
                        $client[$i]->rating = $row->rating;



                        //Code for category...
                        $category[$c] = new CategoryModel();
                        $category[$c]->categoryid = $row->saloncategoryid;
                        $category[$c]->category = $row->saloncategory;
                        $category[$c]->enable = false;


                        $subClient[$z] = new SubClientModel();
                        $subClient[$z]->fullname = $row->fullnamesc;
                        $subClient[$z]->salonsubclientlinkid = $row->salonsubclientlinkid;
                        $categorymodel = new CategoryModel();
                        $categorymodel->category = $row->saloncategory;
                        $categorymodel->categoryid = $row->saloncategoryid;
                        $categorymodel->updatedate = $row->duration;
                        $subClient[$z]->categoryModel = $categorymodel;
                        $z++;
                    } else {
                        $client[$i]->subClient = $subClient;
                        $client[$i]->categoryModel = $category;
                        $i++;
                        $client[$i] = new ClientModel();
                        $client[$i]->cmobileno = $row->cmobileno;
                        $client[$i]->fullname = $row->fullname;
                        $client[$i]->addr1 = $row->addr1;
                        $client[$i]->addr2 = $row->addr2;
                        $client[$i]->emailid = $row->emailid;
                        $client[$i]->client = $row->client;
                        $client[$i]->lat = $row->lat;
                        $client[$i]->lon = $row->lon;
                        $client[$i]->phoneno = $row->phoneno;
                        $client[$i]->reviewers = $row->reviewers;
                        $client[$i]->rating = $row->rating;

                        $z = 0;

                        //Code for category..
                        unset($category);
                        $c = 0;
                        $category[$c] = new CategoryModel();
                        $category[$c]->categoryid = $row->saloncategoryid;
                        $category[$c]->category = $row->saloncategory;
                        $category[$c]->enable = false;

                        unset($subClient);
                        $subClient[$z] = new SubClientModel();
                        $subClient[$z]->fullname = $row->fullnamesc;
                        $subClient[$z]->salonsubclientlinkid = $row->salonsubclientlinkid;
                        $categorymodel = new CategoryModel();
                        $categorymodel->category = $row->saloncategory;
                        $categorymodel->categoryid = $row->saloncategoryid;
                        $categorymodel->updatedate = $row->duration;
                        $subClient[$z]->categoryModel = $categorymodel;
                        $z++;
                    }
                }
            }

            if ($i != -1 && $client[$i] != null && $client[$i]->cmobileno == $row->cmobileno) {
                $client[$i]->subClient = $subClient;
                $client[$i]->categoryModel = $category;
            }
        }
		
		
		//Essentials Working
		
		 $sql = "select * from clientprofile cp
left outer join clientcategoryconnect ccc on ccc.clientcategoryconnectid = cp.clientcategoryconnectid
left outer join citystate cs on cs.citystateid=cp.citystateid
left outer join clientcategory cc on ccc.clientcatid = cc.clientcatid
left outer join clientsubcategory csc on csc.clientsubcatid = ccc.clientsubcatid     
where cc.clientcatid = ? and cs.city= ?
order by cp.client";


		
        $query = $this->db->query($sql, array(4, $citystateid));

        $i = 0;
        $z = 0;
        $c = 0;
        unset($essentials);

        $category = array();


        if ($query->num_rows() > 0) {

            foreach ($query->result() as $row) {
			
				 $essentials[$i] = new ClientModel();
                 $essentials[$i]->cmobileno = $row->cmobileno;
                 $essentials[$i]->fullname = $row->fullname;
                 $essentials[$i]->addr1 = $row->addr1;
                 $essentials[$i]->addr2 = $row->addr2;
                 $essentials[$i]->emailid = $row->emailid;
                 $essentials[$i]->client = $row->client;
                 $essentials[$i]->lat = $row->lat;
                 $essentials[$i]->lon = $row->lon;
                 $essentials[$i]->phoneno = $row->phoneno;
                 $essentials[$i]->reviewers = $row->reviewers;
                 $essentials[$i]->rating = $row->rating;
				 $essentials[$i]->about = $row->about;
				 $essentials[$i]->discount = $row->discount;
				 $essentials[$i]->opentime = $row->opentime;
				 $essentials[$i]->closetime = $row->closetime;
				 $essentials[$i]->website = $row->website;
				 
				 $categoryModel = new CategoryModel();
				 $categoryModel->categoryid = $row->clientcategoryconnectid;
				 $categoryModel->category = $row->category;    
				 $categoryModel->subcategory = $row->subcategory;				
				 $essentials[$i]->categoryModel = $categoryModel;
				 $i++;
			}
			
		}
		


        //Make sure this list matches the category list in database..

        array_push($categoryList, $doctorList);

        array_push($categoryList, $client);

        array_push($categoryList, $rentalCategoryList);

        array_push($categoryList, $essentials);















        return $categoryList;

    }



    public

            function getAllClientDetails($username, $password, $type) {



        $subcount = 0;

        if ($type == 'C') {

            $sql = "select * from clientprofile cp

                left outer join login l on cp.cmobileno=l.mobileno

                left outer join citystate cs on cs.citystateid=cp.citystateid

                left outer join livestatus ls on ls.cmobileno=cp.cmobileno           

                left outer join clientcategoryconnect ccc on ccc.clientcategoryconnectid=cp.clientcategoryconnectid

                left outer join clientcategory cc on cc.clientcatid=ccc.clientcatid

                left outer join clientsubcategory csc on csc.clientsubcatid = ccc.clientsubcatid   

                left outer join clientsublink csl on csl.cmobileno = cp.cmobileno               

                left outer join subclientprofile scp on scp.scmobileno = csl.scmobileno

                left outer join citystate css on css.citystateid = scp.citystateidsc

                where cp.cmobileno=? and l.mobileno=? and l.password=? and type='C' and active='Y'";

            $query = $this->db->query($sql, array($username, $username, $password));



            $this->load->model('ClientModel');

            $this->load->model('SubClientModel');

            $client = new ClientModel();

            $subClient = array();

            $i = 0;

            if ($query->num_rows() > 0) {

                foreach ($query->result() as $row) {

                    if ($i == 0) {

                        $client->addr1 = $row->addr1;

                        $client->addr2 = $row->addr2;

                        // $client->alternatestatus = $row->alternatestatus;                    

                        //$client->bookingModel 

                        //$client->bookinginterval

                        //$client->bookingnos

                        //$client->categoryModel = 

                        //$client->citystateModel

                        $client->client = $row->client;

                        //$client->clientavailability

                        $client->closetime = $row->closetime;

                        $client->cmobileno = $row->cmobileno;

                        $client->emailid = $row->emailid;

                        $client->fullname = $row->fullname;

                        $client->lat = $row->lat;

                        $client->lon = $row->lon;



                        $loginModel = new LoginModel();

                        $loginModel->username = $row->mobileno;

                        $loginModel->password = $row->password;

                        $loginModel->active = $row->active;

                        $loginModel->attempt = $row->attempt;

                        $loginModel->otp = $row->otp;

                        $loginModel->type = $row->type;

                        $client->loginModel = $loginModel;



                        $client->opentime = $row->opentime;

                        $client->phoneno = $row->phoneno;

                        $client->rating = $row->rating;

                        $client->reviewers = $row->reviewers;

                        $client->website = $row->website;



                        $subClient[$subcount] = new SubClientModel();

                        $subClient[$subcount]->addr1 = $row->addr1sc;

                        $subClient[$subcount]->addr2 = $row->addr2sc;
                        $subClient[$subcount]->notes = $row->notes;

                        $subClient[$subcount]->alternatestatus = $row->alternatestatussc;

                        $subClient[$subcount]->bookinginterval = $row->bookingintervalsc;

                        $subClient[$subcount]->bookingnos = $row->bookingnossc;

                        $subClient[$subcount]->alternatestatus = $row->alternatestatussc;
						$subClient[$subcount]->breaktime = $row->breaktime;
						$subClient[$subcount]->breakintervaltime = $row->breakintervaltime;



                        $this->load->model('CategoryModel');

                        $categorymodel = new CategoryModel();

                        $categorymodel->categoryid = $row->clientcategoryconnectidsc;

                        $categorymodel->category = $row->category;

                        $categorymodel->subcategory = $row->subcategory;

                        $subClient[$subcount]->categoryModel = $categorymodel;





                        //$subClient[$subcount]->clientavailability

                        $subClient[$subcount]->closetime = $row->closetimesc;

                        $subClient[$subcount]->emailid = $row->emailidsc;

                        $subClient[$subcount]->fullname = $row->fullnamesc;

                        $subClient[$subcount]->lat = $row->latsc;

                        $subClient[$subcount]->lon = $row->lonsc;

                        $subClient[$subcount]->opentime = $row->opentimesc;

                        $subClient[$subcount]->phoneno = $row->phonenosc;

                        $subClient[$subcount]->rating = $row->ratingsc;

                        $subClient[$subcount]->reviewers = $row->reviewerssc;

                        $subClient[$subcount]->subclientmobileno = $row->scmobileno;

                        $subClient[$subcount]->website = $row->websitesc;





                        $bookingModel = array();



                        $sql = "select * from booking b 

left outer join clientsublink csl on b.cmobileno=csl.cmobileno and b.scmobileno = csl.scmobileno

left outer join memberprofile mp on b.mmobileno = mp.mmobileno

left outer join membertree mt on mt.membertreeid = b.membertreeid

left outer join citystate cs on cs.citystateid = mp.citystateidm

where b.cmobileno=? and b.scmobileno = ? and status='B'";

                        $query = $this->db->query($sql, array($username, $row->scmobileno));

                        $bookingCount = 0;

                        if ($query->num_rows() > 0) {

                            foreach ($query->result() as $row1) {



                                // echo $row->bookingid;

                                $bookingModel[$bookingCount] = new BookingModel();

                                $bookingModel[$bookingCount]->applicationdate = $row1->applicationdate;

                                $bookingModel[$bookingCount]->bookingdate = $row1->bookingdate;

                                //$bookingModel[$bookingCount]->bookingdatedisplay 

                                $bookingModel[$bookingCount]->bookingid = $row1->bookingid;

                                $bookingModel[$bookingCount]->bookingno = $row1->bookingno;

                                $bookingModel[$bookingCount]->bookingtime = $row1->bookingtime;

                                //$bookingModel[$bookingCount]->cmobileno

                                $memberModel = new MemberModel();

                                $memberModel->addr1 = $row1->addr1;

                                $memberModel->addr2 = $row1->addr2;

                                $memberModel->age = $row1->age;



                                $this->load->model('CityStateModel');

                                $citystatemodel = new CityStateModel();

                                $citystatemodel->city = $row1->city;

                                $citystatemodel->pincode = $row1->citystateid;

                                $citystatemodel->state = $row1->state;

                                $memberModel->citystatemodel = $citystatemodel;



                                $memberModel->emailid = $row1->emailid;

                                $memberModel->fullname = $row1->fullname;

                                $memberModel->lat = $row1->lat;

                                $memberModel->lon = $row1->lon;



                                $membertreemodel = new MemberTreeModel();

                                $membertreemodel->age = $row1->agemt;

                                $membertreemodel->fullname = $row1->fullnamemt;

                                $membertreemodel->membertreeid = $row1->membertreeid;

                                $memberModel->membertreemodel = $membertreemodel;

                                $memberModel->phoneno = $row1->phoneno;



                                $bookingModel[$bookingCount]->memberModel = $memberModel;

                                //$bookingModel[$bookingCount]->clientModel

                                $bookingModel[$bookingCount]->mmobileno = $row1->mmobileno;

                                $bookingModel[$bookingCount]->note = $row1->note;

                                //$bookingModel[$bookingCount]->token = $row->token;

                                $bookingCount++;

                            }

                        }





                        $subClient[$subcount]->bookingModel = $bookingModel;



                        $this->load->model('CityStateModel');

                        $citystatemodel = new CityStateModel();

                        $citystatemodel->city = $row->city;

                        $citystatemodel->pincode = $row->citystateid;

                        $citystatemodel->state = $row->state;

                        $subClient[$subcount]->citystateModel = $citystatemodel;



                        //$client->subClient



                        $subcount++;

                        $i++;

                    } else {



                        $subClient[$subcount] = new SubClientModel();

                        $subClient[$subcount]->addr1 = $row->addr1sc;

                        $subClient[$subcount]->addr2 = $row->addr2sc;
                        $subClient[$subcount]->notes = $row->notes;

                        $subClient[$subcount]->alternatestatus = $row->alternatestatussc;

                        $subClient[$subcount]->bookinginterval = $row->bookingintervalsc;

                        $subClient[$subcount]->bookingnos = $row->bookingnossc;



                        $this->load->model('CategoryModel');

                        $categorymodel = new CategoryModel();

                        $categorymodel->categoryid = $row->clientcategoryconnectidsc;

                        $categorymodel->category = $row->category;

                        $categorymodel->subcategory = $row->subcategory;

                        $subClient[$subcount]->categoryModel = $categorymodel;





                        //$subClient[$subcount]->clientavailability

                        $subClient[$subcount]->closetime = $row->closetimesc;

                        $subClient[$subcount]->emailid = $row->emailidsc;

                        $subClient[$subcount]->fullname = $row->fullnamesc;

                        $subClient[$subcount]->lat = $row->latsc;

                        $subClient[$subcount]->lon = $row->lonsc;

                        $subClient[$subcount]->opentime = $row->opentimesc;

                        $subClient[$subcount]->phoneno = $row->phonenosc;

                        $subClient[$subcount]->rating = $row->ratingsc;

                        $subClient[$subcount]->reviewers = $row->reviewerssc;

                        $subClient[$subcount]->subclientmobileno = $row->scmobileno;

                        $subClient[$subcount]->website = $row->websitesc;





                        $bookingModel = array();



                        $sql = "select * from booking b 

left outer join clientsublink csl on b.cmobileno=csl.cmobileno and b.scmobileno = csl.scmobileno

left outer join memberprofile mp on b.mmobileno = mp.mmobileno

inner join membertree mt on mt.membertreeid = b.membertreeid

left outer join citystate cs on cs.citystateid = mp.citystateidm

where b.cmobileno=? and b.scmobileno = ?";

                        $query = $this->db->query($sql, array($username, $row->scmobileno));

                        $bookingCount = 0;

                        if ($query->num_rows() > 0) {

                            foreach ($query->result() as $row) {



                                $bookingModel[$bookingCount] = new BookingModel();

                                $bookingModel[$bookingCount]->applicationdate = $row->applicationdate;

                                $bookingModel[$bookingCount]->bookingdate = $row->bookingdate;

                                //$bookingModel[$bookingCount]->bookingdatedisplay 

                                $bookingModel[$bookingCount]->bookingid = $row->bookingid;

                                $bookingModel[$bookingCount]->bookingno = $row->bookingno;

                                $bookingModel[$bookingCount]->bookingtime = $row->bookingtime;

                                //$bookingModel[$bookingCount]->cmobileno

                                $memberModel = new MemberModel();

                                $memberModel->addr1 = $row->addr1;

                                $memberModel->addr2 = $row->addr2;

                                $memberModel->age = $row->age;



                                $this->load->model('CityStateModel');

                                $citystatemodel = new CityStateModel();

                                $citystatemodel->city = $row->city;

                                $citystatemodel->pincode = $row->citystateid;

                                $citystatemodel->state = $row->state;

                                $memberModel->citystatemodel = $citystatemodel;



                                $memberModel->emailid = $row->emailid;

                                $memberModel->fullname = $row->fullname;

                                $memberModel->lat = $row->lat;

                                $memberModel->lon = $row->lon;



                                $membertreemodel = new MemberTreeModel();

                                $membertreemodel->age = $row->agemt;

                                $membertreemodel->fullname = $row->fullnamemt;

                                $membertreemodel->membertreeid = $row->membertreeid;

                                $memberModel->membertreemodel = $membertreemodel;

                                $memberModel->phoneno = $row->phoneno;



                                $bookingModel[$bookingCount]->memberModel = $memberModel;

                                //$bookingModel[$bookingCount]->clientModel

                                $bookingModel[$bookingCount]->mmobileno = $row->mmobileno;

                                $bookingModel[$bookingCount]->note = $row->note;

                                //$bookingModel[$bookingCount]->token = $row->token;

                            }

                        }





                        $subClient[$subcount]->bookingModel = $bookingModel;



                        $this->load->model('CityStateModel');

                        $citystatemodel = new CityStateModel();

                        $citystatemodel->city = $row->city;

                        $citystatemodel->pincode = $row->citystateid;

                        $citystatemodel->state = $row->state;

                        $subClient[$subcount]->citystateModel = $citystatemodel;

                    }



                    $client->subClient = $subClient;

                }

            }



            return $client;

        } else if ($type == 'S') {

            //This is only for Sub Client.....

//removed left outer join clientsublink csl on csl.scmobileno = scp.scmobileno

            $sql2 = "select * from subclientprofile scp

                left outer join login l on scp.scmobileno=l.mobileno

                left outer join citystate cs on cs.citystateid=scp.citystateidsc

                left outer join livestatus ls on ls.cmobileno=scp.scmobileno           

                left outer join clientsublink csl on csl.scmobileno = scp.scmobileno

                left outer join clientcategoryconnect ccc on ccc.clientcategoryconnectid=scp.clientcategoryconnectidsc

                left outer join clientcategory cc on cc.clientcatid=ccc.clientcatid

                left outer join clientsubcategory csc on csc.clientsubcatid = ccc.clientsubcatid                                  

                where scp.scmobileno=? and l.mobileno=? and l.password=? and type='C' and active='Y'";



            $query2 = $this->db->query($sql2, array($username, $username, $password));



            $this->load->model('SubClientModel');

            $subClient = new SubClientModel();

            $i = 1;

            if ($query2->num_rows() > 0) {

                foreach ($query2->result() as $row1) {
                    if ($i == 1) {

                        $i = 0;

                        $subClient->addr1 = $row1->addr1sc;

                        $subClient->addr2 = $row1->addr2sc;
                        $subClient->notes = $row1->notes;

                        $subClient->alternatestatus = $row1->alternatestatussc;

                        $subClient->startToken = $row1->starttokensc;

                        $subClient->bookingnos = $row1->bookingnossc;

                        //clientAvailability

                        $sql = "select * from clientavailability ca
							left outer join clientsublink csl on csl.scmobileno = ca.scmobileno
							and csl.cmobileno=ca.cmobileno
                            where ca.scmobileno =?
							order by ca.date";

                        $query = $this->db->query($sql, array($username));



                        $clientavailability = array();

                        $availcount = 0;
                         if ($query->num_rows() > 0) {

                            foreach ($query->result() as $row) {
                                if ($row->date >= date("Y-m-d")) {
									
                                    $clientavailability[$availcount] = new ClientAvailabilityModel();

                                    $clientavailability[$availcount]->availability = $row->availability;

                                    $clientavailability[$availcount]->clientavailabilityid = $row->clientavailabilityid;

                                    $clientavailability[$availcount]->clientid = $row->cmobileno;

                                    $date = $row->date;

                                    $convert_date = strtotime($date);

                                    $clientavailability[$availcount]->bookingdate = $row->date;

                                    $clientavailability[$availcount]->date = date('j', $convert_date);

                                    $clientavailability[$availcount]->month = date('M', $convert_date);

                                    $clientavailability[$availcount]->day = date('D', $convert_date);

                                    if ($row->total != 0) {

                                        $per = ($row->availability / $row->total) * 100;

                                    } else {

                                        $per = 0;

                                    }

                                    if ($per >= 50) {

                                        $clientavailability[$availcount]->color = "#70b0ef";

                                    } else if ($per < 50 && $per > 0) {

                                        $clientavailability[$availcount]->color = "#efc86e";

                                    } else {

                                        $clientavailability[$availcount]->color = "#db151f";

                                    }



                                    $clientavailability[$availcount]->scmobileno = $row->scmobileno;

                                    $clientavailability[$availcount]->status = $row->status;

                                    $clientavailability[$availcount]->total = $row->total;
									$clientavailability[$availcount]->opentimesc = $row->opentimesc;
									$clientavailability[$availcount]->closetimesc = $row->closetimesc;
									$clientavailability[$availcount]->bookingintervalsc = $row->bookingintervalsc;
									$clientavailability[$availcount]->starttokensc = $row->starttokensc;
									$clientavailability[$availcount]->alternatestatussc = $row->alternatestatussc;
									$clientavailability[$availcount]->breaktime = $row->breaktime;
									$clientavailability[$availcount]->breakintervaltime = $row->breakintervaltime;
									
                                    $availcount++;

                                }

                            }

                        }

                        $subClient->clientavailability = $clientavailability;



                        $this->load->model('CategoryModel');

                        $categorymodel = new CategoryModel();

                        $categorymodel->categoryid = $row1->clientcategoryconnectidsc;

                        $categorymodel->category = $row1->category;

                        $categorymodel->subcategory = $row1->subcategory;

                        $subClient->categoryModel = $categorymodel;

                        $this->load->model('CityStateModel');

                        $citystatemodel = new CityStateModel();

                        $citystatemodel->city = $row1->city;

                        $citystatemodel->pincode = $row1->citystateid;

                        $citystatemodel->state = $row1->state;

                        $subClient->citystateModel = $citystatemodel;

                        ////$subClient->clientavailability

                        //$subClient->closetime = $row->closetime

                        $subClient->emailid = $row1->emailidsc;

                        $subClient->fullname = $row1->fullnamesc;

                        $subClient->lat = $row1->latsc;

                        $subClient->lon = $row1->lonsc;

                        //$subClient->opentime = $row->

                        $subClient->phoneno = $row1->phonenosc;

                        $subClient->rating = $row1->ratingsc;

                        $subClient->reviewers = $row1->reviewerssc;

                        $subClient->subclientmobileno = $username;

                        $subClient->website = $row1->websitesc;

                        $subClient->reservedschedule = $row1->reservedschedule;

                        $subClient->caupdate = $row1->caupdate;





                        $sql = "select * 

                            from subclientprofile scp

                        left outer join clientsublink csl on csl.scmobileno = scp.scmobileno

                        left outer join clientprofile cp on cp.cmobileno = csl.cmobileno

                        where scp.scmobileno=?";

                        $query = $this->db->query($sql, array($username));

                        $scheduleModel = array();
						$s=0;
                        if ($query->num_rows() > 0) {

                            foreach ($query->result() as $row) {



                                $scheduleString = $row->days;



                                for ($i = 0; $i < strlen($scheduleString); $i++) {

                                    $scheduleModel[$s] = new ScheduleModel();

                                    $scheduleModel[$s]->cmobileno = $row->cmobileno;
									$scheduleModel[$s]->day = $scheduleString[$i];
									$scheduleModel[$s]->opentimesc = $row->opentimesc;
									$scheduleModel[$s]->closetimesc = $row->closetimesc;
									$scheduleModel[$s]->bookingnossc = $row->bookingnossc;
									$scheduleModel[$s]->bookingintervalsc = $row->bookingintervalsc;
									$scheduleModel[$s]->starttokensc = $row->starttokensc;
									$scheduleModel[$s]->alternatestatussc = $row->alternatestatussc;
									$scheduleModel[$s]->breaktime = $row->breaktime;
									$scheduleModel[$s]->breakintervaltime = $row->breakintervaltime;

									$scheduleModel[$s]->notes = $row->notes;
									$s++;
									
                                }

                            }

                        }





                        $subClient->scheduleClient = $scheduleModel;



                        $bookings = array();

                        $sql = "select * from booking b 

left outer join clientsublink csl on b.cmobileno=csl.cmobileno and b.scmobileno = csl.scmobileno

left outer join memberprofile mp on b.mmobileno = mp.mmobileno

left outer join membertree mt on mt.membertreeid = b.membertreeid

inner join clientprofile cp on cp.cmobileno = b.cmobileno

left outer join citystate cs on cs.citystateid = mp.citystateidm

where b.scmobileno=? && b.status='B'";

                        $query = $this->db->query($sql, array($username));

                        $bookingCount = 0;

                        if ($query->num_rows() > 0) {

                            foreach ($query->result() as $row) {

                                $bookings[$bookingCount] = new BookingModel();

                                $bookings[$bookingCount]->applicationdate = $row->applicationdate;

                                $bookings[$bookingCount]->bookingdate = $row->bookingdate;

                                //$bookings[$bookingCount]->bookingdatedisplay

                                $bookings[$bookingCount]->bookingid = $row->bookingid;

                                $bookings[$bookingCount]->bookingno = $row->bookingno;

                                $bookings[$bookingCount]->bookingtime = $row->bookingtime;

                                //$bookings[$bookingCount]->clientModel

                                //$bookings[$bookingCount]->cmobileno



                                $memberModel = new MemberModel();

                                $memberModel->addr1 = $row->addr1;

                                $memberModel->addr2 = $row->addr2;

                                $memberModel->age = $row->age;



                                $this->load->model('CityStateModel');

                                $citystatemodel = new CityStateModel();

                                $citystatemodel->city = $row->city;

                                $citystatemodel->pincode = $row->citystateid;

                                $citystatemodel->state = $row->state;

                                $memberModel->citystatemodel = $citystatemodel;



                                $memberModel->emailid = $row->emailid;

                                $memberModel->fullname = $row->fullnamem;

                                $memberModel->lat = $row->lat;

                                $memberModel->lon = $row->lon;



                                $membertreemodel = new MemberTreeModel();

                                $membertreemodel->age = $row->agemt;

                                $membertreemodel->fullname = $row->fullnamemt;

                                $membertreemodel->membertreeid = $row->membertreeid;

                                $memberModel->membertreemodel = $membertreemodel;

                                $memberModel->phoneno = $row->phoneno;



                                $bookings[$bookingCount]->memberModel = $memberModel;

                                $bookings[$bookingCount]->mmobileno = $row->mmobileno;

                                $bookings[$bookingCount]->note = $row->note;

                                //$bookings[$bookingCount]->token

                                $bookingCount++;

                            }

                        }

                        $subClient->bookingModel = $bookings;

                    }

                }

            }



            return $subClient;

        } else if ($type == 'R') {



            $rentalItems = array();



            $sql = "select * from clientprofile cp

left outer join login l on l.mobileno = cp.cmobileno

left outer join citystate cs on cs.citystateid = cp.citystateid

left outer join rentalclientlink rcl on rcl.cmobileno=cp.cmobileno

left outer join rentalitems ri on ri.rentalitemsid = rcl.rentalitemsid

left outer join rentalclientcustomerlink rccl on rccl.rentalclientlinkid = rcl.rentalclientlink

left outer join clientcategoryconnect ccc on ccc.clientcategoryconnectid = ri.categoryclientconnectid

left outer join clientsubcategory csc on csc.clientsubcatid = ccc.clientsubcatid

left outer join memberprofile mp on mp.mmobileno = rccl.mmobileno

where (l.mobileno=? and l.password=? and l.active='Y' and l.type='R') and cp.cmobileno=?

order by csc.clientsubcatid, rcl.rentalclientlink,rccl.bfrom";





            $first = 1;

            $i = 0;

            $j = 0;

            $clientsubcatid = null;

            $regno = null;

            $rentalItems = array();

            $categoryModel = array();

            $rentalbookings = array();

            $cmobileno = $username;

            $query = $this->db->query($sql, array($cmobileno, $password, $cmobileno));

            $rowlength = $query->num_rows();

            $rowcount = 1;

            $k = 0;

            if ($query->num_rows() > 0) {

                foreach ($query->result() as $row) {

                    if ($first) {

                       // echo nl2br("\nFirst");

                        $client = new ClientModel();

                        $client->addr1 = $row->addr1;

                        $client->addr2 = $row->addr2;

                        $client->alternatestatus = $row->alternatestatus;

                        $categoryModel[$i] = new CategoryModel();

                        $categoryModel[$i]->categoryid = $row->clientcategoryconnectid;

                        $categoryModel[$i]->subcategory = $row->subcategory;

                        $categoryModel[$i]->updatedate = $row->updatedate;

                        $client->categoryModel = $categoryModel;

                        $citystate = new CityStateModel();

                        $citystate->city = $row->city;

                        $citystate->state = $row->state;

                        $citystate->pincode = $row->citystateid;

                        $client->citystateModel = $citystate;

                        $client->client = $row->client;

                        $client->cmobileno = $cmobileno;

                        $client->emailid = $row->emailid;

                        $client->fullname = $row->fullname;

                        $client->lat = $row->lat;

                        $client->lon = $row->lon;

                        $client->opentime = $row->opentime;

                        $client->phoneno = $row->phoneno;

                        $client->rating = $row->rating;

                        $client->reviewers = $row->reviewers;

                        $client->website = $row->website;

                        $first = 0;

                        $secondloop = 1;

                        $thirdloop = 1;

                      //  $client->categoryModel = new CategoryModel();

                    }

                   // echo nl2br("\Categoryid" . $row->clientsubcatid . "Regnbo" . $row->regno);

                    if ($secondloop == 1 || ($row->clientsubcatid == $clientsubcatid)) {



                        $secondloop = 0;

                        if ($thirdloop == 1 || ($row->regno != null && $row->regno == $regno)) {



                          //  echo nl2br("\nRegNo.." . $row->regno);

                            $clientsubcatid = $row->clientsubcatid;

                            $regno = $row->regno;

                            if ($thirdloop) {



                                $rentalItems[$j] = new RentalItemModel();

                                $rentalItems[$j]->cmobileno = $cmobileno;

                                ///      $rentalItems[$i]->imageurl = 

                                ///            $rentalItems[$i]->imageurldp

                                $rentalItems[$j]->item = $row->item;

                                $rentalItems[$j]->price = $row->price;

                                $rentalItems[$j]->quantity = $row->quantity;

                                $rentalItems[$j]->regno = $row->regno;

                                $regno = $row->regno;

                                $rentalItems[$j]->rentalclientlink = $row->rentalclientlink;

                                $rentalItems[$j]->rentalitemsid = $row->rentalitemsid;

                                $thirdloop = 0;

                            }



                            if ($row->bookingdate != null) {

                                $rentalbookings[$k] = new BookingRentalModel();

                                $rentalbookings[$k]->bfrom = $row->bfrom;

                                $rentalbookings[$k]->bookingdate = $row->bookingdate;

                                $rentalbookings[$k]->bookingid = $row->rentalclientcustomerlink;

                                $rentalbookings[$k]->bto = $row->bto;

                                $rentalbookings[$k]->status = $row->status;

                                $memberModel = new MemberModel();

                                $memberModel->addr1 = $row->addr1;

                                $memberModel->addr2 = $row->addr2;

                                $memberModel->age = $row->age;

                                $memberModel->emailid = $row->emailid;

                                $memberModel->fullname = $row->fullname;

                                $memberModel->phoneno = $row->phoneno;

                                $rentalbookings[$k]->memberModel = $memberModel;

                                $k++;

                            }

                            if ($rowcount == $rowlength) {

                                if ($k == 0) {

                                    $rentalbookings = null;

                                }

                                $rentalItems[$j]->bookings = $rentalbookings;

                                $categoryModel[$i]->rentalItems = $rentalItems;

                            }

                        } else {

                        //    echo nl2br("\nNew Reg" . $row->regno);

                            if ($k == 0) {

                                $rentalbookings = null;

                            }

                            $rentalItems[$j]->bookings = $rentalbookings;

                            $j++;

                            $rentalItems[$j] = new RentalItemModel();

                            $rentalItems[$j]->cmobileno = $cmobileno;

                            ///      $rentalItems[$i]->imageurl = 

                            ///            $rentalItems[$i]->imageurldp

                            $rentalItems[$j]->item = $row->item;

                            $rentalItems[$j]->price = $row->price;

                            $rentalItems[$j]->quantity = $row->quantity;

                            $rentalItems[$j]->regno = $row->regno;

                            $regno = $row->regno;

                            $rentalItems[$j]->rentalclientlink = $row->rentalclientlink;

                            $rentalItems[$j]->rentalitemsid = $row->rentalitemsid;



                            unset($rentalbookings);

                            $k = 0;

                            // $rentalbookings[$k] = new BookingRentalModel();

                            if ($row->bookingdate != null) {

                                $rentalbookings[$k] = new BookingRentalModel();

                                $rentalbookings[$k]->bfrom = $row->bfrom;

                                $rentalbookings[$k]->bookingdate = $row->bookingdate;

                                $rentalbookings[$k]->bookingid = $row->rentalclientcustomerlink;

                                $rentalbookings[$k]->bto = $row->bto;

                                $rentalbookings[$k]->status = $row->status;

                                $memberModel = new MemberModel();

                                $memberModel->addr1 = $row->addr1;

                                $memberModel->addr2 = $row->addr2;

                                $memberModel->age = $row->age;

                                $memberModel->emailid = $row->emailid;

                                $memberModel->fullname = $row->fullname;

                                $memberModel->phoneno = $row->phoneno;

                                $rentalbookings[$k]->memberModel = $memberModel;

                                $k++;

                            }

                            if ($rowcount == $rowlength) {

                                if ($k == 0) {

                                    $rentalbookings = null;

                                }

                                $rentalItems[$j]->bookings = $rentalbookings;

                                $categoryModel[$i]->rentalItems = $rentalItems;

                            }

                        }

                    } else {

                      //  echo nl2br("\nNew Category");

                        $rentalItems[$j]->bookings = $rentalbookings;

                        $categoryModel[$i]->rentalItems = $rentalItems;

                        $i++;

                        $categoryModel[$i] = new CategoryModel();

                        $categoryModel[$i]->categoryid = $row->clientcategoryconnectid;

                        $categoryModel[$i]->subcategory = $row->subcategory;                     



                        unset($rentalItems);

                        $j = 0;

                        $rentalItems[$j] = new RentalItemModel();

                        $rentalItems[$j]->cmobileno = $cmobileno;

                        ///      $rentalItems[$i]->imageurl = 

                        ///            $rentalItems[$i]->imageurldp

                        $rentalItems[$j]->item = $row->item;

                        $rentalItems[$j]->price = $row->price;

                        $rentalItems[$j]->quantity = $row->quantity;

                        $rentalItems[$j]->regno = $row->regno;

                        $regno = $row->regno;

                        $rentalItems[$j]->rentalclientlink = $row->rentalclientlink;

                        $rentalItems[$j]->rentalitemsid = $row->rentalitemsid;





                        unset($rentalbookings);

                        $k = 0;

                        // $rentalbookings[$k] = new BookingRentalModel();

                        if ($row->bookingdate != null) {

                            $rentalbookings[$k] = new BookingRentalModel();

                            $rentalbookings[$k]->bfrom = $row->bfrom;

                            $rentalbookings[$k]->bookingdate = $row->bookingdate;

                            $rentalbookings[$k]->bookingid = $row->rentalclientcustomerlink;

                            $rentalbookings[$k]->bto = $row->bto;

                            $rentalbookings[$k]->status = $row->status;

                            $memberModel = new MemberModel();

                            $memberModel->addr1 = $row->addr1;

                            $memberModel->addr2 = $row->addr2;

                            $memberModel->age = $row->age;

                            $memberModel->emailid = $row->emailid;

                            $memberModel->fullname = $row->fullname;

                            $memberModel->phoneno = $row->phoneno;

                            $rentalbookings[$k]->memberModel = $memberModel;

                            $k++;

                        }

                        if ($rowcount == $rowlength) {

                            if ($k == 0) {

                                $rentalbookings = null;

                            }

                            $rentalItems[$j]->bookings = $rentalbookings;

                            $categoryModel[$i]->rentalItems = $rentalItems;

                            $categoryModel[$i]->updatedate = $row->updatedate;

                        }

                    }

                    $rowcount++;

                }

            }

            return $categoryModel;

        }

    }



    function getRentalItemList($cmobileno, $categoryid) {

        $sql = "select * from rentalclientlink rcl 

left outer join rentalitems ri on ri.rentalitemsid = rcl.rentalitemsid

left outer join clientprofile cp on cp.cmobileno = rcl.cmobileno

where rcl.cmobileno=? and ri.categoryclientconnectid=?";

        $query = $this->db->query($sql, array($cmobileno, $categoryid));



        $rentalItemList = array();

        $i = 0;



        if ($query->num_rows() > 0) {

            foreach ($query->result() as $row) {

                $rentalItemList[$i] = new RentalItemModel();

                $rentalItemList[$i]->rentalitemsid = $row->rentalitemsid;

                $rentalItemList[$i]->item = $row->item;

                $rentalItemList[$i]->price = $row->price;

                $rentalItemList[$i]->quantity = $row->quantity;

                $rentalItemList[$i]->regno = $row->regno;

                $rentalItemList[$i]->cmobileno = $row->cmobileno;

                $i++;

            }

        }



        return $rentalItemList;

    }



}

