<?php

class CategoryModel extends CI_Model{
    
    public $categoryid;
    public $category;    
    public $subcategory;
    public $updatedate;
    public $enable;
    
    public function setSubCategoryid($categoryid) {
        $this->subcategory = $categoryid;
    }

    public function getSubCategoryid() {
        return $this->subcategory;
    }
       
    public function setCategoryid($categoryid) {
        $this->categoryid = $categoryid;
    }

    public function getCategoryid() {
        return $this->categoryid;
    }
    
    public function setCategory($category) {
        $this->category = $category;
    }

    public function getCategory() {
        return $this->category;
    }

    
    public function insertCategory($categoryData)
    {
       $this->db->insert('category', $categoryData);
    }
    
    public function searchCategory($categoryid)
    {
        $sql = "select * from category where categoryid=?";
        //   $query = $this->db->query($sql);
        $query = $this->db->query($sql,array($categoryid));

        $category=-1;
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            $this->load->model('CategoryModel');
        $category = new CategoryModel();
        $category->setCategoryid($categoryid);
        $category->setCategory($data[0]->category);
        }
        
       
        
        return $category;
    }
    
    function getJson($pincode){
         //Pass pincode only!!!!
        $sql = "select * from dealer d 
left outer join dealercategory dc on d.dealerid=dc.dealerid
left outer join catsubcat csc on csc.catsubcatid = dc.catsubcatid
left outer join	category c on c.categoryid = csc.categoryid
left outer join	subcategory sc on sc.subcatid = csc.subcatid
left outer join citystate cs on cs.pincode = d.pincode where d.pincode=?
order by csc.subcatid";
        
        
        $query = $this->db->query($sql,array($pincode));
        
        
        $dealer = array();
        $subcategory = array();
        $category = array();
        $i=0;
        $j=0;
        $k=0;
        $flag=0;
        
         if ($query->num_rows() > 0) {
             
            foreach ($query->result() as $row) {
                if($flag==0)
                {
                    $curcatsubid = $row->subcatid;
                    $curcatid = $row->categoryid;
                    $flag=-1;
                }
                //echo nl2br("\nDBCATID-----_" . $row->categoryid . "----DBSUBCAT-----_" . $row->subcatid);
                if($curcatid==$row->categoryid && $curcatsubid==$row->subcatid)
                {
                    $dealer[$i] = new DealerModel();                 
                    $dealer[$i]->fname = $row->fname;
                    $dealer[$i]->lname = $row->lname;
                    $dealer[$i]->mname = $row->mname;
                    $dealer[$i]->dealername = $row->dealername;
                //    $dealer[$i]->offer = $row->offer;
                    $dealer[$i]->addr1 = $row->addr1;
                    $dealer[$i]->addr2 = $row->addr2;
                    $dealer[$i]->phone1 = $row->phone1;
                   // $dealer[$i]->website = $row->website;
                  //  $dealer[$i]->emailid = $row->emailid;
                    $dealer[$i]->location = $row->lat . "," . $row->lon;     
                    $dealer[$i]->description = $row->lat . "," . $row->description;
                  //  $dealer[$i]->premiumMember = $row->premiummember;
                    
                    
                    
                    //echo nl2br("\nDealer is " . $dealer[$i]->fname);
                    
                    $cursubcat = new CategoryModel();
                    $cursubcat->subcategory=$row->subcatname;                    
                    $cursubcat->categoryid =$row->subcatid;
                    
                    $curcat = new MainCategoryModel();
                    $curcat->category = $row->category;                    
                    $curcat->categoryid=$row->categoryid;                    
                    $i++;                                  
                }           
                else{
                    
                    if($curcatid != $row->categoryid)
                    {
                        //echo nl2br ("\nCategory over!! and Also Subcategory");
                        $subcategory[$j]= new CategoryModel();
                        $subcategory[$j]->subcategory=$cursubcat->subcategory;
                        $subcategory[$j]->dealer=$dealer;
                        $subcategory[$j]->categoryid =$cursubcat->categoryid;
                        
                        //echo "\nCompleted Subcat--" . $subcategory[$j]->subcategory;
                        
                        $category[$k] = new MainCategoryModel();
                        $category[$k]->category = $curcat->category;
                        $category[$k]->subcategory= $subcategory;
                        $category[$k]->categoryid=$curcat->categoryid;
                        
                        //echo nl2br ("\nCompleted Category" . $category[$k]->category);
                        
                        $k++;
                        $j=0;
                        $i=0;
                        
                        $dealer[$i] = new DealerModel();                 
                    $dealer[$i]->fname = $row->fname;
                    $dealer[$i]->lname = $row->lname;
                    $dealer[$i]->mname = $row->mname;
                    $dealer[$i]->dealername = $row->dealername;
                 //   $dealer[$i]->offer = $row->offer;
                    $dealer[$i]->addr1 = $row->addr1;
                    $dealer[$i]->addr2 = $row->addr2;
                    $dealer[$i]->phone1 = $row->phone1;
                //    $dealer[$i]->website = $row->website;
                //    $dealer[$i]->emailid = $row->emailid;
                    $dealer[$i]->location = $row->lat . "," . $row->lon;     
                    $dealer[$i]->description = $row->lat . "," . $row->description;
              //      $dealer[$i]->premiumMember = $row->premiummember;
                    
                        $cursubcat = new CategoryModel();
                        $cursubcat->subcategory=$row->subcatname;                    
                        $cursubcat->categoryid =$row->subcatid;
                    
                        $curcat = new MainCategoryModel();
                        $curcat->category = $row->category;                    
                        $curcat->categoryid=$row->categoryid;
                        
                        $curcatsubid = $row->subcatid;
                        $curcatid = $row->categoryid;
                       
                        //echo nl2br ("\n\nNew Dealer is " . $dealer[$i]->fname . "CURCAT--" . $curcatid . "__SubCAT--" . $curcatsubid);
                        
                        $i++;                                  
                        
                    }
                    else
                    
                    if($curcatsubid != $row->subcatid)
                    {
                        //echo nl2br ("Only Subcategory is Over");
                        
                        $subcategory[$j]= new CategoryModel();
                        $subcategory[$j]->subcategory=$cursubcat->subcategory;
                        $subcategory[$j]->dealer=$dealer;
                        $subcategory[$j]->categoryid =$curcat->categoryid;
                        //echo nl2br ("New Subcat--" . $subcategory[$j]->subcategory);
                        
                        $j++;
                        $i=0;                        
                        
                        $dealer[$i] = new DealerModel();                 
                    $dealer[$i]->fname = $row->fname;
                    $dealer[$i]->lname = $row->lname;
                    $dealer[$i]->mname = $row->mname;
                    $dealer[$i]->dealername = $row->dealername;
                //    $dealer[$i]->offer = $row->offer;
                    $dealer[$i]->addr1 = $row->addr1;
                    $dealer[$i]->addr2 = $row->addr2;
                    $dealer[$i]->phone1 = $row->phone1;
                //    $dealer[$i]->website = $row->website;
                //    $dealer[$i]->emailid = $row->emailid;
                    $dealer[$i]->location = $row->lat . "," . $row->lon;     
                    $dealer[$i]->description = $row->lat . "," . $row->description;
              //      $dealer[$i]->premiumMember = $row->premiummember;
                    
                        $cursubcat = new CategoryModel();
                        $cursubcat->subcategory=$row->subcatname;                    
                        $cursubcat->categoryid =$row->subcatid;                                     
                    
                        $curcatsubid = $row->subcatid;
                        
                        //echo nl2br ("\n\nNew Dealer is " . $dealer[$i]->fname);
                         
                        $i++;                                  
                    }
                    
                    
                }
            }
            
            //echo nl2br ("\nCategory over!! and Also Subcategory");
                        $subcategory[$j]= new CategoryModel();
                        $subcategory[$j]->subcategory=$cursubcat->subcategory;
                        $subcategory[$j]->dealer=$dealer;
                        $subcategory[$j]->categoryid =$cursubcat->categoryid;
                        
                    //    echo "\nCompleted Subcat--" . $subcategory[$j]->subcategory;
                        
                        $category[$k] = new MainCategoryModel();
                        $category[$k]->category = $curcat->category;
                        $category[$k]->subcategory= $subcategory;
                        $category[$k]->categoryid=$curcat->categoryid;
                        
                      //  echo nl2br ("\nCompleted Category" . $category[$k]->category);
            
        }
       
        
        return json_encode($category);
    }
}
