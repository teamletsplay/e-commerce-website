<?php

class ScheduleModel extends CI_Model {

    public $day;
    public $cmobileno;
    public $opentimesc;
    public $closetimesc;
    public $bookingnossc;
    public $clientModel;
    public $bookingintervalsc;
    public $starttokensc;
    public $alternatestatussc;
	public $notes;
	public $breaktime;
	public $breakintervaltime;
    

    
}