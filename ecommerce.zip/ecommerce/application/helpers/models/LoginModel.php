<?php

class LoginModel extends CI_Model {

    public $username;
    public $password;
    public $active;
    public $type;
    public $otp;
    public $attempt;

    public function setUsername($username) {
        $this->username = $username;
    }

    public function getUsername() {
        return $this->username;
    }

    public function setPassword($password) {
        $this->status = $password;
    }

    public function getPassword() {
        return $this->password;
    }

    public function setActive($active) {
        $this->status = $active;
    }

    public function getActive() {
        return $this->active;
    }

    public function setType($type) {
        $this->type = $type;
    }

    public function getType() {
        return $this->type;
    }

    public function setOtp($otp) {
        $this->type = $otp;
    }

    public function getOtp() {
        return $this->$otp;
    }

    function authenticate($username, $password, $fcm) {

        $this->load->model('MemberModel');
        $memberModel = new MemberModel();
        $memberModel = $memberModel->getAll($username,$password,$fcm);
        return $memberModel;
    }

    function isRegisteredUser($mobile) {
        $sql = "select * from login l where l.username=? and active='Y' and type='M'";
        $query = $this->db->query($sql, array($mobile));



        //CREATE OTP
        $otp = mt_rand(1999, 9999);

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }

            $login = new LoginModel();
            $login->username = $mobile;
            $login->type = $data[0]->type;
            $login->attempt = $data[0]->attempt;
            $login->active = $data[0]->active;
            $login->otp = $otp;
            return $login;
        } else {
            $sql = "select * from beamember bem where bem.mobileno=?";
            $query = $this->db->query($sql, array($mobile));

            if ($query->num_rows() > 0) {
                foreach ($query->result() as $row) {
                    $data[] = $row;
                }
                $login = new LoginModel();
                $login->username = $mobile;
                if ($data[0]->attempt >=5 || $data[0]->name != null) {
                    $login->type = "AR";
                } else {
                    $login->type = "UR";
                }
                //$login->attempt=$data[0]->attempt;
                $login->active = -1;
                $login->otp = $otp;
                $attempt = $data[0]->attempt + 1;
                $sql = "update beamember set attempt=? where mobileno =?";
                $query = $this->db->query($sql, array($attempt,$mobile));
                
                
                return $login;
            } else {

                $sql = "insert into beamember (mobileno,otp) values(?,?)";
                $query = $this->db->query($sql, array($mobile, $otp));


                $login = new LoginModel();
                $login->username = $mobile;
                $login->type = "UR";
                //$login->attempt=0;
                $login->active = -1;
                return $login;
            }
        }
    }

    function authenticateClient($username, $password, $type) {

        $this->load->model('ClientModel');
        $clientModel = new ClientModel();
        $clientModel = $clientModel->getAllClientDetails($username,$password, $type);
        return $clientModel;
    }

    function insertIntoLogin($registeredUser) {
        $login = new LoginModel();
        $login = $registeredUser;
        $totalattempt = $login->attempt + 1;
        if ($login->attempt <= 5) {
            $sql = "update login set otp=?,attempt=? where username=?";
            $query = $this->db->query($sql, array($login->otp, $totalattempt, $login->username));
            //SEND SMS CONTAINING OTP


            return 1;
        } else {
            return -1;
        }
    }

    function insertIntoBeAMember($registeredUser) {
        $login = new LoginModel();
        $login = json_decode($registeredUser);

        //CREATE OTP
        $otp = mt_rand(1999, 9999);

        $sql = "insert into beamember (mobileno,otp) values(?,?,?)";
        $query = $this->db->query($sql, array($mobile, $otp));
    }
	
	
	function sendEmail($from, $fromName, $to, $toName, $replyTo, $cc, $subject, $message)
	{
		$this->load->library('Phpmailer_lib');

        
        // PHPMailer object
        $mail = $this->phpmailer_lib->load();
		
		$mail->From = $from;
		$mail->FromName = $fromName;
		

//To address and name
$mail->addAddress($to, $toName);
//$mail->addAddress("recepient1@example.com"); //Recipient name is optional

if($replyTo!=null)
{
//Address to which recipient will reply
$mail->addReplyTo($replyTo, "Reply");
}

//CC and BCC
if($cc!=null)
{
	$mail->addCC($cc);
}
//$mail->addBCC("bcc@example.com");

//Send HTML or Plain Text email
$mail->isHTML(true);

$mail->Subject = $subject;
$mail->Body = $message;
//$mail->AltBody = "This is the plain text version of the email content";

try {
    $mail->send();
   // echo "Message has been sent successfully";
    echo 1;
} catch (Exception $e) {
    echo -5; // Mail not sent
    //echo "Mailer Error: " . $mail->ErrorInfo;
}
       
		
	}
	
	
	
	
	function sendGCM($title,$message, $deviceToken) {


  // Put your Server Response Key here
  $apiKey = "AAAA65x9wRQ:APA91bEa7ALv6X_k6uyX0SuCnIk-3SFE7LXx0fcpQrlSEBkn-Z5KRMzLYIdcxW_LIp0xgQuldqR8LXnLBioQpDuCYRjJRBdFdj-f9E7VyKC6FLta69p8vN6uLwlmKkB8ljnP8kVNkTh1";
  
 $url = 'https://fcm.googleapis.com/fcm/send';
        $messageData = ['message' =>  $message];

        $notification = [
            'title' => $title,
            'body' => $message,
		];
        $fields = array (
            "to" => $deviceToken,
            'notification'      => $notification,

            'data'              => $messageData,
             'vibrate'=>'1',
            'sound'=>'default',
        );
        $fields = json_encode ( $fields );
        $headers = array (
            'Authorization: key=' . $apiKey,
            'Content-Type: application/json'
        );

        $ch = curl_init ();
        curl_setopt ( $ch, CURLOPT_URL, $url );
        curl_setopt ( $ch, CURLOPT_POST, true );
        curl_setopt ( $ch, CURLOPT_HTTPHEADER, $headers );
        curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, true );
        curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
        curl_setopt ( $ch, CURLOPT_POSTFIELDS, $fields );

        $result = curl_exec ( $ch );

        curl_close ( $ch );
        echo $result;
}

}
