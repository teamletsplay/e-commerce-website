<?php

class MemberTreeModel extends CI_Model{
    
    public $membertreeid;    
    public $fullname;
    public $age;                     
    
}
