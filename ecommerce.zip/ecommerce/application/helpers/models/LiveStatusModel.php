<?php

class LiveStatusModel extends CI_Model {

    public $clientModel;
    public $memberModel;
    public $liveToken;
    public $livestatusts;
    public $currentbookingno; // Need to update and change $liveToken...
    public $appointmentdate;
    public $livestatusid;
    public $scmobileno;

    function getLiveStatus($mmobileno) {
date_default_timezone_set('Asia/Kolkata');


$td = date('Y-m-d');


        $sql = "select * from booking b 
left outer join livestatus ls on ls.scmobileno = b.scmobileno 
left outer JOIN subclientprofile sc on sc.scmobileno = b.scmobileno
left outer join membertree mt on mt.membertreeid=b.membertreeid
left outer join citystate cs on cs.citystateid = sc.citystateidsc
where b.mmobileno=? and b.bookingdate=? and ls.appointmentdate=? and b.status='B'
group by sc.scmobileno";

        $query = $this->db->query($sql, array($mmobileno,$td,$td));

        $liveStatusModel = array();
        $i=0;
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {

                $liveStatusModel[$i] = new LiveStatusModel();                

                $clientModel = new ClientModel();
                $subclientModel = new SubClientModel();
                
                $cityStateModel = new CityStateModel();
                $cityStateModel->city = $row->city;
                $cityStateModel->state = $row->state;
                $cityStateModel->pincode = $row->citystateid;
                $subclientModel->citystateModel = $cityStateModel;
                $subclientModel->lat = $row->latsc;
                $subclientModel->lon = $row->lonsc;
                $subclientModel->phoneno = $row->phonenosc;
                
                $subclientModel->addr1 = $row->addr1sc;
                $subclientModel->addr2 = $row->addr2sc;
                $subclientModel->fullname = $row->fullnamesc;
                $clientModel->subClient = $subclientModel;
                $liveStatusModel[$i]->clientModel = $clientModel;
                
                
                $memberModel = new MemberModel();
                $memberTreeModel = new MemberTreeModel();
                $memberTreeModel->membertreeid = $row->membertreeid;
                $memberTreeModel->fullname = $row->fullnamemt;
                $memberTreeModel->age = $row->agemt;
                $memberModel->membertreemodel=$memberTreeModel;
                $liveStatusModel[$i]->memberModel = $memberModel;

                $liveStatusModel[$i]->liveToken = $row->currentbookingno;
                $liveStatusModel[$i]->livestatusts = $row->livestatusts;                
                
                $i++;
            }
        }
        
        return $liveStatusModel;
    }

}
