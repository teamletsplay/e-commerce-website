<?php



class BookingRentalModel extends CI_Model {



    public $bookingid;

    public $bookingdate;

    public $memberModel;

    public $bfrom;

    public $bto;

    public $status;
    
    public $clientModel;

   



}

