<?php

class CityStateModel extends CI_Model {

    public $pincode;
    public $city;
    public $state;

    public function setPincode($pincode) {
        $this->pincode = $pincode;
    }

    public function getPincode() {
        return $this->pincode;
    }

    public function setCity($city) {
        $this->city = $city;
    }

    public function getCity() {
        return $this->city;
    }

    public function setState($state) {
        $this->state = $state;
    }

    public function getState() {
        return $this->state;
    }

    public function insertCityState($cityStateData) {
        $this->db->insert('citystate', $cityStateData);
    }

    public function searchCity($searchCity) {
        $sql = "select * from citystate where pincode=?";
        //   $query = $this->db->query($sql);
        $query = $this->db->query($sql, array($searchCity));

        $citystate = -1;
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            $this->load->model('CityStateModel');
            $citystate = new CityStateModel();
            $citystate->setPincode($searchCity);
            $citystate->setCity($data[0]->city);
            $citystate->setState($data[0]->state);
        }



        return $citystate;
    }

    public function getAll() {
        $sql = "select * from citystate";

        $query = $this->db->query($sql);

        $citystate = array();
        $this->load->model('CityStateModel');
        $i=0;
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $citystate[$i]= new CityStateModel();
                $citystate[$i]->setCity($row->city);
                $citystate[$i]->setState($row->state);
                $citystate[$i]->setPincode($row->citystateid);
                $i++;
            }
       
        }



        return $citystate;
    }
    
       
    
    public function getAllState() {
        $sql = "select distinct(state) from citystate";

        $query = $this->db->query($sql);

        $citystate = array();
        $this->load->model('CityStateModel');
        $i=0;
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $citystate[$i]= new CityStateModel();                
                $citystate[$i]->setState($row->state);                
                $i++;
            }
       
        }



        return $citystate;
    }
    
    public function getCityByState($state) {
        $sql = "select * from citystate where state=?";

        $query = $this->db->query($sql,array($state));

        $citystate = array();
        $this->load->model('CityStateModel');
        $i=0;
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
              $citystate[$i]= new CityStateModel();
                $citystate[$i]->setCity($row->city);
                $citystate[$i]->setState($row->state);
                $citystate[$i]->setPincode($row->pincode);
                $i++;
            }
       
        }



        return $citystate;
    }

}
