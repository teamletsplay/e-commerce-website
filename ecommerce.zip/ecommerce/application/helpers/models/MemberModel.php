<?php

class MemberModel extends CI_Model {

    public $loginmodel;
    public $fullname;
    public $age;
    public $lat;
    public $lon;
    public $addr1;
    public $addr2;
    public $citystatemodel;
    public $phoneno;
    public $membertreemodel;
    public $emailid;
    public $bookingModel;
    public $bookingRentalModel;
	
	
	function updateProfile($mmobileno,$fullname,$emailid,$pincode){
	
		$sql = "update memberprofile set fullnamem=?, emailidm=?, citystateidm=? where mmobileno =?";
		$query = $this->db->query($sql, array($fullname,$emailid,$pincode,$mmobileno));
		
		return 1;
		
	}

    function deleteMember($mmobileno, $membertreeid) {

        date_default_timezone_set('Asia/Kolkata');
        $currentdate = date('Y-m-d');
        
        $sql = "select * from booking b                 
                where b.membertreeid=? and b.mmobileno=? and b.bookingdate>=? and b.status='B';";

        $query = $this->db->query($sql, array($membertreeid, $mmobileno, $currentdate));

        $deleteMemberStatus = 'N';
        if ($query->num_rows() > 0) {
            $deleteMemberStatus = 'N';
        } else {
            $deleteMemberStatus = 'Y';
        }


        if ($deleteMemberStatus == 'Y') {
            $this->db->delete('membertree', array('mmobilenomt' => $mmobileno, 'membertreeid' => $membertreeid));
            if ($this->db->affected_rows() > 0)
                return 1; //Member deleted
            else
                return 0; //Some problem in mysql or trying to delete it again
        }
        else if ($deleteMemberStatus == 'N') {
            return 2; //Cannot delete as booking exist
        } else {
            return 3; //Some issue with the previous sql..
        }
    }

    function addMember($mmobileno, $fullname, $age) {

        $data = array(
            'mmobilenomt' => $mmobileno,
            'fullnamemt' => $fullname,
            'agemt' => $age
        );
        $this->db->insert('membertree', $data);
        if ($this->db->affected_rows() > 0)
            return $this->db->insert_id();
        else
            return 0;
    }

    function getAll($mmobileno, $fcm) {
        $this->load->model('MemberModel');
        $member = new MemberModel();
//TODO ADD status and type..
        $sql = "select * from login l 
                left outer join memberprofile mp on l.mobileno=mp.mmobileno
                left outer join citystate cs on cs.citystateid=mp.citystateidm
                left outer join membertree mt on mt.mmobilenomt = mp.mmobileno
                where l.mobileno=?";

        $query = $this->db->query($sql, array($mmobileno));

        $membertreemodel = array();

        $i = 0;
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {

                if ($i == 0) {
					//if FCM is null it means new user
					$fcmdb = $row->fcm;
					if($fcmdb != $fcm)
					{
						$sql = "update login set fcm=? where mobileno =?";
						$query = $this->db->query($sql, array($fcm,$mmobileno));
					}
					
                    $member->addr1 = $row->addr1m;
                    $member->addr2 = $row->addr2m;
                    $member->age = $row->age;
                    $member->emailid = $row->emailidm;
                    $member->fullname = $row->fullnamem;
                    $member->lat = $row->latm;
                    $member->lon = $row->lonm;
                    $member->phoneno = $row->phonenom;


                    $this->load->model('CityStateModel');
                    $citystatemodel = new CityStateModel();
                    $citystatemodel->city = $row->city;
                    $citystatemodel->pincode = $row->citystateidm;
                    $citystatemodel->state = $row->state;
                    $member->citystatemodel = $citystatemodel;


                    $this->load->model('LoginModel');
                    $loginmodel = new LoginModel();
                    $loginmodel->active = $row->active;
                    $loginmodel->attempt = $row->attempt;
                    $loginmodel->otp = $row->otp;
                    $loginmodel->password = $row->password;
                    $loginmodel->type = $row->type;
                    $loginmodel->username = $row->mmobileno;
                    $member->loginmodel = $loginmodel;


                    $membertreemodel[$i] = new MemberTreeModel();
                    $membertreemodel[$i]->age = $row->age;
                    $membertreemodel[$i]->fullname = $row->fullnamem;
                    $membertreemodel[$i]->membertreeid = 0;

                    $i++;

                    $membertreemodel[$i] = new MemberTreeModel();
                    $membertreemodel[$i]->age = $row->agemt;
                    $membertreemodel[$i]->fullname = $row->fullnamemt;
                    $membertreemodel[$i]->membertreeid = $row->membertreeid;
                } else {

                    $membertreemodel[$i] = new MemberTreeModel();
                    $membertreemodel[$i]->age = $row->agemt;
                    $membertreemodel[$i]->fullname = $row->fullnamemt;
                    $membertreemodel[$i]->membertreeid = $row->membertreeid;
                }
                $i++;
            }
        }
        $bookingModel = array();
        $bookingModel = $member->getAllBookings($mmobileno);
        $member->bookingModel = $bookingModel;
        $member->membertreemodel = $membertreemodel;

        $bookingRentalModel = array();
        $bookingRentalModel = $member->getAllRentalBookings($mmobileno);
        $member->bookingRentalModel = $bookingRentalModel;

        return $member;
    }

    function getAllRentalBookings($mmobileno) {

        $this->load->model('BookingRentalModel');
        $rentalBookings = array();

        $sql = "select * from rentalclientcustomerlink rccl
left outer join rentalclientlink rcl on rcl.rentalclientlink = rccl.rentalclientlinkid
left outer join rentalitems ri on ri.rentalitemsid = rcl.rentalitemsid
left outer join clientprofile cp on cp.cmobileno = rccl.cmobileno
where rccl.mmobileno = ?
order by rccl.bfrom desc";
        
        $query = $this->db->query($sql, array($mmobileno));

        $i = 0;
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $rentalBookings[$i] = new BookingRentalModel();
                $rentalBookings[$i]->bfrom = $row->bfrom;
                $rentalBookings[$i]->bookingdate = $row->bookingdate;
                        $rentalBookings[$i]->bookingid = $row->rentalclientcustomerlink;
                        $rentalBookings[$i]->bto = $row->bto;
                        
                        $rentalItemModel = new RentalItemModel();
                        $rentalItemModel->cmobileno = $row->cmobileno;
                        $rentalItemModel->imageurl = $row->imageurl;
                                $rentalItemModel->imageurldp = null;
                                $rentalItemModel->item = $row->item;
                                $rentalItemModel->price = $row->price;
                                $rentalItemModel->quantity = $row->quantity;
                                $rentalItemModel->regno = $row->regno;                               
                                $rentalItemModel->rentalclientlink = $row->rentalclientlink;
                                $rentalItemModel->rentalitemsid = $row->rentalitemsid;
                        $rentalBookings[$i]->rentalModel = $rentalItemModel;
                        
                        
                        $rentalBookings[$i]->status = $row->status;
                        
                        $clientModel = new ClientModel();
                        $clientModel->addr1 = $row->addr1;
                        $clientModel->addr2 = $row->addr2;                                
                                $clientModel->client = $row->client;                                
                                $clientModel->closetime = $row->closetime;
                                $clientModel->cmobileno = $row->cmobileno;
                                $clientModel->emailid = $row->emailid;
                                $clientModel->fullname = $row->fullname;
                                $clientModel->lat = $row->lat;
                                $clientModel->lon = $row->lon;
                                $clientModel->opentime = $row->opentime;
                                $clientModel->phoneno = $row->phoneno;
                                $clientModel->rating = $row->rating;
                                $clientModel->reviewers = $row->reviewers;
                                $clientModel->website = $row->website;
                                
                                
                                
                        $rentalBookings[$i]->clientModel = $clientModel;
                        $i++;
                        
            }
            return $rentalBookings;
        }
        
        
        
    }

    function getAllBookings($mmobileno) {
        $this->load->model('BookingModel');
        $bookings = array();

        $sql = "select * from booking b
                left outer join clientprofile cp on cp.cmobileno=b.cmobileno
                left outer join membertree mt on mt.membertreeid=b.membertreeid
                left outer join memberprofile mp on mp.mmobileno=b.mmobileno                
                left outer join subclientprofile scp on scp.scmobileno = b.scmobileno
                left outer join clientcategoryconnect catc on catc.clientcategoryconnectid = scp.clientcategoryconnectidsc
                left outer join clientcategory cc on cc.clientcatid = catc .clientcatid
                left outer join clientsubcategory csc on csc.clientsubcatid = catc .clientsubcatid 
                where b.mmobileno=? order by b.bookingdate desc";

        $query = $this->db->query($sql, array($mmobileno));

        $i = 0;
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $bookings[$i] = new BookingModel();
                $bookings[$i]->applicationdate = $row->applicationdate;
                $bookings[$i]->bookingdate = $row->bookingdate;
                $bookings[$i]->bookingid = $row->bookingid;
                $bookings[$i]->bookingno = $row->bookingno;
                $bookings[$i]->bookingtime = $row->bookingtime;
                $bookings[$i]->status = $row->status;

                $categoryM = new CategoryModel();
                $categoryM->categoryid = $row->clientcategoryconnectid;
                $categoryM->category = $row->category;
                $categoryM->subcategory = $row->subcategory;

                $client = new ClientModel();
                $client->addr1 = $row->addr1;
                $client->addr2 = $row->addr2;
                $client->alternatestatus = $row->alternatestatus;
                $client->bookinginterval = $row->bookinginterval;
                $client->bookingnos = $row->bookingnos;
                $client->client = $row->client;
                $client->closetime = $row->closetime;
                $client->emailid = $row->emailid;
                $client->fullname = $row->fullname;
                $client->lat = $row->lat;
                $client->lon = $row->lon;
                $client->opentime = $row->opentime;
                $client->phoneno = $row->phoneno;
                $client->website = $row->website;
                //$client->categoryModel = $categoryM;
                $bookings[$i]->clientModel = $client;


                $subClientModel = new SubClientModel();
                $subClientModel->addr1 = $row->addr1sc;
                $subClientModel->addr2 = $row->addr2sc;
                // $subClientModel->alternatestatus = $row->alternatestatussc;
                // $subClientModel->bookinginterval
                // $subClientModel->bookingnos

                $subClientModel->categoryModel = $categoryM;
                //$subClientModel->clientavailability = $row->
                // $subClientModel->closetime
                $subClientModel->emailid = $row->emailidsc;
                $subClientModel->fullname = $row->fullnamesc;
                $subClientModel->lat = $row->latsc;
                $subClientModel->lon = $row->lonsc;
                //$subClientModel->opentime = 
                $subClientModel->phoneno = $row->phonenosc;
                $subClientModel->rating = $row->ratingsc;
                $subClientModel->website = $row->websitesc;

                //TO DO FOR LATER MORE ATTRIB

                $client->subClient = $subClientModel;
                $this->load->model('MemberTreeModel');
                $membertreeModel = new MemberTreeModel();
                $membertreeModel->membertreeid = $row->membertreeid;
                if ($row->fullnamemt != null) {
                    $membertreeModel->fullname = $row->fullnamemt;
                    $membertreeModel->age = $row->agemt;
                } else {
                    $membertreeModel->fullname = $row->fullnamem;
                    $membertreeModel->age = $row->age;
                }
                $bookings[$i]->membertreeModel = $membertreeModel;
                $bookings[$i]->mmobileno = $mmobileno;
                $bookings[$i]->note = $row->note;
                $i++;
            }
        }
        return $bookings;
    }

}
