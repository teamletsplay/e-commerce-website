<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of SignUpModel
 *
 * @author PC
 */
class SignUpModel extends CI_Model {

    public $username;
    public $password;
    public $active;
    public $type;
    public $otp;
    public $attempt;

    public function createOtp($mmobileno, $fcm) {
        $sql = "select * from login where mobileno = ?";
        $query = $this->db->query($sql, array($mmobileno));
		
				   

        $userExist = false;
        $userInactive = false;
		$attempt = 0;
		$finalattempt = 0;

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $userExist = true;
				$attempt = $row->attempt;   
				$finalattempt = $row->finalattempt;
                if ($row->active == 'N') {
                    $userInactive = true;
                }
            }
        }
		
		if($finalattempt >= 5)
		{
			return -11;
		}
		else if ($attempt >= 5) {
			return -9;
        }
		else if ($userExist && !$userInactive) {
			$otp = mt_rand(1999, 9999);
            $sql = "UPDATE login 
                SET otp= ?, fcm = ?, attempt = attempt+1
                WHERE mobileno = ?";

		$query = $this->db->query($sql, array($otp,$fcm,$mmobileno));
            //Send sms to the mobileno...
            $this->sendSms($mmobileno, $otp);			
		/*$this->load->model('MemberModel');
        $memberModel = new MemberModel();
        $memberModel = $memberModel->getAll($mmobileno,$fcm);
		*/
        return 1;											       
            
            
        } else if($userInactive) {
			$otp = mt_rand(1999, 9999);
            $sql = "UPDATE login 
                SET otp= ?,fcm=?, attempt = attempt+1
                WHERE mobileno = ?";

		$query = $this->db->query($sql, array($otp,$fcm,$mmobileno));
            //Send sms to the mobileno...
            $this->sendSms($mmobileno, $otp);
            return -7;
        }
        else
        {			
			$otp = mt_rand(1999, 9999);
			$sql = "insert into login (mobileno,fcm,otp) values(?,?,?)";
                $query = $this->db->query($sql, array($mmobileno, $fcm, $otp));            
		
            //Send sms to the mobileno...
            $this->sendSms($mmobileno, $otp);
            return -5;
        }
    }

    public function signup($mmobileno, $emailid, $fullname) {


        $sql = "select * from login where mobileno = ?";
        $query = $this->db->query($sql, array($mmobileno));

        $userExist = false;
        $userInactive = false;
        $attempt=0;

        //CHECK THIS CODE!!
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $userExist = true;
                if ($row->active == 'N') {
                    $userInactive = true;
                    $attempt = ($row->attempt)+1;
                }
            }
        }

        if (!$userExist) {


            //Create OTP
            $otp = mt_rand(1999, 9999);
            //Send sms to the mobileno...
            $this->sendSms($mmobileno, $otp);

            $data = array('mobileno' => $mmobileno, 'active' => 'N', 'type' => 'C', 'otp' => $otp);
            $this->db->insert('login', $data);

            $data2 = array('mmobileno' => $mmobileno, 'fullnamem' => $fullname, 'emailid' => $emailid);
            $this->db->insert('memberprofile', $data2);

            return 1;
        } else if ($userInactive) {
            //Send sms again... and send otp to the user...
            //Create OTP
            $otp = mt_rand(1999, 9999);
            //Send sms to the mobileno...
            $this->sendSms($mmobileno, $otp);
            $sql = "UPDATE login 
                SET otp= ?, attempt=?
                WHERE mobileno = ?";

        $query = $this->db->query($sql, array($otp,$attempt, $mmobileno));
            
            
            return 2;
        } else {
            return -7;
        }
    }

    public function sendSms($mmobileno, $otp) {

        // Authorisation details.
        $username = "sachukale@gmail.com";
        $hash = "154fda33786264f2dd21a96ee2d78ae9477701ddf5fe0de55311cd312df75e46";

        // Config variables. Consult http://api.textlocal.in/docs for more info.
        $test = "0";

        // Data for text message. This is the text message data.
        //$sender = "BookM!"; // This is who the message appears to be from.
		$sender=urlencode('BOOKMI');
        $numbers = "91" . $mmobileno; // A single number or a comma-seperated list of numbers
        $message = "Welcome to Book M! App. Your otp is ".$otp.".%n %nPowered by Stanza Infotech Private Limited.";
		
		//echo $message;
        // 612 chars or less
        // A single number or a comma-seperated list of numbers
        $message = rawurlencode($message);
        $data = "username=" . $username . "&hash=" . $hash . "&message=" . $message . "&sender=" . $sender . "&numbers=" . $numbers . "&test=" . $test;
        $ch = curl_init('http://api.textlocal.in/send/?');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch); // This is the result from the API
    //    echo $result;
        curl_close($ch);

    }

    public function signupCompleteStep($mmobileno, $name, $pincode, $emailid, $fcm) {
        $sql = "UPDATE login 
                SET active='Y'
                WHERE mobileno = ?";

        $query = $this->db->query($sql, array($mmobileno));


        $sql = "UPDATE memberprofile 
                SET citystateidm= ?, fullnamem=?, emailidm = ?,
                WHERE mmobileno = ?";
				
			
		$sql = "insert into memberprofile (citystateidm,fullnamem, emailidm,mmobileno) values(?,?,?,?)";
        $query = $this->db->query($sql, array($pincode, $name, $emailid, $mmobileno));        

		$this->load->model('MemberModel');
        $memberModel = new MemberModel();
        $memberModel = $memberModel->getAll($mmobileno,$fcm);
        return $memberModel;
        
    }

    public function validateOtp($mmobileno, $otp, $fcm) {
        $sql = "select * from login where mobileno = ?";
        $query = $this->db->query($sql, array($mmobileno));

        $otpfromdb = -2;

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $attempt = $row->attempt;
                if ($attempt < 5) {
                    $otpfromdb = $row->otp;
                }
            }
        }

        if ($otp != $otpfromdb) {
            $sql = "UPDATE login 
                SET attempt= attempt+1
                WHERE mobileno = ?";

            $query = $this->db->query($sql, array($mmobileno));
        }

        if ($otp == $otpfromdb) {
		$this->load->model('MemberModel');
        $memberModel = new MemberModel();
        $memberModel = $memberModel->getAll($mmobileno,$fcm);
		
            return $memberModel; //Otp matchese...
        } else if ($otpfromdb == -2) {
            return -5; //attempts over....
        } else {
            return -7; //otp doesn't match...
        }
    }

}
