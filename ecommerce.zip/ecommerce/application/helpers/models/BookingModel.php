<?php

class BookingModel extends CI_Model {

    public $bookingid;
    public $memberModel;
    public $mmobileno;
    public $bookingdatedisplay;
    public $token;
    public $clientModel;
    public $bookingdate;
    public $bookingtime;
    public $bookingno;
    public $note;
    public $applicationdate;
    public $cmobileno;
    public $scmobileno;
    public $status;
    public $membertreeModel;
    public $fullname;

    public function doBooking($membertree, $mmobileno, $cmobileno, $bookingdate, $bookingtoken, $scmobileno, $bookingtime) {
        $booking = new BookingModel();
		
		
		
		$sql = "select * from livestatus ls                
                where ls.scmobileno = ? and ls.appointmentdate=?";

        $liveStatusStarted = false;
		$liveBookingToken = -1;

        $query = $this->db->query($sql, array($scmobileno,$bookingdate));
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $liveStatusStarted = true;
				$liveBookingToken = $row->currentbookingno;
            }
        }		
		
		if($bookingtoken!=null && $bookingtime==null && $bookingtoken <= $liveBookingToken)
		{
			return -7; // Appointment expired
		}
		if($bookingtime!=null)
		{
			date_default_timezone_set('Asia/Kolkata');			
			$nowTime = date("H:i");
			$nowTimeH = (int)substr($nowTime, 0, 2);
			$bookingtimeH = (int)substr($bookingtime, 0, 2);
			
			$nowTimeM = (int) substr($nowTime, 3, 2);
			$bookingtimeM = (int)substr($bookingtime, 3, 2);
			
			if($bookingtimeH <= $nowTimeH)
			{
				if($bookingtimeH == $nowTimeH)
				{
					
					if($bookingtimeM <= $nowTimeM)
					{
						return -7;
					}
					
				}
				else
				{
					return -7;
				}
			}
		}
		
		

//  echo "MembertreeValue" . $membertree;
        $sql = "select * from membertree mt                
                where mt.fullnamemt = ?";

        $membertreeid = 0;

        $query = $this->db->query($sql, array($membertree));
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $membertreeid = $row->membertreeid;
            }
        }

        $bookingPrev = 0;
        date_default_timezone_set('Asia/Kolkata');
        $currentdate = date('Y-m-d');
        $sql = "select * from booking where mmobileno=? and cmobileno=? and scmobileno=? and membertreeid=? and status='B' and bookingdate >= ?";

        $query = $this->db->query($sql, array($mmobileno, $cmobileno, $scmobileno, $membertreeid, $currentdate));
		//echo $mmobileno . "_" . $cmobileno . "_" . $scmobileno . "_" . $membertreeid . "_" . $currentdate . "_" . $bookingtime . "_" . $bookingtoken;
        if ($query->num_rows() > 0) {
            $bookingPrev = 1;			
        }		
		
				


 //  echo "MemID" . $membertreeid . "MMNO" . $mmobileno . "CMNO" . $cmobileno . "BDATE" . $bookingdate . "BT" . $bookingtoken;
$bookingAlready = false;
        if ($bookingPrev == 0) {
            $bookingAlready = false;

            $booking->bookingdate = $bookingdate;
            if($bookingtime == null) {
                $booking->bookingno = $bookingtoken;
                $booking->bookingtime = NULL;
                $booking->token = strval("Token No. - " . $bookingtoken);

                $sql = "select * from booking b              
                where b.scmobileno=? && b.bookingdate=? && b.bookingno=? && b.status='B'";

		//		echo $cmobileno . "_" . $bookingdate . "_" . $bookingtoken;
                $query = $this->db->query($sql, array($scmobileno, $bookingdate, $bookingtoken));
                if ($query->num_rows() > 0) {
                    $bookingAlready = true;					
                }
            } else {

                $sql = "select * from booking b              
                where b.scmobileno=? && b.bookingdate=? && b.bookingtime=? && b.status='B'";

				//echo "Z" . $cmobileno . "_" . $bookingdate . "_" . $bookingtoken;
                $query = $this->db->query($sql, array($scmobileno, $bookingdate, $bookingtoken));
                if ($query->num_rows() > 0) {
                    $bookingAlready = true;
                }

                $booking->bookingtime = $bookingtoken;
                $booking->bookingno = NULL;
              //  $booking->token = strval("Timing - " + $bookingtoken);
            }

            $booking->mmobileno = $mmobileno;
            $booking->cmobileno = $cmobileno;
            $booking->scmobileno = $scmobileno;

            date_default_timezone_set('Asia/Kolkata');
            $timestamp = date("Y-m-d H:i:s");
            $booking->applicationdate = $timestamp;



            $convert_date = strtotime($bookingdate);
            $dt = date('j', $convert_date);
            $month = date('M', $convert_date);

            $booking->bookingdatedisplay = $dt . " " . $month;

			
            if ($bookingAlready == false) {

                $data = array('membertreeid' => $membertreeid, 'mmobileno' => $booking->mmobileno, 'scmobileno' => $booking->scmobileno, 'cmobileno' => $booking->cmobileno, 'bookingno' =>
                    $booking->bookingno, 'bookingtime' => $booking->bookingtime, 'bookingdate' => $booking->bookingdate, 'applicationdate' =>
                    $booking->applicationdate);

                $this->db->insert('booking', $data);

                $booking->bookingid = $this->db->insert_id();
//TODO Removed this after timing update
                //if (is_numeric($booking->bookingid)) {
                    $sql = "UPDATE clientavailability 
                SET availability= availability- 1
                WHERE cmobileno = ? and scmobileno=? and date = ?
                and availability> 0";

                    $membertreeid = 0;

                    $query = $this->db->query($sql, array($cmobileno, $scmobileno, $bookingdate));

///get dETAILS
                    $sql = "select * from booking b
left outer join clientprofile cp on cp.cmobileno = b.cmobileno
left outer join subclientprofile scp on scp.scmobileno = b.scmobileno
left outer join clientcategoryconnect ccc on ccc.clientcategoryconnectid=scp.clientcategoryconnectidsc
left outer join clientcategory cc on cc.clientcatid = ccc.clientcatid
left outer join clientsubcategory csc on csc.clientsubcatid = ccc.clientsubcatid
left outer join membertree mt on mt.membertreeid = b.membertreeid
where b.bookingid=?";
                    $query = $this->db->query($sql, array($booking->bookingid));
                    if ($query->num_rows() > 0) {
                        foreach ($query->result() as $row) {
                            $membertree2 = new MemberTreeModel();
                            $membertree2->age = $row->agemt;
                            $membertree2->fullname = $row->fullnamemt;
                            $membertree2->membertreeid = $row->membertreeid;
                            $booking->membertreeModel = $membertree2;

                            $booking->status = 'B';

                            $clientModel = new ClientModel();
                            $clientModel->addr1 = $row->addr1;
                            $clientModel->addr2 = $row->addr2;
                            $clientModel->alternatestatus = $row->alternatestatus;
                            $clientModel->bookingnos = $row->bookingnos;

                            $clientModel->client = $row->client;
                            $clientModel->closetime = $row->closetime;
                            $clientModel->cmobileno = $row->cmobileno;
                            $clientModel->emailid = $row->emailid;
                            $clientModel->fullname = $row->fullname;
                            $clientModel->lat = $row->lat;
                            $clientModel->lon = $row->lon;
                            $clientModel->opentime = $row->opentime;
                            $clientModel->phoneno = $row->phoneno;
                            $clientModel->website = $row->website;

                            $subClient = new SubClientModel();
                            $subClient->addr1 = $row->addr1sc;
                            $subClient->addr2 = $row->addr2sc;


                            $categoryModel = new CategoryModel();
                            $categoryModel->category = $row->category;
                            $categoryModel->categoryid = $row->clientcategoryconnectid;
                            $categoryModel->subcategory = $row->subcategory;
                            $subClient->categoryModel = $categoryModel;

                            $subClient->emailid = $row->emailidsc;
                            $subClient->fullname = $row->fullnamesc;
                            $subClient->lat = $row->latsc;
                            $subClient->lon = $row->lonsc;

                            $subClient->phoneno = $row->phonenosc;
                            $subClient->rating = $row->ratingsc;
                            $subClient->reservedschedule = $row->reservedschedule;
                            $subClient->reviewers = $row->reviewerssc;
                            $subClient->website = $row->websitesc;





                            $clientModel->subClient = $subClient;
                            $booking->clientModel = $clientModel;
                        
                    }
                }

                return $booking;
            } else {
                return -1; //Appointment already booked for the selected date & Time or Token
            }
        } else {
            return -2; //Appointment already taken by the customer
        }
    }

    public function cancelBooking($bookingid) {

        $sql = "UPDATE booking
                SET status= 'C'
                WHERE bookingid= ?";

        $query = $this->db->query($sql, array($bookingid));
        $sql = "select * from booking                
                where bookingid = ?";

        $query = $this->db->query($sql, array($bookingid));
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $bdate = $row->bookingdate;
            }
        }


        if ($this->db->affected_rows() > 0) {

            $sql = "UPDATE clientavailability
                SET availability= availability+1
                WHERE date= ?";

            $query = $this->db->query($sql, array($bdate));


            return 1;
        } else {
            return 0;
        }
    }

    public function getBookingAvail($clientid, $bookingdate, $scmobileno) {

//If its today then show availability according to live status token_get_all
// Check the status and accordingly display the bookings

        $sql = "select * from booking b
                left outer join clientsublink csl on csl.scmobileno = b.scmobileno and csl.cmobileno = b.cmobileno                
                where b.cmobileno = ? && b.bookingdate=? && b.scmobileno = ? && b.status='B'
                order by b.bookingno, b.bookingtime";

        $query = $this->db->query($sql, array($clientid, $bookingdate, $scmobileno));

        $bookingModel = array();
        $i = 0;
        $bookednosList = array();
        $bookedTimeList = array();

        $bookingnos = -1;
        $bookingTime = -1;


        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $bookingnos = $row->bookingnossc;
				$bookingTime = $row->bookingintervalsc;
                if ($row->bookingintervalsc == null) {
                    $startTokenDB = $row->starttokensc; //Either E or O
                    if ($startTokenDB == "E") {
                        $startToken = 2;
                    } else {
                        $startToken = 1;
                    }
                    $alternateToken = $row->alternatestatussc;
					$bookingTime=-1;
                    array_push($bookednosList, $row->bookingno);
                } else {
					$bookingnos= -1;
                    $openTime = $row->opentimesc;
                    $closeTime = $row->closetimesc;
                    $alternateToken = $row->alternatestatussc;
                    $bookingInterval = $row->bookingintervalsc;
                    if ($alternateToken == 'Y') {
                        $bookingInterval = $bookingInterval * 2;
                    }
                    $startTokenDB = $row->starttokensc; //Either E or O
                    if ($startTokenDB == "O") {
						$startToken = 1;
                        $startTime = strtotime($openTime) + ($bookingInterval * 60);						
                    } else {
                        $startTime = $openTime;
						$startToken = 2;
                    }					
                    array_push($bookedTimeList, date( "H:i", strtotime($row->bookingtime)));
                }
            }
        }
        if ($bookingnos != -1) {
			
			
			$sql2 = "select * from clientsublink csl                               
left outer join clientavailability ca on ca.cmobileno=csl.cmobileno and ca.scmobileno=csl.scmobileno
where csl.cmobileno = ? && csl.scmobileno = ? && ca.date=?";

            $query = $this->db->query($sql2, array($clientid, $scmobileno, $bookingdate));

            if ($query->num_rows() > 0) {
               foreach ($query->result() as $row) {
                    $bookingnos = $row->bookingnossc;
					$status = $row->status;
					break;
			   }
		  }
					
					if($status == 'C')
					{
						$bookingnos=0;
					}
					else
					{
					
					if($status == 'H')
					{
						$startToken = 1;
						$bookingnos = $bookingnos/2;
					}
					else if($status == 'S')
					{
						$startToken = ($bookingnos/2)+1;
					}
					else if($status == 'F')
					{
						$startToken = 1;
					}
					
									
					

                    if ($row->bookingintervalsc == null) {
                        $startTokenDB = $row->starttokensc; //Either E or O
                        if ($startTokenDB == "E") {
                            $startToken = $startToken+1;
                        } else {
                            $startToken = $startToken;
                        }
                        $alternateToken = $row->alternatestatussc;
					}
			
			
			
			
			
			
			
			
            while ($startToken <= $bookingnos) {

                if (in_array($startToken, $bookednosList)) {
                    
                } else {
                    $bookingModel[$i] = new BookingModel();
                    $bookingModel[$i]->bookingno = $startToken;
                    $i++;
                }
                if ($alternateToken == "Y") {
                    $startToken = $startToken + 2;
                } else {
                    $startToken = $startToken + 1;
                }
            }
					}
        } else if ($bookingTime != -1) {						
			
						$bookingnos = $row->bookingnossc;						
                        $openTime = $row->opentimesc;
                        $closeTime = $row->closetimesc;
                        $alternateToken = $row->alternatestatussc;
                        $bookingInterval = $row->bookingintervalsc;
						$breaktime = $row->breaktime;
						$breakintervaltime = $row->breakintervaltime;
						$starttime = null;
						$startTokenDB = $row->starttokensc; //Either E or O
                        if ($startTokenDB == "E") {
                            $starttime = date( "H:i", strtotime($openTime)+(60*$bookingInterval));
							$startToken=2;
													
                        } else {
                            $starttime = date("H:i" , strtotime($openTime));
							$startToken=1;
                        }
						
						$startToken=1;
						$i=0;						
						while($startToken <= $bookingnos)
						{															
							 if (in_array(date( "H:i", strtotime($starttime)), $bookedTimeList) )
							 {
                        
						} 
						else 
						{
                    
							$bookingModel[$i] = new BookingModel();
							$bookingModel[$i]->bookingtime = $starttime;
							
							$i++;		
						}							
					
							if ($alternateToken == 'Y') {
								$starttime = date( "H:i", strtotime($starttime)+(60*$bookingInterval));
								if(date( "H:i", strtotime($starttime)) == date( "H:i", strtotime($breaktime)))
								{
									$starttime = date( "H:i", strtotime($breaktime)+(60*$breakintervaltime));
								
								}
								$starttime = date( "H:i", strtotime($starttime)+(60*$bookingInterval));
								$startToken = $startToken+2;
								
							}
							else
							{	$starttime = date( "H:i", strtotime($starttime)+(60*$bookingInterval));
								$startToken = $startToken+1;	
								
							}	
														
							
							
							if(date( "H:i", strtotime($starttime)) == date( "H:i", strtotime($breaktime)))
							{
								$starttime = date( "H:i", strtotime($breaktime)+(60*$breakintervaltime));
								
								
							}
						}
						
            
			
			
			
        } else {
						
										
            $sql2 = "select * from clientsublink csl                               
left outer join clientavailability ca on ca.cmobileno=csl.cmobileno and ca.scmobileno=csl.scmobileno
where csl.cmobileno = ? && csl.scmobileno = ? && ca.date=?";

            $query = $this->db->query($sql2, array($clientid, $scmobileno, $bookingdate));

            if ($query->num_rows() > 0) {
                foreach ($query->result() as $row) {
                    $bookingnos = $row->bookingnossc;
					$status = $row->status;
					
					if($status == 'C')
					{
						$bookingnos=0;
					}
					else
					{
					
					if($status == 'H')
					{
						$startToken = 1;
						$bookingnos = $bookingnos/2;
					}
					else if($status == 'S')
					{
						$startToken = ($bookingnos/2)+1;
						$bookingnos = $bookingnos/2;
					}
					else if($status == 'F')
					{
						$startToken = 1;
					}
									
					

                    if ($row->bookingintervalsc == null) {
                        $startTokenDB = $row->starttokensc; //Either E or O
                        if ($startTokenDB == "E") {
                            $startToken = $startToken+1;
                        } else {
                            $startToken = $startToken;
                        }
                        $alternateToken = $row->alternatestatussc;


                        while ($startToken <= $bookingnos) {

                            $bookingModel[$i] = new BookingModel();
                            $bookingModel[$i]->bookingno = $startToken;
                            $i++;
                            if ($alternateToken == 'Y') {
                                $startToken = $startToken + 2;
                            } else {
                                $startToken = $startToken + 1;
                            }
                        }
                    } else {
						if($status == 'H' || $status == 'S')
						{
						$startToken = 1;
						$bookingnos = $bookingnos/2;
						}
						//$bookingnos = $row->bookingnossc;						
                        $openTime = $row->opentimesc;
                        $closeTime = $row->closetimesc;
                        $alternateToken = $row->alternatestatussc;
                        $bookingInterval = $row->bookingintervalsc;
						$breaktime = $row->breaktime;
						$breakintervaltime = $row->breakintervaltime;
						$starttime = null;
						$startTokenDB = $row->starttokensc; //Either E or O
                        if ($startTokenDB == "E") {
                            $starttime = date( "H:i", strtotime($openTime)+(60*$bookingInterval));
							$startToken=$startToken+1;
													
                        } else {
                            $starttime = $openTime;
							$startToken=$startToken;
                        }
						
						//$startToken=1;
						$i=0;						
						while($startToken <= $bookingnos)
						{							
							$bookingModel[$i] = new BookingModel();
							$bookingModel[$i]->bookingtime = $starttime;
							
							$i++;					
					
							if ($alternateToken == 'Y') {
								$starttime = date( "H:i", strtotime($starttime)+(60*$bookingInterval));
								if(date( "H:i", strtotime($starttime)) == date( "H:i", strtotime($breaktime)))
								{
									$starttime = date( "H:i", strtotime($breaktime)+(60*$breakintervaltime));
								
								}
								$starttime = date( "H:i", strtotime($starttime)+(60*$bookingInterval));
								$startToken = $startToken+2;
								
							}
							else
							{	$starttime = date( "H:i", strtotime($starttime)+(60*$bookingInterval));
								$startToken = $startToken+1;	
								
							}
						
														
							
							
							if(date( "H:i", strtotime($starttime)) == date( "H:i", strtotime($breaktime)))
							{
								$starttime = date( "H:i", strtotime($breaktime)+(60*$breakintervaltime));
								
								
							}
						}
							
						}
                        
                    }
			break;	}
                }
            }
        

        return $bookingModel;
    }

    public function getTodayMerchantBooking($cmobileno) {
        date_default_timezone_set("Asia/Calcutta");
        $today = date("Y-m-d");
        $sql = "select * from booking b
                inner join clientavailability ca on ca.date = b.bookingdate
                left outer join membertree mt on mt.membertreeid=b.membertreeid
                where b.cmobileno=? and b.bookingdate=? and b.status='B'
                order by bookingtime,bookingno";

        $query = $this->db->query($sql, array($cmobileno, $today));

        $bookings = array();
        $totalCount = -1;
        $bookingno = 1;
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $totalCount = $row->total;
                while ($bookingno != $row->bookingno) {
                    $bookings[$bookingno] = new BookingModel();
                    $bookings[$bookingno]->bookingno = $bookingno;
                    $bookingno++;
                }


                $bookings[$row->bookingno] = new BookingModel();
                $bookings[$row->bookingno]->applicationdate = $row->applicationdate;
                $bookings[$row->bookingno]->bookingdate = $row->bookingdate;
                $bookings[$row->bookingno]->bookingid = $row->bookingid;
                $bookings[$row->bookingno]->bookingno = $row->bookingno;
                $bookings[$row->bookingno]->bookingtime = $row->bookingtime;
                $bookings[$row->bookingno]->mmobileno = $row->mmobileno;
                $bookings[$row->bookingno]->note = $row->note;
                $memberTreeModel = new MemberTreeModel();

                $memberTreeModel->age = $row->memage;
                $memberTreeModel->fullname = $row->memfullname;
                $memberTreeModel->membertreeid = $row->membertreeid;

                $bookings[$row->bookingno]->membertreeModel = $memberTreeModel;
                $bookingno++;
            }
        }

        while ($bookingno <= $totalCount) {
            $bookings[$bookingno] = new BookingModel();
            $bookings[$bookingno]->bookingno = $bookingno;
            $bookingno++;
        }


        echo json_encode($bookings);
    }

    function saveDataInDB($bookingid, $clientid) {

        $data = array('bookingid' => $bookingid, 'clientid' => $clientid, 'date' => date("d-m-y"));

        $this->db->insert('bookingarduino', $data);

        return $this->db->insert_id();
    }

    function doBookingFromClient($cmobileno, $scmobileno, $mmobileno, $mfullname, $bookingdate, $bookingno, $bookingtiming, $selfname) {

        $membertreeid = 0;
        $memberExist = 0;

        //Check if member exists
        $sql = "select * from memberprofile
                where mmobileno=?";

        $query = $this->db->query($sql, array($mmobileno));


        $fullnamearr = explode(' ', trim($mfullname));
        $fnameE = $fullnamearr[0];
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $memberExist = 1;
//If member exist check if bookiong for self or not
                if ($selfname != null && trim($selfname, " ") != "") {
                    $mfullname = $row->fullnamem;
                } else {
//if booking for someone else check if the member exist
                    $sql2 = "select * from membertree
                            where mmobilenomt=?";
                    $memberTreeExist = 0;
                    $query2 = $this->db->query($sql2, array($mmobileno));
                    if ($query2->num_rows() > 0) {
                        foreach ($query2->result() as $roww) {
                            $fullnamemt = $roww->fullnamemt;
                            $arr = explode(' ', trim($fullnamemt));
                            $fname = $arr[0];
//if member exist then get the membertree if
                            if ($fname == $fnameE) {
                                $membertreeid = $roww->membertreeid;
                                $memberTreeExist = 1;
                            }
                        }
                    }
                    if (!$memberTreeExist) {

//else create a new membertree member
                        $data = array('mmobilenomt' => $mmobileno, 'fullnamemt' => $mfullname);
                        $this->db->insert('membertree', $data);
                        $membertreeid = $this->db->insert_id();
                    }
                }
            }
        }
//if member doesn't exist then....e
//Check if you need to create record in membertreee or not
//TODO
        if ($memberExist) {
            date_default_timezone_set('Asia/Kolkata');
            $timestamp = date('Y-m-d H:i:s');
            $data = array('membertreeid' => $membertreeid, 'mmobileno' => $mmobileno, 'cmobileno' => $cmobileno, 'scmobileno' => $scmobileno, 'scmobileno' => $scmobileno, 'bookingdate' => $bookingdate, 'bookingno' => $bookingno, 'status' => 'B','applicationdate'=>$timestamp);
            $this->db->insert('booking', $data);

            $sql = "UPDATE clientavailability 
                SET availability= availability- 1
                WHERE cmobileno = ? and scmobileno=? and date = ?
                and availability> 0";

            $query = $this->db->query($sql, array($cmobileno, $scmobileno, $bookingdate));
            return 1;
        } else {
            if ($selfname != null && trim($selfname, " ") != "") {
                $ageNA = -1;
                $data = array('mmobilenomt' => $mmobileno, 'fullnamemt' => $mfullname, 'agemt' => $ageNA);
                $this->db->insert('membertree', $data);
                $membertreeid = $this->db->insert_id();
                //Enter record into login
                $data = array('mobileno' => $mmobileno, 'active' => 'N', 'type' => 'C');
                $this->db->insert('login', $data);


                //Enter record into memberprofile
                $data = array('mmobileno' => $mmobileno, 'fullnamem' => $selfname);
                $this->db->insert('memberprofile', $data);

                date_default_timezone_set('Asia/Kolkata');
        $timestamp = date('Y-m-d H:i:s');
		
                $data = array('membertreeid' => $membertreeid, 'mmobileno' => $mmobileno, 'cmobileno' => $cmobileno, 'scmobileno' => $scmobileno, 'scmobileno' => $scmobileno, 'bookingdate' => $bookingdate, 'bookingno' => $bookingno, 'status' => 'B','applicationdate' =>$timestamp);
                $this->db->insert('booking', $data);

                $sql = "UPDATE clientavailability 
                SET availability= availability- 1
                WHERE cmobileno = ? and scmobileno=? and date = ?
                and availability> 0";

                $query = $this->db->query($sql, array($cmobileno, $scmobileno, $bookingdate));

                return 2;
            } else {
                //Enter record into login
                $data = array('mobileno' => $mmobileno, 'active' => 'N', 'type' => 'C');
                $this->db->insert('login', $data);


                //Enter record into memberprofile
                $data = array('mmobileno' => $mmobileno, 'fullnamem' => $mfullname);
                $this->db->insert('memberprofile', $data);
                $membertreeid = 0;
                date_default_timezone_set('Asia/Kolkata');
        $timestamp = date('Y-m-d H:i:s');
				if($bookingtiming != null)
				{
					$data = array('membertreeid' => $membertreeid, 'mmobileno' => $mmobileno, 'cmobileno' => $cmobileno, 'scmobileno' => $scmobileno, 'scmobileno' => $scmobileno, 'bookingdate' => $bookingdate, 'bookingtime' => $bookingtiming, 'status' => 'B','applicationdate'=>$timestamp);
				}
				else
				{
					$data = array('membertreeid' => $membertreeid, 'mmobileno' => $mmobileno, 'cmobileno' => $cmobileno, 'scmobileno' => $scmobileno, 'scmobileno' => $scmobileno, 'bookingdate' => $bookingdate, 'bookingno' => $bookingno, 'status' => 'B','applicationdate'=>$timestamp);
				}
                $this->db->insert('booking', $data);
                return 3;
            }
        }
    }

}
