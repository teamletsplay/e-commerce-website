<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ForgotPasswordModel
 *
 * @author PC
 */
class ForgotPasswordModel extends CI_Model {

    public function validateOtp($mmobileno, $otp) {
        $sql = "select * from login where mobileno = ? and type='C'";
        $query = $this->db->query($sql, array($mmobileno));

        $otpfromdb = -2;

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $attempt = $row->attempt;
                if ($attempt < 5) {
                    $otpfromdb = $row->otp;
                }
            }
        }

        if ($otp != $otpfromdb) {
            $sql = "UPDATE login 
                SET attempt= attempt+1
                WHERE mobileno = ?";

            $query = $this->db->query($sql, array($mmobileno));
        }

        if ($otp == $otpfromdb) {
            return 1; //Otp matchese...
        } else if ($otpfromdb == -2) {
            return -5; //attempts over....
        } else {
            return -7; //otp doesn't match...
        }
    }
    
    public function updateMemberPassword($mmobileno, $password) {
        
        $sql = "UPDATE login 
                SET password= ?
                WHERE mobileno = ?";

        $query = $this->db->query($sql, array($password,$mmobileno));
        
        return 1;
    }
    

}
