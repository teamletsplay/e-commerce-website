<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-09-17 00:00:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:00:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:00:19 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:00:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:00:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:00:20 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:00:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:00:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:00:20 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:00:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:00:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:00:20 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:00:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:00:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:00:21 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:00:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:00:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:00:21 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:00:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:00:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:00:21 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:00:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:00:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:00:21 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:00:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:00:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:00:29 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:01:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:01:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:01:11 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:01:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:01:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:01:11 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:01:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:01:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:01:11 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:01:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:01:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:01:12 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:01:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:01:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:01:12 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:01:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:01:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:01:12 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:01:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:01:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:01:13 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:01:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:01:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:01:13 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:01:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:01:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:01:13 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:01:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:01:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:01:13 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:01:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:01:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:01:14 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:01:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:01:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:01:14 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:01:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:01:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:01:14 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:01:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:01:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:01:15 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:01:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:01:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:01:15 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:01:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:01:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:01:15 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:01:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:01:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:01:15 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:01:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:01:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:01:16 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:01:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:01:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:01:16 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:01:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:01:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:01:16 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:01:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:01:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:01:16 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:01:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:01:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:01:17 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:01:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:01:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:01:17 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:01:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:01:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:01:17 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:01:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:01:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:01:17 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:01:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:01:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:01:18 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:02:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:02:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:02:04 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:02:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:02:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:02:04 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:02:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:02:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:02:05 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:02:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:02:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:02:05 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:02:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:02:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:02:05 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:02:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:02:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:02:05 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:02:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:02:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:02:06 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:02:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:02:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:02:06 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:02:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:02:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:02:06 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:02:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:02:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:02:07 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:02:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:02:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:02:07 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:02:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:02:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:02:07 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:02:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:02:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:02:09 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:02:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:02:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:02:09 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:02:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:02:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:02:10 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:02:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:02:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:02:10 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:02:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:02:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:02:11 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:02:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:02:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:02:11 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:02:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:02:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:02:11 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:02:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:02:26 --> No URI present. Default controller set.
DEBUG - 2023-09-17 00:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 00:02:26 --> initController - LoginPage.php
DEBUG - 2023-09-17 00:02:26 --> Total execution time: 0.0189
DEBUG - 2023-09-17 00:02:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:02:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:02:26 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 00:03:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:03:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:03:08 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:03:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:03:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:03:08 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:03:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:03:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:03:08 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:03:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:03:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:03:09 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:03:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:03:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:03:35 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:03:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:03:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:03:35 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:03:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:03:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:03:35 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:03:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:03:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:03:36 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:03:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:03:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:03:36 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:04:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:04:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:04:00 --> 404 Page Not Found: Crud/insert
DEBUG - 2023-09-17 00:05:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:05:32 --> No URI present. Default controller set.
DEBUG - 2023-09-17 00:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 00:05:32 --> initController - LoginPage.php
DEBUG - 2023-09-17 00:05:32 --> Total execution time: 0.0217
DEBUG - 2023-09-17 00:05:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:05:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:05:32 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 00:05:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 00:05:34 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-17 00:05:34 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-17 00:05:34 --> Total execution time: 0.0222
DEBUG - 2023-09-17 00:05:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:05:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:05:34 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 00:05:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 00:05:37 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-17 00:05:37 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-17 00:05:37 --> Total execution time: 0.0210
DEBUG - 2023-09-17 00:05:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:05:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:05:37 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 00:06:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 00:06:10 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-17 00:06:10 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-17 00:06:10 --> Total execution time: 0.0225
DEBUG - 2023-09-17 00:06:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:06:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:06:10 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 00:06:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 00:06:59 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-17 00:06:59 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-17 00:06:59 --> Total execution time: 0.0210
DEBUG - 2023-09-17 00:07:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:07:00 --> No URI present. Default controller set.
DEBUG - 2023-09-17 00:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 00:07:01 --> initController - LoginPage.php
DEBUG - 2023-09-17 00:07:01 --> Total execution time: 0.0208
DEBUG - 2023-09-17 00:07:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:07:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:07:01 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 00:07:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:07:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:07:09 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:08:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:08:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:08:05 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:08:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:08:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:08:05 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:08:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:08:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:08:05 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:08:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:08:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:08:06 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:08:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:08:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:08:06 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:08:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:08:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:08:24 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:08:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:08:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:08:47 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:08:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:08:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:08:47 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:08:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:08:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:08:47 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:08:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:08:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:08:48 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:09:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:09:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:09:17 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:09:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:09:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:09:17 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:09:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:09:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:09:18 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:09:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:09:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:09:18 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:09:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:09:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:09:18 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:09:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:09:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:09:18 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:11:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:11:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:11:01 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:11:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:11:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:11:02 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:11:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:11:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:11:02 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:11:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:11:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:11:02 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:11:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:11:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:11:02 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:11:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:11:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:11:02 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:11:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:11:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:11:03 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:11:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:11:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:11:03 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:11:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:11:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:11:03 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:11:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:11:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:11:03 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:11:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:11:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:11:03 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:11:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:11:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:11:04 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:11:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:11:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:11:04 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:11:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:11:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:11:04 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:11:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:11:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:11:05 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:11:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:11:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:11:43 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:11:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:11:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:11:44 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:11:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:11:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:11:44 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:11:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:11:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:11:44 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:11:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:11:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:11:44 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:11:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:11:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:11:45 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:11:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:11:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:11:45 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:11:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:11:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:11:46 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:11:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:11:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:11:47 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:11:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:11:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:11:49 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:11:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:11:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:11:49 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:12:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:12:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:12:48 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:12:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:12:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:12:49 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:12:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:12:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:12:49 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:12:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:12:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:12:49 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:12:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:12:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:12:50 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:14:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:14:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:14:48 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:14:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:14:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:14:48 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:14:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:14:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:14:48 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:14:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:14:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:14:49 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:14:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:14:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:14:49 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:14:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:14:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:14:49 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:16:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:16:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:16:25 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:16:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:16:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:16:25 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:16:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:16:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:16:25 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:16:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:16:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:16:25 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:16:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:16:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:16:33 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:16:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:16:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:16:41 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:18:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:18:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:18:33 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:18:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:18:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:18:33 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:18:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:18:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:18:33 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:18:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:18:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:18:34 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:18:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:18:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:18:34 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:18:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:18:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:18:34 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:18:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:18:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:18:57 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:18:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:18:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:18:58 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:18:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:18:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:18:58 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:18:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:18:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:18:58 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:18:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:18:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:18:58 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:18:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:18:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:18:59 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:18:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:18:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:18:59 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:18:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:18:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:18:59 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:18:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:18:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:18:59 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:18:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:18:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:18:59 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:18:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:18:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:18:59 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:19:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:19:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:19:45 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:19:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:19:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:19:46 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:19:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:19:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:19:46 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:19:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:19:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:19:46 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:19:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:19:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:19:47 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:19:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:19:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:19:47 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:19:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:19:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:19:47 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:19:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:19:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:19:47 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:19:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:19:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:19:47 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:19:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:19:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:19:48 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:19:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:19:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:19:48 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:19:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:19:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:19:48 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:19:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:19:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:19:48 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:19:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:19:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:19:49 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:19:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:19:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:19:49 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:19:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:19:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:19:49 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:19:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:19:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:19:49 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:19:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:19:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:19:50 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:19:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:19:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:19:50 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:19:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:19:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:19:50 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:20:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:20:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:20:35 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:20:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:20:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:20:36 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:20:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:20:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:20:36 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:20:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:20:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:20:36 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:21:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:21:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:21:11 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:22:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:22:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:22:17 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:22:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:22:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:22:18 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:22:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:22:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:22:18 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:22:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:22:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:22:18 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:22:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:22:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:22:18 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:22:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:22:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:22:44 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:22:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:22:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:22:44 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:22:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:22:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:22:44 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:22:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:22:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:22:45 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:22:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:22:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:22:45 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:22:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:22:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:22:45 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:22:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:22:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:22:45 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:22:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:22:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:22:45 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:23:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:23:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:23:07 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 00:29:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:29:02 --> No URI present. Default controller set.
DEBUG - 2023-09-17 00:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 00:29:02 --> initController - LoginPage.php
DEBUG - 2023-09-17 00:29:02 --> Total execution time: 0.0233
DEBUG - 2023-09-17 00:29:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:29:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:29:02 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 00:29:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 00:29:05 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-17 00:29:05 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-17 00:29:05 --> Total execution time: 0.0238
DEBUG - 2023-09-17 00:29:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:29:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:29:05 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 00:29:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 00:29:09 --> initController - LoginPage.php
DEBUG - 2023-09-17 00:29:09 --> Total execution time: 0.0210
DEBUG - 2023-09-17 00:29:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:29:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:29:09 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 00:29:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:29:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:29:20 --> 404 Page Not Found: Cyrd/index
DEBUG - 2023-09-17 00:29:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:29:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:29:36 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:31:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:31:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:31:01 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:31:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:31:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:31:01 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:31:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:31:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:31:02 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:33:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:33:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:33:01 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:33:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:33:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:33:02 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:33:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:33:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:33:02 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:33:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:33:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:33:02 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:33:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:33:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:33:02 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:34:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:34:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:34:30 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:34:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:34:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:34:30 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:34:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:34:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:34:31 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:34:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:34:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:34:31 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:34:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:34:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:34:31 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:34:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:34:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:34:31 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:37:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:37:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:37:30 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:37:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:37:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:37:30 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:37:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:37:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:37:31 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:37:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:37:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:37:31 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:38:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:38:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:38:00 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:38:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:38:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:38:03 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:38:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:38:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:38:03 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:38:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:38:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:38:03 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:38:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:38:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:38:03 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:38:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:38:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:38:03 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:38:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:38:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:38:03 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:38:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:38:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:38:04 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:38:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:38:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:38:04 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:40:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:40:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:40:24 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:40:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:40:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:40:24 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:40:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:40:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:40:24 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:40:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:40:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:40:25 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:40:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:40:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:40:25 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:40:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:40:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:40:25 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:40:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:40:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:40:25 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:40:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:40:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:40:25 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:40:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:40:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:40:26 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:40:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:40:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:40:26 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:40:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:40:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:40:26 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:41:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:41:22 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:41:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:41:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:41:23 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:41:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:41:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:41:23 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:41:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:41:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:41:23 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:41:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:41:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:41:23 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:42:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:42:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:42:13 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:42:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:42:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:42:13 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:42:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:42:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:42:13 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:42:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:42:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:42:14 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:42:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:42:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:42:14 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:42:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:42:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:42:14 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:42:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:42:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:42:14 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:42:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:42:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:42:14 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:42:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:42:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:42:15 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:42:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:42:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:42:15 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:42:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:42:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:42:15 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:42:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:42:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:42:15 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:42:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:42:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:42:15 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:42:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:42:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:42:16 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:42:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:42:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:42:16 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:43:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:43:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:43:58 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:43:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:43:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:43:59 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:43:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:43:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:43:59 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:43:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:43:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:43:59 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:43:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:43:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:43:59 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:43:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:43:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:43:59 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:44:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:44:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:44:00 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:44:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:44:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:44:00 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:44:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:44:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:44:00 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:44:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:44:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:44:00 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:44:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:44:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:44:00 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:44:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:44:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:44:01 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:44:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:44:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:44:39 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:44:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:44:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:44:40 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:44:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:44:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:44:40 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:44:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:44:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:44:40 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:44:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:44:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:44:40 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:44:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:44:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:44:40 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:44:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:44:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:44:41 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:44:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:44:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:44:41 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:44:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:44:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:44:41 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:44:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:44:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:44:41 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:44:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:44:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:44:41 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:44:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:44:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:44:41 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:44:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:44:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:44:42 --> 404 Page Not Found: Curry/index
DEBUG - 2023-09-17 00:44:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 00:44:57 --> initController - LoginPage.php
DEBUG - 2023-09-17 00:44:57 --> Total execution time: 0.0506
DEBUG - 2023-09-17 00:44:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:44:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:44:57 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 00:46:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:46:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:46:47 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:47:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 00:47:07 --> initController - LoginPage.php
DEBUG - 2023-09-17 00:47:07 --> Total execution time: 0.0449
DEBUG - 2023-09-17 00:47:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:47:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:47:07 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 00:49:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:49:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:49:23 --> No URI present. Default controller set.
DEBUG - 2023-09-17 00:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 00:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 00:49:23 --> initController - LoginPage.php
DEBUG - 2023-09-17 00:49:23 --> Total execution time: 0.0517
DEBUG - 2023-09-17 00:49:23 --> initController - LoginPage.php
DEBUG - 2023-09-17 00:49:23 --> Total execution time: 0.0531
DEBUG - 2023-09-17 00:49:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:49:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:49:23 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 00:49:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:49:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:49:23 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 00:49:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:49:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:49:31 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:51:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:51:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:51:14 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:51:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:51:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:51:14 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:51:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:51:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:51:14 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:51:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:51:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:51:14 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:51:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:51:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:51:14 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:51:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:51:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:51:14 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:51:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:51:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:51:15 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:51:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:51:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:51:15 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:51:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:51:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:51:15 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:51:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:51:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:51:15 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:51:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:51:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:51:15 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:51:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:51:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:51:16 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:51:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:51:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:51:16 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:51:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:51:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:51:16 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:51:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:51:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:51:16 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:51:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:51:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:51:16 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:51:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:51:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:51:17 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:51:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:51:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:51:17 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:51:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:51:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:51:17 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:51:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:51:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:51:17 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:51:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:51:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:51:17 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:51:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 00:51:33 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-17 00:51:33 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-17 00:51:33 --> Total execution time: 0.0452
DEBUG - 2023-09-17 00:51:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:51:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:51:33 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 00:52:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:52:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:52:05 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-17 00:52:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:52:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:52:10 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-17 00:53:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 00:53:41 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-17 00:53:41 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-17 00:53:41 --> Total execution time: 0.0448
DEBUG - 2023-09-17 00:53:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:53:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:53:41 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 00:53:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 00:53:57 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-17 00:53:57 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-17 00:53:57 --> Total execution time: 0.0424
DEBUG - 2023-09-17 00:53:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:53:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:53:57 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 00:54:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 00:54:49 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-17 00:54:49 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-17 00:54:49 --> Total execution time: 0.0422
DEBUG - 2023-09-17 00:54:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:54:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:54:49 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 00:55:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:55:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:55:16 --> Severity: error --> Exception: Unclosed '{' on line 6 C:\xampp\htdocs\WebProject\application\controllers\Curd.php 24
DEBUG - 2023-09-17 00:55:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:55:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:55:47 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:21 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:22 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:22 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:22 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:23 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:23 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:23 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:23 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:47 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:48 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:48 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:48 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:49 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:49 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:49 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:49 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:49 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:50 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:50 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:50 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:50 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:50 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:51 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:51 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:51 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:51 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:52 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:52 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:52 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:52 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:52 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:53 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:53 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:53 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:53 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:53 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:54 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:54 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:54 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:56 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:56 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:56 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:57 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:56:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:56:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:56:57 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 00:59:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:59:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:59:07 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 00:59:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:59:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:59:38 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 00:59:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:59:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:59:38 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 00:59:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:59:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:59:39 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 00:59:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:59:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:59:39 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 00:59:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:59:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:59:39 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 00:59:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:59:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:59:39 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 00:59:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:59:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:59:39 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 00:59:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 00:59:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 00:59:40 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 01:01:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:01:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:01:24 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 01:01:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:01:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:01:25 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:01:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:01:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:01:27 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:01:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:01:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:01:27 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:01:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:01:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:01:27 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:01:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:01:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:01:27 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:01:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:01:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:01:27 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:01:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:01:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:01:28 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:01:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:01:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:01:28 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:01:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:01:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:01:28 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:01:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:01:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:01:28 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:01:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:01:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:01:29 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:01:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:01:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:01:29 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:01:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:01:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:01:29 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:01:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:01:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:01:29 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:01:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:01:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:01:30 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:01:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:01:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:01:30 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:01:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:01:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:01:30 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:01:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:01:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:01:30 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:01:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:01:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:01:31 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:01:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:01:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:01:31 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:01:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:01:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:01:31 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:01:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:01:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:01:31 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:01:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:01:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:01:31 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:01:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:01:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:01:32 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:01:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:01:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:01:32 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:01:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:01:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:01:32 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:01:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:01:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:01:59 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:02:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:02:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:02:00 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:02:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:02:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:02:00 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:02:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:02:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:02:00 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:02:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:02:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:02:01 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:02:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:02:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:02:01 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:02:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:02:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:02:01 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:02:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:02:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:02:34 --> Severity: error --> Exception: Unmatched '}' C:\xampp\htdocs\WebProject\application\controllers\Curd.php 35
DEBUG - 2023-09-17 01:02:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:02:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:02:35 --> Severity: error --> Exception: Unmatched '}' C:\xampp\htdocs\WebProject\application\controllers\Curd.php 35
DEBUG - 2023-09-17 01:02:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:02:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:02:56 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:03:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:03:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:03:11 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:03:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:03:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:03:11 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:03:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:03:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:03:24 --> Severity: error --> Exception: syntax error, unexpected token "public", expecting end of file C:\xampp\htdocs\WebProject\application\controllers\Curd.php 11
DEBUG - 2023-09-17 01:03:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:03:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:03:24 --> Severity: error --> Exception: syntax error, unexpected token "public", expecting end of file C:\xampp\htdocs\WebProject\application\controllers\Curd.php 11
DEBUG - 2023-09-17 01:03:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:03:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:03:38 --> Severity: error --> Exception: Unmatched '}' C:\xampp\htdocs\WebProject\application\controllers\Curd.php 20
DEBUG - 2023-09-17 01:03:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:03:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:03:39 --> Severity: error --> Exception: Unmatched '}' C:\xampp\htdocs\WebProject\application\controllers\.php 20
DEBUG - 2023-09-17 01:03:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:03:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:03:47 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:04:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:04:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:04:07 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:04:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:04:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:04:08 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:04:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:04:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:04:08 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:04:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:04:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:04:08 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:04:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:04:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:04:09 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:04:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:04:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:04:09 --> 404 Page Not Found: /index
DEBUG - 2023-09-17 01:04:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:04:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:04:16 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:04:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:04:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:04:17 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:04:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:04:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:04:17 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:04:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:04:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:04:17 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:04:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:04:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:04:39 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:04:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:04:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:04:39 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:04:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:04:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:04:40 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:04:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:04:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:04:40 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:04:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:04:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:04:52 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:04:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:04:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:04:53 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:04:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:04:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:04:53 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:04:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:04:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:04:53 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:04:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:04:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:04:53 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:04:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:04:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:04:54 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:04:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:04:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:04:54 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:09:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:09:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:09:25 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:09:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:09:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:09:25 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:09:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:09:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:09:26 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:09:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:09:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:09:26 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:09:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:09:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:09:26 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:11:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 01:11:23 --> initController - LoginPage.php
DEBUG - 2023-09-17 01:11:23 --> Total execution time: 0.0422
DEBUG - 2023-09-17 01:11:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:11:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:11:23 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 01:11:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 01:11:25 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-17 01:11:25 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-17 01:11:25 --> Total execution time: 0.0502
DEBUG - 2023-09-17 01:11:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:11:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:11:25 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 01:11:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 01:11:25 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-17 01:11:25 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-17 01:11:25 --> Total execution time: 0.0436
DEBUG - 2023-09-17 01:11:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:11:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:11:25 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 01:12:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:12:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:12:45 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:12:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:12:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:12:45 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:12:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:12:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:12:46 --> 404 Page Not Found: Curd/index
DEBUG - 2023-09-17 01:13:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:13:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:13:07 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-17 01:13:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:13:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:13:36 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-17 01:13:36 --> Total execution time: 0.0407
DEBUG - 2023-09-17 01:13:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:13:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:13:36 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 01:13:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:13:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:13:36 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-17 01:13:36 --> Total execution time: 0.0488
DEBUG - 2023-09-17 01:13:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:13:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:13:36 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 01:14:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:14:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:14:29 --> Severity: error --> Exception: syntax error, unexpected token "\" C:\xampp\htdocs\WebProject\application\controllers\Crud.php 22
DEBUG - 2023-09-17 01:15:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 01:15:11 --> Total execution time: 0.0499
DEBUG - 2023-09-17 01:15:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 01:15:17 --> Total execution time: 0.0385
DEBUG - 2023-09-17 01:24:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 01:24:05 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-17 01:24:05 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-17 01:24:05 --> Total execution time: 0.0698
DEBUG - 2023-09-17 01:24:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:24:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:24:05 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 01:24:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 01:24:24 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-17 01:24:24 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-17 01:24:24 --> Total execution time: 0.0462
DEBUG - 2023-09-17 01:24:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:24:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:24:24 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 01:24:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 01:24:35 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-17 01:24:35 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-17 01:24:35 --> Total execution time: 0.0674
DEBUG - 2023-09-17 01:24:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:24:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:24:35 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 01:24:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 01:24:43 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-17 01:24:43 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-17 01:24:43 --> Total execution time: 0.0777
DEBUG - 2023-09-17 01:24:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:24:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:24:43 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 01:24:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 01:24:47 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-17 01:24:47 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-17 01:24:47 --> Total execution time: 0.0487
DEBUG - 2023-09-17 01:24:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:24:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:24:47 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 01:24:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 01:24:48 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-17 01:24:48 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-17 01:24:48 --> Total execution time: 0.0446
DEBUG - 2023-09-17 01:24:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:24:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:24:48 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 01:24:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 01:24:48 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-17 01:24:48 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-17 01:24:48 --> Total execution time: 0.0421
DEBUG - 2023-09-17 01:24:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:24:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:24:48 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 01:24:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 01:24:49 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-17 01:24:49 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-17 01:24:49 --> Total execution time: 0.0463
DEBUG - 2023-09-17 01:24:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:24:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:24:49 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 01:24:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 01:24:49 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-17 01:24:49 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-17 01:24:49 --> Total execution time: 0.0431
DEBUG - 2023-09-17 01:24:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:24:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:24:49 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 01:24:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 01:24:50 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-17 01:24:50 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-17 01:24:50 --> Total execution time: 0.0500
DEBUG - 2023-09-17 01:24:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:24:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:24:50 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 01:29:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 01:29:36 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-17 01:29:36 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-17 01:29:36 --> Total execution time: 0.0522
DEBUG - 2023-09-17 01:29:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:29:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:29:36 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 01:29:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 01:29:55 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-17 01:29:55 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-17 01:29:55 --> Total execution time: 0.0424
DEBUG - 2023-09-17 01:29:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:29:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:29:56 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 01:36:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 01:36:36 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-17 01:36:36 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-17 01:36:36 --> Total execution time: 0.0467
DEBUG - 2023-09-17 01:36:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:36:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:36:36 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 01:36:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 01:36:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-17 01:36:52 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-17 01:36:52 --> Total execution time: 0.0430
DEBUG - 2023-09-17 01:36:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:36:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:36:52 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 01:38:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 01:38:26 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-17 01:38:26 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-17 01:38:26 --> Total execution time: 0.0512
DEBUG - 2023-09-17 01:38:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:38:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:38:26 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 01:38:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 01:38:32 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-17 01:38:32 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-17 01:38:32 --> Total execution time: 0.0447
DEBUG - 2023-09-17 01:38:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:38:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:38:32 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 01:39:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 01:39:15 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-17 01:39:15 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-17 01:39:15 --> Total execution time: 0.0437
DEBUG - 2023-09-17 01:39:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:39:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:39:15 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 01:44:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 01:44:43 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-17 01:44:43 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-17 01:44:43 --> Total execution time: 0.0739
DEBUG - 2023-09-17 01:44:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:44:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:44:43 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 01:45:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 01:45:13 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-17 01:45:13 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-17 01:45:13 --> Total execution time: 0.0636
DEBUG - 2023-09-17 01:45:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:45:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:45:13 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 01:50:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 01:50:02 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-17 01:50:02 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-17 01:50:02 --> Total execution time: 0.0601
DEBUG - 2023-09-17 01:50:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:50:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:50:02 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 01:50:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 01:50:20 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-17 01:50:20 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-17 01:50:20 --> Total execution time: 0.0544
DEBUG - 2023-09-17 01:50:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 01:50:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 01:50:20 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 03:12:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:12:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 03:12:05 --> Severity: error --> Exception: syntax error, unexpected token "=>" C:\xampp\htdocs\WebProject\application\controllers\register.php 29
DEBUG - 2023-09-17 03:13:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:13:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 03:13:08 --> Severity: Warning --> include(./templates/navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:13:08 --> Severity: Warning --> include(): Failed opening './templates/navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:13:08 --> Severity: Warning --> include(./templates/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 38
ERROR - 2023-09-17 03:13:08 --> Severity: Warning --> include(): Failed opening './templates/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 38
DEBUG - 2023-09-17 03:13:08 --> Total execution time: 0.0606
DEBUG - 2023-09-17 03:13:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:13:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 03:13:10 --> Severity: Warning --> include(./templates/navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:13:10 --> Severity: Warning --> include(): Failed opening './templates/navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:13:10 --> Severity: Warning --> include(./templates/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 38
ERROR - 2023-09-17 03:13:10 --> Severity: Warning --> include(): Failed opening './templates/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 38
DEBUG - 2023-09-17 03:13:10 --> Total execution time: 0.0521
DEBUG - 2023-09-17 03:20:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:20:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 03:20:15 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:20:15 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:20:15 --> Severity: Warning --> include(footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 42
ERROR - 2023-09-17 03:20:15 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 42
DEBUG - 2023-09-17 03:20:15 --> Total execution time: 0.0221
DEBUG - 2023-09-17 03:20:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:20:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 03:20:16 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:20:16 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:20:16 --> Severity: Warning --> include(footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 42
ERROR - 2023-09-17 03:20:16 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 42
DEBUG - 2023-09-17 03:20:16 --> Total execution time: 0.0404
DEBUG - 2023-09-17 03:20:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:20:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 03:20:17 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:20:17 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:20:17 --> Severity: Warning --> include(footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 42
ERROR - 2023-09-17 03:20:17 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 42
DEBUG - 2023-09-17 03:20:17 --> Total execution time: 0.0208
DEBUG - 2023-09-17 03:20:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:20:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 03:20:17 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:20:17 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:20:17 --> Severity: Warning --> include(footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 42
ERROR - 2023-09-17 03:20:17 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 42
DEBUG - 2023-09-17 03:20:17 --> Total execution time: 0.0202
DEBUG - 2023-09-17 03:20:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:20:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 03:20:17 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:20:17 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:20:17 --> Severity: Warning --> include(footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 42
ERROR - 2023-09-17 03:20:17 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 42
DEBUG - 2023-09-17 03:20:17 --> Total execution time: 0.0225
DEBUG - 2023-09-17 03:20:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:20:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 03:20:17 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:20:17 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:20:17 --> Severity: Warning --> include(footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 42
ERROR - 2023-09-17 03:20:18 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 42
DEBUG - 2023-09-17 03:20:18 --> Total execution time: 0.0212
DEBUG - 2023-09-17 03:20:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:20:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 03:20:18 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:20:18 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:20:18 --> Severity: Warning --> include(footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 42
ERROR - 2023-09-17 03:20:18 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 42
DEBUG - 2023-09-17 03:20:18 --> Total execution time: 0.0204
DEBUG - 2023-09-17 03:20:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:20:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 03:20:18 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:20:18 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:20:18 --> Severity: Warning --> include(footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 42
ERROR - 2023-09-17 03:20:18 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 42
DEBUG - 2023-09-17 03:20:18 --> Total execution time: 0.0209
DEBUG - 2023-09-17 03:20:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:20:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 03:20:18 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:20:18 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:20:18 --> Severity: Warning --> include(footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 42
ERROR - 2023-09-17 03:20:18 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 42
DEBUG - 2023-09-17 03:20:18 --> Total execution time: 0.0201
DEBUG - 2023-09-17 03:20:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:20:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 03:20:18 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:20:18 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:20:18 --> Severity: Warning --> include(footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 42
ERROR - 2023-09-17 03:20:18 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 42
DEBUG - 2023-09-17 03:20:18 --> Total execution time: 0.0224
DEBUG - 2023-09-17 03:20:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:20:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 03:20:18 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:20:18 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:20:18 --> Severity: Warning --> include(footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 42
ERROR - 2023-09-17 03:20:18 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 42
DEBUG - 2023-09-17 03:20:18 --> Total execution time: 0.0208
DEBUG - 2023-09-17 03:20:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:20:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 03:20:19 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:20:19 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:20:19 --> Severity: Warning --> include(footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 42
ERROR - 2023-09-17 03:20:19 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 42
DEBUG - 2023-09-17 03:20:19 --> Total execution time: 0.0396
DEBUG - 2023-09-17 03:20:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:20:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 03:20:19 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:20:19 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:20:19 --> Severity: Warning --> include(footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 42
ERROR - 2023-09-17 03:20:19 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 42
DEBUG - 2023-09-17 03:20:19 --> Total execution time: 0.0210
DEBUG - 2023-09-17 03:20:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:20:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 03:20:19 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:20:19 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:20:19 --> Severity: Warning --> include(footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 42
ERROR - 2023-09-17 03:20:19 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 42
DEBUG - 2023-09-17 03:20:19 --> Total execution time: 0.0216
DEBUG - 2023-09-17 03:20:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:20:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 03:20:19 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:20:19 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:20:19 --> Severity: Warning --> include(footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 42
ERROR - 2023-09-17 03:20:19 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 42
DEBUG - 2023-09-17 03:20:19 --> Total execution time: 0.0213
DEBUG - 2023-09-17 03:20:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:20:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 03:20:20 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:20:20 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:20:20 --> Severity: Warning --> include(footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 42
ERROR - 2023-09-17 03:20:20 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 42
DEBUG - 2023-09-17 03:20:20 --> Total execution time: 0.0204
DEBUG - 2023-09-17 03:22:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:22:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 03:22:30 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:22:30 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:22:30 --> Severity: Warning --> include(include/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 03:22:30 --> Severity: Warning --> include(): Failed opening 'include/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
DEBUG - 2023-09-17 03:22:30 --> Total execution time: 0.0211
DEBUG - 2023-09-17 03:22:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:22:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 03:22:31 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:22:31 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:22:31 --> Severity: Warning --> include(include/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 03:22:31 --> Severity: Warning --> include(): Failed opening 'include/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
DEBUG - 2023-09-17 03:22:31 --> Total execution time: 0.0212
DEBUG - 2023-09-17 03:24:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:24:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 03:24:37 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:24:37 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:24:37 --> Severity: Warning --> include(include/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 03:24:37 --> Severity: Warning --> include(): Failed opening 'include/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
DEBUG - 2023-09-17 03:24:37 --> Total execution time: 0.0219
DEBUG - 2023-09-17 03:30:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:30:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 03:30:45 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:30:45 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:30:45 --> Severity: Warning --> include(include/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 03:30:45 --> Severity: Warning --> include(): Failed opening 'include/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
DEBUG - 2023-09-17 03:30:45 --> Total execution time: 0.0210
DEBUG - 2023-09-17 03:31:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:31:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 03:31:02 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:31:02 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:31:02 --> Severity: Warning --> include(include/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 03:31:02 --> Severity: Warning --> include(): Failed opening 'include/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 03:31:02 --> Severity: error --> Exception: Unknown column 'first_name' in 'field list' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 264
DEBUG - 2023-09-17 03:33:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:33:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 03:33:38 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:33:38 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:33:38 --> Severity: Warning --> include(include/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 03:33:38 --> Severity: Warning --> include(): Failed opening 'include/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 03:33:38 --> Severity: error --> Exception: Unknown column 'password' in 'field list' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 264
DEBUG - 2023-09-17 03:35:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:35:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 03:35:01 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:35:01 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:35:01 --> Severity: Warning --> include(include/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 03:35:01 --> Severity: Warning --> include(): Failed opening 'include/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 03:35:01 --> Severity: error --> Exception: Column 'cust_name' cannot be null C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 264
DEBUG - 2023-09-17 03:35:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:35:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 03:35:20 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:35:20 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:35:20 --> Severity: Warning --> include(include/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 03:35:20 --> Severity: Warning --> include(): Failed opening 'include/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 03:35:20 --> Severity: error --> Exception: Column 'cust_name' cannot be null C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 264
DEBUG - 2023-09-17 03:36:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:36:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 03:36:53 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:36:53 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:36:53 --> Severity: Warning --> include(include/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 03:36:53 --> Severity: Warning --> include(): Failed opening 'include/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 03:36:53 --> Severity: error --> Exception: Column 'cust_name' cannot be null C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 264
DEBUG - 2023-09-17 03:37:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:37:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 03:37:02 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:37:02 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:37:02 --> Severity: Warning --> include(include/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 03:37:02 --> Severity: Warning --> include(): Failed opening 'include/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 03:37:02 --> Severity: error --> Exception: Column 'cust_name' cannot be null C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 264
DEBUG - 2023-09-17 03:37:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:37:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 03:37:17 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:37:17 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:37:17 --> Severity: Warning --> include(include/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 03:37:17 --> Severity: Warning --> include(): Failed opening 'include/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 03:37:17 --> Severity: error --> Exception: Column 'cust_name' cannot be null C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 264
DEBUG - 2023-09-17 03:39:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:39:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 03:39:16 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:39:16 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:39:16 --> Severity: Warning --> include(include/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 03:39:16 --> Severity: Warning --> include(): Failed opening 'include/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 03:39:16 --> Severity: error --> Exception: Column 'cust_name' cannot be null C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 264
DEBUG - 2023-09-17 03:44:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:44:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 03:44:56 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:44:56 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:44:56 --> Severity: Warning --> include(include/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 03:44:56 --> Severity: Warning --> include(): Failed opening 'include/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 03:44:56 --> Severity: error --> Exception: Column 'cust_name' cannot be null C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 264
DEBUG - 2023-09-17 03:45:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:45:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 03:45:08 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:45:08 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:45:08 --> Severity: Warning --> include(include/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 03:45:08 --> Severity: Warning --> include(): Failed opening 'include/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 03:45:08 --> Severity: error --> Exception: Column 'cust_name' cannot be null C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 264
DEBUG - 2023-09-17 03:45:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:45:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 03:45:33 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:45:33 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:45:33 --> Severity: Warning --> include(include/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 03:45:33 --> Severity: Warning --> include(): Failed opening 'include/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 03:45:33 --> Severity: error --> Exception: Column 'cust_name' cannot be null C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 264
DEBUG - 2023-09-17 03:47:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:47:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 03:47:22 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:47:22 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:47:22 --> Severity: Warning --> include(include/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 03:47:22 --> Severity: Warning --> include(): Failed opening 'include/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 03:47:22 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::RegisterView() C:\xampp\htdocs\WebProject\application\models\login_model.php 7
DEBUG - 2023-09-17 03:49:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:49:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 03:49:13 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:49:13 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:49:13 --> Severity: Warning --> include(include/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 03:49:13 --> Severity: Warning --> include(): Failed opening 'include/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 03:49:13 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::RegisterView() C:\xampp\htdocs\WebProject\application\models\login_model.php 7
DEBUG - 2023-09-17 03:52:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:52:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 03:52:54 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:52:54 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:52:54 --> Severity: Warning --> include(include/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 03:52:54 --> Severity: Warning --> include(): Failed opening 'include/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 03:52:54 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::RegisterView() C:\xampp\htdocs\WebProject\application\models\login_model.php 7
DEBUG - 2023-09-17 03:54:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:54:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 03:54:02 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:54:02 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:54:02 --> Severity: Warning --> include(include/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 03:54:02 --> Severity: Warning --> include(): Failed opening 'include/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 03:54:02 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::RegisterView() C:\xampp\htdocs\WebProject\application\models\login_model.php 7
DEBUG - 2023-09-17 03:54:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:54:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 03:54:28 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:54:28 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 03:54:28 --> Severity: Warning --> include(include/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 03:54:28 --> Severity: Warning --> include(): Failed opening 'include/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 03:54:28 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::RegisterView() C:\xampp\htdocs\WebProject\application\models\login_model.php 7
DEBUG - 2023-09-17 03:58:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 03:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 03:58:22 --> Total execution time: 0.0388
DEBUG - 2023-09-17 04:08:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 04:08:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 04:08:14 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 04:08:14 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 04:08:14 --> Severity: Warning --> include(include/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 04:08:14 --> Severity: Warning --> include(): Failed opening 'include/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
DEBUG - 2023-09-17 04:08:14 --> Total execution time: 0.0544
DEBUG - 2023-09-17 04:09:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 04:09:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 04:09:05 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 04:09:05 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 04:09:05 --> Severity: Warning --> include(include/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 04:09:05 --> Severity: Warning --> include(): Failed opening 'include/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 04:09:05 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::RegisterView() C:\xampp\htdocs\WebProject\application\models\login_model.php 7
DEBUG - 2023-09-17 04:11:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 04:11:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 04:11:34 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 04:11:34 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 04:11:34 --> Severity: Warning --> include(include/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 04:11:34 --> Severity: Warning --> include(): Failed opening 'include/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 04:11:34 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::RegisterView() C:\xampp\htdocs\WebProject\application\models\login_model.php 7
DEBUG - 2023-09-17 04:14:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 04:14:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 04:14:19 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 04:14:19 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 04:14:19 --> Severity: Warning --> include(include/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 04:14:19 --> Severity: Warning --> include(): Failed opening 'include/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
DEBUG - 2023-09-17 04:14:19 --> Total execution time: 0.0557
DEBUG - 2023-09-17 04:14:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 04:14:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 04:14:19 --> 404 Page Not Found: Register/js
DEBUG - 2023-09-17 04:14:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 04:14:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 04:14:43 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 04:14:43 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 04:14:43 --> Severity: Warning --> include(include/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 04:14:43 --> Severity: Warning --> include(): Failed opening 'include/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
DEBUG - 2023-09-17 04:14:43 --> Total execution time: 0.0581
DEBUG - 2023-09-17 04:14:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 04:14:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 04:14:43 --> 404 Page Not Found: Register/js
DEBUG - 2023-09-17 04:18:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 04:18:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 04:18:13 --> Severity: error --> Exception: syntax error, unexpected identifier "cust_name" C:\xampp\htdocs\WebProject\application\controllers\register.php 24
DEBUG - 2023-09-17 04:19:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 04:19:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 04:19:00 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 04:19:00 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 04:19:00 --> Severity: Warning --> include(include/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 04:19:00 --> Severity: Warning --> include(): Failed opening 'include/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
DEBUG - 2023-09-17 04:19:00 --> Total execution time: 0.0649
DEBUG - 2023-09-17 04:19:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 04:19:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 04:19:00 --> 404 Page Not Found: Register/js
DEBUG - 2023-09-17 04:19:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 04:19:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 04:19:16 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 04:19:16 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 04:19:16 --> Severity: Warning --> include(include/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 04:19:16 --> Severity: Warning --> include(): Failed opening 'include/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
DEBUG - 2023-09-17 04:19:16 --> Total execution time: 0.0546
DEBUG - 2023-09-17 04:19:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 04:19:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 04:19:16 --> 404 Page Not Found: Register/js
DEBUG - 2023-09-17 10:13:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:13:49 --> No URI present. Default controller set.
DEBUG - 2023-09-17 10:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 10:13:49 --> initController - LoginPage.php
DEBUG - 2023-09-17 10:13:49 --> Total execution time: 0.1264
DEBUG - 2023-09-17 10:13:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:13:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:13:49 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 10:14:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 10:14:02 --> initController - LoginPage.php
DEBUG - 2023-09-17 10:14:02 --> Total execution time: 0.0238
DEBUG - 2023-09-17 10:14:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:14:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:14:02 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 10:14:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 10:14:05 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-17 10:14:05 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-17 10:14:05 --> Total execution time: 0.0257
DEBUG - 2023-09-17 10:14:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:14:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:14:05 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 10:14:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:14:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:14:19 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 10:16:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:16:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:16:57 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 10:16:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:16:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:16:58 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 10:16:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:16:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:16:58 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 10:16:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:16:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:16:59 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 10:16:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:16:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:16:59 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 10:16:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:16:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:16:59 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 10:16:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:16:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:16:59 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 10:16:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:16:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:16:59 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 10:17:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:17:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:17:00 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 10:17:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:17:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:17:01 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 10:17:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:17:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:17:01 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 10:17:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:17:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:17:01 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 10:18:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:18:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:18:36 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 10:18:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:18:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:18:38 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 10:18:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:18:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:18:38 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 10:18:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:18:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:18:38 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 10:24:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:24:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:24:16 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 10:24:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:24:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:24:17 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 10:24:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:24:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:24:17 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 10:24:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:24:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:24:17 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 10:24:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:24:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:24:17 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 10:24:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:24:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:24:18 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 10:24:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:24:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:24:18 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 10:24:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:24:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:24:19 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 10:24:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:24:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:24:19 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 10:24:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:24:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:24:19 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 10:24:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:24:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:24:19 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 10:24:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:24:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:24:20 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 10:24:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:24:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:24:20 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 10:25:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:25:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:25:31 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-17 10:27:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:27:14 --> No URI present. Default controller set.
DEBUG - 2023-09-17 10:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 10:27:14 --> initController - LoginPage.php
DEBUG - 2023-09-17 10:27:14 --> Total execution time: 0.0501
DEBUG - 2023-09-17 10:27:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:27:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:27:14 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 10:27:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:27:27 --> No URI present. Default controller set.
DEBUG - 2023-09-17 10:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 10:27:27 --> initController - LoginPage.php
DEBUG - 2023-09-17 10:27:27 --> Total execution time: 0.0548
DEBUG - 2023-09-17 10:27:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:27:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:27:27 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 10:28:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:28:20 --> No URI present. Default controller set.
DEBUG - 2023-09-17 10:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 10:28:20 --> initController - LoginPage.php
DEBUG - 2023-09-17 10:28:20 --> Total execution time: 0.0591
DEBUG - 2023-09-17 10:28:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:28:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:28:20 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 10:30:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:30:19 --> No URI present. Default controller set.
DEBUG - 2023-09-17 10:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 10:30:19 --> initController - LoginPage.php
DEBUG - 2023-09-17 10:30:19 --> Total execution time: 0.0438
DEBUG - 2023-09-17 10:30:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:30:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:30:19 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 10:30:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:30:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:30:21 --> 404 Page Not Found: Product123/index
DEBUG - 2023-09-17 10:31:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:31:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:31:29 --> 404 Page Not Found: Product123/index
DEBUG - 2023-09-17 10:31:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:31:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:31:29 --> 404 Page Not Found: Product123/index
DEBUG - 2023-09-17 10:31:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:31:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:31:29 --> 404 Page Not Found: Product123/index
DEBUG - 2023-09-17 10:31:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:31:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:31:30 --> 404 Page Not Found: Product123/index
DEBUG - 2023-09-17 10:31:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:31:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:31:30 --> 404 Page Not Found: Product123/index
DEBUG - 2023-09-17 10:31:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:31:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:31:30 --> 404 Page Not Found: Product123/index
DEBUG - 2023-09-17 10:31:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:31:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:31:30 --> 404 Page Not Found: Product123/index
DEBUG - 2023-09-17 10:32:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 10:32:47 --> Total execution time: 0.0430
DEBUG - 2023-09-17 10:32:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:32:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:32:48 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 10:32:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:32:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:32:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:32:48 --> 404 Page Not Found: Img/watch-3.jpg
DEBUG - 2023-09-17 10:32:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:32:48 --> 404 Page Not Found: Img/women-3.jpg
DEBUG - 2023-09-17 10:33:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 10:33:05 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-17 10:33:05 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-17 10:33:05 --> Total execution time: 0.0595
DEBUG - 2023-09-17 10:33:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:33:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:33:05 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 10:33:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 10:33:08 --> initController - LoginPage.php
DEBUG - 2023-09-17 10:33:08 --> Total execution time: 0.0520
DEBUG - 2023-09-17 10:33:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:33:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:33:08 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 10:34:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 10:34:08 --> initController - LoginPage.php
DEBUG - 2023-09-17 10:34:08 --> Total execution time: 0.0434
DEBUG - 2023-09-17 10:34:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:34:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:34:08 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-17 10:34:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 10:34:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 10:34:14 --> 404 Page Not Found: Done/index
DEBUG - 2023-09-17 23:50:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 23:50:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 23:50:09 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 23:50:09 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 23:50:09 --> Severity: Warning --> include(include/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 23:50:09 --> Severity: Warning --> include(): Failed opening 'include/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
DEBUG - 2023-09-17 23:50:09 --> Total execution time: 0.0832
DEBUG - 2023-09-17 23:50:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 23:50:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 23:50:09 --> 404 Page Not Found: Register/js
DEBUG - 2023-09-17 23:50:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 23:50:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 23:50:52 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 23:50:52 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 23:50:52 --> Severity: Warning --> include(include/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 23:50:52 --> Severity: Warning --> include(): Failed opening 'include/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
DEBUG - 2023-09-17 23:50:52 --> Total execution time: 0.0600
DEBUG - 2023-09-17 23:50:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 23:50:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 23:50:52 --> 404 Page Not Found: Register/js
DEBUG - 2023-09-17 23:51:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 23:51:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 23:51:18 --> Severity: Warning --> include(navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 23:51:18 --> Severity: Warning --> include(): Failed opening 'navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 2
ERROR - 2023-09-17 23:51:18 --> Severity: Warning --> include(include/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
ERROR - 2023-09-17 23:51:18 --> Severity: Warning --> include(): Failed opening 'include/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\RegisterView.php 43
DEBUG - 2023-09-17 23:51:18 --> Total execution time: 0.0517
DEBUG - 2023-09-17 23:51:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 23:51:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 23:51:18 --> 404 Page Not Found: Register/js
DEBUG - 2023-09-17 23:55:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 23:55:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 23:55:17 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-17 23:55:17 --> Total execution time: 0.0497
DEBUG - 2023-09-17 23:55:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 23:55:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 23:55:17 --> 404 Page Not Found: Register/assets
DEBUG - 2023-09-17 23:55:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 23:55:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 23:55:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 23:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 23:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 23:55:17 --> UTF-8 Support Enabled
ERROR - 2023-09-17 23:55:17 --> 404 Page Not Found: Register/assets
DEBUG - 2023-09-17 23:55:17 --> UTF-8 Support Enabled
ERROR - 2023-09-17 23:55:17 --> 404 Page Not Found: Register/assets
DEBUG - 2023-09-17 23:55:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 23:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 23:55:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 23:55:17 --> 404 Page Not Found: Register/5546YEEcss
DEBUG - 2023-09-17 23:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 23:55:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 23:55:17 --> 404 Page Not Found: Register/js
ERROR - 2023-09-17 23:55:17 --> 404 Page Not Found: Register/assets
ERROR - 2023-09-17 23:55:17 --> 404 Page Not Found: Register/js
DEBUG - 2023-09-17 23:55:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 23:55:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 23:55:17 --> 404 Page Not Found: Register/assets
DEBUG - 2023-09-17 23:55:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 23:55:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 23:55:17 --> 404 Page Not Found: Register/js
DEBUG - 2023-09-17 23:55:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 23:55:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 23:55:34 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-17 23:55:34 --> Total execution time: 0.0537
DEBUG - 2023-09-17 23:55:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 23:55:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 23:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 23:55:34 --> UTF-8 Support Enabled
ERROR - 2023-09-17 23:55:34 --> 404 Page Not Found: Register/assets
DEBUG - 2023-09-17 23:55:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 23:55:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 23:55:34 --> 404 Page Not Found: Register/5546YEEcss
DEBUG - 2023-09-17 23:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 23:55:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 23:55:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 23:55:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 23:55:34 --> 404 Page Not Found: Register/assets
ERROR - 2023-09-17 23:55:34 --> 404 Page Not Found: Register/js
DEBUG - 2023-09-17 23:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 23:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 23:55:34 --> UTF-8 Support Enabled
ERROR - 2023-09-17 23:55:34 --> 404 Page Not Found: Register/assets
ERROR - 2023-09-17 23:55:34 --> 404 Page Not Found: Register/assets
DEBUG - 2023-09-17 23:55:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 23:55:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 23:55:34 --> 404 Page Not Found: Register/js
DEBUG - 2023-09-17 23:55:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 23:55:34 --> 404 Page Not Found: Register/assets
DEBUG - 2023-09-17 23:55:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 23:55:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 23:55:34 --> 404 Page Not Found: Register/js
DEBUG - 2023-09-17 23:59:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 23:59:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 23:59:53 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-17 23:59:53 --> Total execution time: 0.0625
DEBUG - 2023-09-17 23:59:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 23:59:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 23:59:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 23:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 23:59:53 --> UTF-8 Support Enabled
ERROR - 2023-09-17 23:59:53 --> 404 Page Not Found: Register/5546YEEcss
DEBUG - 2023-09-17 23:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 23:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 23:59:53 --> UTF-8 Support Enabled
ERROR - 2023-09-17 23:59:53 --> 404 Page Not Found: Register/assets
DEBUG - 2023-09-17 23:59:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 23:59:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 23:59:53 --> 404 Page Not Found: Register/assets
ERROR - 2023-09-17 23:59:53 --> 404 Page Not Found: Register/assets
DEBUG - 2023-09-17 23:59:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 23:59:53 --> 404 Page Not Found: Register/assets
DEBUG - 2023-09-17 23:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-17 23:59:53 --> UTF-8 Support Enabled
ERROR - 2023-09-17 23:59:53 --> 404 Page Not Found: Register/js
DEBUG - 2023-09-17 23:59:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 23:59:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 23:59:53 --> 404 Page Not Found: Register/js
DEBUG - 2023-09-17 23:59:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 23:59:53 --> 404 Page Not Found: Register/assets
DEBUG - 2023-09-17 23:59:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-17 23:59:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-17 23:59:53 --> 404 Page Not Found: Register/js
