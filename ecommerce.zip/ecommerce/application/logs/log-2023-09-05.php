<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-09-05 00:56:28 --> UTF-8 Support Enabled
ERROR - 2023-09-05 00:56:28 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 00:56:28 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 00:56:28 --> No URI present. Default controller set.
DEBUG - 2023-09-05 00:56:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 00:56:28 --> Severity: error --> Exception: syntax error, unexpected token "(" C:\xampp\htdocs\WebProject\application\controllers\InitController.php 44
DEBUG - 2023-09-05 00:58:42 --> UTF-8 Support Enabled
ERROR - 2023-09-05 00:58:42 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 00:58:42 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 00:58:42 --> No URI present. Default controller set.
DEBUG - 2023-09-05 00:58:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 00:58:42 --> Severity: error --> Exception: syntax error, unexpected token "(" C:\xampp\htdocs\WebProject\application\controllers\InitController.php 44
DEBUG - 2023-09-05 01:03:24 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:03:24 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:03:24 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:03:24 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:03:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:03:24 --> Severity: error --> Exception: syntax error, unexpected token "(" C:\xampp\htdocs\WebProject\application\controllers\InitController.php 44
DEBUG - 2023-09-05 01:09:45 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:09:45 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:09:45 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:09:45 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:09:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:09:45 --> Severity: error --> Exception: syntax error, unexpected token "(" C:\xampp\htdocs\WebProject\application\controllers\InitController.php 44
DEBUG - 2023-09-05 01:13:52 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:13:52 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:13:52 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:13:52 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:13:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:13:52 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:13:52 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:13:52 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:13:52 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:13:52 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:13:52 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:13:52 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:13:52 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:13:52 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:13:52 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:13:52 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:13:52 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:13:52 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:13:52 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:13:52 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:13:52 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:13:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:14:06 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:14:06 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:14:06 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:14:06 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:14:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:14:06 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:14:06 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:14:06 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:14:06 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:14:06 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:14:06 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:14:06 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:14:06 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:14:06 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:14:06 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:14:06 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:14:06 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:14:06 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:14:06 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:14:06 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:14:06 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:14:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:17:38 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:17:38 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:17:38 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:17:38 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:17:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:17:38 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:38 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:38 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:38 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:38 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:38 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:38 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:38 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:38 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:38 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:38 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:38 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:38 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:17:38 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:17:38 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:17:38 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:17:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:17:39 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:17:39 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:17:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:17:39 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:17:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:17:39 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:17:39 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:17:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:17:39 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:17:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:17:39 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:17:39 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:17:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:17:39 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:17:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:17:39 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:17:39 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:17:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:17:39 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:17:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:17:39 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:17:39 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:17:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:17:39 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:17:39 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:17:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:17:40 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:17:40 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:17:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:17:40 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:17:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:17:40 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:17:40 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:17:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:17:40 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:17:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:17:40 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:17:40 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:17:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:17:40 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:17:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:17:40 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:17:40 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:17:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:17:40 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:17:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:17:40 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:17:40 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:17:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:17:40 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:17:40 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:17:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:17:41 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:17:41 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:17:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:17:41 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:17:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:17:41 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:17:41 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:17:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:17:41 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:17:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:17:41 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:17:41 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:17:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:17:41 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:17:41 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:17:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:20:44 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:20:44 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:20:44 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:20:44 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:20:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:20:44 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:44 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:44 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:44 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:44 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:44 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:44 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:44 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:44 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:44 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:44 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:44 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:44 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:20:44 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:20:44 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:20:44 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:20:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:20:48 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:20:48 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:20:48 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:20:48 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:20:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:20:48 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:48 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:48 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:48 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:48 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:48 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:48 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:48 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:48 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:48 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:48 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:48 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:48 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:20:48 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:20:48 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:20:48 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:20:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:20:48 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:20:48 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:20:48 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:20:48 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:20:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:20:48 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:48 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:48 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:48 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:48 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:48 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:48 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:48 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:48 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:48 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:48 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:48 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:48 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:20:48 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:20:48 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:20:48 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:20:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:20:49 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:20:49 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:20:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:20:49 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:20:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:20:49 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:20:49 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:20:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:20:49 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:20:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:20:49 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:20:49 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:20:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:20:49 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:20:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:20:49 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:20:49 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:20:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:20:49 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:20:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:20:49 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:20:49 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:20:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:20:49 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:20:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:20:49 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:20:49 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:20:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:20:49 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:20:49 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:20:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:20:50 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:20:50 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:20:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:20:50 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:20:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:20:50 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:20:50 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:20:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:20:50 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:20:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:20:50 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:20:50 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:20:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:20:50 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:20:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:20:50 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:20:50 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:20:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:20:50 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:20:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:20:50 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:20:50 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:20:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:20:50 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:20:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:20:50 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:20:50 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:20:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:50 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:20:51 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:20:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:20:51 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:20:51 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:20:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:20:51 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:20:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:20:51 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:20:51 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:20:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:20:51 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:20:51 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:20:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:22:15 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:22:15 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:22:15 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:22:15 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:22:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:22:15 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:15 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:15 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:15 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:15 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:15 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:15 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:15 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:15 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:15 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:15 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:15 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:15 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:22:15 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:22:15 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:22:15 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:22:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:22:20 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:22:20 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:22:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:22:20 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:22:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:22:20 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:22:20 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:22:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:22:20 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:22:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:22:20 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:22:20 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:22:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:22:20 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:22:20 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:22:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:22:21 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:22:21 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:22:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:22:21 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:22:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:22:21 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:22:21 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:22:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:22:21 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:22:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:22:21 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:22:21 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:22:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:22:21 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:22:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:22:21 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:22:21 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:22:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:22:21 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:22:21 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:22:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:55:54 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:55:54 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:55:54 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:55:54 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:55:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:55:54 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:54 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:54 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:54 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:54 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:54 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:54 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:54 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:54 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:54 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:54 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:54 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:54 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:55:54 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:55:54 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:55:54 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:55:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:55:58 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:55:58 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:55:58 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:55:58 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:55:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:55:58 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:58 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:58 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:58 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:58 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:58 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:58 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:58 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:58 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:58 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:58 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:58 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:58 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:55:58 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:55:58 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:55:58 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:55:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:55:59 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:55:59 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:55:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:55:59 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:55:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:55:59 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:55:59 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:55:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:55:59 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:55:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:55:59 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:55:59 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:55:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:55:59 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:55:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:55:59 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:55:59 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:55:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:55:59 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:56:00 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:56:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:56:47 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:56:47 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:56:47 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:56:47 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:56:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:56:47 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:56:47 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:56:47 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:56:47 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:56:47 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:56:47 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:56:47 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:56:47 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:56:47 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:56:47 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:56:47 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:56:47 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:56:47 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:56:47 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:56:47 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:56:47 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:56:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 01:57:46 --> UTF-8 Support Enabled
ERROR - 2023-09-05 01:57:46 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 01:57:46 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 01:57:46 --> No URI present. Default controller set.
DEBUG - 2023-09-05 01:57:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 01:57:46 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:57:46 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:57:46 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:57:46 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:57:46 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:57:46 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:57:46 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:57:46 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:57:46 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:57:46 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:57:46 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:57:46 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 01:57:46 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 01:57:46 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 01:57:46 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 01:57:46 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 01:57:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:24:04 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:24:04 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:24:04 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:24:04 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:24:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:24:04 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:24:04 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:24:04 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:24:04 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:24:04 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:24:04 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:24:04 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:24:04 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:24:04 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:24:04 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:24:04 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:24:04 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:24:04 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:24:04 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:24:04 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:24:04 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:24:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:26:19 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:26:19 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:26:19 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:26:19 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:26:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:26:19 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:26:19 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:26:19 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:26:19 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:26:19 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:26:19 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:26:19 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:26:19 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:26:19 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:26:19 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:26:19 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:26:19 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:26:19 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:26:19 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:26:19 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:26:19 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:26:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:26:20 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:26:20 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:26:20 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:26:20 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:26:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:26:20 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:26:20 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:26:20 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:26:20 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:26:20 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:26:20 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:26:20 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:26:20 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:26:20 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:26:20 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:26:20 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:26:20 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:26:20 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:26:20 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:26:20 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:26:20 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:26:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:27:13 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:27:13 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:27:13 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:27:13 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:27:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:27:13 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:13 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:13 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:13 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:13 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:13 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:13 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:13 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:13 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:13 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:13 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:13 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:13 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:27:13 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:27:13 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:27:13 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:27:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:27:14 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:27:14 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:27:14 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:27:14 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:27:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:27:14 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:14 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:14 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:14 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:14 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:14 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:14 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:14 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:14 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:14 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:14 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:14 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:14 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:27:14 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:27:14 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:27:14 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:27:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:27:14 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:27:14 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:27:14 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:27:14 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:27:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:27:14 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:14 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:14 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:14 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:14 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:14 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:14 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:14 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:14 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:14 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:14 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:14 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:14 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:27:14 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:27:14 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:27:14 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:27:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:27:23 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:27:23 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:27:23 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:27:23 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:27:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:27:23 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:23 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:23 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:23 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:23 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:23 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:23 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:23 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:23 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:23 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:23 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:23 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:23 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:27:23 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:27:23 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:27:23 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:27:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:27:24 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:27:24 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:27:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:27:24 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:27:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:27:24 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:27:24 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:27:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:27:24 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:27:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:27:24 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:27:24 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:27:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:24 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:25 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:27:25 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:27:25 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:27:25 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:27:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:27:32 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:27:32 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:27:32 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:27:32 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:27:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:27:32 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:32 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:32 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:32 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:32 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:32 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:32 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:32 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:32 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:32 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:32 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:32 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:32 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:27:32 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:27:32 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:27:32 --> Severity: error --> Exception: Access denied for user 'jadenm'@'localhost' (using password: NO) C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:27:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:27:54 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:27:54 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:27:54 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:27:54 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:27:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:27:54 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:54 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:54 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:54 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:54 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:54 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:54 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:54 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:54 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:54 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:54 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:54 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:27:54 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:27:54 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:27:54 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:27:54 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:27:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:35:43 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:35:43 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:35:43 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:35:43 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:35:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:35:43 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:43 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:43 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:43 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:43 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:43 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:43 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:43 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:43 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:43 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:43 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:43 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:43 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:35:43 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:35:43 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:35:43 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:35:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:35:44 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:35:44 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:35:44 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:35:44 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:35:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:35:44 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:44 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:44 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:44 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:44 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:44 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:44 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:44 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:44 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:44 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:44 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:44 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:44 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:35:44 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:35:44 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:35:44 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:35:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:35:44 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:35:44 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:35:44 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:35:44 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:35:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:35:44 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:44 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:44 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:44 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:44 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:44 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:44 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:44 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:44 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:44 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:44 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:44 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:44 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:35:44 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:35:44 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:35:44 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:35:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:35:45 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:35:45 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:35:45 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:35:45 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:35:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:35:45 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:45 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:45 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:45 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:45 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:45 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:45 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:45 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:45 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:45 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:45 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:45 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:45 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:35:45 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:35:45 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:35:45 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:35:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:35:45 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:35:45 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:35:45 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:35:45 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:35:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:35:45 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:45 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:45 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:45 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:45 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:45 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:45 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:45 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:45 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:45 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:45 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:45 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:45 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:35:45 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:35:45 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:35:45 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:35:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:35:46 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:35:46 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:35:46 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:35:46 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:35:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:35:46 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:46 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:46 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:46 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:46 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:46 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:46 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:46 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:46 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:46 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:46 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:46 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:46 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:35:46 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:35:46 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:35:46 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:35:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:35:46 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:35:46 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:35:46 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:35:46 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:35:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:35:46 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:46 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:46 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:46 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:46 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:46 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:46 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:46 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:46 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:46 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:46 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:46 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:35:46 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:35:46 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:35:46 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:35:46 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:35:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:54:20 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:54:20 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:54:20 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:54:20 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:54:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:54:20 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:20 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:20 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:20 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:20 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:20 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:20 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:20 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:20 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:20 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:20 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:20 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:20 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:54:20 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:54:20 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:54:20 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:54:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:54:21 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:54:21 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:54:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:54:21 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:54:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:54:21 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:54:21 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:54:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:54:21 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:54:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:54:21 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:54:21 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:54:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:54:21 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:54:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:54:21 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:54:21 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:54:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:54:21 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:54:21 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:54:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:54:22 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:54:22 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:54:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:54:22 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:54:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:54:22 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:54:22 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:54:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:54:22 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:54:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:54:22 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:54:22 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:54:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:54:22 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:54:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:54:22 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:54:22 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:54:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:54:22 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:54:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:54:22 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:54:22 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:54:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:54:22 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:54:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:54:22 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:54:22 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:54:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:54:22 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:54:22 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:54:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:54:23 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:54:23 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:54:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:54:23 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:54:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:54:23 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:54:23 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:54:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:54:23 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:54:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:54:23 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:54:23 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:54:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:54:23 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:54:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:54:23 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:54:23 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:54:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:54:23 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:54:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:54:23 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:54:23 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:54:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:54:23 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:54:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:54:23 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:54:23 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:54:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:54:23 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:54:23 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:54:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:54:24 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:54:24 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:54:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:54:24 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:54:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:54:24 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:54:24 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:54:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:54:24 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:54:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:54:24 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:54:24 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:54:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:54:24 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:54:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:54:24 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:54:24 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:54:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:54:24 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:54:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:54:24 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:54:24 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:54:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:54:24 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:54:24 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:54:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:54:25 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:54:25 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:54:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:54:25 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:54:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:54:25 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:54:25 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:54:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:54:25 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:54:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:54:25 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:54:25 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:54:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:54:25 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:54:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:54:25 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:54:25 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:54:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:54:25 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:54:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:54:25 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:54:25 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:54:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:25 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:54:26 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:54:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:54:26 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:54:26 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:54:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:54:26 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:54:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:54:26 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:54:26 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:54:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:54:26 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:54:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:54:26 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:54:26 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:54:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:54:26 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:54:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:54:26 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:54:26 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:54:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:54:26 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:54:26 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:54:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:55:49 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:55:49 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:55:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:55:49 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:55:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:55:49 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:55:49 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:55:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:55:49 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:55:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:55:49 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:55:49 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:55:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:55:49 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:55:50 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:55:50 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:55:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:55:50 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:55:50 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:55:50 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:55:50 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:55:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:55:50 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:50 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:50 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:50 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:50 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:50 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:50 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:50 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:50 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:50 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:50 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:50 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:55:50 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:55:50 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:55:50 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:55:50 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:55:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:56:14 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:56:14 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:56:14 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:56:14 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:56:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:56:14 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:14 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:14 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:14 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:14 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:14 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:14 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:14 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:14 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:14 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:14 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:14 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:14 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:56:14 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:56:14 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:56:14 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:56:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:56:15 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:56:15 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:56:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:56:15 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:56:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:56:15 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:56:15 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:56:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:56:15 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:56:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:56:15 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:56:15 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:56:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:56:15 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:56:15 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:56:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:56:59 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:56:59 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:56:59 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:56:59 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:56:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:56:59 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:59 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:59 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:59 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:59 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:59 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:59 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:59 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:59 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:59 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:59 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:59 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:56:59 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:56:59 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:56:59 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:56:59 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:56:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:57:00 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:57:00 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:57:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:57:00 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:57:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:57:00 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:57:00 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:57:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:57:00 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:57:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:57:00 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:57:00 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:57:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:57:00 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:57:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:57:00 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:57:00 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:57:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:57:00 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:57:00 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:57:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-05 08:57:01 --> UTF-8 Support Enabled
ERROR - 2023-09-05 08:57:01 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-05 08:57:01 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-05 08:57:01 --> No URI present. Default controller set.
DEBUG - 2023-09-05 08:57:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-05 08:57:01 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:01 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:01 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:01 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:01 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:01 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:01 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:01 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:01 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:01 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:01 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:01 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-05 08:57:01 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-05 08:57:01 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-05 08:57:01 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-05 08:57:01 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-05 08:57:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
