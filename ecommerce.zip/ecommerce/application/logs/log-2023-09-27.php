<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-09-27 12:24:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:24:24 --> No URI present. Default controller set.
DEBUG - 2023-09-27 12:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:24:24 --> initController - LoginPage.php
DEBUG - 2023-09-27 12:24:24 --> Total execution time: 0.0922
DEBUG - 2023-09-27 12:24:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:24:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:24:24 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:25:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:25:08 --> Total execution time: 0.0734
DEBUG - 2023-09-27 12:25:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:25:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:25:08 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:25:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:25:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:25:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:25:08 --> 404 Page Not Found: Img/watch-3.jpg
ERROR - 2023-09-27 12:25:08 --> 404 Page Not Found: Img/women-3.jpg
DEBUG - 2023-09-27 12:26:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:11 --> Total execution time: 0.0440
DEBUG - 2023-09-27 12:26:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:11 --> UTF-8 Support Enabled
ERROR - 2023-09-27 12:26:11 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:26:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:26:11 --> 404 Page Not Found: Img/women-3.jpg
DEBUG - 2023-09-27 12:26:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:26:11 --> 404 Page Not Found: Img/watch-3.jpg
DEBUG - 2023-09-27 12:26:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:11 --> Total execution time: 0.0407
DEBUG - 2023-09-27 12:26:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:11 --> UTF-8 Support Enabled
ERROR - 2023-09-27 12:26:11 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:26:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:26:11 --> 404 Page Not Found: Img/women-3.jpg
ERROR - 2023-09-27 12:26:11 --> 404 Page Not Found: Img/watch-3.jpg
DEBUG - 2023-09-27 12:26:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:11 --> Total execution time: 0.0362
DEBUG - 2023-09-27 12:26:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:26:11 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:26:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:26:12 --> 404 Page Not Found: Img/watch-3.jpg
ERROR - 2023-09-27 12:26:12 --> 404 Page Not Found: Img/women-3.jpg
DEBUG - 2023-09-27 12:26:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:12 --> Total execution time: 0.0389
DEBUG - 2023-09-27 12:26:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:12 --> UTF-8 Support Enabled
ERROR - 2023-09-27 12:26:12 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:26:12 --> 404 Page Not Found: Img/women-3.jpg
ERROR - 2023-09-27 12:26:12 --> 404 Page Not Found: Img/watch-3.jpg
DEBUG - 2023-09-27 12:26:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:12 --> Total execution time: 0.0362
DEBUG - 2023-09-27 12:26:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:12 --> UTF-8 Support Enabled
ERROR - 2023-09-27 12:26:12 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:26:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:26:12 --> 404 Page Not Found: Img/watch-3.jpg
ERROR - 2023-09-27 12:26:12 --> 404 Page Not Found: Img/women-3.jpg
DEBUG - 2023-09-27 12:26:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:12 --> Total execution time: 0.0371
DEBUG - 2023-09-27 12:26:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:12 --> UTF-8 Support Enabled
ERROR - 2023-09-27 12:26:12 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:26:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:26:12 --> 404 Page Not Found: Img/watch-3.jpg
ERROR - 2023-09-27 12:26:12 --> 404 Page Not Found: Img/women-3.jpg
DEBUG - 2023-09-27 12:26:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:12 --> Total execution time: 0.0451
DEBUG - 2023-09-27 12:26:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:26:12 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:26:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:26:12 --> 404 Page Not Found: Img/watch-3.jpg
ERROR - 2023-09-27 12:26:12 --> 404 Page Not Found: Img/women-3.jpg
DEBUG - 2023-09-27 12:26:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:12 --> Total execution time: 0.0365
DEBUG - 2023-09-27 12:26:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:12 --> UTF-8 Support Enabled
ERROR - 2023-09-27 12:26:12 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:26:12 --> 404 Page Not Found: Img/women-3.jpg
ERROR - 2023-09-27 12:26:12 --> 404 Page Not Found: Img/watch-3.jpg
DEBUG - 2023-09-27 12:26:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:12 --> Total execution time: 0.0398
DEBUG - 2023-09-27 12:26:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:12 --> UTF-8 Support Enabled
ERROR - 2023-09-27 12:26:12 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:26:12 --> 404 Page Not Found: Img/watch-3.jpg
ERROR - 2023-09-27 12:26:12 --> 404 Page Not Found: Img/women-3.jpg
DEBUG - 2023-09-27 12:26:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:13 --> Total execution time: 0.0367
DEBUG - 2023-09-27 12:26:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:26:13 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:26:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:26:13 --> 404 Page Not Found: Img/watch-3.jpg
ERROR - 2023-09-27 12:26:13 --> 404 Page Not Found: Img/women-3.jpg
DEBUG - 2023-09-27 12:26:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:13 --> Total execution time: 0.0407
DEBUG - 2023-09-27 12:26:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:26:13 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:26:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:26:13 --> 404 Page Not Found: Img/women-3.jpg
ERROR - 2023-09-27 12:26:13 --> 404 Page Not Found: Img/watch-3.jpg
DEBUG - 2023-09-27 12:26:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:13 --> Total execution time: 0.0395
DEBUG - 2023-09-27 12:26:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:13 --> UTF-8 Support Enabled
ERROR - 2023-09-27 12:26:13 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:26:13 --> 404 Page Not Found: Img/watch-3.jpg
ERROR - 2023-09-27 12:26:13 --> 404 Page Not Found: Img/women-3.jpg
DEBUG - 2023-09-27 12:26:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:13 --> Total execution time: 0.0373
DEBUG - 2023-09-27 12:26:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:26:13 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:26:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:26:13 --> 404 Page Not Found: Img/watch-3.jpg
ERROR - 2023-09-27 12:26:13 --> 404 Page Not Found: Img/women-3.jpg
DEBUG - 2023-09-27 12:26:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:13 --> Total execution time: 0.0360
DEBUG - 2023-09-27 12:26:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:26:13 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:26:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:26:13 --> 404 Page Not Found: Img/women-3.jpg
ERROR - 2023-09-27 12:26:13 --> 404 Page Not Found: Img/watch-3.jpg
DEBUG - 2023-09-27 12:26:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:14 --> Total execution time: 0.0430
DEBUG - 2023-09-27 12:26:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:14 --> UTF-8 Support Enabled
ERROR - 2023-09-27 12:26:14 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:26:14 --> 404 Page Not Found: Img/women-3.jpg
ERROR - 2023-09-27 12:26:14 --> 404 Page Not Found: Img/watch-3.jpg
DEBUG - 2023-09-27 12:26:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:14 --> Total execution time: 0.0379
DEBUG - 2023-09-27 12:26:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:14 --> UTF-8 Support Enabled
ERROR - 2023-09-27 12:26:14 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:26:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:26:14 --> 404 Page Not Found: Img/watch-3.jpg
ERROR - 2023-09-27 12:26:14 --> 404 Page Not Found: Img/women-3.jpg
DEBUG - 2023-09-27 12:26:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:14 --> Total execution time: 0.0463
DEBUG - 2023-09-27 12:26:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:14 --> UTF-8 Support Enabled
ERROR - 2023-09-27 12:26:14 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:26:14 --> 404 Page Not Found: Img/watch-3.jpg
ERROR - 2023-09-27 12:26:14 --> 404 Page Not Found: Img/women-3.jpg
DEBUG - 2023-09-27 12:26:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:14 --> Total execution time: 0.0450
DEBUG - 2023-09-27 12:26:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:14 --> UTF-8 Support Enabled
ERROR - 2023-09-27 12:26:14 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:26:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:26:14 --> 404 Page Not Found: Img/women-3.jpg
ERROR - 2023-09-27 12:26:14 --> 404 Page Not Found: Img/watch-3.jpg
DEBUG - 2023-09-27 12:26:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:14 --> Total execution time: 0.0369
DEBUG - 2023-09-27 12:26:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:26:14 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:26:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:26:14 --> 404 Page Not Found: Img/women-3.jpg
ERROR - 2023-09-27 12:26:14 --> 404 Page Not Found: Img/watch-3.jpg
DEBUG - 2023-09-27 12:26:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:15 --> Total execution time: 0.0383
DEBUG - 2023-09-27 12:26:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:26:15 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:26:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:26:15 --> 404 Page Not Found: Img/watch-3.jpg
DEBUG - 2023-09-27 12:26:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:26:15 --> 404 Page Not Found: Img/women-3.jpg
DEBUG - 2023-09-27 12:26:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:15 --> Total execution time: 0.0395
DEBUG - 2023-09-27 12:26:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:15 --> UTF-8 Support Enabled
ERROR - 2023-09-27 12:26:15 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:26:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:26:15 --> 404 Page Not Found: Img/watch-3.jpg
ERROR - 2023-09-27 12:26:15 --> 404 Page Not Found: Img/women-3.jpg
DEBUG - 2023-09-27 12:26:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:15 --> Total execution time: 0.0379
DEBUG - 2023-09-27 12:26:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:15 --> UTF-8 Support Enabled
ERROR - 2023-09-27 12:26:15 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:26:15 --> 404 Page Not Found: Img/watch-3.jpg
ERROR - 2023-09-27 12:26:15 --> 404 Page Not Found: Img/women-3.jpg
DEBUG - 2023-09-27 12:26:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:15 --> Total execution time: 0.0376
DEBUG - 2023-09-27 12:26:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:26:15 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:26:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:26:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:26:15 --> 404 Page Not Found: Img/women-3.jpg
ERROR - 2023-09-27 12:26:15 --> 404 Page Not Found: Img/watch-3.jpg
DEBUG - 2023-09-27 12:30:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:30:10 --> No URI present. Default controller set.
DEBUG - 2023-09-27 12:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:30:10 --> initController - LoginPage.php
DEBUG - 2023-09-27 12:30:10 --> Total execution time: 0.0603
DEBUG - 2023-09-27 12:30:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:30:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:30:10 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:30:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:30:11 --> No URI present. Default controller set.
DEBUG - 2023-09-27 12:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:30:11 --> initController - LoginPage.php
DEBUG - 2023-09-27 12:30:11 --> Total execution time: 0.0416
DEBUG - 2023-09-27 12:30:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:30:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:30:11 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:30:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:30:11 --> No URI present. Default controller set.
DEBUG - 2023-09-27 12:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:30:11 --> initController - LoginPage.php
DEBUG - 2023-09-27 12:30:11 --> Total execution time: 0.0553
DEBUG - 2023-09-27 12:30:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:30:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:30:11 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:31:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:31:45 --> initController - LoginPage.php
DEBUG - 2023-09-27 12:31:45 --> Total execution time: 0.0461
DEBUG - 2023-09-27 12:31:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:31:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:31:45 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:31:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:31:54 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-27 12:31:54 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-27 12:31:54 --> Total execution time: 0.0716
DEBUG - 2023-09-27 12:31:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:31:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:31:54 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:32:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:32:01 --> initController - LoginPage.php
DEBUG - 2023-09-27 12:32:01 --> Total execution time: 0.0442
DEBUG - 2023-09-27 12:32:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:32:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:32:01 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:32:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:32:05 --> initController - LoginPage.php
DEBUG - 2023-09-27 12:32:05 --> Total execution time: 0.0395
DEBUG - 2023-09-27 12:32:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:32:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:32:05 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:32:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:32:06 --> initController - LoginPage.php
DEBUG - 2023-09-27 12:32:06 --> Total execution time: 0.0398
DEBUG - 2023-09-27 12:32:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:32:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:32:06 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:32:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:32:11 --> No URI present. Default controller set.
DEBUG - 2023-09-27 12:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:32:11 --> initController - LoginPage.php
DEBUG - 2023-09-27 12:32:11 --> Total execution time: 0.0641
DEBUG - 2023-09-27 12:32:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:32:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:32:11 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:32:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:32:15 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-27 12:32:15 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-27 12:32:15 --> Total execution time: 0.0498
DEBUG - 2023-09-27 12:32:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:32:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:32:15 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:32:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:32:19 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-27 12:32:19 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-27 12:32:19 --> Severity: Notice --> session_start(): Ignoring session_start() because a session is already active C:\xampp\htdocs\WebProject\application\views\insert.php 2
ERROR - 2023-09-27 12:32:19 --> Severity: Warning --> include(./templates/top.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 7
ERROR - 2023-09-27 12:32:19 --> Severity: Warning --> include(): Failed opening './templates/top.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 7
ERROR - 2023-09-27 12:32:19 --> Severity: Warning --> include(./templates/navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 11
ERROR - 2023-09-27 12:32:19 --> Severity: Warning --> include(): Failed opening './templates/navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 11
ERROR - 2023-09-27 12:32:19 --> Severity: Warning --> include(./templates/sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 16
ERROR - 2023-09-27 12:32:19 --> Severity: Warning --> include(): Failed opening './templates/sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 16
ERROR - 2023-09-27 12:32:19 --> Severity: Warning --> include(./templates/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 47
ERROR - 2023-09-27 12:32:19 --> Severity: Warning --> include(): Failed opening './templates/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 47
DEBUG - 2023-09-27 12:32:19 --> Total execution time: 0.0571
DEBUG - 2023-09-27 12:32:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:32:23 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-27 12:32:23 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-27 12:32:23 --> Total execution time: 0.0483
DEBUG - 2023-09-27 12:33:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:33:28 --> No URI present. Default controller set.
DEBUG - 2023-09-27 12:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:33:28 --> initController - LoginPage.php
DEBUG - 2023-09-27 12:33:28 --> Total execution time: 0.0499
DEBUG - 2023-09-27 12:33:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:33:28 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:33:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:33:33 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-27 12:33:33 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-27 12:33:33 --> Severity: Notice --> session_start(): Ignoring session_start() because a session is already active C:\xampp\htdocs\WebProject\application\views\insert.php 2
ERROR - 2023-09-27 12:33:33 --> Severity: Warning --> include(./templates/top.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 7
ERROR - 2023-09-27 12:33:33 --> Severity: Warning --> include(): Failed opening './templates/top.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 7
ERROR - 2023-09-27 12:33:33 --> Severity: Warning --> include(./templates/navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 11
ERROR - 2023-09-27 12:33:33 --> Severity: Warning --> include(): Failed opening './templates/navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 11
ERROR - 2023-09-27 12:33:33 --> Severity: Warning --> include(./templates/sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 16
ERROR - 2023-09-27 12:33:33 --> Severity: Warning --> include(): Failed opening './templates/sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 16
ERROR - 2023-09-27 12:33:33 --> Severity: Warning --> include(./templates/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 47
ERROR - 2023-09-27 12:33:33 --> Severity: Warning --> include(): Failed opening './templates/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 47
DEBUG - 2023-09-27 12:33:33 --> Total execution time: 0.0772
DEBUG - 2023-09-27 12:35:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:35:41 --> initController - LoginPage.php
DEBUG - 2023-09-27 12:35:41 --> Total execution time: 0.0431
DEBUG - 2023-09-27 12:35:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:35:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:35:41 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:35:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:35:44 --> initController - LoginPage.php
DEBUG - 2023-09-27 12:35:44 --> Total execution time: 0.0391
DEBUG - 2023-09-27 12:35:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:35:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:35:44 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:35:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:35:49 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-27 12:35:49 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-27 12:35:49 --> Total execution time: 0.0478
DEBUG - 2023-09-27 12:35:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:35:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:35:49 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:35:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:35:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:35:52 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-27 12:35:52 --> Total execution time: 0.0467
DEBUG - 2023-09-27 12:35:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:35:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:35:52 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:36:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:36:16 --> initController - LoginPage.php
DEBUG - 2023-09-27 12:36:16 --> Total execution time: 0.0402
DEBUG - 2023-09-27 12:36:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:36:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:36:16 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:36:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:36:28 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-27 12:36:28 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-27 12:36:28 --> Total execution time: 0.0478
DEBUG - 2023-09-27 12:36:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:36:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:36:28 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:36:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:36:42 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-27 12:36:42 --> Severity: Warning --> Undefined property: stdClass::$username C:\xampp\htdocs\WebProject\application\controllers\login.php 99
DEBUG - 2023-09-27 12:36:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:36:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-27 12:36:42 --> Total execution time: 0.0428
DEBUG - 2023-09-27 12:36:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:36:54 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-27 12:36:54 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\WebProject\system\libraries\Session\Session_driver.php 102
DEBUG - 2023-09-27 12:36:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:36:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:36:55 --> 404 Page Not Found: Welcome/login
DEBUG - 2023-09-27 12:36:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:36:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-27 12:36:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:36:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-27 12:37:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:37:01 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-27 12:37:01 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-27 12:37:01 --> Total execution time: 0.0469
DEBUG - 2023-09-27 12:37:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:37:07 --> initController - LoginPage.php
DEBUG - 2023-09-27 12:37:07 --> Total execution time: 0.0448
DEBUG - 2023-09-27 12:37:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:37:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:37:07 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:38:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:38:26 --> No URI present. Default controller set.
DEBUG - 2023-09-27 12:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:38:26 --> initController - LoginPage.php
DEBUG - 2023-09-27 12:38:26 --> Total execution time: 0.0437
DEBUG - 2023-09-27 12:38:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:38:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:38:26 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:38:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-27 12:38:40 --> Total execution time: 0.0386
DEBUG - 2023-09-27 12:38:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:38:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:38:40 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-27 12:38:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:38:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-27 12:38:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:38:40 --> 404 Page Not Found: Img/women-3.jpg
DEBUG - 2023-09-27 12:38:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-27 12:38:40 --> 404 Page Not Found: Img/watch-3.jpg
