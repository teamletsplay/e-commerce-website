<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-09-30 02:59:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 02:59:20 --> No URI present. Default controller set.
DEBUG - 2023-09-30 02:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 02:59:20 --> initController - LoginPage.php
DEBUG - 2023-09-30 02:59:20 --> Total execution time: 0.0460
DEBUG - 2023-09-30 02:59:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 02:59:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 02:59:20 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 02:59:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 02:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 02:59:23 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 02:59:23 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-30 02:59:23 --> Total execution time: 0.0669
DEBUG - 2023-09-30 02:59:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 02:59:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 02:59:23 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 02:59:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 02:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 02:59:35 --> initController - LoginPage.php
DEBUG - 2023-09-30 02:59:35 --> Total execution time: 0.0613
DEBUG - 2023-09-30 02:59:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 02:59:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 02:59:35 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 02:59:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 02:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 02:59:35 --> initController - LoginPage.php
DEBUG - 2023-09-30 02:59:35 --> Total execution time: 0.0347
DEBUG - 2023-09-30 02:59:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 02:59:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 02:59:35 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 02:59:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 02:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 02:59:36 --> initController - LoginPage.php
DEBUG - 2023-09-30 02:59:36 --> Total execution time: 0.0435
DEBUG - 2023-09-30 02:59:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 02:59:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 02:59:36 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 02:59:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 02:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 02:59:36 --> initController - LoginPage.php
DEBUG - 2023-09-30 02:59:36 --> Total execution time: 0.0345
DEBUG - 2023-09-30 02:59:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 02:59:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 02:59:36 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 02:59:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 02:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 02:59:58 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 02:59:58 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-30 02:59:58 --> Total execution time: 0.0510
DEBUG - 2023-09-30 02:59:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 02:59:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 02:59:58 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 03:00:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 03:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 03:00:31 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 03:00:31 --> Severity: Warning --> Undefined property: stdClass::$username C:\xampp\htdocs\WebProject\application\controllers\login.php 99
DEBUG - 2023-09-30 03:00:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 03:00:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 03:00:31 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-30 03:00:31 --> initController - LoginPage.php
DEBUG - 2023-09-30 03:00:31 --> Total execution time: 0.0412
DEBUG - 2023-09-30 03:00:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 03:00:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 03:00:31 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 03:00:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 03:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 03:00:34 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 03:00:34 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-30 03:00:34 --> Total execution time: 0.0428
DEBUG - 2023-09-30 03:00:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 03:00:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 03:00:34 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 03:00:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 03:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 03:00:46 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 03:00:46 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-30 03:00:46 --> Severity: Notice --> session_start(): Ignoring session_start() because a session is already active C:\xampp\htdocs\WebProject\application\views\insert.php 2
ERROR - 2023-09-30 03:00:46 --> Severity: Warning --> include(./templates/top.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 7
ERROR - 2023-09-30 03:00:46 --> Severity: Warning --> include(): Failed opening './templates/top.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 7
ERROR - 2023-09-30 03:00:46 --> Severity: Warning --> include(./templates/navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 11
ERROR - 2023-09-30 03:00:46 --> Severity: Warning --> include(): Failed opening './templates/navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 11
ERROR - 2023-09-30 03:00:46 --> Severity: Warning --> include(./templates/sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 16
ERROR - 2023-09-30 03:00:46 --> Severity: Warning --> include(): Failed opening './templates/sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 16
ERROR - 2023-09-30 03:00:46 --> Severity: Warning --> include(./templates/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 47
ERROR - 2023-09-30 03:00:46 --> Severity: Warning --> include(): Failed opening './templates/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 47
DEBUG - 2023-09-30 03:00:46 --> Total execution time: 0.0542
DEBUG - 2023-09-30 03:00:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 03:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 03:00:49 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 03:00:49 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-30 03:00:49 --> Total execution time: 0.0430
DEBUG - 2023-09-30 03:00:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 03:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 03:00:56 --> initController - LoginPage.php
DEBUG - 2023-09-30 03:00:56 --> Total execution time: 0.0390
DEBUG - 2023-09-30 03:00:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 03:00:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 03:00:56 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 09:53:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 09:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 09:53:46 --> initController - LoginPage.php
DEBUG - 2023-09-30 09:53:46 --> Total execution time: 0.0336
DEBUG - 2023-09-30 09:53:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 09:53:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 09:53:46 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 09:54:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 09:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 09:54:16 --> Total execution time: 0.0303
DEBUG - 2023-09-30 09:54:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 09:54:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 09:54:16 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 09:54:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 09:54:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 09:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 09:54:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 09:54:16 --> 404 Page Not Found: Img/women-3.jpg
ERROR - 2023-09-30 09:54:16 --> 404 Page Not Found: Img/watch-3.jpg
DEBUG - 2023-09-30 09:54:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 09:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 09:54:38 --> initController - LoginPage.php
DEBUG - 2023-09-30 09:54:38 --> Total execution time: 0.0398
DEBUG - 2023-09-30 09:54:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 09:54:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 09:54:38 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 09:54:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 09:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 09:54:41 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 09:54:41 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-30 09:54:41 --> Severity: Notice --> session_start(): Ignoring session_start() because a session is already active C:\xampp\htdocs\WebProject\application\views\insert.php 2
ERROR - 2023-09-30 09:54:41 --> Severity: Warning --> include(./templates/top.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 7
ERROR - 2023-09-30 09:54:41 --> Severity: Warning --> include(): Failed opening './templates/top.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 7
ERROR - 2023-09-30 09:54:41 --> Severity: Warning --> include(./templates/navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 11
ERROR - 2023-09-30 09:54:41 --> Severity: Warning --> include(): Failed opening './templates/navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 11
ERROR - 2023-09-30 09:54:41 --> Severity: Warning --> include(./templates/sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 16
ERROR - 2023-09-30 09:54:41 --> Severity: Warning --> include(): Failed opening './templates/sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 16
ERROR - 2023-09-30 09:54:41 --> Severity: Warning --> include(./templates/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 47
ERROR - 2023-09-30 09:54:41 --> Severity: Warning --> include(): Failed opening './templates/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 47
DEBUG - 2023-09-30 09:54:41 --> Total execution time: 0.0411
DEBUG - 2023-09-30 09:54:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 09:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 09:54:47 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 09:54:47 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-30 09:54:47 --> Total execution time: 0.0329
DEBUG - 2023-09-30 09:54:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 09:54:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 09:54:47 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:14:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:14:02 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 12:14:02 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-30 12:14:02 --> Total execution time: 0.0440
DEBUG - 2023-09-30 12:14:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:14:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:14:02 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:14:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:14:18 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 12:14:18 --> Severity: Warning --> Undefined property: stdClass::$username C:\xampp\htdocs\WebProject\application\controllers\login.php 99
DEBUG - 2023-09-30 12:14:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:14:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:14:18 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-30 12:14:18 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:14:18 --> Total execution time: 0.0235
DEBUG - 2023-09-30 12:14:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:14:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:14:18 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:14:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:14:20 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 12:14:20 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-30 12:14:20 --> Total execution time: 0.0256
DEBUG - 2023-09-30 12:14:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:14:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:14:20 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:14:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:14:27 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:14:27 --> Total execution time: 0.0560
DEBUG - 2023-09-30 12:14:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:14:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:14:27 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:14:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:14:29 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:14:29 --> Total execution time: 0.0216
DEBUG - 2023-09-30 12:14:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:14:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:14:29 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:25:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:25:56 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:25:56 --> Total execution time: 0.0279
DEBUG - 2023-09-30 12:25:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:25:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:25:56 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:26:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:26:41 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:26:41 --> Total execution time: 0.0250
DEBUG - 2023-09-30 12:26:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:26:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:26:41 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:26:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:26:50 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 12:26:50 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-30 12:26:50 --> Total execution time: 0.0388
DEBUG - 2023-09-30 12:26:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:26:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:26:50 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:27:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:27:10 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 12:27:10 --> Severity: Warning --> Undefined property: stdClass::$username C:\xampp\htdocs\WebProject\application\controllers\login.php 99
DEBUG - 2023-09-30 12:27:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:27:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:27:10 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-30 12:27:10 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:27:10 --> Total execution time: 0.0273
DEBUG - 2023-09-30 12:27:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:27:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:27:10 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:33:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:33:28 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 46
DEBUG - 2023-09-30 12:33:28 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:33:28 --> Total execution time: 0.0256
DEBUG - 2023-09-30 12:33:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:33:28 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:35:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:35:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:35:17 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 46
DEBUG - 2023-09-30 12:35:17 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:35:17 --> Total execution time: 0.0378
DEBUG - 2023-09-30 12:35:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:35:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:35:17 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:35:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:35:36 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 12:35:36 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 46
DEBUG - 2023-09-30 12:35:36 --> Total execution time: 0.0292
DEBUG - 2023-09-30 12:35:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:35:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:35:36 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:35:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:35:39 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 12:35:39 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 46
DEBUG - 2023-09-30 12:35:39 --> Total execution time: 0.0283
DEBUG - 2023-09-30 12:35:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:35:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:35:39 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:36:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:36:02 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 12:36:02 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 43
DEBUG - 2023-09-30 12:36:02 --> Total execution time: 0.0315
DEBUG - 2023-09-30 12:36:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:36:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:36:02 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:36:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:36:03 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 12:36:03 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 43
DEBUG - 2023-09-30 12:36:03 --> Total execution time: 0.0289
DEBUG - 2023-09-30 12:36:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:36:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:36:03 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:36:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:36:03 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 12:36:03 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 43
DEBUG - 2023-09-30 12:36:03 --> Total execution time: 0.0274
DEBUG - 2023-09-30 12:36:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:36:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:36:03 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:36:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:36:03 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 12:36:03 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 43
DEBUG - 2023-09-30 12:36:03 --> Total execution time: 0.0267
DEBUG - 2023-09-30 12:36:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:36:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:36:04 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:36:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:36:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:36:07 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 43
DEBUG - 2023-09-30 12:36:07 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:36:07 --> Total execution time: 0.0457
DEBUG - 2023-09-30 12:36:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:36:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:36:07 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:36:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:36:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:36:08 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 43
DEBUG - 2023-09-30 12:36:08 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:36:08 --> Total execution time: 0.0245
DEBUG - 2023-09-30 12:36:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:36:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:36:08 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:36:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:36:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:36:08 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 43
DEBUG - 2023-09-30 12:36:08 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:36:08 --> Total execution time: 0.0239
DEBUG - 2023-09-30 12:36:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:36:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:36:08 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:36:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:36:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:36:08 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 43
DEBUG - 2023-09-30 12:36:08 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:36:08 --> Total execution time: 0.0237
DEBUG - 2023-09-30 12:36:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:36:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:36:08 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:36:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:36:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:36:09 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 43
DEBUG - 2023-09-30 12:36:09 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:36:09 --> Total execution time: 0.0244
DEBUG - 2023-09-30 12:36:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:36:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:36:09 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:36:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:36:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:36:09 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 43
DEBUG - 2023-09-30 12:36:09 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:36:09 --> Total execution time: 0.0245
DEBUG - 2023-09-30 12:36:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:36:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:36:09 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:36:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:36:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:36:10 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 43
DEBUG - 2023-09-30 12:36:10 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:36:10 --> Total execution time: 0.0260
DEBUG - 2023-09-30 12:36:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:36:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:36:10 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:36:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:36:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:36:10 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 43
DEBUG - 2023-09-30 12:36:10 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:36:10 --> Total execution time: 0.0264
DEBUG - 2023-09-30 12:36:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:36:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:36:10 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:36:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:36:26 --> No URI present. Default controller set.
DEBUG - 2023-09-30 12:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:36:26 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:36:26 --> Total execution time: 0.0244
DEBUG - 2023-09-30 12:36:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:36:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:36:26 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:37:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:37:22 --> No URI present. Default controller set.
DEBUG - 2023-09-30 12:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:37:22 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:37:22 --> Total execution time: 0.0287
DEBUG - 2023-09-30 12:37:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:37:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:37:22 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:37:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:37:22 --> No URI present. Default controller set.
DEBUG - 2023-09-30 12:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:37:22 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:37:22 --> Total execution time: 0.0246
DEBUG - 2023-09-30 12:37:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:37:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:37:22 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:37:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:37:23 --> No URI present. Default controller set.
DEBUG - 2023-09-30 12:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:37:23 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:37:23 --> Total execution time: 0.0241
DEBUG - 2023-09-30 12:37:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:37:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:37:23 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:37:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:37:23 --> No URI present. Default controller set.
DEBUG - 2023-09-30 12:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:37:23 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:37:23 --> Total execution time: 0.0252
DEBUG - 2023-09-30 12:37:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:37:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:37:23 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:37:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:37:23 --> No URI present. Default controller set.
DEBUG - 2023-09-30 12:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:37:23 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:37:23 --> Total execution time: 0.0229
DEBUG - 2023-09-30 12:37:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:37:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:37:23 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:37:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:37:23 --> No URI present. Default controller set.
DEBUG - 2023-09-30 12:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:37:23 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:37:23 --> Total execution time: 0.0354
DEBUG - 2023-09-30 12:37:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:37:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:37:23 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:37:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:37:23 --> No URI present. Default controller set.
DEBUG - 2023-09-30 12:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:37:23 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:37:23 --> Total execution time: 0.0237
DEBUG - 2023-09-30 12:37:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:37:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:37:23 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:37:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:37:24 --> No URI present. Default controller set.
DEBUG - 2023-09-30 12:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:37:24 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:37:24 --> Total execution time: 0.0237
DEBUG - 2023-09-30 12:37:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:37:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:37:24 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:37:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:37:24 --> No URI present. Default controller set.
DEBUG - 2023-09-30 12:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:37:24 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:37:24 --> Total execution time: 0.0238
DEBUG - 2023-09-30 12:37:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:37:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:37:24 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:37:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:37:24 --> No URI present. Default controller set.
DEBUG - 2023-09-30 12:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:37:24 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:37:24 --> Total execution time: 0.0230
DEBUG - 2023-09-30 12:37:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:37:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:37:24 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:37:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:37:24 --> No URI present. Default controller set.
DEBUG - 2023-09-30 12:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:37:24 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:37:24 --> Total execution time: 0.0398
DEBUG - 2023-09-30 12:37:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:37:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:37:24 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:37:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:37:50 --> No URI present. Default controller set.
DEBUG - 2023-09-30 12:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:37:50 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:37:50 --> Total execution time: 0.0247
DEBUG - 2023-09-30 12:37:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:37:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:37:50 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:38:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:38:44 --> No URI present. Default controller set.
DEBUG - 2023-09-30 12:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:38:44 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:38:44 --> Total execution time: 0.0385
DEBUG - 2023-09-30 12:38:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:38:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:38:44 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:38:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:38:57 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 12:38:57 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-30 12:38:57 --> Total execution time: 0.0290
DEBUG - 2023-09-30 12:38:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:38:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:38:57 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:39:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:39:01 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:39:01 --> Total execution time: 0.0223
DEBUG - 2023-09-30 12:39:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:39:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:39:01 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:39:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:39:04 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 12:39:04 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-30 12:39:04 --> Severity: Notice --> session_start(): Ignoring session_start() because a session is already active C:\xampp\htdocs\WebProject\application\views\insert.php 2
ERROR - 2023-09-30 12:39:04 --> Severity: Warning --> include(./templates/top.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 7
ERROR - 2023-09-30 12:39:04 --> Severity: Warning --> include(): Failed opening './templates/top.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 7
ERROR - 2023-09-30 12:39:04 --> Severity: Warning --> include(./templates/navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 11
ERROR - 2023-09-30 12:39:04 --> Severity: Warning --> include(): Failed opening './templates/navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 11
ERROR - 2023-09-30 12:39:04 --> Severity: Warning --> include(./templates/sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 16
ERROR - 2023-09-30 12:39:04 --> Severity: Warning --> include(): Failed opening './templates/sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 16
ERROR - 2023-09-30 12:39:04 --> Severity: Warning --> include(./templates/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 47
ERROR - 2023-09-30 12:39:04 --> Severity: Warning --> include(): Failed opening './templates/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 47
DEBUG - 2023-09-30 12:39:04 --> Total execution time: 0.0326
DEBUG - 2023-09-30 12:39:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:39:10 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 12:39:10 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-30 12:39:10 --> Total execution time: 0.0269
DEBUG - 2023-09-30 12:39:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:39:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:39:10 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:39:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:39:15 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 12:39:15 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-30 12:39:15 --> Total execution time: 0.0266
DEBUG - 2023-09-30 12:39:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:39:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:39:15 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:39:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:39:16 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 12:39:16 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-30 12:39:16 --> Total execution time: 0.0291
DEBUG - 2023-09-30 12:39:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:39:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:39:16 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:39:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:39:16 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 12:39:16 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-30 12:39:16 --> Total execution time: 0.0254
DEBUG - 2023-09-30 12:39:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:39:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:39:16 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:39:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:39:17 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 12:39:17 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-30 12:39:17 --> Total execution time: 0.0263
DEBUG - 2023-09-30 12:39:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:39:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:39:17 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:39:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:39:18 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 12:39:18 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-30 12:39:18 --> Severity: Notice --> session_start(): Ignoring session_start() because a session is already active C:\xampp\htdocs\WebProject\application\views\insert.php 2
ERROR - 2023-09-30 12:39:18 --> Severity: Warning --> include(./templates/top.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 7
ERROR - 2023-09-30 12:39:18 --> Severity: Warning --> include(): Failed opening './templates/top.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 7
ERROR - 2023-09-30 12:39:18 --> Severity: Warning --> include(./templates/navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 11
ERROR - 2023-09-30 12:39:18 --> Severity: Warning --> include(): Failed opening './templates/navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 11
ERROR - 2023-09-30 12:39:18 --> Severity: Warning --> include(./templates/sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 16
ERROR - 2023-09-30 12:39:18 --> Severity: Warning --> include(): Failed opening './templates/sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 16
ERROR - 2023-09-30 12:39:18 --> Severity: Warning --> include(./templates/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 47
ERROR - 2023-09-30 12:39:18 --> Severity: Warning --> include(): Failed opening './templates/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 47
DEBUG - 2023-09-30 12:39:18 --> Total execution time: 0.0316
DEBUG - 2023-09-30 12:39:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:39:20 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 12:39:20 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-30 12:39:20 --> Total execution time: 0.0260
DEBUG - 2023-09-30 12:39:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:39:22 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:39:22 --> Total execution time: 0.0234
DEBUG - 2023-09-30 12:39:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:39:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:39:22 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:39:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:39:23 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:39:23 --> Total execution time: 0.0351
DEBUG - 2023-09-30 12:39:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:39:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:39:23 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:39:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:39:24 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:39:24 --> Total execution time: 0.0216
DEBUG - 2023-09-30 12:39:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:39:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:39:24 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:39:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:39:24 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:39:24 --> Total execution time: 0.0264
DEBUG - 2023-09-30 12:39:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:39:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:39:24 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:41:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:41:03 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:41:03 --> Total execution time: 0.0219
DEBUG - 2023-09-30 12:41:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:41:03 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:41:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:41:03 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:41:03 --> Total execution time: 0.0235
DEBUG - 2023-09-30 12:41:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:41:03 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:41:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:41:04 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:41:04 --> Total execution time: 0.0219
DEBUG - 2023-09-30 12:41:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:41:04 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:41:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:41:04 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:41:04 --> Total execution time: 0.0226
DEBUG - 2023-09-30 12:41:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:41:04 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:41:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:41:04 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:41:04 --> Total execution time: 0.0264
DEBUG - 2023-09-30 12:41:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:41:04 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:41:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:41:04 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:41:04 --> Total execution time: 0.0221
DEBUG - 2023-09-30 12:41:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:41:04 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:41:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:41:04 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:41:04 --> Total execution time: 0.0218
DEBUG - 2023-09-30 12:41:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:41:04 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:41:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:41:05 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:41:05 --> Total execution time: 0.0217
DEBUG - 2023-09-30 12:41:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:41:05 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:41:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:41:05 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:41:05 --> Total execution time: 0.0223
DEBUG - 2023-09-30 12:41:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:41:05 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:41:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:41:05 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:41:05 --> Total execution time: 0.0218
DEBUG - 2023-09-30 12:41:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:41:05 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:41:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:41:05 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:41:05 --> Total execution time: 0.0221
DEBUG - 2023-09-30 12:41:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:41:05 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:41:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:41:05 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:41:05 --> Total execution time: 0.0217
DEBUG - 2023-09-30 12:41:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:41:05 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:41:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:41:06 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:41:06 --> Total execution time: 0.0231
DEBUG - 2023-09-30 12:41:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:41:06 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:41:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:41:06 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:41:06 --> Total execution time: 0.0220
DEBUG - 2023-09-30 12:41:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:41:06 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:41:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:41:06 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:41:06 --> Total execution time: 0.0389
DEBUG - 2023-09-30 12:41:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:41:06 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:41:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:41:06 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:41:06 --> Total execution time: 0.0266
DEBUG - 2023-09-30 12:41:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:41:06 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:41:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:41:07 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:41:07 --> Total execution time: 0.0234
DEBUG - 2023-09-30 12:41:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:41:07 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:41:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:41:07 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:41:07 --> Total execution time: 0.0227
DEBUG - 2023-09-30 12:41:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:41:07 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:41:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:41:07 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:41:07 --> Total execution time: 0.0463
DEBUG - 2023-09-30 12:41:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:41:07 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:41:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:41:07 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:41:07 --> Total execution time: 0.0231
DEBUG - 2023-09-30 12:41:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:41:07 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:41:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:41:07 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:41:07 --> Total execution time: 0.0221
DEBUG - 2023-09-30 12:41:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:41:07 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:41:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:41:08 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:41:08 --> Total execution time: 0.0219
DEBUG - 2023-09-30 12:41:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:41:08 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:41:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:41:08 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:41:08 --> Total execution time: 0.0231
DEBUG - 2023-09-30 12:41:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:41:08 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:41:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:41:08 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:41:08 --> Total execution time: 0.0223
DEBUG - 2023-09-30 12:41:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:41:08 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:41:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:41:08 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:41:08 --> Total execution time: 0.0265
DEBUG - 2023-09-30 12:41:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:41:08 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:41:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:41:08 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:41:08 --> Total execution time: 0.0220
DEBUG - 2023-09-30 12:41:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:41:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:41:08 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:42:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:42:05 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:42:05 --> Total execution time: 0.0247
DEBUG - 2023-09-30 12:42:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:42:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:42:05 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:42:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:42:05 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:42:05 --> Total execution time: 0.0240
DEBUG - 2023-09-30 12:42:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:42:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:42:05 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:42:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:42:05 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:42:05 --> Total execution time: 0.0247
DEBUG - 2023-09-30 12:42:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:42:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:42:05 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:42:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:42:06 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:42:06 --> Total execution time: 0.0230
DEBUG - 2023-09-30 12:42:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:42:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:42:06 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:42:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:42:06 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:42:06 --> Total execution time: 0.0238
DEBUG - 2023-09-30 12:42:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:42:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:42:06 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:42:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:42:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:42:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:42:38 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:42:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:42:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:42:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:42:39 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:42:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:42:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:42:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:42:39 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:42:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:42:52 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:42:52 --> Total execution time: 0.0256
DEBUG - 2023-09-30 12:42:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:42:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:42:52 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:43:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:43:45 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:43:45 --> Total execution time: 0.0249
DEBUG - 2023-09-30 12:43:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:43:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:43:45 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:43:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:43:46 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:43:46 --> Total execution time: 0.0247
DEBUG - 2023-09-30 12:43:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:43:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:43:46 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:43:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:43:46 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:43:46 --> Total execution time: 0.0253
DEBUG - 2023-09-30 12:43:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:43:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:43:46 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:45:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:45:32 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:45:32 --> Total execution time: 0.0235
DEBUG - 2023-09-30 12:45:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:45:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:45:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:45:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:45:32 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:45:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:45:32 --> 404 Page Not Found: Scriptjs/index
ERROR - 2023-09-30 12:45:32 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-30 12:46:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:46:05 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 12:46:05 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-30 12:46:05 --> Total execution time: 0.0271
DEBUG - 2023-09-30 12:46:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:46:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:46:05 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:46:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:46:22 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 12:46:22 --> Severity: Warning --> Undefined property: stdClass::$username C:\xampp\htdocs\WebProject\application\controllers\login.php 99
DEBUG - 2023-09-30 12:46:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:46:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:46:22 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-30 12:46:22 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:46:22 --> Total execution time: 0.0235
DEBUG - 2023-09-30 12:46:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:46:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:46:22 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:46:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:46:57 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 12:46:57 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-30 12:46:57 --> Total execution time: 0.0275
DEBUG - 2023-09-30 12:46:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:46:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:46:57 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:47:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:47:01 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 12:47:01 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\WebProject\system\libraries\Session\Session_driver.php 102
DEBUG - 2023-09-30 12:47:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:47:01 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 12:47:01 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-30 12:47:01 --> Total execution time: 0.0556
DEBUG - 2023-09-30 12:47:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:47:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:47:01 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:47:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:47:03 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:47:03 --> Total execution time: 0.0244
DEBUG - 2023-09-30 12:47:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:47:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:47:03 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:49:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:49:03 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:49:03 --> Total execution time: 0.0418
DEBUG - 2023-09-30 12:49:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:49:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:49:03 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:49:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:49:04 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:49:04 --> Total execution time: 0.0411
DEBUG - 2023-09-30 12:49:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:49:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:49:04 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:49:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:49:04 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:49:04 --> Total execution time: 0.0404
DEBUG - 2023-09-30 12:49:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:49:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:49:04 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:49:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:49:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:49:20 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:49:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:49:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:49:20 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-30 12:49:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:49:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:49:21 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-30 12:49:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:49:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:49:21 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-30 12:51:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:51:23 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 12:51:23 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-30 12:51:23 --> Total execution time: 0.0497
DEBUG - 2023-09-30 12:51:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:51:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:51:23 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 12:51:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 12:51:40 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 12:51:40 --> Severity: Warning --> Undefined property: stdClass::$username C:\xampp\htdocs\WebProject\application\controllers\login.php 99
DEBUG - 2023-09-30 12:51:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:51:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:51:41 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-30 12:51:41 --> initController - LoginPage.php
DEBUG - 2023-09-30 12:51:41 --> Total execution time: 0.0421
DEBUG - 2023-09-30 12:51:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 12:51:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 12:51:41 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:00:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:00:22 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 13:00:22 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-30 13:00:22 --> Total execution time: 0.0513
DEBUG - 2023-09-30 13:00:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:00:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:00:22 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:00:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:00:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:00:25 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-30 13:00:25 --> initController - LoginPage.php
DEBUG - 2023-09-30 13:00:25 --> Total execution time: 0.0420
DEBUG - 2023-09-30 13:00:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:00:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:00:25 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:00:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:00:28 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 13:00:28 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-30 13:00:28 --> Total execution time: 0.0465
DEBUG - 2023-09-30 13:00:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:00:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:00:28 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:00:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:00:31 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 13:00:31 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\WebProject\system\libraries\Session\Session_driver.php 102
DEBUG - 2023-09-30 13:00:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:00:31 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 13:00:31 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-30 13:00:31 --> Total execution time: 0.0468
DEBUG - 2023-09-30 13:00:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:00:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:00:31 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:00:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:00:33 --> initController - LoginPage.php
DEBUG - 2023-09-30 13:00:33 --> Total execution time: 0.0399
DEBUG - 2023-09-30 13:00:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:00:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:00:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:00:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:00:33 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:00:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:00:33 --> 404 Page Not Found: Scriptjs/index
DEBUG - 2023-09-30 13:00:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:00:33 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-30 13:00:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:00:44 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:00:44 --> initController - LoginPage.php
DEBUG - 2023-09-30 13:00:44 --> Total execution time: 0.0469
DEBUG - 2023-09-30 13:00:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:00:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:00:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:00:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:00:46 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-30 13:00:46 --> 404 Page Not Found: Scriptjs/index
DEBUG - 2023-09-30 13:00:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:00:46 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:01:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:01:27 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:01:27 --> initController - LoginPage.php
DEBUG - 2023-09-30 13:01:27 --> Total execution time: 0.0448
DEBUG - 2023-09-30 13:01:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:01:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:01:27 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:02:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:02:37 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:02:37 --> initController - LoginPage.php
DEBUG - 2023-09-30 13:02:37 --> Total execution time: 0.0556
DEBUG - 2023-09-30 13:02:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:02:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:02:37 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:03:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:03:49 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:03:49 --> initController - LoginPage.php
DEBUG - 2023-09-30 13:03:49 --> Total execution time: 0.0445
DEBUG - 2023-09-30 13:03:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:03:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:03:49 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:04:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:04:48 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:04:48 --> initController - LoginPage.php
DEBUG - 2023-09-30 13:04:48 --> Total execution time: 0.0400
DEBUG - 2023-09-30 13:04:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:04:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:04:48 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:07:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:07:26 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:07:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:07:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:07:26 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:07:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:07:55 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:07:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:07:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:07:55 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:07:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:07:56 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:07:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:07:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:07:56 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:07:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:07:56 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:07:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:07:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:07:56 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:07:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:07:56 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:07:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:07:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:07:57 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:07:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:07:57 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:07:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:07:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:07:57 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:07:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:07:57 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:07:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:07:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:07:57 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:07:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:07:57 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:07:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:07:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:07:57 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:07:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:07:57 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:07:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:07:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:07:57 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:07:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:07:58 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:07:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:07:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:07:58 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:08:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:34 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:08:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:08:34 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:08:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:35 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:08:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:08:35 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:08:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:35 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:08:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:08:35 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:08:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:35 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:08:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:08:35 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:08:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:35 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:08:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:08:35 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:08:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:35 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:08:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:08:35 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:08:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:35 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:08:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:08:35 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:08:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:36 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:08:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:08:36 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:08:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:36 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:08:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:08:36 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:08:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:36 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:08:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:08:36 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:08:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:36 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:08:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:08:36 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:08:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:36 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:08:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:08:36 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:08:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:37 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:08:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:08:37 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:08:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:37 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:08:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:08:37 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:08:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:37 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:08:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:08:37 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:08:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:38 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:08:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:08:38 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:08:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:38 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:08:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:08:38 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:08:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:38 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:08:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:08:38 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:08:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:38 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:08:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:08:38 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:08:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:38 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:08:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:08:38 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:08:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:39 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:08:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:08:39 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:08:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:39 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:08:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:08:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:08:39 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:11:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:11:01 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:11:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:11:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:11:01 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:11:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:11:02 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:11:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:11:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:11:02 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:11:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:11:02 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:11:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:11:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:11:02 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:11:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:11:02 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:11:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:11:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:11:02 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:11:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:11:02 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:11:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:11:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:11:02 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:11:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:11:38 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:11:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:11:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:11:38 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:11:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:11:39 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:11:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:11:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:11:39 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:11:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:11:39 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:11:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:11:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:11:39 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:11:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:11:40 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:11:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:11:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:11:40 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:11:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:11:40 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:11:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:11:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:11:40 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:12:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:12:14 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:12:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:12:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:12:14 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:12:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:12:14 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:12:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:12:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:12:14 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:12:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:12:14 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:12:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:12:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:12:14 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:12:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:12:15 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:12:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:12:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:12:15 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:12:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:12:15 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:12:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:12:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:12:15 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:12:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:12:15 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:12:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:12:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:12:15 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:12:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:12:15 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:12:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:12:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:12:15 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:12:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:12:15 --> No URI present. Default controller set.
DEBUG - 2023-09-30 13:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:12:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:12:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:12:16 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:12:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:12:17 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 13:12:17 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-30 13:12:17 --> Total execution time: 0.0474
DEBUG - 2023-09-30 13:12:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:12:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:12:17 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:12:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:12:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:12:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:12:19 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:14:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:14:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:14:05 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\header.php 42
DEBUG - 2023-09-30 13:14:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:14:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:14:21 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\header.php 42
DEBUG - 2023-09-30 13:14:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:14:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:14:22 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\header.php 42
DEBUG - 2023-09-30 13:14:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:14:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:14:22 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\header.php 42
DEBUG - 2023-09-30 13:14:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:14:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:14:23 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\header.php 42
DEBUG - 2023-09-30 13:14:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:14:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:14:23 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\header.php 42
DEBUG - 2023-09-30 13:14:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:14:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:14:23 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\header.php 42
DEBUG - 2023-09-30 13:14:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:14:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:14:23 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\header.php 42
DEBUG - 2023-09-30 13:14:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:14:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:14:24 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\header.php 42
DEBUG - 2023-09-30 13:14:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:14:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:14:24 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\header.php 42
DEBUG - 2023-09-30 13:14:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:14:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:14:24 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\header.php 42
DEBUG - 2023-09-30 13:14:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:14:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:14:24 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\header.php 42
DEBUG - 2023-09-30 13:14:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:14:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:14:25 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\header.php 42
DEBUG - 2023-09-30 13:14:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:14:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:14:25 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\header.php 42
DEBUG - 2023-09-30 13:14:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:14:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:14:26 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\header.php 42
DEBUG - 2023-09-30 13:14:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:14:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:14:26 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\header.php 42
DEBUG - 2023-09-30 13:14:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:14:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:14:56 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\header.php 42
DEBUG - 2023-09-30 13:14:56 --> initController - LoginPage.php
DEBUG - 2023-09-30 13:14:56 --> Total execution time: 0.0443
DEBUG - 2023-09-30 13:14:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:14:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:14:56 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:15:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:15:05 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 13:15:05 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-30 13:15:05 --> Total execution time: 0.0706
DEBUG - 2023-09-30 13:15:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:15:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:15:05 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:15:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:15:33 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 13:15:33 --> Severity: Warning --> Undefined property: stdClass::$username C:\xampp\htdocs\WebProject\application\controllers\login.php 99
DEBUG - 2023-09-30 13:15:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:15:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:15:33 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-30 13:15:33 --> initController - LoginPage.php
DEBUG - 2023-09-30 13:15:33 --> Total execution time: 0.0431
DEBUG - 2023-09-30 13:15:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:15:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:15:33 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:16:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:16:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:16:34 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-30 13:16:34 --> initController - LoginPage.php
DEBUG - 2023-09-30 13:16:34 --> Total execution time: 0.0423
DEBUG - 2023-09-30 13:16:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:16:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:16:34 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:16:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:16:38 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 13:16:38 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-30 13:16:38 --> Total execution time: 0.0494
DEBUG - 2023-09-30 13:16:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:16:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:16:38 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:16:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:16:39 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 13:16:39 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\WebProject\system\libraries\Session\Session_driver.php 102
DEBUG - 2023-09-30 13:16:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:16:39 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 13:16:39 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-30 13:16:39 --> Total execution time: 0.0472
DEBUG - 2023-09-30 13:16:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:16:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:16:39 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:16:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:16:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:16:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:16:42 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:16:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:16:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:16:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:16:43 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:16:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:16:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:16:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:16:44 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:16:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:16:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:16:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:16:44 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:16:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:16:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:16:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:16:44 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:16:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:16:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:16:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:16:45 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:17:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:17:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:17:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:17:10 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:17:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:17:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:17:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:17:10 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:17:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:17:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:17:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:17:10 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:17:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:17:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:17:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:17:11 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:17:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:17:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:17:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:17:11 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:17:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:17:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:17:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:17:11 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:17:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:17:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:17:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:17:11 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:17:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:17:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:17:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:17:11 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:17:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:17:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:17:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:17:12 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:18:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:18:23 --> initController - LoginPage.php
DEBUG - 2023-09-30 13:18:23 --> Total execution time: 0.0401
DEBUG - 2023-09-30 13:20:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:20:06 --> initController - LoginPage.php
DEBUG - 2023-09-30 13:20:06 --> Total execution time: 0.0439
DEBUG - 2023-09-30 13:20:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:20:07 --> initController - LoginPage.php
DEBUG - 2023-09-30 13:20:07 --> Total execution time: 0.0389
DEBUG - 2023-09-30 13:20:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:20:07 --> initController - LoginPage.php
DEBUG - 2023-09-30 13:20:07 --> Total execution time: 0.0410
DEBUG - 2023-09-30 13:20:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:20:07 --> initController - LoginPage.php
DEBUG - 2023-09-30 13:20:07 --> Total execution time: 0.0391
DEBUG - 2023-09-30 13:20:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 13:20:08 --> initController - LoginPage.php
DEBUG - 2023-09-30 13:20:08 --> Total execution time: 0.0560
DEBUG - 2023-09-30 13:20:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:20:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:20:35 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\header.php 42
DEBUG - 2023-09-30 13:20:35 --> initController - LoginPage.php
DEBUG - 2023-09-30 13:20:35 --> Total execution time: 0.0690
DEBUG - 2023-09-30 13:20:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:20:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:20:35 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 13:20:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:20:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:20:57 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\header.php 42
DEBUG - 2023-09-30 13:20:57 --> initController - LoginPage.php
DEBUG - 2023-09-30 13:20:57 --> Total execution time: 0.0448
DEBUG - 2023-09-30 13:20:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 13:20:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 13:20:57 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 16:25:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:25:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:25:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:25:26 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 16:26:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:26:33 --> initController - LoginPage.php
DEBUG - 2023-09-30 16:26:33 --> Total execution time: 0.0307
DEBUG - 2023-09-30 16:26:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:26:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:26:33 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 16:31:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:31:03 --> initController - LoginPage.php
DEBUG - 2023-09-30 16:31:03 --> Total execution time: 0.0201
DEBUG - 2023-09-30 16:31:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:31:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:31:03 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 16:32:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:32:26 --> initController - LoginPage.php
DEBUG - 2023-09-30 16:32:26 --> Total execution time: 0.0195
DEBUG - 2023-09-30 16:32:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:32:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:32:26 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 16:32:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:32:44 --> initController - LoginPage.php
DEBUG - 2023-09-30 16:32:44 --> Total execution time: 0.0189
DEBUG - 2023-09-30 16:32:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:32:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:32:44 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 16:34:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:34:59 --> initController - LoginPage.php
DEBUG - 2023-09-30 16:34:59 --> Total execution time: 0.0204
DEBUG - 2023-09-30 16:34:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:34:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:34:59 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 16:35:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:35:40 --> initController - LoginPage.php
DEBUG - 2023-09-30 16:35:40 --> Total execution time: 0.0190
DEBUG - 2023-09-30 16:35:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:35:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:35:40 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 16:36:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:36:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:36:06 --> initController - LoginPage.php
DEBUG - 2023-09-30 16:36:06 --> Total execution time: 0.0201
DEBUG - 2023-09-30 16:36:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:36:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:36:06 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 16:37:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:37:00 --> Total execution time: 0.0191
DEBUG - 2023-09-30 16:37:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:37:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:37:00 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 16:37:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:37:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:37:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:37:00 --> 404 Page Not Found: Img/women-3.jpg
ERROR - 2023-09-30 16:37:00 --> 404 Page Not Found: Img/watch-3.jpg
DEBUG - 2023-09-30 16:42:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:42:56 --> Total execution time: 0.0190
DEBUG - 2023-09-30 16:42:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:42:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:42:56 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 16:42:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:42:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:42:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:42:56 --> 404 Page Not Found: Img/women-3.jpg
ERROR - 2023-09-30 16:42:56 --> 404 Page Not Found: Img/watch-3.jpg
DEBUG - 2023-09-30 16:43:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:43:09 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 16:43:09 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-30 16:43:09 --> Total execution time: 0.0264
DEBUG - 2023-09-30 16:43:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:43:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:43:09 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 16:43:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:43:33 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 16:43:33 --> Severity: Warning --> Undefined property: stdClass::$username C:\xampp\htdocs\WebProject\application\controllers\login.php 99
DEBUG - 2023-09-30 16:43:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:43:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:43:33 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-30 16:43:33 --> initController - LoginPage.php
DEBUG - 2023-09-30 16:43:33 --> Total execution time: 0.0205
DEBUG - 2023-09-30 16:43:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:43:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:43:33 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 16:43:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:43:36 --> Total execution time: 0.0186
DEBUG - 2023-09-30 16:43:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:43:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:43:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:43:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:43:36 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
ERROR - 2023-09-30 16:43:36 --> 404 Page Not Found: Img/women-3.jpg
ERROR - 2023-09-30 16:43:36 --> 404 Page Not Found: Img/watch-3.jpg
DEBUG - 2023-09-30 16:43:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:43:39 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 16:43:39 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-30 16:43:39 --> Total execution time: 0.0219
DEBUG - 2023-09-30 16:43:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:43:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:43:39 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 16:44:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:44:02 --> initController - LoginPage.php
DEBUG - 2023-09-30 16:44:02 --> Total execution time: 0.0193
DEBUG - 2023-09-30 16:44:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:44:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:44:02 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 16:44:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:44:10 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 16:44:10 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-30 16:44:10 --> Total execution time: 0.0222
DEBUG - 2023-09-30 16:44:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:44:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:44:10 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 16:44:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:44:40 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 16:44:40 --> Severity: Warning --> Undefined property: stdClass::$username C:\xampp\htdocs\WebProject\application\controllers\login.php 99
DEBUG - 2023-09-30 16:44:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:44:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:44:40 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-30 16:44:40 --> initController - LoginPage.php
DEBUG - 2023-09-30 16:44:40 --> Total execution time: 0.0502
DEBUG - 2023-09-30 16:44:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:44:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:44:40 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 16:44:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:44:45 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 16:44:45 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-30 16:44:45 --> Total execution time: 0.0346
DEBUG - 2023-09-30 16:44:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:44:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:44:45 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 16:45:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:45:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:45:32 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-30 16:45:32 --> initController - LoginPage.php
DEBUG - 2023-09-30 16:45:32 --> Total execution time: 0.0376
DEBUG - 2023-09-30 16:45:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:45:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:45:32 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 16:45:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:45:42 --> Total execution time: 0.0355
DEBUG - 2023-09-30 16:45:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:45:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:45:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:45:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:45:42 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
ERROR - 2023-09-30 16:45:42 --> 404 Page Not Found: Img/women-3.jpg
DEBUG - 2023-09-30 16:45:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:45:42 --> 404 Page Not Found: Img/watch-3.jpg
DEBUG - 2023-09-30 16:45:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:45:45 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 16:45:45 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-30 16:45:45 --> Total execution time: 0.0674
DEBUG - 2023-09-30 16:45:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:45:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:45:45 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 16:45:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:45:54 --> initController - LoginPage.php
DEBUG - 2023-09-30 16:45:54 --> Total execution time: 0.0369
DEBUG - 2023-09-30 16:45:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:45:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:45:54 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 16:45:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:45:56 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 16:45:56 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-30 16:45:56 --> Total execution time: 0.0407
DEBUG - 2023-09-30 16:45:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:45:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:45:56 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 16:45:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:45:58 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 16:45:58 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-30 16:45:58 --> Total execution time: 0.0422
DEBUG - 2023-09-30 16:45:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:45:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:45:58 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 16:45:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:45:59 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 16:45:59 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-30 16:45:59 --> Total execution time: 0.0591
DEBUG - 2023-09-30 16:45:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:45:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:45:59 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 16:45:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:45:59 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 16:45:59 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-30 16:45:59 --> Total execution time: 0.0407
DEBUG - 2023-09-30 16:45:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:45:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:45:59 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 16:46:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:46:01 --> initController - LoginPage.php
DEBUG - 2023-09-30 16:46:01 --> Total execution time: 0.0384
DEBUG - 2023-09-30 16:46:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:46:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:46:01 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 16:46:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:46:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:46:03 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 16:46:03 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-30 16:46:03 --> Total execution time: 0.0615
DEBUG - 2023-09-30 16:46:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:46:04 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 16:46:04 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-30 16:46:04 --> Total execution time: 0.0415
DEBUG - 2023-09-30 16:46:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:46:09 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 16:46:09 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-30 16:46:09 --> Total execution time: 0.0438
DEBUG - 2023-09-30 16:46:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:46:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:46:09 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 16:46:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:46:11 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 16:46:11 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\WebProject\system\libraries\Session\Session_driver.php 102
DEBUG - 2023-09-30 16:46:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:46:11 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 16:46:11 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-30 16:46:11 --> Total execution time: 0.0432
DEBUG - 2023-09-30 16:46:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:46:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:46:11 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 16:46:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:46:32 --> initController - LoginPage.php
DEBUG - 2023-09-30 16:46:32 --> Total execution time: 0.0352
DEBUG - 2023-09-30 16:46:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:46:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:46:32 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 16:54:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:54:57 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 16:54:57 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-30 16:54:57 --> Severity: Notice --> session_start(): Ignoring session_start() because a session is already active C:\xampp\htdocs\WebProject\application\views\insert.php 2
ERROR - 2023-09-30 16:54:57 --> Severity: Warning --> include(./templates/top.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 7
ERROR - 2023-09-30 16:54:57 --> Severity: Warning --> include(): Failed opening './templates/top.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 7
ERROR - 2023-09-30 16:54:57 --> Severity: Warning --> include(./templates/navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 11
ERROR - 2023-09-30 16:54:57 --> Severity: Warning --> include(): Failed opening './templates/navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 11
ERROR - 2023-09-30 16:54:57 --> Severity: Warning --> include(./templates/sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 16
ERROR - 2023-09-30 16:54:57 --> Severity: Warning --> include(): Failed opening './templates/sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 16
ERROR - 2023-09-30 16:54:57 --> Severity: Warning --> include(./templates/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 47
ERROR - 2023-09-30 16:54:57 --> Severity: Warning --> include(): Failed opening './templates/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 47
DEBUG - 2023-09-30 16:54:57 --> Total execution time: 0.0724
DEBUG - 2023-09-30 16:55:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:55:01 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 16:55:01 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-30 16:55:01 --> Total execution time: 0.0421
DEBUG - 2023-09-30 16:55:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:55:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:55:01 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 16:55:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 16:55:24 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 16:55:24 --> Severity: Warning --> Undefined property: stdClass::$username C:\xampp\htdocs\WebProject\application\controllers\login.php 99
DEBUG - 2023-09-30 16:55:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:55:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:55:24 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-30 16:55:24 --> initController - LoginPage.php
DEBUG - 2023-09-30 16:55:24 --> Total execution time: 0.0432
DEBUG - 2023-09-30 16:55:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:55:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:55:24 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 16:58:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:58:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:58:39 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-30 16:58:39 --> initController - LoginPage.php
DEBUG - 2023-09-30 16:58:39 --> Total execution time: 0.0395
DEBUG - 2023-09-30 16:58:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:58:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:58:39 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 16:58:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 16:58:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 16:58:42 --> Severity: error --> Exception: Unmatched '}' C:\xampp\htdocs\WebProject\application\controllers\productloggedin.php 52
DEBUG - 2023-09-30 17:00:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:00:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:00:08 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-30 17:00:08 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:00:08 --> Total execution time: 0.0404
DEBUG - 2023-09-30 17:00:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:00:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:00:08 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:00:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:00:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:00:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:00:08 --> 404 Page Not Found: Img/women-3.jpg
DEBUG - 2023-09-30 17:00:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:00:09 --> 404 Page Not Found: Img/watch-3.jpg
DEBUG - 2023-09-30 17:00:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:00:32 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 17:00:32 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-30 17:00:32 --> Total execution time: 0.0448
DEBUG - 2023-09-30 17:00:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:00:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:00:32 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:00:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:00:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:00:35 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-30 17:00:35 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:00:35 --> Total execution time: 0.0379
DEBUG - 2023-09-30 17:00:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:00:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:00:35 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:00:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:00:38 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 17:00:38 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-30 17:00:38 --> Total execution time: 0.0541
DEBUG - 2023-09-30 17:00:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:00:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:00:38 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:00:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:00:45 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 17:00:45 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-30 17:00:45 --> Total execution time: 0.0525
DEBUG - 2023-09-30 17:00:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:00:57 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 17:00:57 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-30 17:00:57 --> Total execution time: 0.0411
DEBUG - 2023-09-30 17:00:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:00:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:00:57 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:00:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:00:58 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 17:00:58 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\WebProject\system\libraries\Session\Session_driver.php 102
DEBUG - 2023-09-30 17:00:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:00:58 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 17:00:58 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-30 17:00:58 --> Total execution time: 0.0449
DEBUG - 2023-09-30 17:00:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:00:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:00:59 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:01:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:01:00 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:01:00 --> Total execution time: 0.0356
DEBUG - 2023-09-30 17:01:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:01:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:01:00 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:01:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:01:02 --> Total execution time: 0.0371
DEBUG - 2023-09-30 17:01:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:01:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:01:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:01:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:01:02 --> 404 Page Not Found: Img/watch-3.jpg
ERROR - 2023-09-30 17:01:02 --> 404 Page Not Found: Img/women-3.jpg
ERROR - 2023-09-30 17:01:02 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:04:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:04:13 --> Total execution time: 0.0432
DEBUG - 2023-09-30 17:04:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:04:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:04:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:04:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:04:13 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:04:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:04:13 --> 404 Page Not Found: Img/watch-3.jpg
ERROR - 2023-09-30 17:04:13 --> 404 Page Not Found: Img/women-3.jpg
DEBUG - 2023-09-30 17:04:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:04:59 --> Total execution time: 0.0447
DEBUG - 2023-09-30 17:04:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:04:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:04:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:04:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:04:59 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:04:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:04:59 --> 404 Page Not Found: Img/watch-3.jpg
ERROR - 2023-09-30 17:04:59 --> 404 Page Not Found: Img/women-3.jpg
DEBUG - 2023-09-30 17:06:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:06:17 --> Total execution time: 0.0616
DEBUG - 2023-09-30 17:06:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:06:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:06:17 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:06:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:06:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:06:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:06:17 --> 404 Page Not Found: Img/women-3.jpg
ERROR - 2023-09-30 17:06:17 --> 404 Page Not Found: Img/watch-3.jpg
DEBUG - 2023-09-30 17:08:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:08:16 --> Total execution time: 0.0449
DEBUG - 2023-09-30 17:08:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:08:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:08:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:08:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:08:16 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
ERROR - 2023-09-30 17:08:16 --> 404 Page Not Found: Img/women-3.jpg
DEBUG - 2023-09-30 17:08:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:08:16 --> 404 Page Not Found: Img/watch-3.jpg
DEBUG - 2023-09-30 17:09:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:09:17 --> Total execution time: 0.0477
DEBUG - 2023-09-30 17:09:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:09:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:09:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:09:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:09:18 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:09:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:09:18 --> 404 Page Not Found: Img/watch-3.jpg
ERROR - 2023-09-30 17:09:18 --> 404 Page Not Found: Img/women-3.jpg
DEBUG - 2023-09-30 17:11:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:11:03 --> Total execution time: 0.0472
DEBUG - 2023-09-30 17:11:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:11:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:11:03 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:11:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:11:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:11:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:11:03 --> 404 Page Not Found: Img/watch-3.jpg
ERROR - 2023-09-30 17:11:03 --> 404 Page Not Found: Img/women-3.jpg
DEBUG - 2023-09-30 17:11:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:11:37 --> Total execution time: 0.0428
DEBUG - 2023-09-30 17:11:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:11:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:11:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:11:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:11:37 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:11:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:11:37 --> 404 Page Not Found: Img/women-3.jpg
ERROR - 2023-09-30 17:11:37 --> 404 Page Not Found: Img/watch-3.jpg
DEBUG - 2023-09-30 17:24:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:24:11 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:24:11 --> Total execution time: 0.0507
DEBUG - 2023-09-30 17:24:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:24:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:24:11 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:25:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:25:02 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:25:02 --> Total execution time: 0.0457
DEBUG - 2023-09-30 17:25:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:25:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:25:02 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:25:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:25:03 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:25:03 --> Total execution time: 0.0467
DEBUG - 2023-09-30 17:25:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:25:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:25:03 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:25:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:25:03 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:25:03 --> Total execution time: 0.0455
DEBUG - 2023-09-30 17:25:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:25:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:25:03 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:25:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:25:03 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:25:03 --> Total execution time: 0.0561
DEBUG - 2023-09-30 17:25:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:25:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:25:03 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:25:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:25:03 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:25:03 --> Total execution time: 0.0496
DEBUG - 2023-09-30 17:25:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:25:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:25:03 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:30:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:30:36 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:30:36 --> Total execution time: 0.0599
DEBUG - 2023-09-30 17:30:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:30:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:30:36 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:30:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:30:38 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:30:38 --> Total execution time: 0.0430
DEBUG - 2023-09-30 17:30:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:30:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:30:38 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:30:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:30:38 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:30:38 --> Total execution time: 0.0446
DEBUG - 2023-09-30 17:30:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:30:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:30:38 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:30:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:30:39 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:30:39 --> Total execution time: 0.0435
DEBUG - 2023-09-30 17:30:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:30:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:30:39 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:30:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:30:39 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:30:39 --> Total execution time: 0.0567
DEBUG - 2023-09-30 17:30:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:30:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:30:39 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:30:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:30:39 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:30:39 --> Total execution time: 0.0671
DEBUG - 2023-09-30 17:30:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:30:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:30:39 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:30:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:30:39 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:30:39 --> Total execution time: 0.0451
DEBUG - 2023-09-30 17:30:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:30:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:30:39 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:30:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:30:40 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:30:40 --> Total execution time: 0.0463
DEBUG - 2023-09-30 17:30:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:30:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:30:40 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:30:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:30:40 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:30:40 --> Total execution time: 0.0456
DEBUG - 2023-09-30 17:30:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:30:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:30:40 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:30:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:30:40 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:30:40 --> Total execution time: 0.0600
DEBUG - 2023-09-30 17:30:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:30:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:30:40 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:30:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:30:40 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:30:40 --> Total execution time: 0.0442
DEBUG - 2023-09-30 17:30:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:30:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:30:40 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:30:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:30:41 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:30:41 --> Total execution time: 0.0440
DEBUG - 2023-09-30 17:30:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:30:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:30:41 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:30:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:30:41 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:30:41 --> Total execution time: 0.0441
DEBUG - 2023-09-30 17:30:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:30:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:30:41 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:30:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:30:41 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:30:41 --> Total execution time: 0.0601
DEBUG - 2023-09-30 17:30:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:30:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:30:41 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:30:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:30:41 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:30:41 --> Total execution time: 0.0597
DEBUG - 2023-09-30 17:30:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:30:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:30:41 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:30:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:30:42 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:30:42 --> Total execution time: 0.0541
DEBUG - 2023-09-30 17:30:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:30:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:30:42 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:30:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:30:42 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:30:42 --> Total execution time: 0.0667
DEBUG - 2023-09-30 17:30:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:30:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:30:42 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:30:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:30:42 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:30:42 --> Total execution time: 0.0712
DEBUG - 2023-09-30 17:30:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:30:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:30:42 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:31:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:31:08 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:31:08 --> Total execution time: 0.0474
DEBUG - 2023-09-30 17:31:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:31:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:31:08 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:31:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:31:09 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:31:09 --> Total execution time: 0.0613
DEBUG - 2023-09-30 17:31:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:31:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:31:09 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:31:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:31:09 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:31:09 --> Total execution time: 0.0436
DEBUG - 2023-09-30 17:31:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:31:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:31:09 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:31:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:31:09 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:31:09 --> Total execution time: 0.0440
DEBUG - 2023-09-30 17:31:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:31:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:31:09 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:31:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:31:09 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:31:09 --> Total execution time: 0.0517
DEBUG - 2023-09-30 17:31:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:31:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:31:09 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:31:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:31:09 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:31:09 --> Total execution time: 0.0441
DEBUG - 2023-09-30 17:31:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:31:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:31:09 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:31:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:31:10 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:31:10 --> Total execution time: 0.0453
DEBUG - 2023-09-30 17:31:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:31:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:31:10 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:31:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:31:10 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:31:10 --> Total execution time: 0.0439
DEBUG - 2023-09-30 17:31:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:31:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:31:10 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:31:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:31:10 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:31:10 --> Total execution time: 0.0576
DEBUG - 2023-09-30 17:31:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:31:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:31:10 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:31:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:31:10 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:31:10 --> Total execution time: 0.0653
DEBUG - 2023-09-30 17:31:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:31:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:31:10 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:31:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:31:10 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:31:10 --> Total execution time: 0.0438
DEBUG - 2023-09-30 17:31:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:31:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:31:11 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:31:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:31:11 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:31:11 --> Total execution time: 0.0527
DEBUG - 2023-09-30 17:31:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:31:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:31:11 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:31:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:31:11 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:31:11 --> Total execution time: 0.0691
DEBUG - 2023-09-30 17:31:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:31:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:31:11 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:33:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:33:23 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:33:23 --> Total execution time: 0.0474
DEBUG - 2023-09-30 17:33:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:33:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:33:23 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:34:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:34:10 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:34:10 --> Total execution time: 0.0666
DEBUG - 2023-09-30 17:34:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:34:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:34:10 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:34:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:34:11 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:34:11 --> Total execution time: 0.0603
DEBUG - 2023-09-30 17:34:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:34:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:34:11 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:34:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:34:11 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:34:11 --> Total execution time: 0.0540
DEBUG - 2023-09-30 17:34:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:34:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:34:11 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:34:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:34:42 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:34:42 --> Total execution time: 0.0460
DEBUG - 2023-09-30 17:34:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:34:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:34:42 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:38:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:38:26 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:38:26 --> Total execution time: 0.0304
DEBUG - 2023-09-30 17:38:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:38:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:38:26 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:38:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:38:27 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:38:27 --> Total execution time: 0.0194
DEBUG - 2023-09-30 17:38:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:38:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:38:27 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:38:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:38:27 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:38:27 --> Total execution time: 0.0198
DEBUG - 2023-09-30 17:38:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:38:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:38:27 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:38:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:38:27 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:38:27 --> Total execution time: 0.0206
DEBUG - 2023-09-30 17:38:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:38:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:38:27 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:38:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:38:27 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:38:27 --> Total execution time: 0.0201
DEBUG - 2023-09-30 17:38:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:38:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:38:28 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:38:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:38:28 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:38:28 --> Total execution time: 0.0209
DEBUG - 2023-09-30 17:38:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:38:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:38:28 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:38:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:38:28 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:38:28 --> Total execution time: 0.0211
DEBUG - 2023-09-30 17:38:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:38:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:38:28 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:38:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:38:28 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:38:28 --> Total execution time: 0.0189
DEBUG - 2023-09-30 17:38:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:38:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:38:28 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:38:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:38:28 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:38:28 --> Total execution time: 0.0199
DEBUG - 2023-09-30 17:38:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:38:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:38:28 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:38:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:38:29 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:38:29 --> Total execution time: 0.0204
DEBUG - 2023-09-30 17:38:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:38:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:38:29 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:38:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:38:29 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:38:29 --> Total execution time: 0.0194
DEBUG - 2023-09-30 17:38:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:38:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:38:29 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:38:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:38:29 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:38:29 --> Total execution time: 0.0208
DEBUG - 2023-09-30 17:38:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:38:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:38:29 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:39:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:39:48 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:39:48 --> Total execution time: 0.0203
DEBUG - 2023-09-30 17:39:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:39:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:39:48 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:39:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:39:49 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:39:49 --> Total execution time: 0.0197
DEBUG - 2023-09-30 17:39:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:39:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:39:49 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:39:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:39:49 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:39:49 --> Total execution time: 0.0193
DEBUG - 2023-09-30 17:39:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:39:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:39:49 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:39:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:39:49 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:39:49 --> Total execution time: 0.0199
DEBUG - 2023-09-30 17:39:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:39:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:39:49 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:39:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:39:49 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:39:49 --> Total execution time: 0.0197
DEBUG - 2023-09-30 17:39:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:39:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:39:49 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:39:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:39:50 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:39:50 --> Total execution time: 0.0186
DEBUG - 2023-09-30 17:39:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:39:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:39:50 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:42:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:42:25 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:42:25 --> Total execution time: 0.0191
DEBUG - 2023-09-30 17:42:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:42:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:42:25 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:42:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:42:26 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:42:26 --> Total execution time: 0.0185
DEBUG - 2023-09-30 17:42:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:42:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:42:26 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:42:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:42:26 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:42:26 --> Total execution time: 0.0203
DEBUG - 2023-09-30 17:42:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:42:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:42:26 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:42:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:42:26 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:42:26 --> Total execution time: 0.0183
DEBUG - 2023-09-30 17:42:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:42:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:42:26 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:42:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:42:26 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:42:26 --> Total execution time: 0.0194
DEBUG - 2023-09-30 17:42:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:42:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:42:26 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:42:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:42:26 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:42:26 --> Total execution time: 0.0202
DEBUG - 2023-09-30 17:42:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:42:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:42:26 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:42:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:42:27 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:42:27 --> Total execution time: 0.0204
DEBUG - 2023-09-30 17:42:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:42:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:42:27 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:42:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:42:27 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:42:27 --> Total execution time: 0.0209
DEBUG - 2023-09-30 17:42:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:42:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:42:27 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:42:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:42:27 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:42:27 --> Total execution time: 0.0189
DEBUG - 2023-09-30 17:42:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:42:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:42:27 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:42:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:42:27 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:42:27 --> Total execution time: 0.0201
DEBUG - 2023-09-30 17:42:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:42:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:42:27 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:42:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:42:28 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:42:28 --> Total execution time: 0.0188
DEBUG - 2023-09-30 17:42:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:42:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:42:28 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:42:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:42:28 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:42:28 --> Total execution time: 0.0194
DEBUG - 2023-09-30 17:42:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:42:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:42:28 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:42:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:42:28 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:42:28 --> Total execution time: 0.0197
DEBUG - 2023-09-30 17:42:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:42:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:42:28 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:42:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:42:28 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:42:28 --> Total execution time: 0.0192
DEBUG - 2023-09-30 17:42:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:42:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:42:28 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:42:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:42:28 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:42:28 --> Total execution time: 0.0201
DEBUG - 2023-09-30 17:42:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:42:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:42:28 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:42:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:42:29 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:42:29 --> Total execution time: 0.0201
DEBUG - 2023-09-30 17:42:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:42:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:42:29 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:42:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:42:29 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:42:29 --> Total execution time: 0.0197
DEBUG - 2023-09-30 17:42:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:42:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:42:29 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:42:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:42:29 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:42:29 --> Total execution time: 0.0203
DEBUG - 2023-09-30 17:42:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:42:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:42:29 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:42:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:42:29 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:42:29 --> Total execution time: 0.0192
DEBUG - 2023-09-30 17:42:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:42:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:42:29 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:49:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:49:20 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:49:20 --> Total execution time: 0.0198
DEBUG - 2023-09-30 17:49:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:49:20 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:49:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:49:21 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:49:21 --> Total execution time: 0.0212
DEBUG - 2023-09-30 17:49:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:49:21 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:49:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:49:21 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:49:21 --> Total execution time: 0.0209
DEBUG - 2023-09-30 17:49:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:49:21 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:49:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:49:21 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:49:21 --> Total execution time: 0.0209
DEBUG - 2023-09-30 17:49:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:49:21 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:49:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:49:22 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:49:22 --> Total execution time: 0.0214
DEBUG - 2023-09-30 17:49:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:49:22 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:49:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:49:22 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:49:22 --> Total execution time: 0.0196
DEBUG - 2023-09-30 17:49:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:49:22 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:49:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:49:22 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:49:22 --> Total execution time: 0.0201
DEBUG - 2023-09-30 17:49:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:49:22 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:49:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:49:22 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:49:22 --> Total execution time: 0.0200
DEBUG - 2023-09-30 17:49:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:49:22 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:49:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:49:23 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:49:23 --> Total execution time: 0.0211
DEBUG - 2023-09-30 17:49:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:49:23 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:49:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:49:23 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:49:23 --> Total execution time: 0.0204
DEBUG - 2023-09-30 17:49:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:49:23 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:49:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:49:23 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:49:23 --> Total execution time: 0.0198
DEBUG - 2023-09-30 17:49:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:49:23 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:49:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:49:23 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:49:23 --> Total execution time: 0.0210
DEBUG - 2023-09-30 17:49:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:49:23 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:49:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:49:24 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:49:24 --> Total execution time: 0.0204
DEBUG - 2023-09-30 17:49:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:49:24 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:49:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:49:24 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:49:24 --> Total execution time: 0.0209
DEBUG - 2023-09-30 17:49:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:49:24 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:49:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:49:24 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:49:24 --> Total execution time: 0.0192
DEBUG - 2023-09-30 17:49:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:49:24 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:49:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:49:24 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:49:24 --> Total execution time: 0.0198
DEBUG - 2023-09-30 17:49:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:49:24 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:49:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:49:24 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:49:24 --> Total execution time: 0.0389
DEBUG - 2023-09-30 17:49:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:49:24 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:49:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:49:25 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:49:25 --> Total execution time: 0.0201
DEBUG - 2023-09-30 17:49:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:49:25 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:49:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:49:25 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:49:25 --> Total execution time: 0.0198
DEBUG - 2023-09-30 17:49:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:49:25 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:49:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:49:25 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:49:25 --> Total execution time: 0.0187
DEBUG - 2023-09-30 17:49:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:49:25 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 17:49:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 17:49:43 --> initController - LoginPage.php
DEBUG - 2023-09-30 17:49:43 --> Total execution time: 0.0202
DEBUG - 2023-09-30 17:49:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 17:49:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 17:49:43 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 18:03:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 18:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 18:03:31 --> initController - LoginPage.php
DEBUG - 2023-09-30 18:03:31 --> Total execution time: 0.0209
DEBUG - 2023-09-30 18:03:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 18:03:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 18:03:31 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 18:04:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 18:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 18:04:43 --> initController - LoginPage.php
DEBUG - 2023-09-30 18:04:43 --> Total execution time: 0.0227
DEBUG - 2023-09-30 18:04:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 18:04:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 18:04:43 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 18:04:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 18:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 18:04:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 18:04:51 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-30 18:04:51 --> Total execution time: 0.0376
DEBUG - 2023-09-30 18:04:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 18:04:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 18:04:51 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 18:07:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 18:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 18:07:23 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 18:07:23 --> Severity: Warning --> Undefined property: stdClass::$username C:\xampp\htdocs\WebProject\application\controllers\login.php 99
DEBUG - 2023-09-30 18:07:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 18:07:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 18:07:23 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 46
DEBUG - 2023-09-30 18:07:23 --> initController - LoginPage.php
DEBUG - 2023-09-30 18:07:23 --> Total execution time: 0.0219
DEBUG - 2023-09-30 18:07:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 18:07:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 18:07:23 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 18:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 18:08:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 18:08:31 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 46
DEBUG - 2023-09-30 18:08:31 --> initController - LoginPage.php
DEBUG - 2023-09-30 18:08:31 --> Total execution time: 0.0209
DEBUG - 2023-09-30 18:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 18:08:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 18:08:31 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 18:08:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 18:08:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 18:08:57 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 46
DEBUG - 2023-09-30 18:08:57 --> initController - LoginPage.php
DEBUG - 2023-09-30 18:08:57 --> Total execution time: 0.0215
DEBUG - 2023-09-30 18:08:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 18:08:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 18:08:57 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 18:10:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 18:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 18:10:05 --> initController - LoginPage.php
DEBUG - 2023-09-30 18:10:05 --> Total execution time: 0.0196
DEBUG - 2023-09-30 18:10:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 18:10:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 18:10:05 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 18:10:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 18:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 18:10:08 --> initController - LoginPage.php
DEBUG - 2023-09-30 18:10:08 --> Total execution time: 0.0203
DEBUG - 2023-09-30 18:10:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 18:10:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 18:10:08 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 18:10:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 18:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 18:10:22 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 18:10:22 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-30 18:10:22 --> Total execution time: 0.0229
DEBUG - 2023-09-30 18:10:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 18:10:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 18:10:22 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 18:49:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 18:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 18:49:41 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 18:49:41 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-30 18:49:41 --> Total execution time: 0.0266
DEBUG - 2023-09-30 18:49:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 18:49:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 18:49:41 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 18:49:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 18:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 18:49:42 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 18:49:42 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-30 18:49:42 --> Total execution time: 0.0232
DEBUG - 2023-09-30 18:49:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 18:49:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 18:49:42 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 18:49:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 18:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 18:49:42 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 18:49:42 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-30 18:49:42 --> Total execution time: 0.0233
DEBUG - 2023-09-30 18:49:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 18:49:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 18:49:42 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 18:49:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 18:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 18:49:44 --> initController - LoginPage.php
DEBUG - 2023-09-30 18:49:44 --> Total execution time: 0.0200
DEBUG - 2023-09-30 18:49:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 18:49:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 18:49:44 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 18:49:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 18:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 18:49:45 --> initController - LoginPage.php
DEBUG - 2023-09-30 18:49:45 --> Total execution time: 0.0217
DEBUG - 2023-09-30 18:49:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 18:49:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 18:49:45 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 18:49:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 18:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 18:49:45 --> initController - LoginPage.php
DEBUG - 2023-09-30 18:49:45 --> Total execution time: 0.0234
DEBUG - 2023-09-30 18:49:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 18:49:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 18:49:46 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 18:49:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 18:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 18:49:46 --> initController - LoginPage.php
DEBUG - 2023-09-30 18:49:46 --> Total execution time: 0.0207
DEBUG - 2023-09-30 18:49:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 18:49:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 18:49:46 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 18:49:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 18:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 18:49:49 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-30 18:49:49 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-30 18:49:49 --> Total execution time: 0.0238
DEBUG - 2023-09-30 18:49:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 18:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 18:49:54 --> Total execution time: 0.0192
DEBUG - 2023-09-30 18:49:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 18:49:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 18:49:54 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-30 18:49:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 18:49:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-30 18:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-30 18:49:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-30 18:49:54 --> 404 Page Not Found: Img/women-3.jpg
ERROR - 2023-09-30 18:49:54 --> 404 Page Not Found: Img/watch-3.jpg
