<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-09-11 12:17:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-11 12:17:55 --> No URI present. Default controller set.
DEBUG - 2023-09-11 12:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-11 12:17:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 12:17:55 --> initController - LoginPage.php
DEBUG - 2023-09-11 12:17:55 --> Total execution time: 0.0418
DEBUG - 2023-09-11 12:18:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-11 12:18:06 --> No URI present. Default controller set.
DEBUG - 2023-09-11 12:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-11 12:18:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 12:18:06 --> initController - LoginPage.php
DEBUG - 2023-09-11 12:18:06 --> Total execution time: 0.0274
DEBUG - 2023-09-11 12:18:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-11 12:18:06 --> No URI present. Default controller set.
DEBUG - 2023-09-11 12:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-11 12:18:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 12:18:06 --> initController - LoginPage.php
DEBUG - 2023-09-11 12:18:06 --> Total execution time: 0.0229
DEBUG - 2023-09-11 12:18:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-11 12:18:07 --> No URI present. Default controller set.
DEBUG - 2023-09-11 12:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-11 12:18:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 12:18:07 --> initController - LoginPage.php
DEBUG - 2023-09-11 12:18:07 --> Total execution time: 0.0250
DEBUG - 2023-09-11 12:18:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-11 12:18:07 --> No URI present. Default controller set.
DEBUG - 2023-09-11 12:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-11 12:18:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 12:18:07 --> initController - LoginPage.php
DEBUG - 2023-09-11 12:18:07 --> Total execution time: 0.0231
DEBUG - 2023-09-11 12:18:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-11 12:18:07 --> No URI present. Default controller set.
DEBUG - 2023-09-11 12:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-11 12:18:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 12:18:07 --> initController - LoginPage.php
DEBUG - 2023-09-11 12:18:07 --> Total execution time: 0.0231
DEBUG - 2023-09-11 12:18:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-11 12:18:23 --> No URI present. Default controller set.
DEBUG - 2023-09-11 12:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-11 12:18:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 12:18:23 --> initController - LoginPage.php
DEBUG - 2023-09-11 12:18:23 --> Total execution time: 0.0221
DEBUG - 2023-09-11 12:18:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-11 12:18:23 --> No URI present. Default controller set.
DEBUG - 2023-09-11 12:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-11 12:18:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 12:18:23 --> initController - LoginPage.php
DEBUG - 2023-09-11 12:18:23 --> Total execution time: 0.0225
DEBUG - 2023-09-11 12:18:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-11 12:18:24 --> No URI present. Default controller set.
DEBUG - 2023-09-11 12:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-11 12:18:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 12:18:24 --> initController - LoginPage.php
DEBUG - 2023-09-11 12:18:24 --> Total execution time: 0.0223
DEBUG - 2023-09-11 12:18:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-11 12:18:24 --> No URI present. Default controller set.
DEBUG - 2023-09-11 12:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-11 12:18:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 12:18:24 --> initController - LoginPage.php
DEBUG - 2023-09-11 12:18:24 --> Total execution time: 0.0226
DEBUG - 2023-09-11 12:18:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-11 12:18:24 --> No URI present. Default controller set.
DEBUG - 2023-09-11 12:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-11 12:18:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 12:18:24 --> initController - LoginPage.php
DEBUG - 2023-09-11 12:18:24 --> Total execution time: 0.0219
DEBUG - 2023-09-11 12:20:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-11 12:20:21 --> No URI present. Default controller set.
DEBUG - 2023-09-11 12:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-11 12:20:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 12:20:21 --> initController - LoginPage.php
DEBUG - 2023-09-11 12:20:21 --> Total execution time: 0.0282
DEBUG - 2023-09-11 12:20:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-11 12:20:22 --> No URI present. Default controller set.
DEBUG - 2023-09-11 12:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-11 12:20:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 12:20:22 --> initController - LoginPage.php
DEBUG - 2023-09-11 12:20:22 --> Total execution time: 0.0247
DEBUG - 2023-09-11 12:20:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-11 12:20:22 --> No URI present. Default controller set.
DEBUG - 2023-09-11 12:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-11 12:20:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 12:20:22 --> initController - LoginPage.php
DEBUG - 2023-09-11 12:20:22 --> Total execution time: 0.0268
DEBUG - 2023-09-11 12:20:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-11 12:20:22 --> No URI present. Default controller set.
DEBUG - 2023-09-11 12:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-11 12:20:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 12:20:22 --> initController - LoginPage.php
DEBUG - 2023-09-11 12:20:22 --> Total execution time: 0.0250
DEBUG - 2023-09-11 12:20:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-11 12:20:22 --> No URI present. Default controller set.
DEBUG - 2023-09-11 12:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-11 12:20:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 12:20:22 --> initController - LoginPage.php
DEBUG - 2023-09-11 12:20:22 --> Total execution time: 0.0258
DEBUG - 2023-09-11 12:20:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-11 12:20:34 --> No URI present. Default controller set.
DEBUG - 2023-09-11 12:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-11 12:20:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 12:20:34 --> initController - LoginPage.php
DEBUG - 2023-09-11 12:20:34 --> Total execution time: 0.0518
DEBUG - 2023-09-11 12:22:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-11 12:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-11 12:22:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 12:22:13 --> initController - LoginPage.php
DEBUG - 2023-09-11 12:22:13 --> Total execution time: 0.0237
DEBUG - 2023-09-11 12:22:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-11 12:22:39 --> No URI present. Default controller set.
DEBUG - 2023-09-11 12:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-11 12:22:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-11 12:22:39 --> initController - LoginPage.php
DEBUG - 2023-09-11 12:22:39 --> Total execution time: 0.0265
