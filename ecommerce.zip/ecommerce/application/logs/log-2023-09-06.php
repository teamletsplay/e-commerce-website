<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-09-06 15:42:38 --> UTF-8 Support Enabled
ERROR - 2023-09-06 15:42:38 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-06 15:42:38 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-06 15:42:38 --> No URI present. Default controller set.
DEBUG - 2023-09-06 15:42:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 15:42:38 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 15:42:38 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 15:42:38 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 15:42:38 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 15:42:38 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 15:42:38 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 15:42:38 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 15:42:38 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 15:42:38 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 15:42:38 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 15:42:38 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 15:42:38 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 15:42:38 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-06 15:42:38 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-06 15:42:38 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-06 15:42:38 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-06 15:42:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-06 15:57:50 --> UTF-8 Support Enabled
ERROR - 2023-09-06 15:57:50 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-06 15:57:50 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-06 15:57:50 --> No URI present. Default controller set.
DEBUG - 2023-09-06 15:57:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 15:57:50 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 15:57:50 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 15:57:50 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 15:57:50 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 15:57:50 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 15:57:50 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 15:57:50 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 15:57:50 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 15:57:50 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 15:57:50 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 15:57:50 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 15:57:50 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 15:57:50 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-06 15:57:50 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-06 15:57:50 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-06 15:57:50 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-06 15:57:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-06 16:26:58 --> UTF-8 Support Enabled
ERROR - 2023-09-06 16:26:58 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-06 16:26:58 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-06 16:26:58 --> No URI present. Default controller set.
DEBUG - 2023-09-06 16:26:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 16:26:58 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 16:26:58 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 16:26:58 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 16:26:58 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 16:26:58 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 16:26:58 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 16:26:58 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 16:26:58 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 16:26:58 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 16:26:58 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 16:26:58 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 16:26:58 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 16:26:58 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-06 16:26:58 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-06 16:26:58 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-06 16:26:58 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-06 16:26:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-06 16:51:38 --> UTF-8 Support Enabled
ERROR - 2023-09-06 16:51:38 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\WebProject\system\core\URI.php 101
ERROR - 2023-09-06 16:51:38 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Router.php 126
DEBUG - 2023-09-06 16:51:38 --> No URI present. Default controller set.
DEBUG - 2023-09-06 16:51:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 16:51:38 --> Severity: 8192 --> Creation of dynamic property InitController::$benchmark is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 16:51:38 --> Severity: 8192 --> Creation of dynamic property InitController::$hooks is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 16:51:38 --> Severity: 8192 --> Creation of dynamic property InitController::$config is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 16:51:38 --> Severity: 8192 --> Creation of dynamic property InitController::$log is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 16:51:38 --> Severity: 8192 --> Creation of dynamic property InitController::$utf8 is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 16:51:38 --> Severity: 8192 --> Creation of dynamic property InitController::$uri is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 16:51:38 --> Severity: 8192 --> Creation of dynamic property InitController::$exceptions is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 16:51:38 --> Severity: 8192 --> Creation of dynamic property InitController::$router is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 16:51:38 --> Severity: 8192 --> Creation of dynamic property InitController::$output is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 16:51:38 --> Severity: 8192 --> Creation of dynamic property InitController::$security is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 16:51:38 --> Severity: 8192 --> Creation of dynamic property InitController::$input is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 16:51:38 --> Severity: 8192 --> Creation of dynamic property InitController::$lang is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 75
ERROR - 2023-09-06 16:51:38 --> Severity: 8192 --> Creation of dynamic property InitController::$load is deprecated C:\xampp\htdocs\WebProject\system\core\Controller.php 78
ERROR - 2023-09-06 16:51:38 --> Severity: 8192 --> Creation of dynamic property InitController::$db is deprecated C:\xampp\htdocs\WebProject\system\core\Loader.php 360
ERROR - 2023-09-06 16:51:38 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\WebProject\system\database\DB_driver.php 371
ERROR - 2023-09-06 16:51:38 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2023-09-06 16:51:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 573
DEBUG - 2023-09-06 16:56:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 16:56:27 --> No URI present. Default controller set.
DEBUG - 2023-09-06 16:56:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 16:56:27 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
DEBUG - 2023-09-06 16:59:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 16:59:03 --> No URI present. Default controller set.
DEBUG - 2023-09-06 16:59:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 16:59:03 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
DEBUG - 2023-09-06 17:10:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 17:10:02 --> No URI present. Default controller set.
DEBUG - 2023-09-06 17:10:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 17:10:06 --> Severity: error --> Exception: No connection could be made because the target machine actively refused it C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
DEBUG - 2023-09-06 17:10:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 17:10:11 --> No URI present. Default controller set.
DEBUG - 2023-09-06 17:10:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 17:10:15 --> Severity: error --> Exception: No connection could be made because the target machine actively refused it C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
DEBUG - 2023-09-06 17:13:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 17:13:54 --> No URI present. Default controller set.
DEBUG - 2023-09-06 17:13:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 17:13:54 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
DEBUG - 2023-09-06 17:13:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 17:13:55 --> No URI present. Default controller set.
DEBUG - 2023-09-06 17:13:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 17:13:55 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
DEBUG - 2023-09-06 17:13:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 17:13:55 --> No URI present. Default controller set.
DEBUG - 2023-09-06 17:13:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 17:13:55 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
DEBUG - 2023-09-06 17:13:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 17:13:56 --> No URI present. Default controller set.
DEBUG - 2023-09-06 17:13:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 17:13:56 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
DEBUG - 2023-09-06 17:13:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 17:13:56 --> No URI present. Default controller set.
DEBUG - 2023-09-06 17:13:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 17:13:56 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
DEBUG - 2023-09-06 17:13:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 17:13:59 --> No URI present. Default controller set.
DEBUG - 2023-09-06 17:13:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 17:13:59 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
DEBUG - 2023-09-06 17:14:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 17:14:03 --> No URI present. Default controller set.
DEBUG - 2023-09-06 17:14:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 17:14:03 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
DEBUG - 2023-09-06 17:14:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 17:14:03 --> No URI present. Default controller set.
DEBUG - 2023-09-06 17:14:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 17:14:03 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
DEBUG - 2023-09-06 17:14:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 17:14:03 --> No URI present. Default controller set.
DEBUG - 2023-09-06 17:14:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 17:14:03 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
DEBUG - 2023-09-06 17:14:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 17:14:25 --> No URI present. Default controller set.
DEBUG - 2023-09-06 17:14:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 17:14:25 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
DEBUG - 2023-09-06 17:14:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 17:14:25 --> No URI present. Default controller set.
DEBUG - 2023-09-06 17:14:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 17:14:25 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
DEBUG - 2023-09-06 17:14:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 17:14:25 --> No URI present. Default controller set.
DEBUG - 2023-09-06 17:14:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 17:14:25 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
DEBUG - 2023-09-06 17:14:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 17:14:26 --> No URI present. Default controller set.
DEBUG - 2023-09-06 17:14:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 17:14:26 --> Severity: error --> Exception: Unknown database 'shantadurgatemple' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 161
DEBUG - 2023-09-06 17:29:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 17:29:09 --> No URI present. Default controller set.
DEBUG - 2023-09-06 17:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 17:29:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 17:29:09 --> initController - LoginPage.php
DEBUG - 2023-09-06 17:29:09 --> Total execution time: 0.0352
DEBUG - 2023-09-06 18:12:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:12:58 --> No URI present. Default controller set.
DEBUG - 2023-09-06 18:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 18:12:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 18:12:58 --> initController - LoginPage.php
DEBUG - 2023-09-06 18:12:58 --> Total execution time: 0.0466
DEBUG - 2023-09-06 18:12:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:12:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 18:12:58 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-06 18:14:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:14:31 --> No URI present. Default controller set.
DEBUG - 2023-09-06 18:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 18:14:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 18:14:32 --> initController - LoginPage.php
DEBUG - 2023-09-06 18:14:32 --> Total execution time: 0.0557
DEBUG - 2023-09-06 18:14:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:14:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 18:14:32 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-06 18:15:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:15:30 --> No URI present. Default controller set.
DEBUG - 2023-09-06 18:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 18:15:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 18:15:30 --> initController - LoginPage.php
DEBUG - 2023-09-06 18:15:30 --> Total execution time: 0.0468
DEBUG - 2023-09-06 18:15:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:15:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 18:15:31 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-06 18:16:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:16:25 --> No URI present. Default controller set.
DEBUG - 2023-09-06 18:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 18:16:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 18:16:25 --> initController - LoginPage.php
DEBUG - 2023-09-06 18:16:25 --> Total execution time: 0.0473
DEBUG - 2023-09-06 18:16:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:16:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 18:16:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 18:16:25 --> 404 Page Not Found: Scriptjs/index
ERROR - 2023-09-06 18:16:25 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-06 18:16:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:16:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 18:16:31 --> 404 Page Not Found: Paymenthtml/index
DEBUG - 2023-09-06 18:16:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:16:33 --> No URI present. Default controller set.
DEBUG - 2023-09-06 18:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 18:16:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 18:16:33 --> initController - LoginPage.php
DEBUG - 2023-09-06 18:16:33 --> Total execution time: 0.0476
DEBUG - 2023-09-06 18:16:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:16:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 18:16:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 18:16:33 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-06 18:16:33 --> 404 Page Not Found: Scriptjs/index
DEBUG - 2023-09-06 18:18:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:18:55 --> No URI present. Default controller set.
DEBUG - 2023-09-06 18:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 18:18:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 18:18:55 --> initController - LoginPage.php
DEBUG - 2023-09-06 18:18:55 --> Total execution time: 0.0475
DEBUG - 2023-09-06 18:18:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:18:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 18:18:55 --> 404 Page Not Found: Scriptjs/index
DEBUG - 2023-09-06 18:18:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:18:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 18:18:55 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-06 18:21:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:21:25 --> No URI present. Default controller set.
DEBUG - 2023-09-06 18:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 18:21:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 18:21:25 --> initController - LoginPage.php
DEBUG - 2023-09-06 18:21:25 --> Total execution time: 0.0502
DEBUG - 2023-09-06 18:21:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:21:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 18:21:25 --> 404 Page Not Found: Scriptjs/index
DEBUG - 2023-09-06 18:21:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:21:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 18:21:25 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-06 18:23:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:23:05 --> No URI present. Default controller set.
DEBUG - 2023-09-06 18:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 18:23:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 18:23:05 --> initController - LoginPage.php
DEBUG - 2023-09-06 18:23:05 --> Total execution time: 0.0514
DEBUG - 2023-09-06 18:23:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:23:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 18:23:05 --> 404 Page Not Found: Scriptjs/index
DEBUG - 2023-09-06 18:23:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:23:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 18:23:05 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-06 18:23:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:23:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 18:23:05 --> 404 Page Not Found: Scriptjs/index
DEBUG - 2023-09-06 18:23:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:23:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 18:23:54 --> 404 Page Not Found: Index1html/index
DEBUG - 2023-09-06 18:30:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:30:58 --> No URI present. Default controller set.
DEBUG - 2023-09-06 18:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 18:30:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 18:30:58 --> initController - LoginPage.php
DEBUG - 2023-09-06 18:30:58 --> Total execution time: 0.0532
DEBUG - 2023-09-06 18:30:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:30:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:30:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 18:30:58 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-06 18:30:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 18:30:58 --> 404 Page Not Found: Scriptjs/index
DEBUG - 2023-09-06 18:31:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:31:51 --> No URI present. Default controller set.
DEBUG - 2023-09-06 18:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 18:31:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 18:31:51 --> initController - LoginPage.php
DEBUG - 2023-09-06 18:31:51 --> Total execution time: 0.0466
DEBUG - 2023-09-06 18:31:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:31:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 18:31:51 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-06 18:32:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:32:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 18:32:07 --> 404 Page Not Found: Loginhtml/index
DEBUG - 2023-09-06 18:32:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:32:10 --> No URI present. Default controller set.
DEBUG - 2023-09-06 18:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 18:32:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 18:32:10 --> initController - LoginPage.php
DEBUG - 2023-09-06 18:32:10 --> Total execution time: 0.0708
DEBUG - 2023-09-06 18:32:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:32:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 18:32:10 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-06 18:32:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:32:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 18:32:13 --> 404 Page Not Found: Carthtml/index
DEBUG - 2023-09-06 18:32:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:32:15 --> No URI present. Default controller set.
DEBUG - 2023-09-06 18:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 18:32:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 18:32:15 --> initController - LoginPage.php
DEBUG - 2023-09-06 18:32:15 --> Total execution time: 0.0487
DEBUG - 2023-09-06 18:32:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:32:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 18:32:15 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-06 18:35:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:35:54 --> No URI present. Default controller set.
DEBUG - 2023-09-06 18:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 18:35:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 18:35:54 --> initController - LoginPage.php
DEBUG - 2023-09-06 18:35:54 --> Total execution time: 0.0514
DEBUG - 2023-09-06 18:35:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:35:56 --> No URI present. Default controller set.
DEBUG - 2023-09-06 18:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 18:35:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 18:35:57 --> initController - LoginPage.php
DEBUG - 2023-09-06 18:35:57 --> Total execution time: 0.0536
DEBUG - 2023-09-06 18:37:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:37:21 --> No URI present. Default controller set.
DEBUG - 2023-09-06 18:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 18:37:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 18:37:21 --> initController - LoginPage.php
DEBUG - 2023-09-06 18:37:21 --> Total execution time: 0.0509
DEBUG - 2023-09-06 18:39:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:39:29 --> No URI present. Default controller set.
DEBUG - 2023-09-06 18:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 18:39:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 18:39:29 --> initController - LoginPage.php
DEBUG - 2023-09-06 18:39:29 --> Total execution time: 0.0469
DEBUG - 2023-09-06 18:39:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:39:48 --> No URI present. Default controller set.
DEBUG - 2023-09-06 18:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 18:39:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 18:39:48 --> initController - LoginPage.php
DEBUG - 2023-09-06 18:39:48 --> Total execution time: 0.0462
DEBUG - 2023-09-06 18:45:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 18:45:00 --> No URI present. Default controller set.
DEBUG - 2023-09-06 18:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 18:45:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 18:45:00 --> initController - LoginPage.php
DEBUG - 2023-09-06 18:45:00 --> Total execution time: 0.0592
DEBUG - 2023-09-06 19:38:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 19:38:15 --> No URI present. Default controller set.
DEBUG - 2023-09-06 19:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-06 19:38:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-06 19:38:15 --> initController - LoginPage.php
DEBUG - 2023-09-06 19:38:15 --> Total execution time: 0.0418
DEBUG - 2023-09-06 19:38:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-06 19:38:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-06 19:38:25 --> 404 Page Not Found: Index1html/index
