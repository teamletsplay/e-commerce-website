<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-09-09 07:45:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 07:45:08 --> No URI present. Default controller set.
DEBUG - 2023-09-09 07:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 07:45:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-09 07:45:08 --> initController - LoginPage.php
DEBUG - 2023-09-09 07:45:08 --> Total execution time: 0.0343
DEBUG - 2023-09-09 07:45:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 07:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 07:45:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-09 07:45:13 --> initController - LoginPage.php
DEBUG - 2023-09-09 07:45:13 --> Total execution time: 0.0325
DEBUG - 2023-09-09 07:45:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 07:45:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 07:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 07:45:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 07:45:13 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-09 07:45:13 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 07:45:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 07:45:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 07:45:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 07:45:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 07:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 07:45:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 07:45:13 --> 404 Page Not Found: Js/main.js
DEBUG - 2023-09-09 07:45:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 07:45:13 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-09 07:45:13 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-09 07:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 07:45:13 --> UTF-8 Support Enabled
ERROR - 2023-09-09 07:45:13 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 07:45:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 07:45:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 07:45:13 --> 404 Page Not Found: Js/script.js
DEBUG - 2023-09-09 07:45:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 07:45:13 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-09 07:45:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 07:45:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 07:45:13 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-09 07:45:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 07:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 07:45:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-09 07:45:59 --> initController - LoginPage.php
DEBUG - 2023-09-09 07:45:59 --> Total execution time: 0.0314
DEBUG - 2023-09-09 08:04:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:04:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-09 08:04:20 --> initController - LoginPage.php
DEBUG - 2023-09-09 08:04:20 --> Total execution time: 0.0290
DEBUG - 2023-09-09 08:04:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:04:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-09 08:04:20 --> initController - LoginPage.php
DEBUG - 2023-09-09 08:04:20 --> Total execution time: 0.0315
DEBUG - 2023-09-09 08:04:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:04:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-09 08:04:20 --> initController - LoginPage.php
DEBUG - 2023-09-09 08:04:20 --> Total execution time: 0.0266
DEBUG - 2023-09-09 08:04:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:04:28 --> No URI present. Default controller set.
DEBUG - 2023-09-09 08:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:04:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-09 08:04:28 --> initController - LoginPage.php
DEBUG - 2023-09-09 08:04:28 --> Total execution time: 0.0284
DEBUG - 2023-09-09 08:04:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:04:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-09 08:04:31 --> initController - LoginPage.php
DEBUG - 2023-09-09 08:04:31 --> Total execution time: 0.0544
DEBUG - 2023-09-09 08:04:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:04:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:04:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 08:04:31 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 08:04:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:04:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:04:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:04:31 --> UTF-8 Support Enabled
ERROR - 2023-09-09 08:04:31 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 08:04:31 --> UTF-8 Support Enabled
ERROR - 2023-09-09 08:04:31 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 08:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:04:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 08:04:31 --> 404 Page Not Found: Js/main.js
ERROR - 2023-09-09 08:04:31 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-09 08:04:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 08:04:31 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 08:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:04:31 --> UTF-8 Support Enabled
ERROR - 2023-09-09 08:04:31 --> 404 Page Not Found: Js/script.js
DEBUG - 2023-09-09 08:04:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 08:04:31 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-09 08:05:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:05:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-09 08:05:11 --> initController - LoginPage.php
DEBUG - 2023-09-09 08:05:11 --> Total execution time: 0.0270
DEBUG - 2023-09-09 08:05:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:05:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 08:05:11 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 08:05:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:05:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:05:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:05:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:05:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 08:05:11 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 08:05:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:05:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:05:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 08:05:11 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 08:05:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 08:05:11 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-09 08:05:11 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-09 08:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:05:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 08:05:11 --> 404 Page Not Found: Js/main.js
ERROR - 2023-09-09 08:05:11 --> 404 Page Not Found: Js/script.js
DEBUG - 2023-09-09 08:05:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:05:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 08:05:11 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-09 08:05:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:05:13 --> No URI present. Default controller set.
DEBUG - 2023-09-09 08:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:05:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-09 08:05:13 --> initController - LoginPage.php
DEBUG - 2023-09-09 08:05:13 --> Total execution time: 0.0300
DEBUG - 2023-09-09 08:05:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:05:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-09 08:05:17 --> initController - LoginPage.php
DEBUG - 2023-09-09 08:05:17 --> Total execution time: 0.0507
DEBUG - 2023-09-09 08:05:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:05:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:05:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:05:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:05:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:05:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:05:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 08:05:17 --> 404 Page Not Found: Js/main.js
DEBUG - 2023-09-09 08:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:05:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 08:05:17 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-09 08:05:17 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-09 08:05:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 08:05:17 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 08:05:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 08:05:17 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-09 08:05:17 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 08:05:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:05:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:05:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 08:05:17 --> 404 Page Not Found: Js/script.js
DEBUG - 2023-09-09 08:05:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 08:05:17 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-09 08:06:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:06:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-09 08:06:19 --> initController - LoginPage.php
DEBUG - 2023-09-09 08:06:19 --> Total execution time: 0.0317
DEBUG - 2023-09-09 08:06:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:06:19 --> UTF-8 Support Enabled
ERROR - 2023-09-09 08:06:19 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 08:06:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:06:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:06:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:06:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:06:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 08:06:19 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-09 08:06:19 --> 404 Page Not Found: Js/main.js
ERROR - 2023-09-09 08:06:19 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 08:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:06:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 08:06:19 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-09 08:06:19 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-09 08:06:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:06:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:06:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 08:06:19 --> 404 Page Not Found: Js/script.js
DEBUG - 2023-09-09 08:06:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 08:06:19 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-09 08:06:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:06:21 --> No URI present. Default controller set.
DEBUG - 2023-09-09 08:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:06:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-09 08:06:21 --> initController - LoginPage.php
DEBUG - 2023-09-09 08:06:21 --> Total execution time: 0.0322
DEBUG - 2023-09-09 08:06:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:06:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-09 08:06:23 --> initController - LoginPage.php
DEBUG - 2023-09-09 08:06:23 --> Total execution time: 0.0551
DEBUG - 2023-09-09 08:06:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:06:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:06:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:06:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:06:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:06:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 08:06:23 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-09 08:06:23 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-09 08:06:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 08:06:23 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 08:06:23 --> UTF-8 Support Enabled
ERROR - 2023-09-09 08:06:23 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 08:06:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 08:06:23 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 08:06:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:06:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 08:06:23 --> 404 Page Not Found: Js/main.js
DEBUG - 2023-09-09 08:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:06:23 --> UTF-8 Support Enabled
ERROR - 2023-09-09 08:06:23 --> 404 Page Not Found: Js/script.js
DEBUG - 2023-09-09 08:06:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 08:06:23 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-09 08:06:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:06:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-09 08:06:36 --> initController - LoginPage.php
DEBUG - 2023-09-09 08:06:36 --> Total execution time: 0.0287
DEBUG - 2023-09-09 08:08:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:08:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-09 08:08:57 --> initController - LoginPage.php
DEBUG - 2023-09-09 08:08:57 --> Total execution time: 0.0283
DEBUG - 2023-09-09 08:09:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:09:08 --> No URI present. Default controller set.
DEBUG - 2023-09-09 08:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:09:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-09 08:09:08 --> initController - LoginPage.php
DEBUG - 2023-09-09 08:09:08 --> Total execution time: 0.0283
DEBUG - 2023-09-09 08:09:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:09:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-09 08:09:10 --> initController - LoginPage.php
DEBUG - 2023-09-09 08:09:10 --> Total execution time: 0.0317
DEBUG - 2023-09-09 08:09:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:09:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:09:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:09:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:09:10 --> UTF-8 Support Enabled
ERROR - 2023-09-09 08:09:10 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-09 08:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:09:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:09:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 08:09:10 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-09 08:09:10 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 08:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:09:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 08:09:10 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-09 08:09:10 --> 404 Page Not Found: Js/main.js
ERROR - 2023-09-09 08:09:10 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 08:09:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:09:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:09:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 08:09:10 --> 404 Page Not Found: Js/script.js
DEBUG - 2023-09-09 08:09:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 08:09:10 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-09 08:12:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:12:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-09 08:12:14 --> initController - LoginPage.php
DEBUG - 2023-09-09 08:12:14 --> Total execution time: 0.0288
DEBUG - 2023-09-09 08:12:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:12:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 08:12:14 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 08:12:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:12:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:12:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:12:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:12:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:12:14 --> UTF-8 Support Enabled
ERROR - 2023-09-09 08:12:14 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 08:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:12:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 08:12:14 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-09 08:12:14 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 08:12:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 08:12:14 --> 404 Page Not Found: Js/script.js
ERROR - 2023-09-09 08:12:14 --> 404 Page Not Found: Js/main.js
ERROR - 2023-09-09 08:12:14 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-09 08:12:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:12:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 08:12:14 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-09 08:12:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:12:15 --> No URI present. Default controller set.
DEBUG - 2023-09-09 08:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:12:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-09 08:12:15 --> initController - LoginPage.php
DEBUG - 2023-09-09 08:12:15 --> Total execution time: 0.0318
DEBUG - 2023-09-09 08:12:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:12:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-09 08:12:18 --> initController - LoginPage.php
DEBUG - 2023-09-09 08:12:18 --> Total execution time: 0.0298
DEBUG - 2023-09-09 08:12:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:12:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:12:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:12:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:12:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:12:18 --> UTF-8 Support Enabled
ERROR - 2023-09-09 08:12:18 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 08:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 08:12:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 08:12:18 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 08:12:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 08:12:18 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-09 08:12:18 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 08:12:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 08:12:18 --> 404 Page Not Found: Js/main.js
ERROR - 2023-09-09 08:12:18 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-09 08:12:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:12:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 08:12:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 08:12:18 --> 404 Page Not Found: Js/script.js
DEBUG - 2023-09-09 08:12:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 08:12:18 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-09 09:06:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 09:06:54 --> No URI present. Default controller set.
DEBUG - 2023-09-09 09:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 09:06:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-09 09:06:54 --> initController - LoginPage.php
DEBUG - 2023-09-09 09:06:54 --> Total execution time: 0.0804
DEBUG - 2023-09-09 09:07:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 09:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 09:07:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-09 09:07:02 --> initController - LoginPage.php
DEBUG - 2023-09-09 09:07:02 --> Total execution time: 0.0631
DEBUG - 2023-09-09 09:07:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 09:07:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 09:07:02 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 09:07:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 09:07:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 09:07:02 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 09:07:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 09:07:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 09:07:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 09:07:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 09:07:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 09:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 09:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 09:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 09:07:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 09:07:02 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 09:07:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 09:07:02 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-09 09:07:02 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 09:07:02 --> UTF-8 Support Enabled
ERROR - 2023-09-09 09:07:02 --> 404 Page Not Found: Js/main.js
ERROR - 2023-09-09 09:07:02 --> 404 Page Not Found: Js/script.js
DEBUG - 2023-09-09 09:07:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 09:07:02 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-09 09:07:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 09:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 09:07:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-09 09:07:25 --> initController - LoginPage.php
DEBUG - 2023-09-09 09:07:25 --> Total execution time: 0.0511
DEBUG - 2023-09-09 09:07:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 09:07:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 09:07:25 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 09:07:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 09:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 09:07:25 --> UTF-8 Support Enabled
ERROR - 2023-09-09 09:07:25 --> 404 Page Not Found: Js/script.js
DEBUG - 2023-09-09 09:07:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 09:07:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 09:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 09:07:25 --> UTF-8 Support Enabled
ERROR - 2023-09-09 09:07:25 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 09:07:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 09:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 09:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 09:07:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 09:07:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 09:07:25 --> 404 Page Not Found: Js/main.js
ERROR - 2023-09-09 09:07:25 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 09:07:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 09:07:25 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-09 09:07:25 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 09:07:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 09:07:25 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-09 10:48:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:48:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-09 10:48:49 --> initController - LoginPage.php
DEBUG - 2023-09-09 10:48:49 --> Total execution time: 0.0372
DEBUG - 2023-09-09 10:48:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:48:49 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 10:48:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:48:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:49 --> UTF-8 Support Enabled
ERROR - 2023-09-09 10:48:49 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 10:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:48:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:48:49 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-09 10:48:49 --> 404 Page Not Found: Js/script.js
DEBUG - 2023-09-09 10:48:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:48:49 --> 404 Page Not Found: Js/main.js
ERROR - 2023-09-09 10:48:49 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-09 10:48:49 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 10:48:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:48:49 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-09 10:48:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:48:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-09 10:48:49 --> initController - LoginPage.php
DEBUG - 2023-09-09 10:48:49 --> Total execution time: 0.0234
DEBUG - 2023-09-09 10:48:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:48:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:48:49 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-09 10:48:49 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-09 10:48:49 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-09 10:48:49 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 10:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:48:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:48:49 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-09 10:48:49 --> 404 Page Not Found: Js/main.js
DEBUG - 2023-09-09 10:48:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:48:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:48:49 --> 404 Page Not Found: Assets/images
ERROR - 2023-09-09 10:48:49 --> 404 Page Not Found: Js/script.js
DEBUG - 2023-09-09 10:48:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:48:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-09 10:48:49 --> initController - LoginPage.php
DEBUG - 2023-09-09 10:48:49 --> Total execution time: 0.0251
DEBUG - 2023-09-09 10:48:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:48:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:48:49 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-09 10:48:49 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-09 10:48:49 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 10:48:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:48:49 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 10:48:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:48:49 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-09 10:48:49 --> 404 Page Not Found: Js/main.js
DEBUG - 2023-09-09 10:48:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:48:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:48:49 --> 404 Page Not Found: Js/script.js
ERROR - 2023-09-09 10:48:49 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-09 10:48:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:48:50 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-09 10:48:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:48:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-09 10:48:50 --> initController - LoginPage.php
DEBUG - 2023-09-09 10:48:50 --> Total execution time: 0.0253
DEBUG - 2023-09-09 10:48:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:48:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:48:50 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-09 10:48:50 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-09 10:48:50 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-09 10:48:50 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 10:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:48:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:48:50 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-09 10:48:50 --> 404 Page Not Found: Js/main.js
DEBUG - 2023-09-09 10:48:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:48:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:48:50 --> 404 Page Not Found: Assets/images
ERROR - 2023-09-09 10:48:50 --> 404 Page Not Found: Js/script.js
DEBUG - 2023-09-09 10:48:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:48:50 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-09 10:48:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:48:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-09 10:48:50 --> initController - LoginPage.php
DEBUG - 2023-09-09 10:48:50 --> Total execution time: 0.0259
DEBUG - 2023-09-09 10:48:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:48:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:48:50 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-09 10:48:50 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-09 10:48:50 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 10:48:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:48:50 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 10:48:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:48:50 --> 404 Page Not Found: Js/main.js
ERROR - 2023-09-09 10:48:50 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-09 10:48:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:48:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:48:50 --> 404 Page Not Found: Assets/images
ERROR - 2023-09-09 10:48:50 --> 404 Page Not Found: Js/script.js
DEBUG - 2023-09-09 10:48:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:48:50 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-09 10:48:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:48:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-09 10:48:50 --> initController - LoginPage.php
DEBUG - 2023-09-09 10:48:50 --> Total execution time: 0.0233
DEBUG - 2023-09-09 10:48:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:48:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:48:50 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-09 10:48:50 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 10:48:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:48:50 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-09 10:48:50 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 10:48:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:48:50 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-09 10:48:50 --> 404 Page Not Found: Js/main.js
DEBUG - 2023-09-09 10:48:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:48:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:48:50 --> 404 Page Not Found: Js/script.js
ERROR - 2023-09-09 10:48:50 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-09 10:49:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:49:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-09 10:49:00 --> initController - LoginPage.php
DEBUG - 2023-09-09 10:49:00 --> Total execution time: 0.0230
DEBUG - 2023-09-09 10:50:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:50:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-09 10:50:27 --> initController - LoginPage.php
DEBUG - 2023-09-09 10:50:27 --> Total execution time: 0.0225
DEBUG - 2023-09-09 10:50:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:50:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:50:27 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 10:50:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:50:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:50:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:50:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:50:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:50:27 --> UTF-8 Support Enabled
ERROR - 2023-09-09 10:50:27 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 10:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:50:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:50:27 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-09 10:50:27 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-09 10:50:27 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-09 10:50:27 --> 404 Page Not Found: Js/main.js
DEBUG - 2023-09-09 10:50:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:50:27 --> 404 Page Not Found: Js/script.js
DEBUG - 2023-09-09 10:50:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:50:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:50:27 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-09 10:50:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:50:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-09 10:50:28 --> initController - LoginPage.php
DEBUG - 2023-09-09 10:50:28 --> Total execution time: 0.0304
DEBUG - 2023-09-09 10:50:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:50:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:50:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:50:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:50:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:50:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:50:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:50:28 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-09 10:50:28 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-09 10:50:28 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-09 10:50:28 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 10:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:50:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:50:28 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-09 10:50:28 --> 404 Page Not Found: Js/main.js
DEBUG - 2023-09-09 10:50:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:50:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:50:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:50:28 --> 404 Page Not Found: Js/script.js
ERROR - 2023-09-09 10:50:28 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-09 10:50:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:50:29 --> No URI present. Default controller set.
DEBUG - 2023-09-09 10:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:50:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-09 10:50:29 --> initController - LoginPage.php
DEBUG - 2023-09-09 10:50:29 --> Total execution time: 0.0270
DEBUG - 2023-09-09 10:51:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:51:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-09 10:51:45 --> initController - LoginPage.php
DEBUG - 2023-09-09 10:51:45 --> Total execution time: 0.0241
DEBUG - 2023-09-09 10:51:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:51:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:51:45 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 10:51:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:51:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:51:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:51:45 --> UTF-8 Support Enabled
ERROR - 2023-09-09 10:51:45 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 10:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:51:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:51:45 --> UTF-8 Support Enabled
ERROR - 2023-09-09 10:51:45 --> 404 Page Not Found: Js/script.js
DEBUG - 2023-09-09 10:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:51:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:51:45 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-09 10:51:45 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-09 10:51:45 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-09 10:51:45 --> 404 Page Not Found: Js/main.js
DEBUG - 2023-09-09 10:51:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:51:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:51:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:51:45 --> 404 Page Not Found: Assets/images
ERROR - 2023-09-09 10:51:45 --> 404 Page Not Found: Img/logo.png
DEBUG - 2023-09-09 10:51:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:51:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-09 10:51:51 --> initController - LoginPage.php
DEBUG - 2023-09-09 10:51:51 --> Total execution time: 0.0232
DEBUG - 2023-09-09 10:51:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:51:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:51:51 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 10:51:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:51:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:51:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:51:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:51:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:51:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:51:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:51:51 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-09 10:51:51 --> 404 Page Not Found: Js/script.js
DEBUG - 2023-09-09 10:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:51:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:51:51 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-09 10:51:51 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-09 10:51:51 --> 404 Page Not Found: Js/main.js
ERROR - 2023-09-09 10:51:51 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-09 10:51:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:51:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:51:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:51:51 --> 404 Page Not Found: Img/logo.png
ERROR - 2023-09-09 10:51:51 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-09 10:52:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:52:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:52:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:52:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:52:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-09 10:52:21 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-09 10:52:21 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-09 10:52:21 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-09 10:52:21 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-09 10:52:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-09 10:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-09 10:52:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-09 10:52:50 --> initController - LoginPage.php
DEBUG - 2023-09-09 10:52:50 --> Total execution time: 0.0235
