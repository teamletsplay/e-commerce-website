<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-09-24 14:11:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 14:11:43 --> No URI present. Default controller set.
DEBUG - 2023-09-24 14:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 14:11:43 --> initController - LoginPage.php
DEBUG - 2023-09-24 14:11:43 --> Total execution time: 0.0247
DEBUG - 2023-09-24 14:11:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 14:11:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 14:11:43 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-24 14:11:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 14:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 14:11:45 --> initController - LoginPage.php
DEBUG - 2023-09-24 14:11:45 --> Total execution time: 0.0290
DEBUG - 2023-09-24 14:11:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 14:11:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 14:11:45 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-24 14:15:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 14:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 14:15:39 --> initController - LoginPage.php
DEBUG - 2023-09-24 14:15:39 --> Total execution time: 0.0241
DEBUG - 2023-09-24 14:15:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 14:15:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 14:15:39 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-24 14:34:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 14:34:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 14:34:37 --> Severity: error --> Exception: syntax error, unexpected identifier "session_start", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\controllers\login.php 4
DEBUG - 2023-09-24 14:35:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 14:35:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 14:35:46 --> Severity: error --> Exception: syntax error, unexpected identifier "session_start", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\controllers\login.php 4
DEBUG - 2023-09-24 14:35:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 14:35:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 14:35:47 --> Severity: error --> Exception: syntax error, unexpected identifier "session_start", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\controllers\login.php 4
DEBUG - 2023-09-24 14:35:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 14:35:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 14:35:47 --> Severity: error --> Exception: syntax error, unexpected identifier "session_start", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\controllers\login.php 4
DEBUG - 2023-09-24 14:35:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 14:35:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 14:35:47 --> Severity: error --> Exception: syntax error, unexpected identifier "session_start", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\controllers\login.php 4
DEBUG - 2023-09-24 14:35:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 14:35:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 14:35:48 --> Severity: error --> Exception: syntax error, unexpected identifier "session_start", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\controllers\login.php 4
DEBUG - 2023-09-24 14:35:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 14:35:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 14:35:48 --> Severity: error --> Exception: syntax error, unexpected identifier "session_start", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\controllers\login.php 4
DEBUG - 2023-09-24 14:35:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 14:35:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 14:35:48 --> Severity: error --> Exception: syntax error, unexpected identifier "session_start", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\controllers\login.php 4
DEBUG - 2023-09-24 14:36:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 14:36:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 14:36:19 --> Severity: error --> Exception: syntax error, unexpected token "public" C:\xampp\htdocs\WebProject\application\controllers\login.php 24
DEBUG - 2023-09-24 14:36:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 14:36:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 14:36:51 --> Severity: Warning --> include(db.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\controllers\login.php 35
ERROR - 2023-09-24 14:36:51 --> Severity: Warning --> include(): Failed opening 'db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\controllers\login.php 35
DEBUG - 2023-09-24 14:36:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 14:36:51 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 288
ERROR - 2023-09-24 14:36:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 303
ERROR - 2023-09-24 14:36:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 313
ERROR - 2023-09-24 14:36:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 314
ERROR - 2023-09-24 14:36:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 315
ERROR - 2023-09-24 14:36:51 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 316
ERROR - 2023-09-24 14:36:51 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 107
ERROR - 2023-09-24 14:36:51 --> Severity: Notice --> session_start(): Ignoring session_start() because a session is already active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 140
ERROR - 2023-09-24 14:36:51 --> Severity: error --> Exception: The model name you are loading is the name of a resource that is already being used: db C:\xampp\htdocs\WebProject\system\core\Loader.php 277
ERROR - 2023-09-24 14:36:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 571
DEBUG - 2023-09-24 14:39:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 14:39:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 14:39:37 --> Severity: Warning --> include(db.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\controllers\login.php 36
ERROR - 2023-09-24 14:39:37 --> Severity: Warning --> include(): Failed opening 'db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\controllers\login.php 36
DEBUG - 2023-09-24 14:39:38 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 14:39:38 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 288
ERROR - 2023-09-24 14:39:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 303
ERROR - 2023-09-24 14:39:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 313
ERROR - 2023-09-24 14:39:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 314
ERROR - 2023-09-24 14:39:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 315
ERROR - 2023-09-24 14:39:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 316
ERROR - 2023-09-24 14:39:38 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 107
ERROR - 2023-09-24 14:39:38 --> Severity: Notice --> session_start(): Ignoring session_start() because a session is already active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 140
ERROR - 2023-09-24 14:39:38 --> Severity: error --> Exception: The model name you are loading is the name of a resource that is already being used: db C:\xampp\htdocs\WebProject\system\core\Loader.php 277
ERROR - 2023-09-24 14:39:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 571
DEBUG - 2023-09-24 14:39:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 14:39:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 14:39:38 --> Severity: Warning --> include(db.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\controllers\login.php 36
ERROR - 2023-09-24 14:39:38 --> Severity: Warning --> include(): Failed opening 'db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\controllers\login.php 36
DEBUG - 2023-09-24 14:39:38 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 14:39:38 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 288
ERROR - 2023-09-24 14:39:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 303
ERROR - 2023-09-24 14:39:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 313
ERROR - 2023-09-24 14:39:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 314
ERROR - 2023-09-24 14:39:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 315
ERROR - 2023-09-24 14:39:38 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 316
ERROR - 2023-09-24 14:39:38 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 107
ERROR - 2023-09-24 14:39:38 --> Severity: Notice --> session_start(): Ignoring session_start() because a session is already active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 140
ERROR - 2023-09-24 14:39:38 --> Severity: error --> Exception: The model name you are loading is the name of a resource that is already being used: db C:\xampp\htdocs\WebProject\system\core\Loader.php 277
ERROR - 2023-09-24 14:39:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 571
DEBUG - 2023-09-24 14:39:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 14:39:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 14:39:39 --> Severity: Warning --> include(db.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\controllers\login.php 36
ERROR - 2023-09-24 14:39:39 --> Severity: Warning --> include(): Failed opening 'db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\controllers\login.php 36
DEBUG - 2023-09-24 14:39:39 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 14:39:39 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 288
ERROR - 2023-09-24 14:39:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 303
ERROR - 2023-09-24 14:39:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 313
ERROR - 2023-09-24 14:39:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 314
ERROR - 2023-09-24 14:39:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 315
ERROR - 2023-09-24 14:39:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 316
ERROR - 2023-09-24 14:39:39 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 107
ERROR - 2023-09-24 14:39:39 --> Severity: Notice --> session_start(): Ignoring session_start() because a session is already active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 140
ERROR - 2023-09-24 14:39:39 --> Severity: error --> Exception: The model name you are loading is the name of a resource that is already being used: db C:\xampp\htdocs\WebProject\system\core\Loader.php 277
ERROR - 2023-09-24 14:39:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 571
DEBUG - 2023-09-24 14:39:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 14:39:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 14:39:39 --> Severity: Warning --> include(db.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\controllers\login.php 36
ERROR - 2023-09-24 14:39:39 --> Severity: Warning --> include(): Failed opening 'db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\controllers\login.php 36
DEBUG - 2023-09-24 14:39:39 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 14:39:39 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 288
ERROR - 2023-09-24 14:39:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 303
ERROR - 2023-09-24 14:39:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 313
ERROR - 2023-09-24 14:39:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 314
ERROR - 2023-09-24 14:39:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 315
ERROR - 2023-09-24 14:39:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 316
ERROR - 2023-09-24 14:39:39 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 107
ERROR - 2023-09-24 14:39:39 --> Severity: Notice --> session_start(): Ignoring session_start() because a session is already active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 140
ERROR - 2023-09-24 14:39:39 --> Severity: error --> Exception: The model name you are loading is the name of a resource that is already being used: db C:\xampp\htdocs\WebProject\system\core\Loader.php 277
ERROR - 2023-09-24 14:39:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 571
DEBUG - 2023-09-24 14:43:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 14:43:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 14:43:16 --> Severity: Warning --> include(db.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\controllers\login.php 36
ERROR - 2023-09-24 14:43:16 --> Severity: Warning --> include(): Failed opening 'db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\controllers\login.php 36
DEBUG - 2023-09-24 14:43:16 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 14:43:16 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 288
ERROR - 2023-09-24 14:43:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 303
ERROR - 2023-09-24 14:43:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 313
ERROR - 2023-09-24 14:43:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 314
ERROR - 2023-09-24 14:43:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 315
ERROR - 2023-09-24 14:43:16 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 316
ERROR - 2023-09-24 14:43:16 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 107
ERROR - 2023-09-24 14:43:16 --> Severity: Notice --> session_start(): Ignoring session_start() because a session is already active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 140
ERROR - 2023-09-24 14:43:16 --> Severity: Warning --> session_regenerate_id(): Session ID cannot be regenerated after headers have already been sent C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 625
ERROR - 2023-09-24 14:43:16 --> Severity: Warning --> require(config/constant1.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\models\db1.php 3
ERROR - 2023-09-24 14:43:16 --> Severity: error --> Exception: Failed opening required 'config/constant1.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\models\db1.php 3
ERROR - 2023-09-24 14:43:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 571
DEBUG - 2023-09-24 14:44:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 14:44:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 14:44:55 --> Severity: Warning --> include(db.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\controllers\login.php 36
ERROR - 2023-09-24 14:44:55 --> Severity: Warning --> include(): Failed opening 'db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\controllers\login.php 36
DEBUG - 2023-09-24 14:44:55 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 14:44:55 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 288
ERROR - 2023-09-24 14:44:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 303
ERROR - 2023-09-24 14:44:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 313
ERROR - 2023-09-24 14:44:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 314
ERROR - 2023-09-24 14:44:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 315
ERROR - 2023-09-24 14:44:55 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 316
ERROR - 2023-09-24 14:44:55 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 107
ERROR - 2023-09-24 14:44:55 --> Severity: Notice --> session_start(): Ignoring session_start() because a session is already active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 140
ERROR - 2023-09-24 14:44:55 --> Severity: error --> Exception: C:\xampp\htdocs\WebProject\application\models/Db1.php exists, but doesn't declare class Db1 C:\xampp\htdocs\WebProject\system\core\Loader.php 342
ERROR - 2023-09-24 14:44:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 571
DEBUG - 2023-09-24 14:46:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 14:46:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 14:46:54 --> Severity: Warning --> include(db.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\controllers\login.php 36
ERROR - 2023-09-24 14:46:54 --> Severity: Warning --> include(): Failed opening 'db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\controllers\login.php 36
DEBUG - 2023-09-24 14:46:54 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 14:46:54 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 288
ERROR - 2023-09-24 14:46:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 303
ERROR - 2023-09-24 14:46:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 313
ERROR - 2023-09-24 14:46:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 314
ERROR - 2023-09-24 14:46:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 315
ERROR - 2023-09-24 14:46:54 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 316
ERROR - 2023-09-24 14:46:54 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 107
ERROR - 2023-09-24 14:46:54 --> Severity: Notice --> session_start(): Ignoring session_start() because a session is already active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 140
ERROR - 2023-09-24 14:46:54 --> Severity: error --> Exception: syntax error, unexpected token "require", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 4
ERROR - 2023-09-24 14:46:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 571
DEBUG - 2023-09-24 14:51:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 14:51:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 14:51:26 --> Severity: Warning --> include(db.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\controllers\login.php 36
ERROR - 2023-09-24 14:51:26 --> Severity: Warning --> include(): Failed opening 'db.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\controllers\login.php 36
DEBUG - 2023-09-24 14:51:26 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 14:51:26 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 288
ERROR - 2023-09-24 14:51:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 303
ERROR - 2023-09-24 14:51:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 313
ERROR - 2023-09-24 14:51:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 314
ERROR - 2023-09-24 14:51:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 315
ERROR - 2023-09-24 14:51:26 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 316
ERROR - 2023-09-24 14:51:26 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 107
ERROR - 2023-09-24 14:51:26 --> Severity: Notice --> session_start(): Ignoring session_start() because a session is already active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 140
ERROR - 2023-09-24 14:51:26 --> Severity: Warning --> session_regenerate_id(): Session ID cannot be regenerated after headers have already been sent C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 625
ERROR - 2023-09-24 14:51:26 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 17
ERROR - 2023-09-24 14:51:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 571
DEBUG - 2023-09-24 14:52:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 14:52:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 14:52:19 --> Severity: Warning --> include(db1.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\controllers\login.php 36
ERROR - 2023-09-24 14:52:19 --> Severity: Warning --> include(): Failed opening 'db1.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\controllers\login.php 36
DEBUG - 2023-09-24 14:52:19 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 14:52:19 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 288
ERROR - 2023-09-24 14:52:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 303
ERROR - 2023-09-24 14:52:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 313
ERROR - 2023-09-24 14:52:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 314
ERROR - 2023-09-24 14:52:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 315
ERROR - 2023-09-24 14:52:19 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 316
ERROR - 2023-09-24 14:52:19 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed when a session is active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 107
ERROR - 2023-09-24 14:52:19 --> Severity: Notice --> session_start(): Ignoring session_start() because a session is already active C:\xampp\htdocs\WebProject\system\libraries\Session\Session.php 140
ERROR - 2023-09-24 14:52:19 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 17
ERROR - 2023-09-24 14:52:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\WebProject\system\core\Exceptions.php:272) C:\xampp\htdocs\WebProject\system\core\Common.php 571
DEBUG - 2023-09-24 14:54:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 14:54:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 14:54:22 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 17
DEBUG - 2023-09-24 14:56:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 14:56:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 14:56:11 --> Severity: error --> Exception: syntax error, unexpected identifier "define", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 17
DEBUG - 2023-09-24 15:05:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:05:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 15:05:06 --> Severity: error --> Exception: syntax error, unexpected variable "$this", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 10
DEBUG - 2023-09-24 15:09:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:09:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 15:09:14 --> Severity: error --> Exception: syntax error, unexpected token "require_once", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 10
DEBUG - 2023-09-24 15:09:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:09:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 15:09:18 --> Severity: error --> Exception: syntax error, unexpected token "require_once", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 10
DEBUG - 2023-09-24 15:15:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:15:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 15:15:18 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:02 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:02 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:03 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:03 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:07 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:07 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:07 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:07 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:07 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:07 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:07 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:07 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:07 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:07 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:08 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:08 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:08 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:08 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:08 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:08 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:08 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:08 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:08 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:08 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:09 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:09 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:09 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:09 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:09 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:09 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:10 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:10 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:10 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:10 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:10 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:10 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:10 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:10 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:11 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:11 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:11 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:11 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:11 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:11 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:11 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:11 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:11 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:11 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:12 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:12 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:12 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:12 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:12 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:12 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:12 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:12 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:12 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:12 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:12 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:12 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:13 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:13 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:13 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:13 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:13 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:13 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:13 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:13 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:13 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:13 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:14 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:14 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:14 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:14 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:14 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:14 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:14 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:14 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:14 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:14 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:15 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:15 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:15 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:15 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:15 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:15 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:15 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:15 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:15 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:15 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:16 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:16 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:16 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:16 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:16 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:16 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:16 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:16 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:16 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:16 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:51:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:17 --> No URI present. Default controller set.
DEBUG - 2023-09-24 15:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:17 --> initController - LoginPage.php
DEBUG - 2023-09-24 15:51:17 --> Total execution time: 0.0447
DEBUG - 2023-09-24 15:51:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 15:51:17 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-24 15:51:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:51:22 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:51:22 --> Severity: error --> Exception: syntax error, unexpected variable "$servername", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\models\db1.php 11
DEBUG - 2023-09-24 15:53:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:53:35 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:53:35 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-24 15:53:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:53:37 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:53:37 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-24 15:53:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:53:37 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:53:37 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-24 15:53:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:53:37 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:53:37 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-24 15:53:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:53:37 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:53:37 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-24 15:53:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:53:38 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:53:38 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-24 15:54:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:54:38 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:54:38 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-24 15:54:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:54:38 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:54:38 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-24 15:54:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:54:38 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:54:38 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-24 15:54:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:54:38 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:54:38 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-24 15:54:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:54:39 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:54:39 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-24 15:54:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:54:39 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:54:39 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-24 15:54:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:54:39 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:54:39 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-24 15:54:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:54:39 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:54:39 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-24 15:54:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:54:39 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:54:39 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-24 15:54:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:54:40 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:54:40 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-24 15:54:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:54:40 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:54:40 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-24 15:55:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:55:01 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:55:01 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-24 15:55:01 --> Total execution time: 0.0575
DEBUG - 2023-09-24 15:55:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:55:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 15:55:01 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-24 15:55:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 15:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 15:55:16 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 15:55:16 --> Severity: error --> Exception: Unknown column 'status' in 'where clause' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 264
DEBUG - 2023-09-24 16:17:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 16:17:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 16:17:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 16:17:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 16:18:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 16:18:20 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 16:18:20 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-24 16:18:20 --> Total execution time: 0.0573
DEBUG - 2023-09-24 16:18:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:18:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:18:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:18:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 16:18:20 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-24 16:18:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:18:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 16:18:20 --> 404 Page Not Found: Login/5546YEEcss
DEBUG - 2023-09-24 16:18:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:18:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 16:18:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 16:18:20 --> 404 Page Not Found: Login/js
ERROR - 2023-09-24 16:18:21 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-24 16:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 16:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 16:18:21 --> UTF-8 Support Enabled
ERROR - 2023-09-24 16:18:21 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-24 16:18:21 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-24 16:18:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:18:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 16:18:21 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-24 16:18:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:18:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:18:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 16:18:21 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-24 16:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 16:18:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 16:18:21 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-24 16:18:21 --> 404 Page Not Found: Login/images
DEBUG - 2023-09-24 16:18:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 16:18:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 16:18:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 16:18:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 16:21:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 16:21:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 16:21:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 16:21:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 16:21:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 16:21:27 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 16:21:27 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-24 16:21:27 --> Total execution time: 0.0552
DEBUG - 2023-09-24 16:21:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 16:21:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 16:21:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 16:21:47 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 16:21:47 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-24 16:21:47 --> Total execution time: 0.0528
DEBUG - 2023-09-24 16:21:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:21:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 16:21:47 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-24 16:22:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 16:22:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 16:22:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 16:22:55 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 16:22:55 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-24 16:22:55 --> Total execution time: 0.0648
DEBUG - 2023-09-24 16:22:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:22:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 16:22:56 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-24 16:23:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:23:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 16:23:00 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-24 16:23:00 --> Total execution time: 0.0485
DEBUG - 2023-09-24 16:23:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:23:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 16:23:01 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-24 16:23:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:23:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 16:23:24 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-24 16:23:24 --> Total execution time: 0.0574
DEBUG - 2023-09-24 16:23:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:23:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 16:23:24 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-24 16:23:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 16:23:37 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 16:23:37 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-24 16:23:37 --> Total execution time: 0.0579
DEBUG - 2023-09-24 16:23:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:23:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 16:23:37 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-24 16:23:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 16:23:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 16:23:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 16:23:45 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 16:23:45 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-24 16:23:45 --> Total execution time: 0.0574
DEBUG - 2023-09-24 16:23:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:23:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 16:23:45 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-24 16:24:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 16:24:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 16:24:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 16:24:13 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 16:24:13 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-24 16:24:13 --> Total execution time: 0.0525
DEBUG - 2023-09-24 16:24:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:24:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 16:24:13 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-24 16:25:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 16:25:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 16:25:51 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-24 16:25:51 --> Total execution time: 0.0627
DEBUG - 2023-09-24 16:25:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:25:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 16:25:51 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-24 16:26:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 16:26:00 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 16:26:00 --> Severity: error --> Exception: Unknown column 'status' in 'where clause' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 264
DEBUG - 2023-09-24 16:38:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 16:38:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 16:38:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 16:38:33 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 16:38:33 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-24 16:38:33 --> Total execution time: 0.0529
DEBUG - 2023-09-24 16:38:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:38:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 16:38:34 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-24 16:38:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 16:38:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 16:38:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 16:38:41 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 16:38:41 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-24 16:38:41 --> Total execution time: 0.0530
DEBUG - 2023-09-24 16:38:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:38:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 16:38:41 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-24 16:39:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 16:39:58 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 16:39:58 --> Severity: Warning --> Undefined property: stdClass::$username C:\xampp\htdocs\WebProject\application\controllers\login.php 80
DEBUG - 2023-09-24 16:39:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 16:39:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 16:39:58 --> Total execution time: 0.0502
DEBUG - 2023-09-24 16:47:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 16:47:33 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 16:47:33 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\WebProject\system\libraries\Session\Session_driver.php 102
DEBUG - 2023-09-24 16:47:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:47:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 16:47:33 --> 404 Page Not Found: Welcome/login
DEBUG - 2023-09-24 16:47:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 16:47:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 16:47:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 16:47:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-24 16:47:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 16:47:43 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 16:47:43 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-24 16:47:43 --> Total execution time: 0.0254
DEBUG - 2023-09-24 16:47:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 16:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 16:47:48 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-24 16:47:48 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-24 16:47:48 --> Severity: Notice --> session_start(): Ignoring session_start() because a session is already active C:\xampp\htdocs\WebProject\application\views\insert.php 2
ERROR - 2023-09-24 16:47:48 --> Severity: Warning --> include(./templates/top.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 7
ERROR - 2023-09-24 16:47:48 --> Severity: Warning --> include(): Failed opening './templates/top.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 7
ERROR - 2023-09-24 16:47:48 --> Severity: Warning --> include(./templates/navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 11
ERROR - 2023-09-24 16:47:48 --> Severity: Warning --> include(): Failed opening './templates/navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 11
ERROR - 2023-09-24 16:47:48 --> Severity: Warning --> include(./templates/sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 16
ERROR - 2023-09-24 16:47:48 --> Severity: Warning --> include(): Failed opening './templates/sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 16
ERROR - 2023-09-24 16:47:48 --> Severity: Warning --> include(./templates/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 47
ERROR - 2023-09-24 16:47:48 --> Severity: Warning --> include(): Failed opening './templates/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 47
DEBUG - 2023-09-24 16:47:48 --> Total execution time: 0.0294
DEBUG - 2023-09-24 17:34:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 17:34:39 --> No URI present. Default controller set.
DEBUG - 2023-09-24 17:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 17:34:39 --> initController - LoginPage.php
DEBUG - 2023-09-24 17:34:39 --> Total execution time: 0.0234
DEBUG - 2023-09-24 17:34:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 17:34:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 17:34:39 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-24 18:40:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 18:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 18:40:14 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-24 18:40:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 18:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 18:40:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 18:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 18:41:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 18:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 18:41:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 18:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 18:41:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 18:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 18:41:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 18:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 18:41:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 18:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 18:43:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 18:43:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 18:43:16 --> Severity: Warning --> include_once(./templates/top.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\help.php 13
ERROR - 2023-09-24 18:43:16 --> Severity: Warning --> include_once(): Failed opening './templates/top.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\help.php 13
ERROR - 2023-09-24 18:43:16 --> Severity: Warning --> include_once(./templates/navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\help.php 14
ERROR - 2023-09-24 18:43:16 --> Severity: Warning --> include_once(): Failed opening './templates/navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\help.php 14
ERROR - 2023-09-24 18:43:16 --> Severity: Warning --> include(./templates/sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\help.php 18
ERROR - 2023-09-24 18:43:16 --> Severity: Warning --> include(): Failed opening './templates/sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\help.php 18
ERROR - 2023-09-24 18:43:16 --> Severity: Warning --> include_once(./templates/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\help.php 74
ERROR - 2023-09-24 18:43:16 --> Severity: Warning --> include_once(): Failed opening './templates/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\help.php 74
DEBUG - 2023-09-24 18:43:16 --> Total execution time: 0.0472
DEBUG - 2023-09-24 18:43:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 18:43:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 18:43:16 --> 404 Page Not Found: Js/help.js
DEBUG - 2023-09-24 18:45:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 18:45:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 18:45:14 --> Severity: Warning --> include_once(./templates/navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\help.php 14
ERROR - 2023-09-24 18:45:14 --> Severity: Warning --> include_once(): Failed opening './templates/navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\help.php 14
ERROR - 2023-09-24 18:45:14 --> Severity: Warning --> include(./templates/sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\help.php 18
ERROR - 2023-09-24 18:45:14 --> Severity: Warning --> include(): Failed opening './templates/sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\help.php 18
DEBUG - 2023-09-24 18:45:14 --> Total execution time: 0.0405
DEBUG - 2023-09-24 18:45:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 18:45:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 18:45:14 --> 404 Page Not Found: Js/help.js
DEBUG - 2023-09-24 18:45:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 18:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 18:45:54 --> Total execution time: 0.0348
DEBUG - 2023-09-24 18:45:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 18:45:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 18:45:54 --> 404 Page Not Found: Js/help.js
DEBUG - 2023-09-24 18:45:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 18:45:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 18:45:59 --> 404 Page Not Found: Customersphp/index
DEBUG - 2023-09-24 18:46:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 18:46:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 18:46:03 --> Total execution time: 0.0409
DEBUG - 2023-09-24 18:46:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 18:46:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 18:46:03 --> 404 Page Not Found: Js/help.js
DEBUG - 2023-09-24 18:46:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 18:46:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 18:46:08 --> 404 Page Not Found: Customersphp/index
DEBUG - 2023-09-24 18:46:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 18:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 18:46:10 --> Total execution time: 0.0490
DEBUG - 2023-09-24 18:46:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 18:46:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 18:46:11 --> 404 Page Not Found: Js/help.js
DEBUG - 2023-09-24 18:47:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 18:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 18:47:20 --> Total execution time: 0.0352
DEBUG - 2023-09-24 18:47:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 18:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 18:47:21 --> Total execution time: 0.0603
DEBUG - 2023-09-24 18:47:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 18:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 18:47:21 --> Total execution time: 0.0448
DEBUG - 2023-09-24 18:47:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 18:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 18:47:21 --> Total execution time: 0.0349
DEBUG - 2023-09-24 18:47:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 18:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 18:47:21 --> Total execution time: 0.0338
DEBUG - 2023-09-24 18:47:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 18:47:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 18:47:26 --> 404 Page Not Found: Customersphp/index
DEBUG - 2023-09-24 18:47:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 18:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 18:47:29 --> Total execution time: 0.0388
DEBUG - 2023-09-24 18:47:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 18:47:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 18:47:34 --> 404 Page Not Found: Customersphp/index
DEBUG - 2023-09-24 18:47:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 18:47:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 18:47:37 --> Severity: Warning --> Undefined array key "admin_name" C:\xampp\htdocs\WebProject\application\admin\templates\sidebar.php 66
DEBUG - 2023-09-24 18:47:37 --> Total execution time: 0.0397
DEBUG - 2023-09-24 18:47:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 18:47:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 18:47:51 --> Severity: Warning --> Undefined array key "admin_name" C:\xampp\htdocs\WebProject\application\admin\templates\sidebar.php 66
DEBUG - 2023-09-24 18:47:51 --> Total execution time: 0.0356
DEBUG - 2023-09-24 18:47:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 18:47:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 18:47:52 --> Severity: Warning --> Undefined array key "admin_name" C:\xampp\htdocs\WebProject\application\admin\templates\sidebar.php 66
DEBUG - 2023-09-24 18:47:52 --> Total execution time: 0.0387
DEBUG - 2023-09-24 18:47:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 18:47:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 18:47:52 --> Severity: Warning --> Undefined array key "admin_name" C:\xampp\htdocs\WebProject\application\admin\templates\sidebar.php 66
DEBUG - 2023-09-24 18:47:52 --> Total execution time: 0.0377
DEBUG - 2023-09-24 18:50:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 18:50:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 18:50:18 --> Severity: Warning --> Undefined array key "admin_name" C:\xampp\htdocs\WebProject\application\admin\templates\sidebar.php 66
DEBUG - 2023-09-24 18:50:18 --> Total execution time: 0.0394
DEBUG - 2023-09-24 18:50:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 18:50:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 18:50:18 --> Severity: Warning --> Undefined array key "admin_name" C:\xampp\htdocs\WebProject\application\admin\templates\sidebar.php 66
DEBUG - 2023-09-24 18:50:18 --> Total execution time: 0.0363
DEBUG - 2023-09-24 18:50:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 18:50:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 18:50:19 --> Severity: Warning --> Undefined array key "admin_name" C:\xampp\htdocs\WebProject\application\admin\templates\sidebar.php 66
DEBUG - 2023-09-24 18:50:19 --> Total execution time: 0.0361
DEBUG - 2023-09-24 18:50:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 18:50:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 18:50:19 --> Severity: Warning --> Undefined array key "admin_name" C:\xampp\htdocs\WebProject\application\admin\templates\sidebar.php 66
DEBUG - 2023-09-24 18:50:19 --> Total execution time: 0.0397
DEBUG - 2023-09-24 20:00:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 20:00:18 --> No URI present. Default controller set.
DEBUG - 2023-09-24 20:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-24 20:00:18 --> initController - LoginPage.php
DEBUG - 2023-09-24 20:00:18 --> Total execution time: 0.0217
DEBUG - 2023-09-24 20:00:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-24 20:00:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-24 20:00:18 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
