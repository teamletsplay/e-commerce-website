<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-09-12 09:12:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:12:31 --> No URI present. Default controller set.
DEBUG - 2023-09-12 09:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:12:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:12:31 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:12:31 --> Total execution time: 0.0535
DEBUG - 2023-09-12 09:12:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:12:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:12:40 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:12:40 --> Total execution time: 0.0264
DEBUG - 2023-09-12 09:12:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:12:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 09:12:46 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-12 09:12:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:12:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:12:49 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:12:49 --> Total execution time: 0.0234
DEBUG - 2023-09-12 09:12:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:12:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:12:57 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:12:57 --> Total execution time: 0.0224
DEBUG - 2023-09-12 09:15:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:15:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 09:15:17 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-12 09:26:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:26:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:26:14 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:26:14 --> Total execution time: 0.0235
DEBUG - 2023-09-12 09:26:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:26:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:26:15 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:26:15 --> Total execution time: 0.0235
DEBUG - 2023-09-12 09:26:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:26:24 --> No URI present. Default controller set.
DEBUG - 2023-09-12 09:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:26:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:26:24 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:26:24 --> Total execution time: 0.0241
DEBUG - 2023-09-12 09:26:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:26:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:26:38 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:26:38 --> Total execution time: 0.0255
DEBUG - 2023-09-12 09:27:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:27:15 --> No URI present. Default controller set.
DEBUG - 2023-09-12 09:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:27:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:27:15 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:27:15 --> Total execution time: 0.0255
DEBUG - 2023-09-12 09:27:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:27:19 --> No URI present. Default controller set.
DEBUG - 2023-09-12 09:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:27:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:27:19 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:27:19 --> Total execution time: 0.0250
DEBUG - 2023-09-12 09:27:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:27:20 --> No URI present. Default controller set.
DEBUG - 2023-09-12 09:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:27:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:27:20 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:27:20 --> Total execution time: 0.0258
DEBUG - 2023-09-12 09:27:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:27:20 --> No URI present. Default controller set.
DEBUG - 2023-09-12 09:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:27:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:27:20 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:27:20 --> Total execution time: 0.0236
DEBUG - 2023-09-12 09:27:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:27:20 --> No URI present. Default controller set.
DEBUG - 2023-09-12 09:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:27:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:27:20 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:27:20 --> Total execution time: 0.0235
DEBUG - 2023-09-12 09:27:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:27:20 --> No URI present. Default controller set.
DEBUG - 2023-09-12 09:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:27:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:27:20 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:27:20 --> Total execution time: 0.0240
DEBUG - 2023-09-12 09:27:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:27:21 --> No URI present. Default controller set.
DEBUG - 2023-09-12 09:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:27:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:27:21 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:27:21 --> Total execution time: 0.0242
DEBUG - 2023-09-12 09:27:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:27:21 --> No URI present. Default controller set.
DEBUG - 2023-09-12 09:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:27:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:27:21 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:27:21 --> Total execution time: 0.0248
DEBUG - 2023-09-12 09:27:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:27:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:27:23 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:27:23 --> Total execution time: 0.0220
DEBUG - 2023-09-12 09:27:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:27:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:27:57 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:27:57 --> Total execution time: 0.0230
DEBUG - 2023-09-12 09:27:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:27:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 09:27:57 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 09:27:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:27:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:27:58 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:27:58 --> Total execution time: 0.0278
DEBUG - 2023-09-12 09:27:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:27:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 09:27:58 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 09:27:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:27:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:27:58 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:27:58 --> Total execution time: 0.0244
DEBUG - 2023-09-12 09:27:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:27:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 09:27:58 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 09:27:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:27:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:27:58 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:27:58 --> Total execution time: 0.0232
DEBUG - 2023-09-12 09:27:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:27:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 09:27:58 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 09:27:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:27:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:27:59 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:27:59 --> Total execution time: 0.0229
DEBUG - 2023-09-12 09:27:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:27:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 09:27:59 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 09:27:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:27:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:27:59 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:27:59 --> Total execution time: 0.0246
DEBUG - 2023-09-12 09:27:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:27:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 09:27:59 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 09:27:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:27:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:27:59 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:27:59 --> Total execution time: 0.0228
DEBUG - 2023-09-12 09:27:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:27:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 09:27:59 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 09:27:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:27:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:27:59 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:27:59 --> Total execution time: 0.0225
DEBUG - 2023-09-12 09:27:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:27:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 09:27:59 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 09:27:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:27:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:27:59 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:27:59 --> Total execution time: 0.0230
DEBUG - 2023-09-12 09:27:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:27:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 09:27:59 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 09:28:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:28:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:28:00 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:28:00 --> Total execution time: 0.0218
DEBUG - 2023-09-12 09:28:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:28:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 09:28:00 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 09:28:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:28:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:28:00 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:28:00 --> Total execution time: 0.0226
DEBUG - 2023-09-12 09:28:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:28:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 09:28:00 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 09:28:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:28:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:28:00 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:28:00 --> Total execution time: 0.0231
DEBUG - 2023-09-12 09:28:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:28:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 09:28:00 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 09:28:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:28:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:28:01 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:28:01 --> Total execution time: 0.0245
DEBUG - 2023-09-12 09:28:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:28:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 09:28:01 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 09:28:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:28:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:28:01 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:28:01 --> Total execution time: 0.0232
DEBUG - 2023-09-12 09:28:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:28:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 09:28:01 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 09:28:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:28:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:28:02 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:28:02 --> Total execution time: 0.0240
DEBUG - 2023-09-12 09:28:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:28:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 09:28:02 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 09:28:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:28:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:28:02 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:28:02 --> Total execution time: 0.0240
DEBUG - 2023-09-12 09:28:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:28:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 09:28:02 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 09:28:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:28:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:28:02 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:28:02 --> Total execution time: 0.0228
DEBUG - 2023-09-12 09:28:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:28:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 09:28:02 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 09:28:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:28:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:28:02 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:28:02 --> Total execution time: 0.0229
DEBUG - 2023-09-12 09:28:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:28:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 09:28:02 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 09:28:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:28:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:28:02 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:28:02 --> Total execution time: 0.0234
DEBUG - 2023-09-12 09:28:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:28:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 09:28:02 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 09:28:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:28:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:28:03 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:28:03 --> Total execution time: 0.0221
DEBUG - 2023-09-12 09:28:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:28:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 09:28:03 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 09:30:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:30:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:30:51 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:30:51 --> Total execution time: 0.0254
DEBUG - 2023-09-12 09:30:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:30:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 09:30:51 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 09:30:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:30:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:30:52 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:30:52 --> Total execution time: 0.0233
DEBUG - 2023-09-12 09:30:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:30:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 09:30:52 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 09:31:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:31:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:31:08 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:31:08 --> Total execution time: 0.0267
DEBUG - 2023-09-12 09:31:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:31:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 09:31:08 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 09:31:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:31:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 09:31:21 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-12 09:31:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:31:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:31:25 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:31:25 --> Total execution time: 0.0241
DEBUG - 2023-09-12 09:32:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:32:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:32:08 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:32:08 --> Total execution time: 0.0221
DEBUG - 2023-09-12 09:32:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:32:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 09:32:08 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 09:34:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:34:38 --> No URI present. Default controller set.
DEBUG - 2023-09-12 09:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:34:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:34:38 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:34:38 --> Total execution time: 0.0248
DEBUG - 2023-09-12 09:34:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:34:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 09:34:38 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 09:34:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:34:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:34:42 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:34:42 --> Total execution time: 0.0231
DEBUG - 2023-09-12 09:34:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:34:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 09:34:42 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 09:35:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:35:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:35:13 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:35:13 --> Total execution time: 0.0234
DEBUG - 2023-09-12 09:35:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:35:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:35:47 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:35:47 --> Total execution time: 0.0455
DEBUG - 2023-09-12 09:35:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:35:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 09:35:48 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 09:36:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 09:36:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 09:36:50 --> initController - LoginPage.php
DEBUG - 2023-09-12 09:36:50 --> Total execution time: 0.0262
DEBUG - 2023-09-12 09:36:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 09:36:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 09:36:50 --> 404 Page Not Found: Assets/style3.css
DEBUG - 2023-09-12 11:10:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:10:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:10:09 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:10:09 --> Total execution time: 0.0251
DEBUG - 2023-09-12 11:10:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:10:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:10:17 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:10:17 --> Total execution time: 0.0226
DEBUG - 2023-09-12 11:10:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:10:17 --> 404 Page Not Found: Assets/style3.css
DEBUG - 2023-09-12 11:10:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:10:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:10:18 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:10:18 --> Total execution time: 0.0272
DEBUG - 2023-09-12 11:10:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:10:18 --> 404 Page Not Found: Assets/style3.css
DEBUG - 2023-09-12 11:10:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:10:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:10:18 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:10:18 --> Total execution time: 0.0247
DEBUG - 2023-09-12 11:10:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:10:18 --> 404 Page Not Found: Assets/style3.css
DEBUG - 2023-09-12 11:10:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:10:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:10:18 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:10:18 --> Total execution time: 0.0396
DEBUG - 2023-09-12 11:10:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:10:18 --> 404 Page Not Found: Assets/style3.css
DEBUG - 2023-09-12 11:10:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:10:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:10:19 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:10:19 --> Total execution time: 0.0308
DEBUG - 2023-09-12 11:10:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:10:19 --> 404 Page Not Found: Assets/style3.css
DEBUG - 2023-09-12 11:10:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:10:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:10:19 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:10:19 --> Total execution time: 0.0255
DEBUG - 2023-09-12 11:10:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:10:19 --> 404 Page Not Found: Assets/style3.css
DEBUG - 2023-09-12 11:10:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:10:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:10:19 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:10:19 --> Total execution time: 0.0227
DEBUG - 2023-09-12 11:10:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:10:19 --> 404 Page Not Found: Assets/style3.css
DEBUG - 2023-09-12 11:10:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:10:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:10:19 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:10:19 --> Total execution time: 0.0227
DEBUG - 2023-09-12 11:10:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:10:19 --> 404 Page Not Found: Assets/style3.css
DEBUG - 2023-09-12 11:10:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:10:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:10:20 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:10:20 --> Total execution time: 0.0212
DEBUG - 2023-09-12 11:10:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:10:20 --> 404 Page Not Found: Assets/style3.css
DEBUG - 2023-09-12 11:10:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:10:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:10:20 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:10:20 --> Total execution time: 0.0223
DEBUG - 2023-09-12 11:10:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:10:20 --> 404 Page Not Found: Assets/style3.css
DEBUG - 2023-09-12 11:10:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:10:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:10:20 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:10:20 --> Total execution time: 0.0219
DEBUG - 2023-09-12 11:10:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:10:20 --> 404 Page Not Found: Assets/style3.css
DEBUG - 2023-09-12 11:10:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:10:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:10:20 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:10:20 --> Total execution time: 0.0240
DEBUG - 2023-09-12 11:10:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:10:20 --> 404 Page Not Found: Assets/style3.css
DEBUG - 2023-09-12 11:10:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:10:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:10:20 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:10:20 --> Total execution time: 0.0234
DEBUG - 2023-09-12 11:10:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:10:20 --> 404 Page Not Found: Assets/style3.css
DEBUG - 2023-09-12 11:10:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:10:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:10:21 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:10:21 --> Total execution time: 0.0224
DEBUG - 2023-09-12 11:10:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:10:21 --> 404 Page Not Found: Assets/style3.css
DEBUG - 2023-09-12 11:10:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:10:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:10:21 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:10:21 --> Total execution time: 0.0228
DEBUG - 2023-09-12 11:10:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:10:21 --> 404 Page Not Found: Assets/style3.css
DEBUG - 2023-09-12 11:10:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:10:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:10:21 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:10:21 --> Total execution time: 0.0229
DEBUG - 2023-09-12 11:10:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:10:21 --> 404 Page Not Found: Assets/style3.css
DEBUG - 2023-09-12 11:10:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:10:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:10:21 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:10:21 --> Total execution time: 0.0227
DEBUG - 2023-09-12 11:10:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:10:21 --> 404 Page Not Found: Assets/style3.css
DEBUG - 2023-09-12 11:10:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:10:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:10:21 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:10:21 --> Total execution time: 0.0246
DEBUG - 2023-09-12 11:10:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:10:21 --> 404 Page Not Found: Assets/style3.css
DEBUG - 2023-09-12 11:10:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:10:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:10:22 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:10:22 --> Total execution time: 0.0224
DEBUG - 2023-09-12 11:10:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:10:22 --> 404 Page Not Found: Assets/style3.css
DEBUG - 2023-09-12 11:10:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:10:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:10:22 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:10:22 --> Total execution time: 0.0347
DEBUG - 2023-09-12 11:10:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:10:22 --> 404 Page Not Found: Assets/style3.css
DEBUG - 2023-09-12 11:10:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:10:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:10:22 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:10:22 --> Total execution time: 0.0226
DEBUG - 2023-09-12 11:10:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:10:22 --> 404 Page Not Found: Assets/style3.css
DEBUG - 2023-09-12 11:10:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:10:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:10:22 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:10:22 --> Total execution time: 0.0227
DEBUG - 2023-09-12 11:10:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:10:22 --> 404 Page Not Found: Assets/style3.css
DEBUG - 2023-09-12 11:10:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:10:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:10:23 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:10:23 --> Total execution time: 0.0222
DEBUG - 2023-09-12 11:10:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:10:23 --> 404 Page Not Found: Assets/style3.css
DEBUG - 2023-09-12 11:10:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:10:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:10:23 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:10:23 --> Total execution time: 0.0230
DEBUG - 2023-09-12 11:10:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:10:23 --> 404 Page Not Found: Assets/style3.css
DEBUG - 2023-09-12 11:10:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:10:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:10:23 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:10:23 --> Total execution time: 0.0225
DEBUG - 2023-09-12 11:10:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:10:23 --> 404 Page Not Found: Assets/style3.css
DEBUG - 2023-09-12 11:10:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:10:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:10:23 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:10:23 --> Total execution time: 0.0227
DEBUG - 2023-09-12 11:10:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:10:23 --> 404 Page Not Found: Assets/style3.css
DEBUG - 2023-09-12 11:10:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:10:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:10:24 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:10:24 --> Total execution time: 0.0214
DEBUG - 2023-09-12 11:10:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:10:24 --> 404 Page Not Found: Assets/style3.css
DEBUG - 2023-09-12 11:10:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:10:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:10:24 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:10:24 --> Total execution time: 0.0226
DEBUG - 2023-09-12 11:10:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:10:24 --> 404 Page Not Found: Assets/style3.css
DEBUG - 2023-09-12 11:10:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:10:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:10:24 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:10:24 --> Total execution time: 0.0220
DEBUG - 2023-09-12 11:10:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:10:24 --> 404 Page Not Found: Assets/style3.css
DEBUG - 2023-09-12 11:10:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:10:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:10:24 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:10:24 --> Total execution time: 0.0225
DEBUG - 2023-09-12 11:10:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:10:24 --> 404 Page Not Found: Assets/style3.css
DEBUG - 2023-09-12 11:10:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:10:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:10:24 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:10:24 --> Total execution time: 0.0226
DEBUG - 2023-09-12 11:10:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:10:24 --> 404 Page Not Found: Assets/style3.css
DEBUG - 2023-09-12 11:10:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:10:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:10:25 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:10:25 --> Total execution time: 0.0209
DEBUG - 2023-09-12 11:10:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:10:25 --> 404 Page Not Found: Assets/style3.css
DEBUG - 2023-09-12 11:10:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:10:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:10:25 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:10:25 --> Total execution time: 0.0218
DEBUG - 2023-09-12 11:10:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:10:25 --> 404 Page Not Found: Assets/style3.css
DEBUG - 2023-09-12 11:10:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:10:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:10:25 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:10:25 --> Total execution time: 0.0226
DEBUG - 2023-09-12 11:10:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:10:25 --> 404 Page Not Found: Assets/style3.css
DEBUG - 2023-09-12 11:10:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:10:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:10:25 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:10:25 --> Total execution time: 0.0231
DEBUG - 2023-09-12 11:10:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:10:25 --> 404 Page Not Found: Assets/style3.css
DEBUG - 2023-09-12 11:10:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:10:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:10:26 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:10:26 --> Total execution time: 0.0225
DEBUG - 2023-09-12 11:10:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:10:26 --> 404 Page Not Found: Assets/style3.css
DEBUG - 2023-09-12 11:10:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:10:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:10:26 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:10:26 --> Total execution time: 0.0230
DEBUG - 2023-09-12 11:10:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:10:26 --> 404 Page Not Found: Assets/style3.css
DEBUG - 2023-09-12 11:10:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:10:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:10:26 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:10:26 --> Total execution time: 0.0221
DEBUG - 2023-09-12 11:10:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:10:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:10:26 --> 404 Page Not Found: Assets/style3.css
DEBUG - 2023-09-12 11:14:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:14:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:14:13 --> Total execution time: 0.0231
DEBUG - 2023-09-12 11:14:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:14:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:14:13 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 11:14:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:14:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:14:13 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-12 11:14:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:14:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:14:57 --> Total execution time: 0.0229
DEBUG - 2023-09-12 11:14:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:14:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:14:57 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 11:14:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:14:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:14:57 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-12 11:18:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:18:44 --> Total execution time: 0.0246
DEBUG - 2023-09-12 11:18:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:18:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:18:44 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 11:18:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:18:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:18:44 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-12 11:20:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:20:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:20:05 --> Total execution time: 0.0227
DEBUG - 2023-09-12 11:20:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:20:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:20:05 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 11:20:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:20:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:20:05 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-12 11:20:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:20:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:20:41 --> Total execution time: 0.0439
DEBUG - 2023-09-12 11:20:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:20:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:20:41 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 11:20:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:20:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:20:41 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-12 11:25:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:25:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:25:55 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:25:55 --> Total execution time: 0.0244
DEBUG - 2023-09-12 11:25:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:25:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:25:57 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:25:57 --> Total execution time: 0.0257
DEBUG - 2023-09-12 11:25:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:25:58 --> No URI present. Default controller set.
DEBUG - 2023-09-12 11:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:25:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:25:58 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:25:58 --> Total execution time: 0.0222
DEBUG - 2023-09-12 11:25:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:25:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:25:58 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 11:25:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:25:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:25:58 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-12 11:25:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:25:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:25:58 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:25:58 --> Total execution time: 0.0231
DEBUG - 2023-09-12 11:25:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:25:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:25:59 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:25:59 --> Total execution time: 0.0229
DEBUG - 2023-09-12 11:27:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:27:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:27:47 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:27:47 --> Total execution time: 0.0225
DEBUG - 2023-09-12 11:27:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:27:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:27:47 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 11:27:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:27:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:27:47 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-12 11:27:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:27:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:27:50 --> initController - LoginPage.php
DEBUG - 2023-09-12 11:27:50 --> Total execution time: 0.0225
DEBUG - 2023-09-12 11:27:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:27:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:27:50 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 11:27:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 11:27:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 11:27:56 --> Total execution time: 0.0333
DEBUG - 2023-09-12 11:27:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 11:27:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 11:27:56 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 12:09:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 12:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 12:09:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 12:09:07 --> Total execution time: 0.0228
DEBUG - 2023-09-12 12:09:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 12:09:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 12:09:07 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 12:09:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 12:09:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 12:09:07 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-12 12:09:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 12:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 12:09:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 12:09:07 --> Total execution time: 0.0224
DEBUG - 2023-09-12 12:09:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 12:09:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 12:09:07 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 12:09:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 12:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 12:09:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 12:09:07 --> Total execution time: 0.0216
DEBUG - 2023-09-12 12:09:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 12:09:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 12:09:07 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 12:09:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 12:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 12:09:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 12:09:08 --> Total execution time: 0.0212
DEBUG - 2023-09-12 12:09:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 12:09:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 12:09:08 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 12:09:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 12:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 12:09:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 12:09:46 --> initController - LoginPage.php
DEBUG - 2023-09-12 12:09:46 --> Total execution time: 0.0234
DEBUG - 2023-09-12 12:09:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 12:09:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 12:09:57 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-12 12:10:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 12:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 12:10:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 12:10:10 --> initController - LoginPage.php
DEBUG - 2023-09-12 12:10:10 --> Total execution time: 0.0228
DEBUG - 2023-09-12 12:10:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 12:10:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 12:10:52 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-12 12:10:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 12:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 12:10:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 12:10:55 --> initController - LoginPage.php
DEBUG - 2023-09-12 12:10:55 --> Total execution time: 0.0459
DEBUG - 2023-09-12 12:22:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 12:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 12:22:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 12:22:41 --> Total execution time: 0.0228
DEBUG - 2023-09-12 12:22:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 12:22:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 12:22:41 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 12:22:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 12:22:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 12:22:41 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-12 12:33:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 12:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 12:33:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 12:33:49 --> Total execution time: 0.0229
DEBUG - 2023-09-12 12:33:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 12:33:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 12:33:49 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 12:33:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 12:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 12:33:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 12:33:50 --> initController - LoginPage.php
DEBUG - 2023-09-12 12:33:50 --> Total execution time: 0.0231
DEBUG - 2023-09-12 12:34:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 12:34:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 12:34:12 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-12 12:34:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 12:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 12:34:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 12:34:14 --> initController - LoginPage.php
DEBUG - 2023-09-12 12:34:14 --> Total execution time: 0.0227
DEBUG - 2023-09-12 12:34:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 12:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 12:34:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 12:34:53 --> initController - LoginPage.php
DEBUG - 2023-09-12 12:34:53 --> Total execution time: 0.0236
DEBUG - 2023-09-12 12:34:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 12:34:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 12:34:53 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 12:34:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 12:34:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 12:34:53 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-12 12:35:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 12:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 12:35:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 12:35:22 --> initController - LoginPage.php
DEBUG - 2023-09-12 12:35:22 --> Total execution time: 0.0443
DEBUG - 2023-09-12 12:35:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 12:35:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 12:35:22 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 12:36:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 12:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 12:36:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 12:36:19 --> initController - LoginPage.php
DEBUG - 2023-09-12 12:36:19 --> Total execution time: 0.0226
DEBUG - 2023-09-12 12:36:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 12:36:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 12:36:19 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 12:36:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 12:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 12:36:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 12:36:21 --> Total execution time: 0.0215
DEBUG - 2023-09-12 12:36:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 12:36:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 12:36:21 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 12:36:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 12:36:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 12:36:21 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-12 20:16:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 20:16:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 20:16:23 --> initController - LoginPage.php
DEBUG - 2023-09-12 20:16:23 --> Total execution time: 0.0675
DEBUG - 2023-09-12 20:38:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 20:38:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 20:38:28 --> initController - LoginPage.php
DEBUG - 2023-09-12 20:38:28 --> Total execution time: 0.0398
DEBUG - 2023-09-12 20:38:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:38:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:38:28 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 20:38:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 20:38:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 20:38:33 --> initController - LoginPage.php
DEBUG - 2023-09-12 20:38:33 --> Total execution time: 0.0321
DEBUG - 2023-09-12 20:38:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:38:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:38:33 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 20:39:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:39:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:39:58 --> 404 Page Not Found: Productcontroller/index
DEBUG - 2023-09-12 20:40:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:40:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:40:02 --> 404 Page Not Found: Productcontroller/index
DEBUG - 2023-09-12 20:40:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:40:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:40:19 --> 404 Page Not Found: Productcontroller/index
DEBUG - 2023-09-12 20:40:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:40:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:40:20 --> 404 Page Not Found: Productcontroller/index
DEBUG - 2023-09-12 20:40:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:40:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:40:20 --> 404 Page Not Found: Productcontroller/index
DEBUG - 2023-09-12 20:40:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:40:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:40:20 --> 404 Page Not Found: Productcontroller/index
DEBUG - 2023-09-12 20:40:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:40:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:40:20 --> 404 Page Not Found: Productcontroller/index
DEBUG - 2023-09-12 20:40:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:40:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:40:21 --> 404 Page Not Found: Productcontroller/index
DEBUG - 2023-09-12 20:40:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:40:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:40:21 --> 404 Page Not Found: Productcontroller/index
DEBUG - 2023-09-12 20:40:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:40:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:40:21 --> 404 Page Not Found: Productcontroller/index
DEBUG - 2023-09-12 20:40:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:40:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:40:21 --> 404 Page Not Found: Productcontroller/index
DEBUG - 2023-09-12 20:40:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:40:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:40:22 --> 404 Page Not Found: Productcontroller/index
DEBUG - 2023-09-12 20:41:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:41:13 --> No URI present. Default controller set.
DEBUG - 2023-09-12 20:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 20:41:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 20:41:13 --> initController - LoginPage.php
DEBUG - 2023-09-12 20:41:13 --> Total execution time: 0.0606
DEBUG - 2023-09-12 20:41:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:41:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:41:13 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 20:41:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:41:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:41:19 --> 404 Page Not Found: Productcontroller/index
DEBUG - 2023-09-12 20:42:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:42:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:42:58 --> 404 Page Not Found: Productcontroller/index
DEBUG - 2023-09-12 20:43:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:43:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:43:13 --> 404 Page Not Found: Productcontroller/index
DEBUG - 2023-09-12 20:43:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:43:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:43:15 --> 404 Page Not Found: Productcontroller/index
DEBUG - 2023-09-12 20:43:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:43:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:43:16 --> 404 Page Not Found: Productcontroller/index
DEBUG - 2023-09-12 20:43:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:43:17 --> No URI present. Default controller set.
DEBUG - 2023-09-12 20:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 20:43:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 20:43:17 --> initController - LoginPage.php
DEBUG - 2023-09-12 20:43:17 --> Total execution time: 0.0447
DEBUG - 2023-09-12 20:43:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:43:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:43:17 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 20:43:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 20:43:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 20:43:36 --> initController - LoginPage.php
DEBUG - 2023-09-12 20:43:36 --> Total execution time: 0.0431
DEBUG - 2023-09-12 20:43:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:43:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:43:36 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 20:55:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:55:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:55:00 --> 404 Page Not Found: Index1html/index
DEBUG - 2023-09-12 20:55:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:55:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:55:17 --> 404 Page Not Found: Index1html/index
DEBUG - 2023-09-12 20:55:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:55:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:55:18 --> 404 Page Not Found: Index1html/index
DEBUG - 2023-09-12 20:55:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:55:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:55:18 --> 404 Page Not Found: Index1html/index
DEBUG - 2023-09-12 20:55:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:55:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:55:18 --> 404 Page Not Found: Index1html/index
DEBUG - 2023-09-12 20:55:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:55:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:55:19 --> 404 Page Not Found: Index1html/index
DEBUG - 2023-09-12 20:55:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 20:55:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 20:55:20 --> initController - LoginPage.php
DEBUG - 2023-09-12 20:55:20 --> Total execution time: 0.0280
DEBUG - 2023-09-12 20:55:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 20:55:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 20:55:24 --> Total execution time: 0.0705
DEBUG - 2023-09-12 20:55:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:55:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:55:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:55:24 --> 404 Page Not Found: Img/men-1.jpg
DEBUG - 2023-09-12 20:55:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:55:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:55:24 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 20:55:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:55:24 --> 404 Page Not Found: Img/women-1.jpg
DEBUG - 2023-09-12 20:55:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:55:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:55:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:55:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:55:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 20:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 20:55:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:55:24 --> 404 Page Not Found: Img/men-3.jpg
ERROR - 2023-09-12 20:55:24 --> 404 Page Not Found: Img/watch-2.jpg
DEBUG - 2023-09-12 20:55:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:55:24 --> 404 Page Not Found: Img/women-2.jpg
DEBUG - 2023-09-12 20:55:24 --> UTF-8 Support Enabled
ERROR - 2023-09-12 20:55:24 --> 404 Page Not Found: Img/watch-1.jpg
DEBUG - 2023-09-12 20:55:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:55:24 --> 404 Page Not Found: Img/men-2.jpg
DEBUG - 2023-09-12 20:55:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:55:24 --> 404 Page Not Found: Img/women-3.jpg
DEBUG - 2023-09-12 20:55:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:55:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:55:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 20:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 20:55:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:55:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:55:24 --> 404 Page Not Found: Img/watch-3.jpg
DEBUG - 2023-09-12 20:55:24 --> UTF-8 Support Enabled
ERROR - 2023-09-12 20:55:24 --> 404 Page Not Found: Img/women-4.jpg
ERROR - 2023-09-12 20:55:24 --> 404 Page Not Found: Img/men-1.jpg
DEBUG - 2023-09-12 20:55:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:55:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:55:24 --> 404 Page Not Found: Img/watch-4.jpg
DEBUG - 2023-09-12 20:55:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:55:24 --> 404 Page Not Found: Img/men-4.jpg
DEBUG - 2023-09-12 20:55:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:55:24 --> 404 Page Not Found: Img/women-1.jpg
DEBUG - 2023-09-12 20:58:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 20:58:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 20:58:52 --> Total execution time: 0.0435
DEBUG - 2023-09-12 20:58:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:58:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:58:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 20:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 20:58:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:58:52 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
ERROR - 2023-09-12 20:58:52 --> 404 Page Not Found: Img/men-1.jpg
ERROR - 2023-09-12 20:58:52 --> 404 Page Not Found: Img/women-1.jpg
DEBUG - 2023-09-12 20:58:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:58:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 20:58:52 --> UTF-8 Support Enabled
ERROR - 2023-09-12 20:58:52 --> 404 Page Not Found: Img/women-2.jpg
DEBUG - 2023-09-12 20:58:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:58:52 --> 404 Page Not Found: Img/men-2.jpg
DEBUG - 2023-09-12 20:58:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 20:58:52 --> UTF-8 Support Enabled
ERROR - 2023-09-12 20:58:52 --> 404 Page Not Found: Img/watch-1.jpg
DEBUG - 2023-09-12 20:58:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:58:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:58:52 --> 404 Page Not Found: Img/watch-2.jpg
DEBUG - 2023-09-12 20:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 20:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 20:58:52 --> UTF-8 Support Enabled
ERROR - 2023-09-12 20:58:52 --> 404 Page Not Found: Img/men-3.jpg
DEBUG - 2023-09-12 20:58:52 --> UTF-8 Support Enabled
ERROR - 2023-09-12 20:58:52 --> 404 Page Not Found: Img/women-3.jpg
DEBUG - 2023-09-12 20:58:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:58:52 --> 404 Page Not Found: Img/watch-3.jpg
DEBUG - 2023-09-12 20:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 20:58:52 --> UTF-8 Support Enabled
ERROR - 2023-09-12 20:58:52 --> 404 Page Not Found: Img/men-4.jpg
DEBUG - 2023-09-12 20:58:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:58:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:58:52 --> 404 Page Not Found: Img/women-4.jpg
DEBUG - 2023-09-12 20:58:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:58:52 --> 404 Page Not Found: Img/watch-4.jpg
DEBUG - 2023-09-12 20:58:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:58:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:58:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:58:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 20:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 20:58:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:58:52 --> 404 Page Not Found: Img/men-2.jpg
ERROR - 2023-09-12 20:58:52 --> 404 Page Not Found: Img/men-1.jpg
DEBUG - 2023-09-12 20:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 20:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 20:58:52 --> UTF-8 Support Enabled
ERROR - 2023-09-12 20:58:52 --> 404 Page Not Found: Img/women-1.jpg
ERROR - 2023-09-12 20:58:52 --> 404 Page Not Found: Img/women-2.jpg
DEBUG - 2023-09-12 20:58:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 20:58:52 --> 404 Page Not Found: Img/watch-1.jpg
DEBUG - 2023-09-12 21:00:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 21:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 21:00:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 21:00:17 --> Total execution time: 0.0277
DEBUG - 2023-09-12 21:00:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 21:00:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 21:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 21:00:17 --> UTF-8 Support Enabled
ERROR - 2023-09-12 21:00:17 --> 404 Page Not Found: Img/women-1.jpg
DEBUG - 2023-09-12 21:00:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 21:00:17 --> 404 Page Not Found: Img/men-1.jpg
DEBUG - 2023-09-12 21:00:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 21:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 21:00:17 --> UTF-8 Support Enabled
ERROR - 2023-09-12 21:00:17 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 21:00:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 21:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 21:00:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 21:00:17 --> 404 Page Not Found: Img/women-2.jpg
DEBUG - 2023-09-12 21:00:17 --> UTF-8 Support Enabled
ERROR - 2023-09-12 21:00:17 --> 404 Page Not Found: Img/watch-1.jpg
DEBUG - 2023-09-12 21:00:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 21:00:17 --> 404 Page Not Found: Img/men-2.jpg
DEBUG - 2023-09-12 21:00:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 21:00:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 21:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 21:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 21:00:17 --> UTF-8 Support Enabled
ERROR - 2023-09-12 21:00:17 --> 404 Page Not Found: Img/watch-2.jpg
ERROR - 2023-09-12 21:00:17 --> 404 Page Not Found: Img/women-3.jpg
DEBUG - 2023-09-12 21:00:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 21:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 21:00:17 --> UTF-8 Support Enabled
ERROR - 2023-09-12 21:00:17 --> 404 Page Not Found: Img/watch-3.jpg
DEBUG - 2023-09-12 21:00:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 21:00:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 21:00:17 --> 404 Page Not Found: Img/men-3.jpg
DEBUG - 2023-09-12 21:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 21:00:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 21:00:17 --> 404 Page Not Found: Img/women-4.jpg
DEBUG - 2023-09-12 21:00:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 21:00:17 --> 404 Page Not Found: Img/watch-4.jpg
ERROR - 2023-09-12 21:00:17 --> 404 Page Not Found: Img/men-4.jpg
DEBUG - 2023-09-12 21:00:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 21:00:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 21:00:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 21:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 21:00:17 --> UTF-8 Support Enabled
ERROR - 2023-09-12 21:00:17 --> 404 Page Not Found: Img/men-1.jpg
DEBUG - 2023-09-12 21:00:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 21:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 21:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 21:00:17 --> UTF-8 Support Enabled
ERROR - 2023-09-12 21:00:17 --> 404 Page Not Found: Img/women-3.jpg
ERROR - 2023-09-12 21:00:17 --> 404 Page Not Found: Img/women-2.jpg
DEBUG - 2023-09-12 21:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 21:00:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 21:00:17 --> 404 Page Not Found: Img/watch-1.jpg
ERROR - 2023-09-12 21:00:17 --> 404 Page Not Found: Img/women-1.jpg
DEBUG - 2023-09-12 21:00:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 21:00:17 --> 404 Page Not Found: Img/watch-2.jpg
DEBUG - 2023-09-12 21:02:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 21:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 21:02:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 21:02:43 --> Total execution time: 0.0438
DEBUG - 2023-09-12 21:02:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 21:02:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 21:02:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 21:02:43 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 21:02:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 21:02:43 --> 404 Page Not Found: Img/women-1.jpg
DEBUG - 2023-09-12 21:02:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 21:02:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 21:02:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 21:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 21:02:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 21:02:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 21:02:43 --> 404 Page Not Found: Img/men-2.jpg
DEBUG - 2023-09-12 21:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 21:02:43 --> UTF-8 Support Enabled
ERROR - 2023-09-12 21:02:43 --> 404 Page Not Found: Img/women-2.jpg
ERROR - 2023-09-12 21:02:43 --> 404 Page Not Found: Img/watch-1.jpg
DEBUG - 2023-09-12 21:02:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 21:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 21:02:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 21:02:43 --> 404 Page Not Found: Img/men-4.jpg
ERROR - 2023-09-12 21:02:43 --> 404 Page Not Found: Img/men-1.jpg
DEBUG - 2023-09-12 21:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 21:02:43 --> UTF-8 Support Enabled
ERROR - 2023-09-12 21:02:43 --> 404 Page Not Found: Img/women-3.jpg
DEBUG - 2023-09-12 21:02:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 21:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 21:02:43 --> UTF-8 Support Enabled
ERROR - 2023-09-12 21:02:43 --> 404 Page Not Found: Img/women-4.jpg
DEBUG - 2023-09-12 21:02:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 21:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 21:02:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 21:02:43 --> 404 Page Not Found: Img/watch-2.jpg
ERROR - 2023-09-12 21:02:43 --> 404 Page Not Found: Img/watch-4.jpg
DEBUG - 2023-09-12 21:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 21:02:43 --> UTF-8 Support Enabled
ERROR - 2023-09-12 21:02:43 --> 404 Page Not Found: Img/watch-3.jpg
DEBUG - 2023-09-12 21:02:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 21:02:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 21:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 21:02:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 21:02:43 --> 404 Page Not Found: Img/women-1.jpg
ERROR - 2023-09-12 21:02:43 --> 404 Page Not Found: Img/women-2.jpg
DEBUG - 2023-09-12 21:02:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 21:02:43 --> 404 Page Not Found: Img/watch-1.jpg
DEBUG - 2023-09-12 21:04:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 21:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 21:04:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 21:04:59 --> Total execution time: 0.0445
DEBUG - 2023-09-12 21:04:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 21:04:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 21:04:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 21:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 21:04:59 --> UTF-8 Support Enabled
ERROR - 2023-09-12 21:04:59 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 21:04:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 21:04:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 21:04:59 --> 404 Page Not Found: Img/women-1.jpg
DEBUG - 2023-09-12 21:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 21:04:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 21:04:59 --> 404 Page Not Found: Img/men-2.jpg
ERROR - 2023-09-12 21:04:59 --> 404 Page Not Found: Img/women-3.jpg
DEBUG - 2023-09-12 21:04:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 21:04:59 --> 404 Page Not Found: Img/watch-3.jpg
DEBUG - 2023-09-12 21:05:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 21:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 21:05:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 21:05:50 --> Total execution time: 0.0316
DEBUG - 2023-09-12 21:05:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 21:05:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 21:05:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 21:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 21:05:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 21:05:50 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 21:05:50 --> UTF-8 Support Enabled
ERROR - 2023-09-12 21:05:50 --> 404 Page Not Found: Img/men-2.jpg
DEBUG - 2023-09-12 21:05:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 21:05:50 --> 404 Page Not Found: Img/women-3.jpg
DEBUG - 2023-09-12 21:05:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 21:05:50 --> 404 Page Not Found: Img/watch-3.jpg
DEBUG - 2023-09-12 21:06:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 21:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-12 21:06:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-12 21:06:13 --> Total execution time: 0.0426
DEBUG - 2023-09-12 21:06:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 21:06:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 21:06:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 21:06:13 --> 404 Page Not Found: Img/women-3.jpg
DEBUG - 2023-09-12 21:06:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 21:06:13 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-12 21:06:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-12 21:06:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-12 21:06:13 --> 404 Page Not Found: Img/watch-3.jpg
