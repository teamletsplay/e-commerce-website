<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-09-10 01:51:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 01:51:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 01:51:13 --> 404 Page Not Found: WebProject/index
DEBUG - 2023-09-10 01:51:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 01:51:25 --> No URI present. Default controller set.
DEBUG - 2023-09-10 01:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 01:51:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 01:51:25 --> initController - LoginPage.php
DEBUG - 2023-09-10 01:51:25 --> Total execution time: 0.0338
DEBUG - 2023-09-10 01:51:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 01:51:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 01:51:25 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 01:51:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 01:51:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 01:51:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 01:51:25 --> 404 Page Not Found: Js/script.js
DEBUG - 2023-09-10 01:51:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 01:51:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 01:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 01:51:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 01:51:25 --> UTF-8 Support Enabled
ERROR - 2023-09-10 01:51:25 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 01:51:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 01:51:25 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 01:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 01:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 01:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 01:51:25 --> UTF-8 Support Enabled
ERROR - 2023-09-10 01:51:25 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-10 01:51:25 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 01:51:25 --> 404 Page Not Found: Js/main.js
DEBUG - 2023-09-10 01:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 01:51:25 --> UTF-8 Support Enabled
ERROR - 2023-09-10 01:51:25 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-10 01:51:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 01:51:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 01:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 01:51:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 01:51:25 --> UTF-8 Support Enabled
ERROR - 2023-09-10 01:51:25 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-10 01:51:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 01:51:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 01:51:25 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-10 01:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 01:51:25 --> UTF-8 Support Enabled
ERROR - 2023-09-10 01:51:25 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-10 01:51:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 01:51:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 01:51:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 01:51:25 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-10 01:51:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 01:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 01:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 01:51:25 --> UTF-8 Support Enabled
ERROR - 2023-09-10 01:51:25 --> 404 Page Not Found: Assets/images
ERROR - 2023-09-10 01:51:25 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-10 01:51:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 01:51:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 01:51:25 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-10 01:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 01:51:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 01:51:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 01:51:25 --> 404 Page Not Found: Assets/images
ERROR - 2023-09-10 01:51:25 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-10 01:51:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 01:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 01:51:25 --> UTF-8 Support Enabled
ERROR - 2023-09-10 01:51:25 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-10 01:51:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 01:51:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 01:51:25 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-10 01:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 01:51:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 01:51:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 01:51:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 01:51:25 --> 404 Page Not Found: Assets/images
ERROR - 2023-09-10 01:51:25 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-10 01:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 01:51:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 01:51:25 --> 404 Page Not Found: Assets/images
ERROR - 2023-09-10 01:51:25 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-10 01:51:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 01:51:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 01:51:25 --> 404 Page Not Found: Js/main.js
DEBUG - 2023-09-10 01:51:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 01:51:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 01:51:25 --> 404 Page Not Found: Js/script.js
DEBUG - 2023-09-10 01:51:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 01:51:57 --> No URI present. Default controller set.
DEBUG - 2023-09-10 01:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 01:51:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 01:51:57 --> initController - LoginPage.php
DEBUG - 2023-09-10 01:51:57 --> Total execution time: 0.0245
DEBUG - 2023-09-10 02:06:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:06:47 --> No URI present. Default controller set.
DEBUG - 2023-09-10 02:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:06:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 02:06:47 --> initController - LoginPage.php
DEBUG - 2023-09-10 02:06:47 --> Total execution time: 0.0262
DEBUG - 2023-09-10 02:06:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:06:48 --> No URI present. Default controller set.
DEBUG - 2023-09-10 02:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:06:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 02:06:48 --> initController - LoginPage.php
DEBUG - 2023-09-10 02:06:48 --> Total execution time: 0.0255
DEBUG - 2023-09-10 02:06:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:06:48 --> No URI present. Default controller set.
DEBUG - 2023-09-10 02:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:06:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 02:06:48 --> initController - LoginPage.php
DEBUG - 2023-09-10 02:06:48 --> Total execution time: 0.0235
DEBUG - 2023-09-10 02:07:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:07:31 --> No URI present. Default controller set.
DEBUG - 2023-09-10 02:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:07:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 02:07:31 --> initController - LoginPage.php
DEBUG - 2023-09-10 02:07:31 --> Total execution time: 0.0527
DEBUG - 2023-09-10 02:07:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:07:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 02:07:33 --> initController - LoginPage.php
DEBUG - 2023-09-10 02:07:33 --> Total execution time: 0.0385
DEBUG - 2023-09-10 02:07:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:07:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:07:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:07:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:07:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:07:33 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:07:33 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:07:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:07:33 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:07:33 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:07:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:07:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:07:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:07:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:07:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:07:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:07:33 --> 404 Page Not Found: Js/script.js
DEBUG - 2023-09-10 02:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:07:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:07:33 --> 404 Page Not Found: Assets/images
ERROR - 2023-09-10 02:07:33 --> 404 Page Not Found: Js/main.js
ERROR - 2023-09-10 02:07:33 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-10 02:07:33 --> 404 Page Not Found: Img/logo.png
DEBUG - 2023-09-10 02:08:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:08:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 02:08:24 --> initController - LoginPage.php
DEBUG - 2023-09-10 02:08:24 --> Total execution time: 0.0390
DEBUG - 2023-09-10 02:08:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:08:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:08:24 --> 404 Page Not Found: Img/logo.png
DEBUG - 2023-09-10 02:08:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:08:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:08:47 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:08:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:08:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:08:47 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-10 02:10:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:10:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 02:10:12 --> initController - LoginPage.php
DEBUG - 2023-09-10 02:10:12 --> Total execution time: 0.0490
DEBUG - 2023-09-10 02:10:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:10:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:10:12 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:10:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:10:12 --> UTF-8 Support Enabled
ERROR - 2023-09-10 02:10:12 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:10:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:10:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:10:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:10:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:10:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:10:12 --> 404 Page Not Found: Js/main.js
DEBUG - 2023-09-10 02:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:10:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:10:12 --> 404 Page Not Found: Js/script.js
ERROR - 2023-09-10 02:10:12 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-10 02:10:12 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:10:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:10:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:10:12 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:10:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:10:12 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-10 02:10:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:10:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:10:12 --> 404 Page Not Found: Img/logo.png
DEBUG - 2023-09-10 02:10:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:10:14 --> No URI present. Default controller set.
DEBUG - 2023-09-10 02:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:10:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 02:10:14 --> initController - LoginPage.php
DEBUG - 2023-09-10 02:10:14 --> Total execution time: 0.0537
DEBUG - 2023-09-10 02:10:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:10:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 02:10:16 --> initController - LoginPage.php
DEBUG - 2023-09-10 02:10:16 --> Total execution time: 0.0404
DEBUG - 2023-09-10 02:10:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:10:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:10:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:10:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:10:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:10:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:10:16 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:10:16 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:10:16 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:10:16 --> UTF-8 Support Enabled
ERROR - 2023-09-10 02:10:16 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:10:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:10:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:10:16 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-10 02:10:16 --> 404 Page Not Found: Js/main.js
DEBUG - 2023-09-10 02:10:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:10:17 --> UTF-8 Support Enabled
ERROR - 2023-09-10 02:10:17 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-10 02:10:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:10:17 --> 404 Page Not Found: Img/logo.png
DEBUG - 2023-09-10 02:10:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:10:17 --> 404 Page Not Found: Js/script.js
DEBUG - 2023-09-10 02:11:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:11:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 02:11:21 --> initController - LoginPage.php
DEBUG - 2023-09-10 02:11:21 --> Total execution time: 0.0498
DEBUG - 2023-09-10 02:11:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:11:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:11:29 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-10 02:14:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 02:14:39 --> initController - LoginPage.php
DEBUG - 2023-09-10 02:14:39 --> Total execution time: 0.0476
DEBUG - 2023-09-10 02:14:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:39 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:14:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:40 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:40 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:40 --> 404 Page Not Found: Js/script.js
ERROR - 2023-09-10 02:14:40 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-10 02:14:40 --> 404 Page Not Found: Js/main.js
ERROR - 2023-09-10 02:14:40 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:14:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:40 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-10 02:14:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:40 --> 404 Page Not Found: Images/logo.png
DEBUG - 2023-09-10 02:14:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 02:14:40 --> initController - LoginPage.php
DEBUG - 2023-09-10 02:14:40 --> Total execution time: 0.0474
DEBUG - 2023-09-10 02:14:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:40 --> UTF-8 Support Enabled
ERROR - 2023-09-10 02:14:40 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:40 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-10 02:14:40 --> 404 Page Not Found: Js/main.js
ERROR - 2023-09-10 02:14:40 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:40 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:40 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:14:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:40 --> UTF-8 Support Enabled
ERROR - 2023-09-10 02:14:40 --> 404 Page Not Found: Js/script.js
DEBUG - 2023-09-10 02:14:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:40 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-10 02:14:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:40 --> 404 Page Not Found: Images/logo.png
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 02:14:41 --> initController - LoginPage.php
DEBUG - 2023-09-10 02:14:41 --> Total execution time: 0.0371
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:41 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:41 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:41 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:41 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-10 02:14:41 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:41 --> 404 Page Not Found: Js/main.js
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:41 --> 404 Page Not Found: Js/script.js
ERROR - 2023-09-10 02:14:41 --> 404 Page Not Found: Images/logo.png
ERROR - 2023-09-10 02:14:41 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 02:14:41 --> initController - LoginPage.php
DEBUG - 2023-09-10 02:14:41 --> Total execution time: 0.0416
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:41 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:41 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:41 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:41 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:41 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-10 02:14:41 --> 404 Page Not Found: Js/main.js
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:41 --> 404 Page Not Found: Js/script.js
ERROR - 2023-09-10 02:14:41 --> 404 Page Not Found: Assets/images
ERROR - 2023-09-10 02:14:41 --> 404 Page Not Found: Images/logo.png
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 02:14:41 --> initController - LoginPage.php
DEBUG - 2023-09-10 02:14:41 --> Total execution time: 0.0564
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:41 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:41 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:41 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:41 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:41 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-10 02:14:41 --> 404 Page Not Found: Js/main.js
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:41 --> 404 Page Not Found: Js/script.js
ERROR - 2023-09-10 02:14:41 --> 404 Page Not Found: Assets/images
ERROR - 2023-09-10 02:14:41 --> 404 Page Not Found: Images/logo.png
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 02:14:41 --> initController - LoginPage.php
DEBUG - 2023-09-10 02:14:41 --> Total execution time: 0.0534
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:41 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:41 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:41 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:41 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:41 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-10 02:14:41 --> 404 Page Not Found: Js/main.js
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:41 --> 404 Page Not Found: Js/script.js
ERROR - 2023-09-10 02:14:41 --> 404 Page Not Found: Images/logo.png
ERROR - 2023-09-10 02:14:41 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-10 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 02:14:41 --> initController - LoginPage.php
DEBUG - 2023-09-10 02:14:41 --> Total execution time: 0.0669
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:42 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:42 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:42 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:42 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:42 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-10 02:14:42 --> 404 Page Not Found: Js/main.js
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:42 --> 404 Page Not Found: Assets/images
ERROR - 2023-09-10 02:14:42 --> 404 Page Not Found: Js/script.js
ERROR - 2023-09-10 02:14:42 --> 404 Page Not Found: Images/logo.png
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 02:14:42 --> initController - LoginPage.php
DEBUG - 2023-09-10 02:14:42 --> Total execution time: 0.0496
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:42 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:42 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:42 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:42 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-10 02:14:42 --> 404 Page Not Found: Js/main.js
ERROR - 2023-09-10 02:14:42 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:42 --> 404 Page Not Found: Assets/images
ERROR - 2023-09-10 02:14:42 --> 404 Page Not Found: Js/script.js
ERROR - 2023-09-10 02:14:42 --> 404 Page Not Found: Images/logo.png
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 02:14:42 --> initController - LoginPage.php
DEBUG - 2023-09-10 02:14:42 --> Total execution time: 0.0387
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:42 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:42 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:42 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:42 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:42 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-10 02:14:42 --> 404 Page Not Found: Js/main.js
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:42 --> 404 Page Not Found: Js/script.js
ERROR - 2023-09-10 02:14:42 --> 404 Page Not Found: Assets/images
ERROR - 2023-09-10 02:14:42 --> 404 Page Not Found: Images/logo.png
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 02:14:42 --> initController - LoginPage.php
DEBUG - 2023-09-10 02:14:42 --> Total execution time: 0.0424
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:42 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:42 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:42 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:42 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:42 --> 404 Page Not Found: Js/main.js
ERROR - 2023-09-10 02:14:42 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:42 --> 404 Page Not Found: Js/script.js
ERROR - 2023-09-10 02:14:42 --> 404 Page Not Found: Assets/images
ERROR - 2023-09-10 02:14:42 --> 404 Page Not Found: Images/logo.png
DEBUG - 2023-09-10 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 02:14:42 --> initController - LoginPage.php
DEBUG - 2023-09-10 02:14:42 --> Total execution time: 0.0390
DEBUG - 2023-09-10 02:14:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:43 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:43 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:43 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:43 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:43 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-10 02:14:43 --> 404 Page Not Found: Js/main.js
DEBUG - 2023-09-10 02:14:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:43 --> 404 Page Not Found: Assets/images
ERROR - 2023-09-10 02:14:43 --> 404 Page Not Found: Js/script.js
ERROR - 2023-09-10 02:14:43 --> 404 Page Not Found: Images/logo.png
DEBUG - 2023-09-10 02:14:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 02:14:43 --> initController - LoginPage.php
DEBUG - 2023-09-10 02:14:43 --> Total execution time: 0.0418
DEBUG - 2023-09-10 02:14:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:43 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:14:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:43 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:43 --> UTF-8 Support Enabled
ERROR - 2023-09-10 02:14:43 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:43 --> 404 Page Not Found: Js/main.js
DEBUG - 2023-09-10 02:14:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:43 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:14:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:43 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-10 02:14:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:43 --> 404 Page Not Found: Js/script.js
ERROR - 2023-09-10 02:14:43 --> 404 Page Not Found: Assets/images
ERROR - 2023-09-10 02:14:43 --> 404 Page Not Found: Images/logo.png
DEBUG - 2023-09-10 02:14:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 02:14:43 --> initController - LoginPage.php
DEBUG - 2023-09-10 02:14:43 --> Total execution time: 0.0387
DEBUG - 2023-09-10 02:14:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:43 --> 404 Page Not Found: Js/main.js
DEBUG - 2023-09-10 02:14:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:43 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:43 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-10 02:14:43 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:14:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:43 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:14:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:43 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:14:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:43 --> 404 Page Not Found: Js/script.js
DEBUG - 2023-09-10 02:14:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:43 --> 404 Page Not Found: Images/logo.png
ERROR - 2023-09-10 02:14:43 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 02:14:44 --> initController - LoginPage.php
DEBUG - 2023-09-10 02:14:44 --> Total execution time: 0.0407
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Js/main.js
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Js/script.js
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Assets/images
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Images/logo.png
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 02:14:44 --> initController - LoginPage.php
DEBUG - 2023-09-10 02:14:44 --> Total execution time: 0.0410
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Js/main.js
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Images/logo.png
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Js/script.js
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 02:14:44 --> initController - LoginPage.php
DEBUG - 2023-09-10 02:14:44 --> Total execution time: 0.0377
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Js/main.js
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Js/script.js
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Images/logo.png
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 02:14:44 --> initController - LoginPage.php
DEBUG - 2023-09-10 02:14:44 --> Total execution time: 0.0556
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Js/main.js
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Js/script.js
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Images/logo.png
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 02:14:44 --> initController - LoginPage.php
DEBUG - 2023-09-10 02:14:44 --> Total execution time: 0.0512
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Js/script.js
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Js/main.js
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Assets/images
ERROR - 2023-09-10 02:14:44 --> 404 Page Not Found: Images/logo.png
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 02:14:45 --> initController - LoginPage.php
DEBUG - 2023-09-10 02:14:45 --> Total execution time: 0.0409
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:45 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:45 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:45 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-10 02:14:45 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:45 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:45 --> 404 Page Not Found: Js/main.js
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:45 --> 404 Page Not Found: Js/script.js
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:45 --> 404 Page Not Found: Assets/images
ERROR - 2023-09-10 02:14:45 --> 404 Page Not Found: Images/logo.png
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 02:14:45 --> initController - LoginPage.php
DEBUG - 2023-09-10 02:14:45 --> Total execution time: 0.0609
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:45 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:45 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:45 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:45 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:45 --> 404 Page Not Found: Js/main.js
ERROR - 2023-09-10 02:14:45 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:45 --> 404 Page Not Found: Images/logo.png
ERROR - 2023-09-10 02:14:45 --> 404 Page Not Found: Js/script.js
ERROR - 2023-09-10 02:14:45 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 02:14:45 --> initController - LoginPage.php
DEBUG - 2023-09-10 02:14:45 --> Total execution time: 0.0432
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:45 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:45 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:45 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:45 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:45 --> 404 Page Not Found: Js/main.js
ERROR - 2023-09-10 02:14:45 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:45 --> 404 Page Not Found: Assets/images
ERROR - 2023-09-10 02:14:45 --> 404 Page Not Found: Js/script.js
ERROR - 2023-09-10 02:14:45 --> 404 Page Not Found: Images/logo.png
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 02:14:45 --> initController - LoginPage.php
DEBUG - 2023-09-10 02:14:45 --> Total execution time: 0.0384
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:45 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:45 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:14:45 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:45 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-10 02:14:45 --> 404 Page Not Found: Js/main.js
ERROR - 2023-09-10 02:14:45 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:45 --> 404 Page Not Found: Js/script.js
DEBUG - 2023-09-10 02:14:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:14:45 --> 404 Page Not Found: Images/logo.png
ERROR - 2023-09-10 02:14:45 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-10 02:14:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:14:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 02:14:55 --> initController - LoginPage.php
DEBUG - 2023-09-10 02:14:55 --> Total execution time: 0.0339
DEBUG - 2023-09-10 02:18:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:18:58 --> No URI present. Default controller set.
DEBUG - 2023-09-10 02:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:18:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 02:18:58 --> initController - LoginPage.php
DEBUG - 2023-09-10 02:18:58 --> Total execution time: 0.0661
DEBUG - 2023-09-10 02:19:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:19:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 02:19:06 --> initController - LoginPage.php
DEBUG - 2023-09-10 02:19:06 --> Total execution time: 0.0408
DEBUG - 2023-09-10 02:19:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:19:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:19:06 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:19:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:19:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:19:06 --> UTF-8 Support Enabled
ERROR - 2023-09-10 02:19:06 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:19:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:19:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:19:06 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:19:06 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:19:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:19:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:19:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:19:06 --> 404 Page Not Found: Js/script.js
DEBUG - 2023-09-10 02:19:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:19:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:19:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:19:06 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-10 02:19:06 --> 404 Page Not Found: Js/main.js
DEBUG - 2023-09-10 02:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:19:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:19:06 --> 404 Page Not Found: Assets/images
ERROR - 2023-09-10 02:19:06 --> 404 Page Not Found: Images/logo.png
DEBUG - 2023-09-10 02:38:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:38:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 02:38:17 --> initController - LoginPage.php
DEBUG - 2023-09-10 02:38:17 --> Total execution time: 0.0648
DEBUG - 2023-09-10 02:38:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:38:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:38:17 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:38:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:38:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:38:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:38:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:38:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:38:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:38:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:38:17 --> 404 Page Not Found: Js/script.js
ERROR - 2023-09-10 02:38:17 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:38:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:38:17 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-10 02:38:17 --> 404 Page Not Found: Js/main.js
ERROR - 2023-09-10 02:38:17 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:38:17 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:38:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:38:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:38:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:38:17 --> 404 Page Not Found: Images/logo.png
ERROR - 2023-09-10 02:38:17 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-10 02:38:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:38:18 --> No URI present. Default controller set.
DEBUG - 2023-09-10 02:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:38:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 02:38:18 --> initController - LoginPage.php
DEBUG - 2023-09-10 02:38:18 --> Total execution time: 0.0402
DEBUG - 2023-09-10 02:38:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:38:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 02:38:21 --> initController - LoginPage.php
DEBUG - 2023-09-10 02:38:21 --> Total execution time: 0.0463
DEBUG - 2023-09-10 02:38:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:38:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:38:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:38:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:38:21 --> UTF-8 Support Enabled
ERROR - 2023-09-10 02:38:21 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:38:21 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 02:38:21 --> 404 Page Not Found: Js/main.js
ERROR - 2023-09-10 02:38:21 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:38:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:38:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:38:21 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 02:38:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:38:21 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-10 02:38:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:38:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:38:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 02:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 02:38:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:38:21 --> 404 Page Not Found: Assets/images
ERROR - 2023-09-10 02:38:21 --> 404 Page Not Found: Js/script.js
DEBUG - 2023-09-10 02:38:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 02:38:21 --> 404 Page Not Found: Images/logo.png
DEBUG - 2023-09-10 05:31:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 05:31:09 --> No URI present. Default controller set.
DEBUG - 2023-09-10 05:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 05:31:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 05:31:10 --> initController - LoginPage.php
DEBUG - 2023-09-10 05:31:10 --> Total execution time: 0.0280
DEBUG - 2023-09-10 05:59:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 05:59:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 05:59:47 --> 404 Page Not Found: Carthtml/index
DEBUG - 2023-09-10 05:59:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 05:59:52 --> No URI present. Default controller set.
DEBUG - 2023-09-10 05:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 05:59:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 05:59:52 --> initController - LoginPage.php
DEBUG - 2023-09-10 05:59:52 --> Total execution time: 0.0546
DEBUG - 2023-09-10 05:59:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 05:59:53 --> No URI present. Default controller set.
DEBUG - 2023-09-10 05:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 05:59:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 05:59:53 --> initController - LoginPage.php
DEBUG - 2023-09-10 05:59:53 --> Total execution time: 0.0494
DEBUG - 2023-09-10 05:59:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 05:59:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 05:59:58 --> 404 Page Not Found: Carthtml/index
DEBUG - 2023-09-10 06:00:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:00:40 --> No URI present. Default controller set.
DEBUG - 2023-09-10 06:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:00:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 06:00:40 --> initController - LoginPage.php
DEBUG - 2023-09-10 06:00:40 --> Total execution time: 0.0581
DEBUG - 2023-09-10 06:00:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:00:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 06:00:43 --> initController - LoginPage.php
DEBUG - 2023-09-10 06:00:43 --> Total execution time: 0.0771
DEBUG - 2023-09-10 06:00:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:00:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:00:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:00:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:00:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:00:43 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-10 06:00:43 --> UTF-8 Support Enabled
ERROR - 2023-09-10 06:00:43 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 06:00:43 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 06:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:00:43 --> UTF-8 Support Enabled
ERROR - 2023-09-10 06:00:43 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 06:00:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:00:43 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 06:00:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:00:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:00:43 --> UTF-8 Support Enabled
ERROR - 2023-09-10 06:00:43 --> 404 Page Not Found: Js/main.js
DEBUG - 2023-09-10 06:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:00:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:00:43 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-10 06:00:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:00:43 --> 404 Page Not Found: Js/script.js
ERROR - 2023-09-10 06:00:43 --> 404 Page Not Found: Images/logo.png
DEBUG - 2023-09-10 06:00:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:00:45 --> No URI present. Default controller set.
DEBUG - 2023-09-10 06:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:00:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 06:00:45 --> initController - LoginPage.php
DEBUG - 2023-09-10 06:00:45 --> Total execution time: 0.0544
DEBUG - 2023-09-10 06:00:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:00:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:00:47 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-10 06:01:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:01:03 --> No URI present. Default controller set.
DEBUG - 2023-09-10 06:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:01:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 06:01:03 --> initController - LoginPage.php
DEBUG - 2023-09-10 06:01:03 --> Total execution time: 0.0526
DEBUG - 2023-09-10 06:01:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:01:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:01:26 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-10 06:08:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:08:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:08:08 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-10 06:08:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:08:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:08:09 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-10 06:08:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:08:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:08:09 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-10 06:08:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:08:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:08:10 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-10 06:08:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:08:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:08:10 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-10 06:08:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:08:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:08:10 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-10 06:08:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:08:11 --> No URI present. Default controller set.
DEBUG - 2023-09-10 06:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:08:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 06:08:11 --> initController - LoginPage.php
DEBUG - 2023-09-10 06:08:11 --> Total execution time: 0.0646
DEBUG - 2023-09-10 06:08:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:08:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 06:08:16 --> initController - LoginPage.php
DEBUG - 2023-09-10 06:08:16 --> Total execution time: 0.0524
DEBUG - 2023-09-10 06:08:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:08:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:08:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:08:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:08:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:08:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:08:16 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 06:08:16 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 06:08:16 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 06:08:16 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 06:08:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:08:16 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-10 06:08:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:08:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:08:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:08:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:08:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:08:16 --> 404 Page Not Found: Images/logo.png
ERROR - 2023-09-10 06:08:16 --> 404 Page Not Found: Assets/images
ERROR - 2023-09-10 06:08:16 --> 404 Page Not Found: Js/script.js
ERROR - 2023-09-10 06:08:16 --> 404 Page Not Found: Js/main.js
DEBUG - 2023-09-10 06:08:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:08:18 --> No URI present. Default controller set.
DEBUG - 2023-09-10 06:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:08:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 06:08:18 --> initController - LoginPage.php
DEBUG - 2023-09-10 06:08:18 --> Total execution time: 0.0549
DEBUG - 2023-09-10 06:08:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:08:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:08:20 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-10 06:08:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:08:26 --> No URI present. Default controller set.
DEBUG - 2023-09-10 06:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:08:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 06:08:26 --> initController - LoginPage.php
DEBUG - 2023-09-10 06:08:26 --> Total execution time: 0.0648
DEBUG - 2023-09-10 06:08:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:08:27 --> No URI present. Default controller set.
DEBUG - 2023-09-10 06:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:08:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 06:08:27 --> initController - LoginPage.php
DEBUG - 2023-09-10 06:08:27 --> Total execution time: 0.0534
DEBUG - 2023-09-10 06:08:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:08:27 --> No URI present. Default controller set.
DEBUG - 2023-09-10 06:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:08:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 06:08:27 --> initController - LoginPage.php
DEBUG - 2023-09-10 06:08:27 --> Total execution time: 0.0571
DEBUG - 2023-09-10 06:08:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:08:28 --> No URI present. Default controller set.
DEBUG - 2023-09-10 06:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:08:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 06:08:28 --> initController - LoginPage.php
DEBUG - 2023-09-10 06:08:28 --> Total execution time: 0.0579
DEBUG - 2023-09-10 06:08:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:08:28 --> No URI present. Default controller set.
DEBUG - 2023-09-10 06:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:08:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 06:08:28 --> initController - LoginPage.php
DEBUG - 2023-09-10 06:08:28 --> Total execution time: 0.0596
DEBUG - 2023-09-10 06:08:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:08:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:08:32 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-10 06:08:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:08:47 --> No URI present. Default controller set.
DEBUG - 2023-09-10 06:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:08:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 06:08:47 --> initController - LoginPage.php
DEBUG - 2023-09-10 06:08:47 --> Total execution time: 0.0544
DEBUG - 2023-09-10 06:08:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:08:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 06:08:51 --> initController - LoginPage.php
DEBUG - 2023-09-10 06:08:51 --> Total execution time: 0.0788
DEBUG - 2023-09-10 06:08:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:08:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:08:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:08:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:08:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:08:51 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 06:08:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:08:51 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 06:08:51 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 06:08:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:08:51 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 06:08:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:08:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:08:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:08:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:08:51 --> UTF-8 Support Enabled
ERROR - 2023-09-10 06:08:51 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-10 06:08:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:08:51 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-10 06:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:08:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:08:51 --> 404 Page Not Found: Images/logo.png
ERROR - 2023-09-10 06:08:51 --> 404 Page Not Found: Js/script.js
ERROR - 2023-09-10 06:08:51 --> 404 Page Not Found: Js/main.js
DEBUG - 2023-09-10 06:08:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:08:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:08:55 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-10 06:09:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:09:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 06:09:02 --> initController - LoginPage.php
DEBUG - 2023-09-10 06:09:02 --> Total execution time: 0.0622
DEBUG - 2023-09-10 06:09:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:09:02 --> UTF-8 Support Enabled
ERROR - 2023-09-10 06:09:02 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 06:09:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:09:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:09:02 --> UTF-8 Support Enabled
ERROR - 2023-09-10 06:09:02 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 06:09:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:09:02 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-10 06:09:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:09:02 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 06:09:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:09:02 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 06:09:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:09:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:09:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:09:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:09:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:09:02 --> 404 Page Not Found: Js/main.js
ERROR - 2023-09-10 06:09:02 --> 404 Page Not Found: Js/script.js
DEBUG - 2023-09-10 06:09:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:09:02 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-10 06:09:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:09:02 --> 404 Page Not Found: Images/logo.png
DEBUG - 2023-09-10 06:09:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:09:02 --> No URI present. Default controller set.
DEBUG - 2023-09-10 06:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:09:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 06:09:02 --> initController - LoginPage.php
DEBUG - 2023-09-10 06:09:02 --> Total execution time: 0.0540
DEBUG - 2023-09-10 06:09:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:09:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 06:09:17 --> initController - LoginPage.php
DEBUG - 2023-09-10 06:09:17 --> Total execution time: 0.0509
DEBUG - 2023-09-10 06:09:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:09:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:09:17 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 06:09:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:09:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:09:17 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 06:09:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:09:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:09:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:09:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:09:17 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 06:09:17 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-10 06:09:17 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 06:09:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:09:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:09:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:09:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:09:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:09:17 --> 404 Page Not Found: Js/script.js
ERROR - 2023-09-10 06:09:17 --> 404 Page Not Found: Assets/images
ERROR - 2023-09-10 06:09:17 --> 404 Page Not Found: Js/main.js
ERROR - 2023-09-10 06:09:17 --> 404 Page Not Found: Images/logo.png
DEBUG - 2023-09-10 06:09:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:09:20 --> No URI present. Default controller set.
DEBUG - 2023-09-10 06:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:09:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 06:09:20 --> initController - LoginPage.php
DEBUG - 2023-09-10 06:09:20 --> Total execution time: 0.0512
DEBUG - 2023-09-10 06:09:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:09:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:09:23 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-10 06:11:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:11:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:11:33 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-10 06:11:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:11:35 --> No URI present. Default controller set.
DEBUG - 2023-09-10 06:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:11:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 06:11:35 --> initController - LoginPage.php
DEBUG - 2023-09-10 06:11:35 --> Total execution time: 0.0627
DEBUG - 2023-09-10 06:11:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:11:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 06:11:37 --> initController - LoginPage.php
DEBUG - 2023-09-10 06:11:37 --> Total execution time: 0.0484
DEBUG - 2023-09-10 06:11:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:11:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:11:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:11:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:11:37 --> UTF-8 Support Enabled
ERROR - 2023-09-10 06:11:37 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 06:11:37 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 06:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:11:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:11:37 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 06:11:37 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 06:11:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:11:37 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-10 06:11:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:11:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:11:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:11:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:11:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:11:37 --> 404 Page Not Found: Js/main.js
ERROR - 2023-09-10 06:11:37 --> 404 Page Not Found: Js/script.js
ERROR - 2023-09-10 06:11:37 --> 404 Page Not Found: Images/logo.png
ERROR - 2023-09-10 06:11:37 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-10 06:11:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:11:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:11:42 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-10 06:12:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:12:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-10 06:12:11 --> initController - LoginPage.php
DEBUG - 2023-09-10 06:12:11 --> Total execution time: 0.0615
DEBUG - 2023-09-10 06:12:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:12:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:12:11 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 06:12:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:12:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:12:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:12:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:12:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:12:11 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-10 06:12:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:12:11 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-10 06:12:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:12:11 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 06:12:11 --> 404 Page Not Found: Js/script.js
DEBUG - 2023-09-10 06:12:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:12:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:12:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:12:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:12:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:12:11 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-10 06:12:11 --> 404 Page Not Found: Js/main.js
DEBUG - 2023-09-10 06:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-10 06:12:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:12:11 --> 404 Page Not Found: Assets/images
ERROR - 2023-09-10 06:12:11 --> 404 Page Not Found: Images/logo.png
DEBUG - 2023-09-10 06:12:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-10 06:12:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-10 06:12:18 --> 404 Page Not Found: Pay/index
