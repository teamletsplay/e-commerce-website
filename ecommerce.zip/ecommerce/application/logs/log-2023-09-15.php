<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-09-15 09:26:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 09:26:02 --> No URI present. Default controller set.
DEBUG - 2023-09-15 09:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-15 09:26:02 --> initController - LoginPage.php
DEBUG - 2023-09-15 09:26:02 --> Total execution time: 0.0733
DEBUG - 2023-09-15 09:26:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 09:26:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-15 09:26:02 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-15 09:26:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 09:26:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-15 09:26:30 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-15 09:26:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 09:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-15 09:26:43 --> Total execution time: 0.0393
DEBUG - 2023-09-15 09:26:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 09:26:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-15 09:26:43 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-15 09:26:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 09:26:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 09:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-15 09:26:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-15 09:26:43 --> 404 Page Not Found: Img/watch-3.jpg
ERROR - 2023-09-15 09:26:43 --> 404 Page Not Found: Img/women-3.jpg
DEBUG - 2023-09-15 09:28:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 09:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-15 09:28:11 --> initController - LoginPage.php
DEBUG - 2023-09-15 09:28:11 --> Total execution time: 0.0484
DEBUG - 2023-09-15 09:28:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 09:28:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-15 09:28:11 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-15 09:42:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 09:42:08 --> No URI present. Default controller set.
DEBUG - 2023-09-15 09:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-15 09:42:08 --> initController - LoginPage.php
DEBUG - 2023-09-15 09:42:08 --> Total execution time: 0.0337
DEBUG - 2023-09-15 09:42:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 09:42:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-15 09:42:08 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-15 09:42:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 09:42:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-15 09:42:37 --> Severity: error --> Exception: syntax error, unexpected token "{", expecting "(" C:\xampp\htdocs\WebProject\application\controllers\login.php 15
DEBUG - 2023-09-15 09:45:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 09:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-15 09:45:49 --> initController - LoginPage.php
DEBUG - 2023-09-15 09:45:49 --> Total execution time: 0.0450
DEBUG - 2023-09-15 09:45:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 09:45:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-15 09:45:50 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-15 09:45:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 09:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-15 09:45:53 --> initController - LoginPage.php
DEBUG - 2023-09-15 09:45:53 --> Total execution time: 0.0326
DEBUG - 2023-09-15 09:45:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 09:45:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-15 09:45:53 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-15 09:45:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 09:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-15 09:45:58 --> Total execution time: 0.0298
DEBUG - 2023-09-15 09:45:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 09:45:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-15 09:45:58 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-15 09:45:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 09:45:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-15 09:45:58 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-15 09:46:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 09:46:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-15 09:46:04 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-15 10:09:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 10:09:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-15 10:09:12 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-15 10:38:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 10:38:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-15 10:38:19 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-15 10:38:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 10:38:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-15 10:38:22 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-15 10:38:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 10:38:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-15 10:38:22 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-15 10:38:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 10:38:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-15 10:38:23 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-15 10:38:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 10:38:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-15 10:38:23 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-15 10:38:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 10:38:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-15 10:38:23 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-15 10:38:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 10:38:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-15 10:38:31 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-15 10:38:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 10:38:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-15 10:38:31 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-15 10:38:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 10:38:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-15 10:38:32 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-15 10:38:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 10:38:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-15 10:38:32 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-15 21:44:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 21:44:32 --> No URI present. Default controller set.
DEBUG - 2023-09-15 21:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-15 21:44:32 --> initController - LoginPage.php
DEBUG - 2023-09-15 21:44:32 --> Total execution time: 0.0342
DEBUG - 2023-09-15 21:44:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 21:44:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-15 21:44:32 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-15 21:44:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 21:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-15 21:44:36 --> initController - LoginPage.php
DEBUG - 2023-09-15 21:44:36 --> Total execution time: 0.0202
DEBUG - 2023-09-15 21:44:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 21:44:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-15 21:44:36 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-15 21:44:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 21:44:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-15 21:44:40 --> Severity: Warning --> include(./templates/sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\admin_view.php 3
ERROR - 2023-09-15 21:44:40 --> Severity: Warning --> include(): Failed opening './templates/sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\admin_view.php 3
DEBUG - 2023-09-15 21:44:40 --> Total execution time: 0.0187
DEBUG - 2023-09-15 21:44:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 21:44:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-15 21:44:40 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-15 21:45:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 21:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-15 21:45:57 --> Total execution time: 0.0163
DEBUG - 2023-09-15 21:45:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 21:45:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-15 21:45:57 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-15 21:50:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 21:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-15 21:50:37 --> Total execution time: 0.0165
DEBUG - 2023-09-15 21:50:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 21:50:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-15 21:50:37 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-15 22:00:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 22:00:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-15 22:00:55 --> Severity: Compile Error --> Cannot declare class Admin, because the name is already in use C:\xampp\htdocs\WebProject\application\views\admin_view.php 6
DEBUG - 2023-09-15 22:00:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 22:00:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-15 22:00:55 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-15 22:01:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 22:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-15 22:01:36 --> Total execution time: 0.0169
DEBUG - 2023-09-15 22:01:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 22:01:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-15 22:01:36 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-15 22:01:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 22:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-15 22:01:38 --> Total execution time: 0.0165
DEBUG - 2023-09-15 22:01:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 22:01:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-15 22:01:38 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-15 22:01:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 22:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-15 22:01:38 --> Total execution time: 0.0162
DEBUG - 2023-09-15 22:01:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 22:01:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-15 22:01:38 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-15 22:01:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 22:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-15 22:01:39 --> Total execution time: 0.0165
DEBUG - 2023-09-15 22:01:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 22:01:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-15 22:01:39 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-15 22:01:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 22:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-15 22:01:39 --> Total execution time: 0.0164
DEBUG - 2023-09-15 22:01:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 22:01:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-15 22:01:39 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-15 22:01:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 22:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-15 22:01:39 --> Total execution time: 0.0167
DEBUG - 2023-09-15 22:01:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 22:01:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-15 22:01:39 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-15 22:01:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 22:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-15 22:01:39 --> Total execution time: 0.0157
DEBUG - 2023-09-15 22:01:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-15 22:01:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-15 22:01:39 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
