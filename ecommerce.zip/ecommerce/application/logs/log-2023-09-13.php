<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-09-13 09:49:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 09:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-13 09:49:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-13 09:49:27 --> initController - LoginPage.php
DEBUG - 2023-09-13 09:49:27 --> Total execution time: 0.0450
DEBUG - 2023-09-13 09:49:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 09:49:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-13 09:49:27 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-13 10:38:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 10:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-13 10:38:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-13 10:38:06 --> Total execution time: 0.0343
DEBUG - 2023-09-13 10:38:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 10:38:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-13 10:38:06 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-13 10:38:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 10:38:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 10:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-13 10:38:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-13 10:38:06 --> 404 Page Not Found: Img/women-3.jpg
ERROR - 2023-09-13 10:38:06 --> 404 Page Not Found: Img/watch-3.jpg
DEBUG - 2023-09-13 10:38:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 10:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-13 10:38:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-13 10:38:25 --> initController - LoginPage.php
DEBUG - 2023-09-13 10:38:25 --> Total execution time: 0.0252
DEBUG - 2023-09-13 10:38:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 10:38:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-13 10:38:25 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-13 10:38:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 10:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-13 10:38:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-13 10:38:27 --> Total execution time: 0.0212
DEBUG - 2023-09-13 10:38:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 10:38:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-13 10:38:27 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-13 10:38:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 10:38:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-13 10:38:27 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-13 10:41:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 10:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-13 10:41:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-13 10:41:06 --> initController - LoginPage.php
DEBUG - 2023-09-13 10:41:06 --> Total execution time: 0.0237
DEBUG - 2023-09-13 10:41:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 10:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-13 10:41:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-13 10:41:11 --> initController - LoginPage.php
DEBUG - 2023-09-13 10:41:11 --> Total execution time: 0.0214
DEBUG - 2023-09-13 10:41:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 10:41:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-13 10:41:11 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-13 11:27:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-13 11:27:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-13 11:27:50 --> Total execution time: 0.0239
DEBUG - 2023-09-13 11:27:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:27:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-13 11:27:50 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-13 11:27:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:27:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-13 11:27:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-13 11:27:50 --> 404 Page Not Found: Img/watch-3.jpg
ERROR - 2023-09-13 11:27:50 --> 404 Page Not Found: Img/women-3.jpg
DEBUG - 2023-09-13 11:28:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-13 11:28:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-13 11:28:01 --> initController - LoginPage.php
DEBUG - 2023-09-13 11:28:01 --> Total execution time: 0.0235
DEBUG - 2023-09-13 11:28:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:28:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-13 11:28:01 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-13 11:28:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-13 11:28:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-13 11:28:03 --> Total execution time: 0.0213
DEBUG - 2023-09-13 11:28:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:28:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-13 11:28:03 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-13 11:28:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:28:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-13 11:28:03 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-13 11:28:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-13 11:28:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-13 11:28:05 --> initController - LoginPage.php
DEBUG - 2023-09-13 11:28:05 --> Total execution time: 0.0226
DEBUG - 2023-09-13 11:28:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-13 11:28:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-13 11:28:08 --> Total execution time: 0.0437
DEBUG - 2023-09-13 11:28:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:28:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-13 11:28:08 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-13 11:28:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:28:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-13 11:28:08 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-13 11:28:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-13 11:28:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-13 11:28:12 --> initController - LoginPage.php
DEBUG - 2023-09-13 11:28:12 --> Total execution time: 0.0477
DEBUG - 2023-09-13 11:28:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-13 11:28:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-13 11:28:25 --> initController - LoginPage.php
DEBUG - 2023-09-13 11:28:25 --> Total execution time: 0.0225
DEBUG - 2023-09-13 11:28:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:28:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-13 11:28:25 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-13 11:32:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-13 11:32:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-13 11:32:34 --> initController - LoginPage.php
DEBUG - 2023-09-13 11:32:34 --> Total execution time: 0.0234
DEBUG - 2023-09-13 11:32:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-13 11:32:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-13 11:32:44 --> Total execution time: 0.0211
DEBUG - 2023-09-13 11:32:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:32:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-13 11:32:44 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-13 11:32:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:32:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-13 11:32:44 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-13 11:32:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-13 11:32:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-13 11:32:48 --> initController - LoginPage.php
DEBUG - 2023-09-13 11:32:48 --> Total execution time: 0.0456
DEBUG - 2023-09-13 11:32:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-13 11:32:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-13 11:32:58 --> initController - LoginPage.php
DEBUG - 2023-09-13 11:32:58 --> Total execution time: 0.0234
DEBUG - 2023-09-13 11:32:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:32:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-13 11:32:58 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-13 11:38:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:38:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-13 11:38:04 --> 404 Page Not Found: Payment/index
DEBUG - 2023-09-13 11:38:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-13 11:38:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-13 11:38:07 --> initController - LoginPage.php
DEBUG - 2023-09-13 11:38:07 --> Total execution time: 0.0239
DEBUG - 2023-09-13 11:38:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-13 11:38:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-13 11:38:19 --> initController - LoginPage.php
DEBUG - 2023-09-13 11:38:19 --> Total execution time: 0.0222
DEBUG - 2023-09-13 11:38:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:38:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-13 11:38:19 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-13 11:38:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-13 11:38:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-13 11:38:57 --> initController - LoginPage.php
DEBUG - 2023-09-13 11:38:57 --> Total execution time: 0.0225
DEBUG - 2023-09-13 11:59:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-13 11:59:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-13 11:59:37 --> initController - LoginPage.php
DEBUG - 2023-09-13 11:59:37 --> Total execution time: 0.0254
DEBUG - 2023-09-13 11:59:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:59:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-13 11:59:37 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-13 11:59:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-13 11:59:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-13 11:59:46 --> initController - LoginPage.php
DEBUG - 2023-09-13 11:59:46 --> Total execution time: 0.0225
DEBUG - 2023-09-13 11:59:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:59:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-13 11:59:46 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-13 11:59:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-13 11:59:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-13 11:59:46 --> initController - LoginPage.php
DEBUG - 2023-09-13 11:59:46 --> Total execution time: 0.0257
DEBUG - 2023-09-13 11:59:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:59:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-13 11:59:46 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-13 11:59:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-13 11:59:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-13 11:59:46 --> initController - LoginPage.php
DEBUG - 2023-09-13 11:59:46 --> Total execution time: 0.0241
DEBUG - 2023-09-13 11:59:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:59:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-13 11:59:46 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-13 11:59:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-13 11:59:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-13 11:59:46 --> initController - LoginPage.php
DEBUG - 2023-09-13 11:59:46 --> Total execution time: 0.0246
DEBUG - 2023-09-13 11:59:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:59:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-13 11:59:46 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-13 11:59:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-13 11:59:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-13 11:59:47 --> initController - LoginPage.php
DEBUG - 2023-09-13 11:59:47 --> Total execution time: 0.0229
DEBUG - 2023-09-13 11:59:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:59:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-13 11:59:47 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-13 11:59:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-13 11:59:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-13 11:59:47 --> initController - LoginPage.php
DEBUG - 2023-09-13 11:59:47 --> Total execution time: 0.0227
DEBUG - 2023-09-13 11:59:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:59:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-13 11:59:47 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-13 11:59:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-13 11:59:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-13 11:59:47 --> initController - LoginPage.php
DEBUG - 2023-09-13 11:59:47 --> Total execution time: 0.0234
DEBUG - 2023-09-13 11:59:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:59:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-13 11:59:47 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-13 11:59:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-13 11:59:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-13 11:59:47 --> initController - LoginPage.php
DEBUG - 2023-09-13 11:59:47 --> Total execution time: 0.0220
DEBUG - 2023-09-13 11:59:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:59:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-13 11:59:47 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-13 11:59:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-13 11:59:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-13 11:59:47 --> initController - LoginPage.php
DEBUG - 2023-09-13 11:59:47 --> Total execution time: 0.0212
DEBUG - 2023-09-13 11:59:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 11:59:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-13 11:59:48 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-13 17:41:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 17:41:21 --> No URI present. Default controller set.
DEBUG - 2023-09-13 17:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-13 17:41:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-13 17:41:21 --> initController - LoginPage.php
DEBUG - 2023-09-13 17:41:21 --> Total execution time: 0.0895
DEBUG - 2023-09-13 17:41:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 17:41:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-13 17:41:21 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-13 17:41:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 17:41:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-13 17:41:28 --> 404 Page Not Found: Userguide3/index
DEBUG - 2023-09-13 17:41:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-13 17:41:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-13 17:41:35 --> 404 Page Not Found: Userguide3/index
