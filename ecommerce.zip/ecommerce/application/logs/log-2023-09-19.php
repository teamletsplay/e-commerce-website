<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-09-19 10:36:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 10:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-19 10:36:10 --> initController - LoginPage.php
DEBUG - 2023-09-19 10:36:10 --> Total execution time: 0.0310
DEBUG - 2023-09-19 10:36:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 10:36:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-19 10:36:10 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-19 10:36:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 10:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-19 10:36:51 --> initController - LoginPage.php
DEBUG - 2023-09-19 10:36:51 --> Total execution time: 0.0177
DEBUG - 2023-09-19 10:36:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 10:36:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-19 10:36:51 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-19 10:37:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 10:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-19 10:37:04 --> initController - LoginPage.php
DEBUG - 2023-09-19 10:37:04 --> Total execution time: 0.0197
DEBUG - 2023-09-19 10:37:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 10:37:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-19 10:37:04 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-19 10:37:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 10:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-19 10:37:05 --> initController - LoginPage.php
DEBUG - 2023-09-19 10:37:05 --> Total execution time: 0.0214
DEBUG - 2023-09-19 10:37:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 10:37:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-19 10:37:05 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-19 10:37:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 10:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-19 10:37:06 --> initController - LoginPage.php
DEBUG - 2023-09-19 10:37:06 --> Total execution time: 0.0186
DEBUG - 2023-09-19 10:37:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 10:37:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-19 10:37:06 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-19 10:38:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 10:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-19 10:38:44 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-19 10:38:44 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-19 10:38:44 --> Total execution time: 0.0510
DEBUG - 2023-09-19 10:38:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 10:38:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-19 10:38:44 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-19 10:38:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 10:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-19 10:38:57 --> initController - LoginPage.php
DEBUG - 2023-09-19 10:38:57 --> Total execution time: 0.0193
DEBUG - 2023-09-19 10:38:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 10:38:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-19 10:38:57 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-19 10:39:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 10:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-19 10:39:29 --> initController - LoginPage.php
DEBUG - 2023-09-19 10:39:29 --> Total execution time: 0.0214
DEBUG - 2023-09-19 10:39:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 10:39:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-19 10:39:29 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-19 10:39:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 10:39:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-19 10:39:32 --> 404 Page Not Found: Done/index
DEBUG - 2023-09-19 11:40:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 11:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-19 11:40:46 --> Total execution time: 0.0302
DEBUG - 2023-09-19 11:40:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 11:40:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-19 11:40:46 --> 404 Page Not Found: Js/ajaxfileupload.js
DEBUG - 2023-09-19 12:03:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-19 12:03:20 --> Total execution time: 0.0234
DEBUG - 2023-09-19 12:03:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:03:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-19 12:03:20 --> 404 Page Not Found: Js/ajaxfileupload.js
DEBUG - 2023-09-19 12:03:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-19 12:03:28 --> Total execution time: 0.0252
DEBUG - 2023-09-19 12:03:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:03:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-19 12:03:28 --> 404 Page Not Found: Js/ajaxfileupload.js
DEBUG - 2023-09-19 12:16:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:16:00 --> No URI present. Default controller set.
DEBUG - 2023-09-19 12:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-19 12:16:00 --> initController - LoginPage.php
DEBUG - 2023-09-19 12:16:00 --> Total execution time: 0.0464
DEBUG - 2023-09-19 12:16:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:16:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-19 12:16:00 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-19 12:16:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-19 12:16:08 --> Total execution time: 0.0313
DEBUG - 2023-09-19 12:16:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:16:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-19 12:16:08 --> 404 Page Not Found: Js/ajaxfileupload.js
DEBUG - 2023-09-19 12:16:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-19 12:16:18 --> Total execution time: 0.0237
DEBUG - 2023-09-19 12:16:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:16:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-19 12:16:18 --> 404 Page Not Found: Js/ajaxfileupload.js
DEBUG - 2023-09-19 12:17:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-19 12:17:03 --> Total execution time: 0.0206
DEBUG - 2023-09-19 12:17:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:17:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-19 12:17:03 --> 404 Page Not Found: Js/ajaxfileupload.js
DEBUG - 2023-09-19 12:27:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:27:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-19 12:27:09 --> Severity: error --> Exception: Unable to locate the model you have specified: Files_model C:\xampp\htdocs\WebProject\system\core\Loader.php 350
DEBUG - 2023-09-19 12:30:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:30:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-19 12:30:30 --> Severity: error --> Exception: Unclosed '{' on line 3 C:\xampp\htdocs\WebProject\application\controllers\upload.php 40
DEBUG - 2023-09-19 12:31:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:31:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-19 12:31:01 --> Severity: error --> Exception: Unable to locate the model you have specified: Files_model C:\xampp\htdocs\WebProject\system\core\Loader.php 350
DEBUG - 2023-09-19 12:32:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-19 12:32:15 --> You did not select a file to upload.
DEBUG - 2023-09-19 12:32:15 --> Total execution time: 0.0246
DEBUG - 2023-09-19 12:32:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-19 12:32:21 --> You did not select a file to upload.
DEBUG - 2023-09-19 12:32:21 --> Total execution time: 0.0337
DEBUG - 2023-09-19 12:35:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:35:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-19 12:35:58 --> Severity: Compile Error --> Cannot redeclare Upload::do_upload() C:\xampp\htdocs\WebProject\application\controllers\upload.php 30
DEBUG - 2023-09-19 12:39:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:39:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-19 12:39:42 --> Severity: Compile Error --> Cannot redeclare Upload::do_upload() C:\xampp\htdocs\WebProject\application\controllers\upload.php 30
DEBUG - 2023-09-19 12:40:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:40:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-19 12:40:56 --> Severity: Compile Error --> Cannot declare class Upload, because the name is already in use C:\xampp\htdocs\WebProject\application\views\upload_view.php 2
DEBUG - 2023-09-19 12:42:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-19 12:42:49 --> Total execution time: 0.0252
DEBUG - 2023-09-19 12:42:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:42:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:42:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-19 12:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-19 12:42:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-19 12:42:49 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-19 12:42:49 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-19 12:42:49 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-19 12:42:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-19 12:42:58 --> Total execution time: 0.0279
DEBUG - 2023-09-19 12:42:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:42:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:42:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-19 12:42:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-19 12:42:58 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-19 12:42:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-19 12:42:58 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-19 12:42:58 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-19 12:44:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-19 12:44:43 --> Total execution time: 0.0241
DEBUG - 2023-09-19 12:44:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:44:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-19 12:44:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:44:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-19 12:44:43 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-19 12:44:43 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-19 12:44:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-19 12:44:43 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-19 12:46:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-19 12:46:36 --> Total execution time: 0.0221
DEBUG - 2023-09-19 12:46:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:46:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:46:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-19 12:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-19 12:46:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-19 12:46:36 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-19 12:46:36 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-19 12:46:36 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-19 12:47:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-19 12:47:25 --> Total execution time: 0.0229
DEBUG - 2023-09-19 12:47:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:47:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:47:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-19 12:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-19 12:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-19 12:47:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-19 12:47:25 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-19 12:47:25 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-19 12:47:25 --> 404 Page Not Found: Assets/css
