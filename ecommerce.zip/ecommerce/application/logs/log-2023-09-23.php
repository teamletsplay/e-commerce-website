<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-09-23 11:30:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 11:30:45 --> No URI present. Default controller set.
DEBUG - 2023-09-23 11:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 11:30:45 --> initController - LoginPage.php
DEBUG - 2023-09-23 11:30:45 --> Total execution time: 0.0424
DEBUG - 2023-09-23 11:30:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 11:30:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 11:30:45 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 11:35:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 11:35:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 11:35:10 --> 404 Page Not Found: Uplod/index
DEBUG - 2023-09-23 11:35:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 11:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 11:35:15 --> Total execution time: 0.0185
DEBUG - 2023-09-23 11:35:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 11:35:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 11:35:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 11:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 11:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 11:35:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 11:35:15 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-23 11:35:15 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-23 11:35:15 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-23 11:35:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 11:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 11:35:30 --> Total execution time: 0.0179
DEBUG - 2023-09-23 11:35:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 11:35:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 11:35:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 11:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 11:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 11:35:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 11:35:30 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-23 11:35:30 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-23 11:35:30 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-23 11:37:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 11:37:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 11:37:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 11:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 11:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 11:37:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 11:37:20 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-23 11:37:20 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-23 11:37:20 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-23 11:37:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 11:37:37 --> No URI present. Default controller set.
DEBUG - 2023-09-23 11:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 11:37:37 --> initController - LoginPage.php
DEBUG - 2023-09-23 11:37:37 --> Total execution time: 0.0182
DEBUG - 2023-09-23 11:37:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 11:37:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 11:37:37 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 11:37:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 11:37:53 --> No URI present. Default controller set.
DEBUG - 2023-09-23 11:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 11:37:53 --> initController - LoginPage.php
DEBUG - 2023-09-23 11:37:53 --> Total execution time: 0.0220
DEBUG - 2023-09-23 11:37:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 11:37:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 11:37:53 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 11:39:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 11:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 11:39:12 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-23 11:39:12 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 11:39:12 --> Total execution time: 0.0242
DEBUG - 2023-09-23 11:39:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 11:39:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 11:39:12 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 11:42:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 11:42:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 11:42:49 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 11:42:49 --> Total execution time: 0.0198
DEBUG - 2023-09-23 11:42:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 11:42:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 11:42:49 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 11:43:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 11:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 11:43:49 --> Total execution time: 0.0198
DEBUG - 2023-09-23 11:45:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 11:45:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 11:45:36 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 11:45:36 --> Total execution time: 0.0200
DEBUG - 2023-09-23 11:45:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 11:45:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 11:45:36 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 11:50:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 11:50:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 11:50:55 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 11:50:55 --> Total execution time: 0.0193
DEBUG - 2023-09-23 11:50:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 11:50:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 11:50:55 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 11:54:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 11:54:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 11:54:56 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 11:54:56 --> Total execution time: 0.0395
DEBUG - 2023-09-23 11:54:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 11:54:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 11:54:56 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 11:56:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 11:56:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 11:56:59 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 11:56:59 --> Total execution time: 0.0208
DEBUG - 2023-09-23 11:56:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 11:56:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 11:56:59 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 12:03:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:03:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:03:07 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 12:03:07 --> Total execution time: 0.0196
DEBUG - 2023-09-23 12:03:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:03:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:03:07 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 12:26:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:26:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:26:14 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 12:26:14 --> Total execution time: 0.0198
DEBUG - 2023-09-23 12:26:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:26:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:26:14 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 12:28:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:28:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:28:48 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 12:28:48 --> Total execution time: 0.0192
DEBUG - 2023-09-23 12:28:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:28:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:28:48 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 12:29:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:29:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:29:05 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 12:29:05 --> Total execution time: 0.0225
DEBUG - 2023-09-23 12:29:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:29:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:29:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:29:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 12:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 12:29:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:29:05 --> 404 Page Not Found: Customers/assets
DEBUG - 2023-09-23 12:29:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:29:05 --> 404 Page Not Found: Customers/5546YEEcss
ERROR - 2023-09-23 12:29:05 --> 404 Page Not Found: Customers/assets
ERROR - 2023-09-23 12:29:05 --> 404 Page Not Found: Customers/assets
DEBUG - 2023-09-23 12:29:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:29:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:29:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:29:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:29:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 12:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 12:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 12:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 12:29:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:29:05 --> 404 Page Not Found: Customers/js
ERROR - 2023-09-23 12:29:05 --> 404 Page Not Found: Customers/assets
ERROR - 2023-09-23 12:29:05 --> 404 Page Not Found: Customers/js
ERROR - 2023-09-23 12:29:05 --> 404 Page Not Found: Customers/assets
ERROR - 2023-09-23 12:29:05 --> 404 Page Not Found: Customers/images
DEBUG - 2023-09-23 12:29:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:29:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:29:51 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 12:29:51 --> Total execution time: 0.0232
DEBUG - 2023-09-23 12:29:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:29:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:29:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:29:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:29:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:29:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 12:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 12:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 12:29:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:29:51 --> 404 Page Not Found: Customers/assets
ERROR - 2023-09-23 12:29:51 --> 404 Page Not Found: Customers/assets
ERROR - 2023-09-23 12:29:51 --> 404 Page Not Found: Customers/assets
ERROR - 2023-09-23 12:29:51 --> 404 Page Not Found: Customers/5546YEEcss
DEBUG - 2023-09-23 12:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 12:29:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:29:51 --> 404 Page Not Found: Customers/js
ERROR - 2023-09-23 12:29:51 --> 404 Page Not Found: Customers/assets
DEBUG - 2023-09-23 12:29:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:29:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:29:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 12:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 12:29:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:29:51 --> 404 Page Not Found: Customers/js
ERROR - 2023-09-23 12:29:51 --> 404 Page Not Found: Customers/assets
ERROR - 2023-09-23 12:29:51 --> 404 Page Not Found: Customers/images
DEBUG - 2023-09-23 12:31:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:31:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:31:27 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 12:31:27 --> Total execution time: 0.0448
DEBUG - 2023-09-23 12:31:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:31:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 12:31:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:31:27 --> UTF-8 Support Enabled
ERROR - 2023-09-23 12:31:27 --> 404 Page Not Found: Customers/assets
DEBUG - 2023-09-23 12:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 12:31:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:31:27 --> UTF-8 Support Enabled
ERROR - 2023-09-23 12:31:27 --> 404 Page Not Found: Customers/5546YEEcss
DEBUG - 2023-09-23 12:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 12:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 12:31:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:31:27 --> 404 Page Not Found: Customers/assets
DEBUG - 2023-09-23 12:31:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:31:27 --> 404 Page Not Found: Customers/js
ERROR - 2023-09-23 12:31:27 --> 404 Page Not Found: Customers/assets
ERROR - 2023-09-23 12:31:27 --> 404 Page Not Found: Customers/assets
DEBUG - 2023-09-23 12:31:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:31:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:31:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 12:31:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:31:27 --> 404 Page Not Found: Customers/js
ERROR - 2023-09-23 12:31:27 --> 404 Page Not Found: Customers/assets
DEBUG - 2023-09-23 12:31:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:31:27 --> 404 Page Not Found: Customers/images
DEBUG - 2023-09-23 12:31:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:31:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:31:37 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 12:31:37 --> Total execution time: 0.0485
DEBUG - 2023-09-23 12:31:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:31:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:31:37 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 12:35:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:35:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:35:19 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 12:35:19 --> Total execution time: 0.0651
DEBUG - 2023-09-23 12:35:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:35:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:35:19 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 12:35:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:35:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:35:58 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 12:35:58 --> Total execution time: 0.0487
DEBUG - 2023-09-23 12:35:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:35:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:35:58 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 12:37:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:37:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:37:03 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 12:37:03 --> Total execution time: 0.0491
DEBUG - 2023-09-23 12:37:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:37:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:37:03 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 12:37:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:37:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:37:18 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 12:37:18 --> Total execution time: 0.0543
DEBUG - 2023-09-23 12:37:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:37:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:37:18 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 12:37:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:37:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:37:47 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 12:37:47 --> Total execution time: 0.0534
DEBUG - 2023-09-23 12:37:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:37:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:37:47 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 12:38:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:38:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:38:27 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 12:38:27 --> Total execution time: 0.0515
DEBUG - 2023-09-23 12:38:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:38:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:38:27 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 12:39:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:39:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:39:34 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 12:39:34 --> Total execution time: 0.1021
DEBUG - 2023-09-23 12:39:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:39:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:39:34 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 12:41:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:41:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:41:12 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 12:41:12 --> Total execution time: 0.0699
DEBUG - 2023-09-23 12:41:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:41:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:41:12 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 12:41:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:41:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:41:31 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 12:41:31 --> Total execution time: 0.0524
DEBUG - 2023-09-23 12:41:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:41:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:41:31 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 12:42:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:42:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:42:30 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 12:42:30 --> Total execution time: 0.0551
DEBUG - 2023-09-23 12:42:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:42:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:42:30 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 12:43:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:43:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:43:13 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 12:43:13 --> Total execution time: 0.0434
DEBUG - 2023-09-23 12:43:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:43:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:43:13 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 12:44:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 12:44:55 --> initController - LoginPage.php
DEBUG - 2023-09-23 12:44:55 --> Total execution time: 0.0414
DEBUG - 2023-09-23 12:44:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:44:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:44:55 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 12:44:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:44:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:44:57 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 12:44:57 --> Total execution time: 0.0399
DEBUG - 2023-09-23 12:44:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:44:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:44:57 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 12:46:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 12:46:10 --> initController - LoginPage.php
DEBUG - 2023-09-23 12:46:10 --> Total execution time: 0.0467
DEBUG - 2023-09-23 12:46:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:46:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:46:10 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 12:46:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:46:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:46:14 --> 404 Page Not Found: Done/index
DEBUG - 2023-09-23 12:47:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 12:47:45 --> initController - LoginPage.php
DEBUG - 2023-09-23 12:47:45 --> Total execution time: 0.0380
DEBUG - 2023-09-23 12:47:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:47:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:47:45 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 12:47:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:47:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:47:55 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 12:47:55 --> Total execution time: 0.0411
DEBUG - 2023-09-23 12:47:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:47:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:47:55 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 12:48:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 12:48:06 --> initController - LoginPage.php
DEBUG - 2023-09-23 12:48:06 --> Total execution time: 0.0539
DEBUG - 2023-09-23 12:48:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:48:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:48:06 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 12:48:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 12:48:08 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-23 12:48:08 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 12:48:08 --> Total execution time: 0.0495
DEBUG - 2023-09-23 12:48:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:48:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:48:08 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 12:48:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 12:48:31 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-23 12:48:31 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 12:48:31 --> Total execution time: 0.0447
DEBUG - 2023-09-23 12:48:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 12:48:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 12:48:31 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 13:42:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 13:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 13:42:53 --> Total execution time: 0.0398
DEBUG - 2023-09-23 13:42:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 13:42:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 13:42:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 13:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 13:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 13:42:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 13:42:53 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-23 13:42:53 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-23 13:42:53 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-23 13:43:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 13:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 13:43:07 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-23 13:43:07 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 13:43:07 --> Total execution time: 0.0453
DEBUG - 2023-09-23 13:43:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 13:43:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 13:43:07 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 13:48:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 13:48:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 13:48:03 --> 404 Page Not Found: KhanStore/admin
DEBUG - 2023-09-23 13:49:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 13:49:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 13:49:29 --> 404 Page Not Found: KhanStore/admin
DEBUG - 2023-09-23 13:49:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 13:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 13:49:30 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-23 13:49:30 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 13:49:30 --> Total execution time: 0.0455
DEBUG - 2023-09-23 13:49:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 13:49:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 13:49:30 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 14:05:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:05:27 --> No URI present. Default controller set.
DEBUG - 2023-09-23 14:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 14:05:27 --> initController - LoginPage.php
DEBUG - 2023-09-23 14:05:27 --> Total execution time: 0.0645
DEBUG - 2023-09-23 14:05:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:05:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:05:28 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 14:05:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 14:05:34 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-23 14:05:34 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 14:07:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 14:07:40 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-23 14:07:40 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 14:10:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 14:10:50 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-23 14:10:50 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 14:10:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 14:10:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-23 14:10:51 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 14:10:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 14:10:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-23 14:10:51 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 14:10:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 14:10:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-23 14:10:51 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 14:10:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 14:10:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-23 14:10:51 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 14:10:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 14:10:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-23 14:10:51 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 14:10:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 14:10:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-23 14:10:52 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 14:10:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 14:10:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-23 14:10:52 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 14:10:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 14:10:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-23 14:10:52 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 14:10:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 14:10:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-23 14:10:52 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 14:12:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 14:12:26 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-23 14:12:26 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 14:12:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 14:12:27 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-23 14:12:27 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 14:12:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 14:12:27 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-23 14:12:27 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 14:12:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 14:12:27 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-23 14:12:27 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 14:12:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 14:12:27 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-23 14:12:27 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 14:12:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 14:12:27 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-23 14:12:27 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 14:12:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 14:12:28 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-23 14:12:28 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 14:12:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 14:12:28 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-23 14:12:28 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 14:12:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 14:12:28 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-23 14:12:28 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 14:12:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 14:12:28 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-23 14:12:28 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 14:13:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 14:13:09 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-23 14:13:09 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-23 14:13:09 --> Severity: Notice --> session_start(): Ignoring session_start() because a session is already active C:\xampp\htdocs\WebProject\application\views\insert.php 2
ERROR - 2023-09-23 14:13:09 --> Severity: Warning --> include(./templates/top.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 7
ERROR - 2023-09-23 14:13:09 --> Severity: Warning --> include(): Failed opening './templates/top.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 7
ERROR - 2023-09-23 14:13:09 --> Severity: Warning --> include(./templates/navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 11
ERROR - 2023-09-23 14:13:09 --> Severity: Warning --> include(): Failed opening './templates/navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 11
ERROR - 2023-09-23 14:13:09 --> Severity: Warning --> include(./templates/sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 16
ERROR - 2023-09-23 14:13:09 --> Severity: Warning --> include(): Failed opening './templates/sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 16
ERROR - 2023-09-23 14:13:09 --> Severity: Warning --> include(./templates/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 47
ERROR - 2023-09-23 14:13:09 --> Severity: Warning --> include(): Failed opening './templates/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 47
DEBUG - 2023-09-23 14:13:09 --> Total execution time: 0.0732
DEBUG - 2023-09-23 14:13:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:13:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:13:09 --> 404 Page Not Found: Loginphp/index
DEBUG - 2023-09-23 14:13:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:13:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:13:09 --> 404 Page Not Found: Loginphp/index
DEBUG - 2023-09-23 14:13:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:13:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:13:10 --> 404 Page Not Found: Loginphp/index
DEBUG - 2023-09-23 14:13:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:13:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:13:10 --> 404 Page Not Found: Loginphp/index
DEBUG - 2023-09-23 14:13:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:13:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:13:10 --> 404 Page Not Found: Loginphp/index
DEBUG - 2023-09-23 14:13:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:13:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:13:10 --> 404 Page Not Found: Loginphp/index
DEBUG - 2023-09-23 14:13:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:13:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:13:11 --> 404 Page Not Found: Loginphp/index
DEBUG - 2023-09-23 14:13:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:13:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:13:11 --> 404 Page Not Found: Loginphp/index
DEBUG - 2023-09-23 14:13:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:13:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:13:11 --> 404 Page Not Found: Loginphp/index
DEBUG - 2023-09-23 14:13:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:13:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:13:11 --> 404 Page Not Found: Loginphp/index
DEBUG - 2023-09-23 14:13:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:13:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:13:12 --> 404 Page Not Found: Loginphp/index
DEBUG - 2023-09-23 14:13:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:13:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:13:12 --> 404 Page Not Found: Loginphp/index
DEBUG - 2023-09-23 14:13:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:13:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:13:12 --> 404 Page Not Found: Loginphp/index
DEBUG - 2023-09-23 14:13:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:13:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:13:13 --> 404 Page Not Found: Loginphp/index
DEBUG - 2023-09-23 14:13:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:13:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:13:13 --> 404 Page Not Found: Loginphp/index
DEBUG - 2023-09-23 14:13:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:13:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:13:13 --> 404 Page Not Found: Loginphp/index
DEBUG - 2023-09-23 14:17:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:17:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:17:00 --> 404 Page Not Found: Loginphp/index
DEBUG - 2023-09-23 14:17:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 14:17:06 --> initController - LoginPage.php
DEBUG - 2023-09-23 14:17:06 --> Total execution time: 0.0437
DEBUG - 2023-09-23 14:17:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:17:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:17:06 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 14:21:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:21:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:21:14 --> 404 Page Not Found: Loginphp/index
DEBUG - 2023-09-23 14:21:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 14:21:22 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-23 14:21:22 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-23 14:21:22 --> Severity: Notice --> session_start(): Ignoring session_start() because a session is already active C:\xampp\htdocs\WebProject\application\views\insert.php 2
ERROR - 2023-09-23 14:21:22 --> Severity: Warning --> include(./templates/top.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 7
ERROR - 2023-09-23 14:21:22 --> Severity: Warning --> include(): Failed opening './templates/top.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 7
ERROR - 2023-09-23 14:21:22 --> Severity: Warning --> include(./templates/navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 11
ERROR - 2023-09-23 14:21:22 --> Severity: Warning --> include(): Failed opening './templates/navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 11
ERROR - 2023-09-23 14:21:22 --> Severity: Warning --> include(./templates/sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 16
ERROR - 2023-09-23 14:21:22 --> Severity: Warning --> include(): Failed opening './templates/sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 16
ERROR - 2023-09-23 14:21:22 --> Severity: Warning --> include(./templates/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 47
ERROR - 2023-09-23 14:21:22 --> Severity: Warning --> include(): Failed opening './templates/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 47
DEBUG - 2023-09-23 14:21:22 --> Total execution time: 0.0308
DEBUG - 2023-09-23 14:21:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:21:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:21:22 --> 404 Page Not Found: Loginphp/index
DEBUG - 2023-09-23 14:23:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:23:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:23:38 --> 404 Page Not Found: Loginphp/index
DEBUG - 2023-09-23 14:23:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:23:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:23:39 --> 404 Page Not Found: Loginphp/index
DEBUG - 2023-09-23 14:23:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:23:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:23:39 --> 404 Page Not Found: Loginphp/index
DEBUG - 2023-09-23 14:23:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:23:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:23:40 --> 404 Page Not Found: Loginphp/index
DEBUG - 2023-09-23 14:23:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:23:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:23:40 --> 404 Page Not Found: Loginphp/index
DEBUG - 2023-09-23 14:23:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:23:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:23:41 --> 404 Page Not Found: Loginphp/index
DEBUG - 2023-09-23 14:23:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 14:23:48 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-23 14:23:48 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-23 14:23:48 --> Severity: Notice --> session_start(): Ignoring session_start() because a session is already active C:\xampp\htdocs\WebProject\application\views\insert.php 2
ERROR - 2023-09-23 14:23:48 --> Severity: Warning --> include(./templates/top.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 7
ERROR - 2023-09-23 14:23:48 --> Severity: Warning --> include(): Failed opening './templates/top.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 7
ERROR - 2023-09-23 14:23:48 --> Severity: Warning --> include(./templates/navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 11
ERROR - 2023-09-23 14:23:48 --> Severity: Warning --> include(): Failed opening './templates/navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 11
ERROR - 2023-09-23 14:23:48 --> Severity: Warning --> include(./templates/sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 16
ERROR - 2023-09-23 14:23:48 --> Severity: Warning --> include(): Failed opening './templates/sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 16
ERROR - 2023-09-23 14:23:48 --> Severity: Warning --> include(./templates/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 47
ERROR - 2023-09-23 14:23:48 --> Severity: Warning --> include(): Failed opening './templates/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 47
DEBUG - 2023-09-23 14:23:48 --> Total execution time: 0.0273
DEBUG - 2023-09-23 14:23:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:23:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:23:48 --> 404 Page Not Found: Loginphp/index
DEBUG - 2023-09-23 14:23:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:23:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:23:53 --> 404 Page Not Found: Loginphp/index
DEBUG - 2023-09-23 14:26:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:26:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:26:51 --> 404 Page Not Found: Loginphp/index
DEBUG - 2023-09-23 14:26:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:26:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:26:52 --> 404 Page Not Found: Loginphp/index
DEBUG - 2023-09-23 14:26:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:26:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:26:52 --> 404 Page Not Found: Loginphp/index
DEBUG - 2023-09-23 14:26:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:26:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:26:52 --> 404 Page Not Found: Loginphp/index
DEBUG - 2023-09-23 14:26:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:26:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:26:52 --> 404 Page Not Found: Loginphp/index
DEBUG - 2023-09-23 14:26:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:26:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:26:53 --> 404 Page Not Found: Loginphp/index
DEBUG - 2023-09-23 14:26:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:26:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:26:53 --> 404 Page Not Found: Loginphp/index
DEBUG - 2023-09-23 14:26:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:26:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:26:54 --> 404 Page Not Found: Loginphp/index
DEBUG - 2023-09-23 14:27:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 14:27:01 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-23 14:27:01 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-23 14:27:01 --> Severity: Notice --> session_start(): Ignoring session_start() because a session is already active C:\xampp\htdocs\WebProject\application\views\insert.php 2
ERROR - 2023-09-23 14:27:01 --> Severity: Warning --> include(./templates/top.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 7
ERROR - 2023-09-23 14:27:01 --> Severity: Warning --> include(): Failed opening './templates/top.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 7
ERROR - 2023-09-23 14:27:01 --> Severity: Warning --> include(./templates/navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 11
ERROR - 2023-09-23 14:27:02 --> Severity: Warning --> include(): Failed opening './templates/navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 11
ERROR - 2023-09-23 14:27:02 --> Severity: Warning --> include(./templates/sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 16
ERROR - 2023-09-23 14:27:02 --> Severity: Warning --> include(): Failed opening './templates/sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 16
ERROR - 2023-09-23 14:27:02 --> Severity: Warning --> include(./templates/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 47
ERROR - 2023-09-23 14:27:02 --> Severity: Warning --> include(): Failed opening './templates/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 47
DEBUG - 2023-09-23 14:27:02 --> Total execution time: 0.0281
DEBUG - 2023-09-23 14:27:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:27:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:27:02 --> 404 Page Not Found: Admin/login.php
DEBUG - 2023-09-23 14:28:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 14:28:13 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-23 14:28:13 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-23 14:28:13 --> Severity: Notice --> session_start(): Ignoring session_start() because a session is already active C:\xampp\htdocs\WebProject\application\views\insert.php 2
ERROR - 2023-09-23 14:28:13 --> Severity: Warning --> include(./templates/top.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 7
ERROR - 2023-09-23 14:28:13 --> Severity: Warning --> include(): Failed opening './templates/top.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 7
ERROR - 2023-09-23 14:28:13 --> Severity: Warning --> include(./templates/navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 11
ERROR - 2023-09-23 14:28:13 --> Severity: Warning --> include(): Failed opening './templates/navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 11
ERROR - 2023-09-23 14:28:13 --> Severity: Warning --> include(./templates/sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 16
ERROR - 2023-09-23 14:28:13 --> Severity: Warning --> include(): Failed opening './templates/sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 16
ERROR - 2023-09-23 14:28:13 --> Severity: Warning --> include(./templates/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 47
ERROR - 2023-09-23 14:28:13 --> Severity: Warning --> include(): Failed opening './templates/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 47
DEBUG - 2023-09-23 14:28:13 --> Total execution time: 0.0260
DEBUG - 2023-09-23 14:28:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 14:28:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:28:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:28:14 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 14:32:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:32:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 14:32:34 --> 404 Page Not Found: Ladmin/index
DEBUG - 2023-09-23 14:32:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 14:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 14:32:39 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-23 14:32:39 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-23 14:32:39 --> Severity: Notice --> session_start(): Ignoring session_start() because a session is already active C:\xampp\htdocs\WebProject\application\views\insert.php 2
ERROR - 2023-09-23 14:32:39 --> Severity: Warning --> include(./templates/top.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 7
ERROR - 2023-09-23 14:32:39 --> Severity: Warning --> include(): Failed opening './templates/top.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 7
ERROR - 2023-09-23 14:32:39 --> Severity: Warning --> include(./templates/navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 11
ERROR - 2023-09-23 14:32:39 --> Severity: Warning --> include(): Failed opening './templates/navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 11
ERROR - 2023-09-23 14:32:39 --> Severity: Warning --> include(./templates/sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 16
ERROR - 2023-09-23 14:32:39 --> Severity: Warning --> include(): Failed opening './templates/sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 16
ERROR - 2023-09-23 14:32:39 --> Severity: Warning --> include(./templates/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 47
ERROR - 2023-09-23 14:32:39 --> Severity: Warning --> include(): Failed opening './templates/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 47
DEBUG - 2023-09-23 14:32:39 --> Total execution time: 0.0287
DEBUG - 2023-09-23 15:04:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 15:04:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 15:04:17 --> 404 Page Not Found: Admin/index.php
DEBUG - 2023-09-23 15:05:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 15:05:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 15:05:55 --> 404 Page Not Found: Admin/index.php
DEBUG - 2023-09-23 15:05:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 15:05:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 15:05:58 --> 404 Page Not Found: Admin/index.php
DEBUG - 2023-09-23 15:06:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 15:06:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 15:06:11 --> 404 Page Not Found: Admin/index.php
DEBUG - 2023-09-23 18:42:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 18:42:42 --> No URI present. Default controller set.
DEBUG - 2023-09-23 18:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 18:42:42 --> initController - LoginPage.php
DEBUG - 2023-09-23 18:42:42 --> Total execution time: 0.0527
DEBUG - 2023-09-23 18:42:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 18:42:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 18:42:42 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 18:42:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 18:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 18:42:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-23 18:42:52 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-23 18:42:52 --> Severity: Notice --> session_start(): Ignoring session_start() because a session is already active C:\xampp\htdocs\WebProject\application\views\insert.php 2
ERROR - 2023-09-23 18:42:52 --> Severity: Warning --> include(./templates/top.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 7
ERROR - 2023-09-23 18:42:52 --> Severity: Warning --> include(): Failed opening './templates/top.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 7
ERROR - 2023-09-23 18:42:52 --> Severity: Warning --> include(./templates/navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 11
ERROR - 2023-09-23 18:42:52 --> Severity: Warning --> include(): Failed opening './templates/navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 11
ERROR - 2023-09-23 18:42:52 --> Severity: Warning --> include(./templates/sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 16
ERROR - 2023-09-23 18:42:52 --> Severity: Warning --> include(): Failed opening './templates/sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 16
ERROR - 2023-09-23 18:42:52 --> Severity: Warning --> include(./templates/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 47
ERROR - 2023-09-23 18:42:52 --> Severity: Warning --> include(): Failed opening './templates/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 47
DEBUG - 2023-09-23 18:42:52 --> Total execution time: 0.0655
DEBUG - 2023-09-23 19:55:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 19:55:05 --> No URI present. Default controller set.
DEBUG - 2023-09-23 19:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 19:55:05 --> initController - LoginPage.php
DEBUG - 2023-09-23 19:55:05 --> Total execution time: 0.0227
DEBUG - 2023-09-23 19:55:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 19:55:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 19:55:05 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 19:55:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 19:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 19:55:06 --> initController - LoginPage.php
DEBUG - 2023-09-23 19:55:06 --> Total execution time: 0.0225
DEBUG - 2023-09-23 19:55:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 19:55:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 19:55:06 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 19:55:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 19:55:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 19:55:10 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 19:55:10 --> Total execution time: 0.0206
DEBUG - 2023-09-23 19:55:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 19:55:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 19:55:10 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 19:55:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 19:55:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 19:55:21 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-23 19:55:21 --> Severity: error --> Exception: Column 'address' cannot be null C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 264
DEBUG - 2023-09-23 19:57:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 19:57:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 19:57:08 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-23 19:57:08 --> Severity: error --> Exception: Unknown column 'address' in 'field list' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 264
DEBUG - 2023-09-23 19:58:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 19:58:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 19:58:08 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-23 19:58:08 --> Severity: error --> Exception: Unknown column 'address' in 'field list' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 264
DEBUG - 2023-09-23 20:00:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 20:00:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 20:00:52 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 20:00:52 --> Total execution time: 0.0328
DEBUG - 2023-09-23 20:00:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 20:00:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 20:00:52 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 20:01:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 20:01:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 20:01:06 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 20:01:06 --> Total execution time: 0.0228
DEBUG - 2023-09-23 20:01:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 20:01:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 20:01:06 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 20:08:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 20:08:12 --> No URI present. Default controller set.
DEBUG - 2023-09-23 20:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 20:08:12 --> initController - LoginPage.php
DEBUG - 2023-09-23 20:08:12 --> Total execution time: 0.0259
DEBUG - 2023-09-23 20:08:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 20:08:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 20:08:12 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 20:08:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 20:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-23 20:08:14 --> initController - LoginPage.php
DEBUG - 2023-09-23 20:08:14 --> Total execution time: 0.0214
DEBUG - 2023-09-23 20:08:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 20:08:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 20:08:14 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 20:08:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 20:08:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 20:08:16 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-23 20:08:16 --> Total execution time: 0.0200
DEBUG - 2023-09-23 20:08:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 20:08:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 20:08:16 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-23 20:08:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 20:08:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 20:08:33 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-23 20:08:33 --> Severity: Warning --> Undefined array key "password" C:\xampp\htdocs\WebProject\application\controllers\Customers.php 33
ERROR - 2023-09-23 20:08:33 --> Severity: 8192 --> password_hash(): Passing null to parameter #1 ($password) of type string is deprecated C:\xampp\htdocs\WebProject\application\controllers\Customers.php 33
DEBUG - 2023-09-23 20:08:33 --> Total execution time: 0.0749
DEBUG - 2023-09-23 20:08:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-23 20:08:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-23 20:08:34 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
