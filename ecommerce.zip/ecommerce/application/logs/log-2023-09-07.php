<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-09-07 08:35:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 08:35:13 --> No URI present. Default controller set.
DEBUG - 2023-09-07 08:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 08:35:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 08:35:13 --> initController - LoginPage.php
DEBUG - 2023-09-07 08:35:13 --> Total execution time: 0.0593
DEBUG - 2023-09-07 08:43:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 08:43:19 --> No URI present. Default controller set.
DEBUG - 2023-09-07 08:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 08:43:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 08:43:19 --> initController - LoginPage.php
DEBUG - 2023-09-07 08:43:19 --> Total execution time: 0.0320
DEBUG - 2023-09-07 08:44:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 08:44:21 --> No URI present. Default controller set.
DEBUG - 2023-09-07 08:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 08:44:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 08:44:21 --> initController - LoginPage.php
DEBUG - 2023-09-07 08:44:21 --> Total execution time: 0.0267
DEBUG - 2023-09-07 08:45:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 08:45:04 --> No URI present. Default controller set.
DEBUG - 2023-09-07 08:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 08:45:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 08:45:04 --> initController - LoginPage.php
DEBUG - 2023-09-07 08:45:04 --> Total execution time: 0.0269
DEBUG - 2023-09-07 08:45:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 08:45:53 --> No URI present. Default controller set.
DEBUG - 2023-09-07 08:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 08:45:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 08:45:53 --> initController - LoginPage.php
DEBUG - 2023-09-07 08:45:53 --> Total execution time: 0.0266
DEBUG - 2023-09-07 08:46:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 08:46:08 --> No URI present. Default controller set.
DEBUG - 2023-09-07 08:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 08:46:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 08:46:08 --> initController - LoginPage.php
DEBUG - 2023-09-07 08:46:08 --> Total execution time: 0.0269
DEBUG - 2023-09-07 08:48:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 08:48:31 --> No URI present. Default controller set.
DEBUG - 2023-09-07 08:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 08:48:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 08:48:31 --> initController - LoginPage.php
DEBUG - 2023-09-07 08:48:31 --> Total execution time: 0.0309
DEBUG - 2023-09-07 08:49:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 08:49:30 --> No URI present. Default controller set.
DEBUG - 2023-09-07 08:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 08:49:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 08:49:30 --> initController - LoginPage.php
DEBUG - 2023-09-07 08:49:30 --> Total execution time: 0.0274
DEBUG - 2023-09-07 10:36:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 10:36:29 --> No URI present. Default controller set.
DEBUG - 2023-09-07 10:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 10:36:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 10:36:29 --> initController - LoginPage.php
DEBUG - 2023-09-07 10:36:29 --> Total execution time: 0.0450
DEBUG - 2023-09-07 10:59:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 10:59:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 10:59:38 --> 404 Page Not Found: Carthtml/index
DEBUG - 2023-09-07 11:07:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 11:07:09 --> No URI present. Default controller set.
DEBUG - 2023-09-07 11:07:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 11:07:09 --> Severity: Compile Error --> Cannot redeclare InitController::login() C:\xampp\htdocs\WebProject\application\controllers\InitController.php 20
DEBUG - 2023-09-07 11:07:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 11:07:15 --> No URI present. Default controller set.
DEBUG - 2023-09-07 11:07:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 11:07:15 --> Severity: Compile Error --> Cannot redeclare InitController::login() C:\xampp\htdocs\WebProject\application\controllers\InitController.php 20
DEBUG - 2023-09-07 11:07:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 11:07:15 --> No URI present. Default controller set.
DEBUG - 2023-09-07 11:07:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 11:07:15 --> Severity: Compile Error --> Cannot redeclare InitController::login() C:\xampp\htdocs\WebProject\application\controllers\InitController.php 20
DEBUG - 2023-09-07 11:07:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 11:07:15 --> No URI present. Default controller set.
DEBUG - 2023-09-07 11:07:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 11:07:15 --> Severity: Compile Error --> Cannot redeclare InitController::login() C:\xampp\htdocs\WebProject\application\controllers\InitController.php 20
DEBUG - 2023-09-07 11:07:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 11:07:16 --> No URI present. Default controller set.
DEBUG - 2023-09-07 11:07:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 11:07:16 --> Severity: Compile Error --> Cannot redeclare InitController::login() C:\xampp\htdocs\WebProject\application\controllers\InitController.php 20
DEBUG - 2023-09-07 11:19:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 11:19:40 --> No URI present. Default controller set.
DEBUG - 2023-09-07 11:19:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 11:19:40 --> Severity: Compile Error --> Cannot redeclare InitController::login() C:\xampp\htdocs\WebProject\application\controllers\InitController.php 20
DEBUG - 2023-09-07 11:19:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 11:19:41 --> No URI present. Default controller set.
DEBUG - 2023-09-07 11:19:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 11:19:41 --> Severity: Compile Error --> Cannot redeclare InitController::login() C:\xampp\htdocs\WebProject\application\controllers\InitController.php 20
DEBUG - 2023-09-07 11:19:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 11:19:41 --> No URI present. Default controller set.
DEBUG - 2023-09-07 11:19:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 11:19:41 --> Severity: Compile Error --> Cannot redeclare InitController::login() C:\xampp\htdocs\WebProject\application\controllers\InitController.php 20
DEBUG - 2023-09-07 11:19:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 11:19:41 --> No URI present. Default controller set.
DEBUG - 2023-09-07 11:19:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 11:19:41 --> Severity: Compile Error --> Cannot redeclare InitController::login() C:\xampp\htdocs\WebProject\application\controllers\InitController.php 20
DEBUG - 2023-09-07 11:19:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 11:19:41 --> No URI present. Default controller set.
DEBUG - 2023-09-07 11:19:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 11:19:41 --> Severity: Compile Error --> Cannot redeclare InitController::login() C:\xampp\htdocs\WebProject\application\controllers\InitController.php 20
DEBUG - 2023-09-07 11:19:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 11:19:41 --> No URI present. Default controller set.
DEBUG - 2023-09-07 11:19:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 11:19:41 --> Severity: Compile Error --> Cannot redeclare InitController::login() C:\xampp\htdocs\WebProject\application\controllers\InitController.php 20
DEBUG - 2023-09-07 11:19:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 11:19:42 --> No URI present. Default controller set.
DEBUG - 2023-09-07 11:19:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 11:19:42 --> Severity: Compile Error --> Cannot redeclare InitController::login() C:\xampp\htdocs\WebProject\application\controllers\InitController.php 20
DEBUG - 2023-09-07 11:19:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 11:19:42 --> No URI present. Default controller set.
DEBUG - 2023-09-07 11:19:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 11:19:42 --> Severity: Compile Error --> Cannot redeclare InitController::login() C:\xampp\htdocs\WebProject\application\controllers\InitController.php 20
DEBUG - 2023-09-07 11:19:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 11:19:42 --> No URI present. Default controller set.
DEBUG - 2023-09-07 11:19:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 11:19:42 --> Severity: Compile Error --> Cannot redeclare InitController::login() C:\xampp\htdocs\WebProject\application\controllers\InitController.php 20
DEBUG - 2023-09-07 11:19:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 11:19:42 --> No URI present. Default controller set.
DEBUG - 2023-09-07 11:19:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 11:19:42 --> Severity: Compile Error --> Cannot redeclare InitController::login() C:\xampp\htdocs\WebProject\application\controllers\InitController.php 20
DEBUG - 2023-09-07 11:20:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 11:20:25 --> No URI present. Default controller set.
DEBUG - 2023-09-07 11:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 11:20:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 11:20:25 --> initController - LoginPage.php
DEBUG - 2023-09-07 11:20:25 --> Total execution time: 0.0431
DEBUG - 2023-09-07 11:25:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 11:25:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 11:25:18 --> 404 Page Not Found: LoginView/index
DEBUG - 2023-09-07 11:25:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 11:25:24 --> No URI present. Default controller set.
DEBUG - 2023-09-07 11:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 11:25:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 11:25:24 --> initController - LoginPage.php
DEBUG - 2023-09-07 11:25:24 --> Total execution time: 0.0397
DEBUG - 2023-09-07 11:25:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 11:25:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 11:25:26 --> 404 Page Not Found: Loginhtml/index
DEBUG - 2023-09-07 11:25:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 11:25:35 --> No URI present. Default controller set.
DEBUG - 2023-09-07 11:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 11:25:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 11:25:35 --> initController - LoginPage.php
DEBUG - 2023-09-07 11:25:35 --> Total execution time: 0.0464
DEBUG - 2023-09-07 11:39:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 11:39:49 --> No URI present. Default controller set.
DEBUG - 2023-09-07 11:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 11:39:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 11:39:49 --> initController - LoginPage.php
DEBUG - 2023-09-07 11:39:49 --> Total execution time: 0.0289
DEBUG - 2023-09-07 11:40:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 11:40:05 --> No URI present. Default controller set.
DEBUG - 2023-09-07 11:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 11:40:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 11:40:05 --> initController - LoginPage.php
DEBUG - 2023-09-07 11:40:05 --> Total execution time: 0.0313
DEBUG - 2023-09-07 11:40:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 11:40:24 --> No URI present. Default controller set.
DEBUG - 2023-09-07 11:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 11:40:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 11:40:24 --> initController - LoginPage.php
DEBUG - 2023-09-07 11:40:24 --> Total execution time: 0.0295
DEBUG - 2023-09-07 11:41:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 11:41:48 --> No URI present. Default controller set.
DEBUG - 2023-09-07 11:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 11:41:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 11:41:48 --> initController - LoginPage.php
DEBUG - 2023-09-07 11:41:48 --> Total execution time: 0.0290
DEBUG - 2023-09-07 11:41:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 11:41:51 --> No URI present. Default controller set.
DEBUG - 2023-09-07 11:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 11:41:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 11:41:51 --> initController - LoginPage.php
DEBUG - 2023-09-07 11:41:51 --> Total execution time: 0.0285
DEBUG - 2023-09-07 12:26:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 12:26:41 --> No URI present. Default controller set.
DEBUG - 2023-09-07 12:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 12:26:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 12:26:41 --> initController - LoginPage.php
DEBUG - 2023-09-07 12:26:41 --> Total execution time: 0.0360
DEBUG - 2023-09-07 12:51:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 12:51:42 --> No URI present. Default controller set.
DEBUG - 2023-09-07 12:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 12:51:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 12:51:42 --> initController - LoginPage.php
DEBUG - 2023-09-07 12:51:42 --> Total execution time: 0.0509
DEBUG - 2023-09-07 12:51:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 12:51:43 --> No URI present. Default controller set.
DEBUG - 2023-09-07 12:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 12:51:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 12:51:43 --> initController - LoginPage.php
DEBUG - 2023-09-07 12:51:43 --> Total execution time: 0.0489
DEBUG - 2023-09-07 12:51:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 12:51:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 12:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 12:51:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 12:51:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 12:51:44 --> Total execution time: 0.0681
DEBUG - 2023-09-07 12:51:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 12:51:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 12:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 12:51:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 12:51:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 12:51:44 --> Total execution time: 0.0762
DEBUG - 2023-09-07 12:51:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 12:51:56 --> No URI present. Default controller set.
DEBUG - 2023-09-07 12:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 12:51:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 12:51:56 --> initController - LoginPage.php
DEBUG - 2023-09-07 12:51:56 --> Total execution time: 0.0481
DEBUG - 2023-09-07 13:16:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 13:16:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 13:16:04 --> 404 Page Not Found: Index1html/index
DEBUG - 2023-09-07 13:29:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 13:29:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 13:29:11 --> 404 Page Not Found: Index1html/index
DEBUG - 2023-09-07 13:29:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 13:29:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 13:29:12 --> 404 Page Not Found: Index1html/index
DEBUG - 2023-09-07 13:29:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 13:29:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 13:29:12 --> 404 Page Not Found: Index1html/index
DEBUG - 2023-09-07 13:29:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 13:29:13 --> No URI present. Default controller set.
DEBUG - 2023-09-07 13:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 13:29:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 13:29:13 --> initController - LoginPage.php
DEBUG - 2023-09-07 13:29:13 --> Total execution time: 0.0588
DEBUG - 2023-09-07 15:51:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 15:51:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 15:51:27 --> 404 Page Not Found: Views/includes
DEBUG - 2023-09-07 15:51:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 15:51:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 15:51:43 --> 404 Page Not Found: LoginView/index
DEBUG - 2023-09-07 15:51:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 15:51:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 15:51:48 --> 404 Page Not Found: Views/includes
DEBUG - 2023-09-07 15:52:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 15:52:33 --> No URI present. Default controller set.
DEBUG - 2023-09-07 15:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 15:52:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 15:52:33 --> initController - LoginPage.php
DEBUG - 2023-09-07 15:52:33 --> Total execution time: 0.0379
DEBUG - 2023-09-07 15:52:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 15:52:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 15:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 15:52:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 15:52:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 15:52:47 --> Total execution time: 0.0410
DEBUG - 2023-09-07 15:52:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 15:52:48 --> No URI present. Default controller set.
DEBUG - 2023-09-07 15:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 15:52:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 15:52:48 --> initController - LoginPage.php
DEBUG - 2023-09-07 15:52:48 --> Total execution time: 0.0354
DEBUG - 2023-09-07 15:52:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 15:52:48 --> No URI present. Default controller set.
DEBUG - 2023-09-07 15:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 15:52:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 15:52:48 --> initController - LoginPage.php
DEBUG - 2023-09-07 15:52:48 --> Total execution time: 0.0351
DEBUG - 2023-09-07 15:52:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 15:52:48 --> No URI present. Default controller set.
DEBUG - 2023-09-07 15:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 15:52:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 15:52:48 --> initController - LoginPage.php
DEBUG - 2023-09-07 15:52:48 --> Total execution time: 0.0338
DEBUG - 2023-09-07 15:52:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 15:52:49 --> No URI present. Default controller set.
DEBUG - 2023-09-07 15:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 15:52:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 15:52:49 --> initController - LoginPage.php
DEBUG - 2023-09-07 15:52:49 --> Total execution time: 0.0327
DEBUG - 2023-09-07 15:52:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 15:52:49 --> No URI present. Default controller set.
DEBUG - 2023-09-07 15:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 15:52:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 15:52:49 --> initController - LoginPage.php
DEBUG - 2023-09-07 15:52:49 --> Total execution time: 0.0345
DEBUG - 2023-09-07 15:52:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 15:52:49 --> No URI present. Default controller set.
DEBUG - 2023-09-07 15:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 15:52:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 15:52:49 --> initController - LoginPage.php
DEBUG - 2023-09-07 15:52:49 --> Total execution time: 0.0341
DEBUG - 2023-09-07 15:52:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 15:52:49 --> No URI present. Default controller set.
DEBUG - 2023-09-07 15:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 15:52:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 15:52:49 --> initController - LoginPage.php
DEBUG - 2023-09-07 15:52:49 --> Total execution time: 0.0356
DEBUG - 2023-09-07 15:52:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 15:52:49 --> No URI present. Default controller set.
DEBUG - 2023-09-07 15:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 15:52:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 15:52:49 --> initController - LoginPage.php
DEBUG - 2023-09-07 15:52:49 --> Total execution time: 0.0365
DEBUG - 2023-09-07 15:52:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 15:52:50 --> No URI present. Default controller set.
DEBUG - 2023-09-07 15:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 15:52:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 15:52:50 --> initController - LoginPage.php
DEBUG - 2023-09-07 15:52:50 --> Total execution time: 0.0348
DEBUG - 2023-09-07 15:52:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 15:52:50 --> No URI present. Default controller set.
DEBUG - 2023-09-07 15:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 15:52:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 15:52:50 --> initController - LoginPage.php
DEBUG - 2023-09-07 15:52:50 --> Total execution time: 0.0342
DEBUG - 2023-09-07 15:53:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 15:53:00 --> No URI present. Default controller set.
DEBUG - 2023-09-07 15:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 15:53:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 15:53:00 --> initController - LoginPage.php
DEBUG - 2023-09-07 15:53:00 --> Total execution time: 0.0400
DEBUG - 2023-09-07 15:53:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 15:53:02 --> No URI present. Default controller set.
DEBUG - 2023-09-07 15:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 15:53:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 15:53:02 --> initController - LoginPage.php
DEBUG - 2023-09-07 15:53:02 --> Total execution time: 0.0435
DEBUG - 2023-09-07 15:53:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 15:53:03 --> No URI present. Default controller set.
DEBUG - 2023-09-07 15:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 15:53:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 15:53:03 --> initController - LoginPage.php
DEBUG - 2023-09-07 15:53:03 --> Total execution time: 0.0367
DEBUG - 2023-09-07 15:53:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 15:53:03 --> No URI present. Default controller set.
DEBUG - 2023-09-07 15:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 15:53:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 15:53:03 --> initController - LoginPage.php
DEBUG - 2023-09-07 15:53:03 --> Total execution time: 0.0435
DEBUG - 2023-09-07 15:53:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 15:53:03 --> No URI present. Default controller set.
DEBUG - 2023-09-07 15:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 15:53:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 15:53:03 --> initController - LoginPage.php
DEBUG - 2023-09-07 15:53:03 --> Total execution time: 0.0329
DEBUG - 2023-09-07 15:53:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 15:53:03 --> No URI present. Default controller set.
DEBUG - 2023-09-07 15:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 15:53:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 15:53:03 --> initController - LoginPage.php
DEBUG - 2023-09-07 15:53:03 --> Total execution time: 0.0581
DEBUG - 2023-09-07 15:53:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 15:53:04 --> No URI present. Default controller set.
DEBUG - 2023-09-07 15:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 15:53:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 15:53:04 --> initController - LoginPage.php
DEBUG - 2023-09-07 15:53:04 --> Total execution time: 0.0338
DEBUG - 2023-09-07 15:53:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 15:53:04 --> No URI present. Default controller set.
DEBUG - 2023-09-07 15:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 15:53:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 15:53:04 --> initController - LoginPage.php
DEBUG - 2023-09-07 15:53:04 --> Total execution time: 0.0364
DEBUG - 2023-09-07 15:53:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 15:53:04 --> No URI present. Default controller set.
DEBUG - 2023-09-07 15:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 15:53:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 15:53:04 --> initController - LoginPage.php
DEBUG - 2023-09-07 15:53:04 --> Total execution time: 0.0342
DEBUG - 2023-09-07 15:53:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 15:53:04 --> No URI present. Default controller set.
DEBUG - 2023-09-07 15:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 15:53:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 15:53:04 --> initController - LoginPage.php
DEBUG - 2023-09-07 15:53:04 --> Total execution time: 0.0342
DEBUG - 2023-09-07 15:53:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 15:53:05 --> No URI present. Default controller set.
DEBUG - 2023-09-07 15:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 15:53:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 15:53:05 --> initController - LoginPage.php
DEBUG - 2023-09-07 15:53:05 --> Total execution time: 0.0439
DEBUG - 2023-09-07 15:53:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 15:53:05 --> No URI present. Default controller set.
DEBUG - 2023-09-07 15:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 15:53:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 15:53:05 --> initController - LoginPage.php
DEBUG - 2023-09-07 15:53:05 --> Total execution time: 0.0334
DEBUG - 2023-09-07 15:53:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 15:53:05 --> No URI present. Default controller set.
DEBUG - 2023-09-07 15:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 15:53:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 15:53:05 --> initController - LoginPage.php
DEBUG - 2023-09-07 15:53:05 --> Total execution time: 0.0402
DEBUG - 2023-09-07 15:53:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 15:53:05 --> No URI present. Default controller set.
DEBUG - 2023-09-07 15:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 15:53:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 15:53:06 --> initController - LoginPage.php
DEBUG - 2023-09-07 15:53:06 --> Total execution time: 0.0353
DEBUG - 2023-09-07 15:53:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 15:53:06 --> No URI present. Default controller set.
DEBUG - 2023-09-07 15:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 15:53:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 15:53:06 --> initController - LoginPage.php
DEBUG - 2023-09-07 15:53:06 --> Total execution time: 0.0328
DEBUG - 2023-09-07 15:53:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 15:53:06 --> No URI present. Default controller set.
DEBUG - 2023-09-07 15:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 15:53:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 15:53:06 --> initController - LoginPage.php
DEBUG - 2023-09-07 15:53:06 --> Total execution time: 0.0330
DEBUG - 2023-09-07 15:53:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 15:53:06 --> No URI present. Default controller set.
DEBUG - 2023-09-07 15:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 15:53:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 15:53:06 --> initController - LoginPage.php
DEBUG - 2023-09-07 15:53:06 --> Total execution time: 0.0324
DEBUG - 2023-09-07 16:23:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:23:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:23:30 --> 404 Page Not Found: LoginView/index
DEBUG - 2023-09-07 16:23:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:23:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:23:39 --> 404 Page Not Found: Login/index
DEBUG - 2023-09-07 16:23:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:23:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:23:50 --> 404 Page Not Found: Login/index
DEBUG - 2023-09-07 16:24:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:24:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:24:17 --> 404 Page Not Found: Login/index
DEBUG - 2023-09-07 16:29:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:29:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 16:29:03 --> Total execution time: 0.0365
DEBUG - 2023-09-07 16:29:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:29:03 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-07 16:29:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:29:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:29:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:29:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:29:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:29:03 --> UTF-8 Support Enabled
ERROR - 2023-09-07 16:29:03 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-07 16:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:29:03 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-07 16:29:03 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-07 16:29:03 --> 404 Page Not Found: Js/main.js
ERROR - 2023-09-07 16:29:03 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-07 16:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:29:03 --> 404 Page Not Found: Js/script.js
DEBUG - 2023-09-07 16:29:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:29:03 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-07 16:29:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:29:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:29:38 --> 404 Page Not Found: LoginView/index
DEBUG - 2023-09-07 16:29:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:29:40 --> No URI present. Default controller set.
DEBUG - 2023-09-07 16:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:29:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 16:29:40 --> initController - LoginPage.php
DEBUG - 2023-09-07 16:29:40 --> Total execution time: 0.0330
DEBUG - 2023-09-07 16:29:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:29:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 16:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:29:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 16:29:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 16:29:47 --> Total execution time: 0.0340
DEBUG - 2023-09-07 16:31:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:31:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:31:03 --> 404 Page Not Found: Loginhtml/index
DEBUG - 2023-09-07 16:31:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:31:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 16:31:08 --> Total execution time: 0.0290
DEBUG - 2023-09-07 16:33:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:33:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 16:33:03 --> Total execution time: 0.0287
DEBUG - 2023-09-07 16:44:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:44:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 16:44:01 --> Total execution time: 0.0496
DEBUG - 2023-09-07 16:44:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:44:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 16:44:50 --> Total execution time: 0.0451
DEBUG - 2023-09-07 16:44:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:44:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 16:44:54 --> Total execution time: 0.0462
DEBUG - 2023-09-07 16:44:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:44:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 16:44:55 --> Total execution time: 0.0474
DEBUG - 2023-09-07 16:44:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:44:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 16:44:55 --> Total execution time: 0.0449
DEBUG - 2023-09-07 16:44:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:44:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 16:44:55 --> Total execution time: 0.0595
DEBUG - 2023-09-07 16:44:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:44:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 16:44:55 --> Total execution time: 0.0523
DEBUG - 2023-09-07 16:44:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:44:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 16:44:55 --> Total execution time: 0.0463
DEBUG - 2023-09-07 16:44:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:44:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 16:44:56 --> Total execution time: 0.0456
DEBUG - 2023-09-07 16:44:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:44:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 16:44:56 --> Total execution time: 0.0472
DEBUG - 2023-09-07 16:44:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:44:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 16:44:56 --> Total execution time: 0.0454
DEBUG - 2023-09-07 16:44:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:44:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 16:44:56 --> Total execution time: 0.0498
DEBUG - 2023-09-07 16:44:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:44:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 16:44:57 --> Total execution time: 0.0437
DEBUG - 2023-09-07 16:44:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:44:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 16:44:57 --> Total execution time: 0.0448
DEBUG - 2023-09-07 16:44:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:44:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 16:44:57 --> Total execution time: 0.0469
DEBUG - 2023-09-07 16:44:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:44:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 16:44:57 --> Total execution time: 0.0454
DEBUG - 2023-09-07 16:45:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:45:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 16:45:56 --> Total execution time: 0.0497
DEBUG - 2023-09-07 16:49:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:49:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 16:49:46 --> Total execution time: 0.0538
DEBUG - 2023-09-07 16:49:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:49:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 16:49:48 --> Total execution time: 0.0535
DEBUG - 2023-09-07 16:49:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:49:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:49:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:49:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:49:48 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-07 16:49:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:49:48 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-07 16:49:48 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-07 16:49:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:49:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:49:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:49:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:49:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:49:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:49:48 --> 404 Page Not Found: Js/script.js
ERROR - 2023-09-07 16:49:48 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-07 16:49:48 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-07 16:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:49:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:49:48 --> 404 Page Not Found: Js/main.js
ERROR - 2023-09-07 16:49:48 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-07 16:49:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:49:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:49:48 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-07 16:51:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:51:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 16:51:36 --> Total execution time: 0.0455
DEBUG - 2023-09-07 16:51:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:51:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 16:51:43 --> Total execution time: 0.0497
DEBUG - 2023-09-07 16:51:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:51:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:51:43 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-07 16:51:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:51:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:51:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:51:43 --> UTF-8 Support Enabled
ERROR - 2023-09-07 16:51:43 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-07 16:51:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:51:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:51:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:51:43 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-07 16:51:43 --> 404 Page Not Found: Js/script.js
ERROR - 2023-09-07 16:51:43 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-07 16:51:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:51:43 --> 404 Page Not Found: Js/main.js
DEBUG - 2023-09-07 16:51:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:51:43 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-07 16:51:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:51:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:51:43 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-07 16:52:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:52:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 16:52:31 --> Total execution time: 0.0512
DEBUG - 2023-09-07 16:52:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:52:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:52:31 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-07 16:52:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:52:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:52:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:52:31 --> UTF-8 Support Enabled
ERROR - 2023-09-07 16:52:31 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-07 16:52:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:52:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:52:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:52:31 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-07 16:52:31 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-07 16:52:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:52:31 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-07 16:52:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:52:31 --> 404 Page Not Found: Js/main.js
ERROR - 2023-09-07 16:52:31 --> 404 Page Not Found: Js/script.js
DEBUG - 2023-09-07 16:52:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:52:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:52:31 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-07 16:52:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:52:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:52:32 --> 404 Page Not Found: Login_template/index
DEBUG - 2023-09-07 16:52:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:52:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 16:52:37 --> Total execution time: 0.0565
DEBUG - 2023-09-07 16:52:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:52:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:52:37 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-07 16:52:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:52:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:52:37 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-07 16:52:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:52:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:52:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:52:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:52:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:52:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:52:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:52:37 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-07 16:52:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:52:37 --> 404 Page Not Found: Assets/images
ERROR - 2023-09-07 16:52:37 --> 404 Page Not Found: Js/main.js
DEBUG - 2023-09-07 16:52:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:52:37 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-07 16:52:37 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-07 16:52:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:52:37 --> 404 Page Not Found: Js/script.js
DEBUG - 2023-09-07 16:52:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:52:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:52:37 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-07 16:52:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:52:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 16:52:37 --> Total execution time: 0.0516
DEBUG - 2023-09-07 16:52:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:52:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:52:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:52:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:52:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:52:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:52:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:52:37 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-07 16:52:37 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-07 16:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:52:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:52:37 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-07 16:52:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:52:37 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-07 16:52:37 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-07 16:52:37 --> 404 Page Not Found: Js/main.js
DEBUG - 2023-09-07 16:52:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:52:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:52:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:52:37 --> 404 Page Not Found: Assets/images
ERROR - 2023-09-07 16:52:37 --> 404 Page Not Found: Js/script.js
DEBUG - 2023-09-07 16:52:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:52:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:52:37 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-07 16:52:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:52:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 16:52:38 --> Total execution time: 0.0512
DEBUG - 2023-09-07 16:52:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:52:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:52:40 --> 404 Page Not Found: Login_template/index
DEBUG - 2023-09-07 16:54:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:54:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 16:54:36 --> Total execution time: 0.0700
DEBUG - 2023-09-07 16:54:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:54:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:54:38 --> 404 Page Not Found: Login_template/index
DEBUG - 2023-09-07 16:54:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:54:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 16:54:41 --> Total execution time: 0.0490
DEBUG - 2023-09-07 16:54:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 16:54:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 16:54:42 --> Total execution time: 0.0470
DEBUG - 2023-09-07 16:54:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 16:54:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 16:54:44 --> 404 Page Not Found: Login_template/index
DEBUG - 2023-09-07 17:02:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:02:38 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:02:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:02:38 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:02:38 --> Total execution time: 0.0548
DEBUG - 2023-09-07 17:02:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:02:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:02:40 --> Total execution time: 0.0554
DEBUG - 2023-09-07 17:02:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:02:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:02:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:02:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:02:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:02:40 --> UTF-8 Support Enabled
ERROR - 2023-09-07 17:02:40 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-07 17:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:02:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 17:02:40 --> 404 Page Not Found: Js/main.js
ERROR - 2023-09-07 17:02:40 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-07 17:02:40 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-07 17:02:40 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-07 17:02:40 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-07 17:02:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:02:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:02:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 17:02:40 --> 404 Page Not Found: Js/script.js
DEBUG - 2023-09-07 17:02:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 17:02:40 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-07 17:02:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:02:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 17:02:41 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-07 17:08:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:08:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:08:57 --> Total execution time: 0.0722
DEBUG - 2023-09-07 17:08:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:08:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:08:59 --> Total execution time: 0.0689
DEBUG - 2023-09-07 17:08:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:08:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:08:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:08:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:08:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 17:08:59 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-07 17:08:59 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-07 17:08:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 17:08:59 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-07 17:08:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 17:08:59 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-07 17:08:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:08:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:08:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:08:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:08:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 17:08:59 --> 404 Page Not Found: Js/script.js
ERROR - 2023-09-07 17:08:59 --> 404 Page Not Found: Assets/js
ERROR - 2023-09-07 17:08:59 --> 404 Page Not Found: Js/main.js
DEBUG - 2023-09-07 17:08:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 17:08:59 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-07 17:08:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:08:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 17:08:59 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-07 17:09:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:09:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:09:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:09:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:09:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 17:09:11 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-07 17:09:11 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-07 17:09:11 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-07 17:09:11 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-07 17:09:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:09:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:09:17 --> Total execution time: 0.0713
DEBUG - 2023-09-07 17:09:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:09:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 17:09:17 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-07 17:09:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:09:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:09:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:09:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:09:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:09:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 17:09:17 --> 404 Page Not Found: Assets/css
ERROR - 2023-09-07 17:09:17 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-07 17:09:17 --> UTF-8 Support Enabled
ERROR - 2023-09-07 17:09:17 --> 404 Page Not Found: Js/script.js
DEBUG - 2023-09-07 17:09:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 17:09:17 --> 404 Page Not Found: Assets/js
DEBUG - 2023-09-07 17:09:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 17:09:17 --> 404 Page Not Found: Assets/css
DEBUG - 2023-09-07 17:09:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 17:09:17 --> 404 Page Not Found: Js/main.js
DEBUG - 2023-09-07 17:09:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:09:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 17:09:17 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-07 17:09:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:09:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-07 17:09:18 --> 404 Page Not Found: Assets/images
DEBUG - 2023-09-07 17:09:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:09:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:09:44 --> Total execution time: 0.0771
DEBUG - 2023-09-07 17:18:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:36 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:36 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:36 --> Total execution time: 0.0706
DEBUG - 2023-09-07 17:18:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:36 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:36 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:36 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:36 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:36 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:36 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:36 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:36 --> Total execution time: 0.0891
DEBUG - 2023-09-07 17:18:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:36 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:36 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:36 --> Total execution time: 0.0918
DEBUG - 2023-09-07 17:18:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:36 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:36 --> Total execution time: 0.0905
DEBUG - 2023-09-07 17:18:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:36 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:36 --> Total execution time: 0.1050
DEBUG - 2023-09-07 17:18:36 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:36 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:36 --> Total execution time: 0.1191
DEBUG - 2023-09-07 17:18:36 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:36 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:36 --> Total execution time: 0.1355
DEBUG - 2023-09-07 17:18:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:36 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:36 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:36 --> Total execution time: 0.0993
DEBUG - 2023-09-07 17:18:36 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:36 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:36 --> Total execution time: 0.0841
DEBUG - 2023-09-07 17:18:36 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:36 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:36 --> Total execution time: 0.0843
DEBUG - 2023-09-07 17:18:36 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:36 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:36 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:36 --> Total execution time: 0.0811
DEBUG - 2023-09-07 17:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:36 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:36 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:36 --> Total execution time: 0.0970
DEBUG - 2023-09-07 17:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:37 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:37 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:37 --> Total execution time: 0.0924
DEBUG - 2023-09-07 17:18:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:37 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:37 --> Total execution time: 0.0910
DEBUG - 2023-09-07 17:18:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:37 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:37 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:37 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:37 --> Total execution time: 0.0961
DEBUG - 2023-09-07 17:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:37 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:37 --> Total execution time: 0.1169
DEBUG - 2023-09-07 17:18:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:37 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:37 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:37 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:37 --> Total execution time: 0.1122
DEBUG - 2023-09-07 17:18:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:37 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:37 --> Total execution time: 0.1005
DEBUG - 2023-09-07 17:18:37 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:37 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:37 --> Total execution time: 0.1118
DEBUG - 2023-09-07 17:18:37 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:37 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:37 --> Total execution time: 0.0814
DEBUG - 2023-09-07 17:18:37 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:37 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:37 --> Total execution time: 0.0962
DEBUG - 2023-09-07 17:18:37 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:37 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:37 --> Total execution time: 0.0847
DEBUG - 2023-09-07 17:18:37 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:37 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:37 --> Total execution time: 0.0847
DEBUG - 2023-09-07 17:18:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:37 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:37 --> Total execution time: 0.0779
DEBUG - 2023-09-07 17:18:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:37 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:37 --> Total execution time: 0.0762
DEBUG - 2023-09-07 17:18:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:37 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:37 --> Total execution time: 0.0746
DEBUG - 2023-09-07 17:18:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:37 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:37 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:37 --> Total execution time: 0.0695
DEBUG - 2023-09-07 17:18:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:44 --> Total execution time: 0.0668
DEBUG - 2023-09-07 17:18:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:44 --> Total execution time: 0.0846
DEBUG - 2023-09-07 17:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:44 --> Total execution time: 0.0830
DEBUG - 2023-09-07 17:18:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:44 --> Total execution time: 0.0903
DEBUG - 2023-09-07 17:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:44 --> Total execution time: 0.0957
DEBUG - 2023-09-07 17:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:44 --> Total execution time: 0.1001
DEBUG - 2023-09-07 17:18:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:44 --> Total execution time: 0.1158
DEBUG - 2023-09-07 17:18:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:44 --> Total execution time: 0.0830
DEBUG - 2023-09-07 17:18:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:44 --> Total execution time: 0.0771
DEBUG - 2023-09-07 17:18:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:44 --> Total execution time: 0.0780
DEBUG - 2023-09-07 17:18:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:44 --> Total execution time: 0.0769
DEBUG - 2023-09-07 17:18:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:44 --> Total execution time: 0.0811
DEBUG - 2023-09-07 17:18:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:44 --> Total execution time: 0.0811
DEBUG - 2023-09-07 17:18:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:44 --> Total execution time: 0.0783
DEBUG - 2023-09-07 17:18:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:44 --> Total execution time: 0.0788
DEBUG - 2023-09-07 17:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:44 --> Total execution time: 0.0774
DEBUG - 2023-09-07 17:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:44 --> Total execution time: 0.0812
DEBUG - 2023-09-07 17:18:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:44 --> Total execution time: 0.0711
DEBUG - 2023-09-07 17:18:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:44 --> Total execution time: 0.0800
DEBUG - 2023-09-07 17:18:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:44 --> Total execution time: 0.0793
DEBUG - 2023-09-07 17:18:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:44 --> Total execution time: 0.0770
DEBUG - 2023-09-07 17:18:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:44 --> Total execution time: 0.0754
DEBUG - 2023-09-07 17:18:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:44 --> Total execution time: 0.0706
DEBUG - 2023-09-07 17:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:44 --> Total execution time: 0.0709
DEBUG - 2023-09-07 17:18:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:45 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:45 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:45 --> Total execution time: 0.0686
DEBUG - 2023-09-07 17:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:45 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:45 --> Total execution time: 0.0689
DEBUG - 2023-09-07 17:18:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:45 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:45 --> Total execution time: 0.0674
DEBUG - 2023-09-07 17:18:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:47 --> Total execution time: 0.0634
DEBUG - 2023-09-07 17:18:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:47 --> Total execution time: 0.0775
DEBUG - 2023-09-07 17:18:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:47 --> Total execution time: 0.0870
DEBUG - 2023-09-07 17:18:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:47 --> Total execution time: 0.0933
DEBUG - 2023-09-07 17:18:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:47 --> Total execution time: 0.1078
DEBUG - 2023-09-07 17:18:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:47 --> Total execution time: 0.1239
DEBUG - 2023-09-07 17:18:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:47 --> Total execution time: 0.1398
DEBUG - 2023-09-07 17:18:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:47 --> Total execution time: 0.0982
DEBUG - 2023-09-07 17:18:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:47 --> Total execution time: 0.0795
DEBUG - 2023-09-07 17:18:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:47 --> Total execution time: 0.0730
DEBUG - 2023-09-07 17:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:47 --> Total execution time: 0.1059
DEBUG - 2023-09-07 17:18:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:47 --> Total execution time: 0.0883
DEBUG - 2023-09-07 17:18:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:47 --> Total execution time: 0.0901
DEBUG - 2023-09-07 17:18:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:47 --> Total execution time: 0.0917
DEBUG - 2023-09-07 17:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:47 --> Total execution time: 0.0920
DEBUG - 2023-09-07 17:18:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:47 --> Total execution time: 0.0897
DEBUG - 2023-09-07 17:18:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:47 --> Total execution time: 0.0814
DEBUG - 2023-09-07 17:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:47 --> Total execution time: 0.0912
DEBUG - 2023-09-07 17:18:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:47 --> Total execution time: 0.1092
DEBUG - 2023-09-07 17:18:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:47 --> Total execution time: 0.1051
DEBUG - 2023-09-07 17:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:47 --> Total execution time: 0.0999
DEBUG - 2023-09-07 17:18:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:47 --> Total execution time: 0.0931
DEBUG - 2023-09-07 17:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:47 --> Total execution time: 0.0707
DEBUG - 2023-09-07 17:18:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:47 --> Total execution time: 0.0844
DEBUG - 2023-09-07 17:18:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:47 --> Total execution time: 0.0706
DEBUG - 2023-09-07 17:18:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:47 --> Total execution time: 0.0615
DEBUG - 2023-09-07 17:18:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:48 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:48 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:48 --> Total execution time: 0.0700
DEBUG - 2023-09-07 17:18:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:49 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:49 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:49 --> Total execution time: 0.0678
DEBUG - 2023-09-07 17:18:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:49 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:49 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:49 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:49 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:49 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:49 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:49 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:49 --> Total execution time: 0.0739
DEBUG - 2023-09-07 17:18:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:49 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:49 --> Total execution time: 0.0834
DEBUG - 2023-09-07 17:18:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:49 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:49 --> Total execution time: 0.0997
DEBUG - 2023-09-07 17:18:49 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:49 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:49 --> Total execution time: 0.1123
DEBUG - 2023-09-07 17:18:49 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:49 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:49 --> Total execution time: 0.1153
DEBUG - 2023-09-07 17:18:49 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:49 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:49 --> Total execution time: 0.1119
DEBUG - 2023-09-07 17:18:49 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:49 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:49 --> Total execution time: 0.0723
DEBUG - 2023-09-07 17:18:49 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:49 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:49 --> Total execution time: 0.0802
DEBUG - 2023-09-07 17:18:49 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:49 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:49 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:49 --> Total execution time: 0.0814
DEBUG - 2023-09-07 17:18:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:49 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:49 --> Total execution time: 0.0851
DEBUG - 2023-09-07 17:18:49 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:49 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:49 --> Total execution time: 0.0870
DEBUG - 2023-09-07 17:18:49 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:49 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:49 --> Total execution time: 0.0842
DEBUG - 2023-09-07 17:18:49 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:49 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:49 --> Total execution time: 0.0853
DEBUG - 2023-09-07 17:18:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:49 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:49 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:49 --> Total execution time: 0.0789
DEBUG - 2023-09-07 17:18:49 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:49 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:49 --> Total execution time: 0.0785
DEBUG - 2023-09-07 17:18:49 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:49 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:49 --> Total execution time: 0.0804
DEBUG - 2023-09-07 17:18:49 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:49 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:49 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:49 --> Total execution time: 0.0732
DEBUG - 2023-09-07 17:18:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:49 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:49 --> Total execution time: 0.0790
DEBUG - 2023-09-07 17:18:49 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:49 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:49 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:49 --> Total execution time: 0.0812
DEBUG - 2023-09-07 17:18:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:49 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:49 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:49 --> Total execution time: 0.1093
DEBUG - 2023-09-07 17:18:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:49 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:49 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:49 --> Total execution time: 0.1036
DEBUG - 2023-09-07 17:18:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:49 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:49 --> Total execution time: 0.0988
DEBUG - 2023-09-07 17:18:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:49 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:49 --> Total execution time: 0.0975
DEBUG - 2023-09-07 17:18:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:49 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:49 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:49 --> Total execution time: 0.0888
DEBUG - 2023-09-07 17:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:49 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:49 --> Total execution time: 0.0822
DEBUG - 2023-09-07 17:18:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:49 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:49 --> Total execution time: 0.0629
DEBUG - 2023-09-07 17:18:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:50 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:50 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:50 --> Total execution time: 0.0654
DEBUG - 2023-09-07 17:18:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:18:55 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:18:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:18:55 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:18:55 --> Total execution time: 0.0650
DEBUG - 2023-09-07 17:19:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:06 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:06 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:06 --> Total execution time: 0.0741
DEBUG - 2023-09-07 17:19:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:06 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:06 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:06 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:06 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:06 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:06 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:06 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:06 --> Total execution time: 0.1102
DEBUG - 2023-09-07 17:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:06 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:06 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:06 --> Total execution time: 0.1076
DEBUG - 2023-09-07 17:19:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:06 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:06 --> Total execution time: 0.1379
DEBUG - 2023-09-07 17:19:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:06 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:06 --> Total execution time: 0.1415
DEBUG - 2023-09-07 17:19:06 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:06 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:06 --> Total execution time: 0.1570
DEBUG - 2023-09-07 17:19:06 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:06 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:06 --> Total execution time: 0.1684
DEBUG - 2023-09-07 17:19:06 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:06 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:06 --> Total execution time: 0.1181
DEBUG - 2023-09-07 17:19:06 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:06 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:06 --> Total execution time: 0.0824
DEBUG - 2023-09-07 17:19:06 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:06 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:06 --> Total execution time: 0.0816
DEBUG - 2023-09-07 17:19:06 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:06 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:06 --> Total execution time: 0.0830
DEBUG - 2023-09-07 17:19:06 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:06 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:06 --> Total execution time: 0.0843
DEBUG - 2023-09-07 17:19:06 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:06 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:06 --> Total execution time: 0.0854
DEBUG - 2023-09-07 17:19:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:06 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:06 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:06 --> Total execution time: 0.0827
DEBUG - 2023-09-07 17:19:06 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:06 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:06 --> Total execution time: 0.0816
DEBUG - 2023-09-07 17:19:06 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:06 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:06 --> Total execution time: 0.0835
DEBUG - 2023-09-07 17:19:06 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:06 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:06 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:06 --> Total execution time: 0.0801
DEBUG - 2023-09-07 17:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:06 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:06 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:06 --> Total execution time: 0.0898
DEBUG - 2023-09-07 17:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:06 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:06 --> Total execution time: 0.0888
DEBUG - 2023-09-07 17:19:06 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:06 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:06 --> Total execution time: 0.0885
DEBUG - 2023-09-07 17:19:06 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:06 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:06 --> Total execution time: 0.0829
DEBUG - 2023-09-07 17:19:06 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:06 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:06 --> Total execution time: 0.0812
DEBUG - 2023-09-07 17:19:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:06 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:06 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:06 --> Total execution time: 0.0726
DEBUG - 2023-09-07 17:19:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:06 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:06 --> Total execution time: 0.0715
DEBUG - 2023-09-07 17:19:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:06 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:06 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:06 --> Total execution time: 0.0709
DEBUG - 2023-09-07 17:19:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:06 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:06 --> Total execution time: 0.0695
DEBUG - 2023-09-07 17:19:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:07 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:07 --> Total execution time: 0.0659
DEBUG - 2023-09-07 17:19:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:13 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:13 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:13 --> Total execution time: 0.0985
DEBUG - 2023-09-07 17:19:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:23 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:23 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:23 --> Total execution time: 0.0803
DEBUG - 2023-09-07 17:19:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:26 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:26 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:26 --> Total execution time: 0.0729
DEBUG - 2023-09-07 17:19:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:26 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:26 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:26 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:26 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:26 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:26 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:26 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:26 --> Total execution time: 0.0904
DEBUG - 2023-09-07 17:19:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:26 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:26 --> Total execution time: 0.0827
DEBUG - 2023-09-07 17:19:26 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:26 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:26 --> Total execution time: 0.0801
DEBUG - 2023-09-07 17:19:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:26 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:26 --> Total execution time: 0.0967
DEBUG - 2023-09-07 17:19:26 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:26 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:26 --> Total execution time: 0.1126
DEBUG - 2023-09-07 17:19:26 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:26 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:26 --> Total execution time: 0.1270
DEBUG - 2023-09-07 17:19:26 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:26 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:26 --> Total execution time: 0.0965
DEBUG - 2023-09-07 17:19:26 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:26 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:26 --> Total execution time: 0.0822
DEBUG - 2023-09-07 17:19:26 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:26 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:26 --> Total execution time: 0.0819
DEBUG - 2023-09-07 17:19:26 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:26 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:26 --> Total execution time: 0.0799
DEBUG - 2023-09-07 17:19:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:26 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:26 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:26 --> Total execution time: 0.0807
DEBUG - 2023-09-07 17:19:26 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:26 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:26 --> Total execution time: 0.0813
DEBUG - 2023-09-07 17:19:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:26 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:26 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:26 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:26 --> Total execution time: 0.0790
DEBUG - 2023-09-07 17:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:26 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:26 --> Total execution time: 0.0733
DEBUG - 2023-09-07 17:19:26 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:26 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:26 --> Total execution time: 0.0767
DEBUG - 2023-09-07 17:19:26 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:26 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:26 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:26 --> Total execution time: 0.0698
DEBUG - 2023-09-07 17:19:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:26 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:26 --> Total execution time: 0.0877
DEBUG - 2023-09-07 17:19:26 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:26 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:26 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:26 --> Total execution time: 0.0870
DEBUG - 2023-09-07 17:19:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:26 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:26 --> Total execution time: 0.0865
DEBUG - 2023-09-07 17:19:26 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:27 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:27 --> Total execution time: 0.0869
DEBUG - 2023-09-07 17:19:27 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:27 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:27 --> Total execution time: 0.0848
DEBUG - 2023-09-07 17:19:27 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:27 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:27 --> Total execution time: 0.0818
DEBUG - 2023-09-07 17:19:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:27 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:27 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:27 --> Total execution time: 0.0915
DEBUG - 2023-09-07 17:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:27 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:27 --> Total execution time: 0.0792
DEBUG - 2023-09-07 17:19:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:27 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:27 --> Total execution time: 0.1053
DEBUG - 2023-09-07 17:19:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:27 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:27 --> Total execution time: 0.0691
DEBUG - 2023-09-07 17:19:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:19:38 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:19:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:19:38 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:19:38 --> Total execution time: 0.0656
DEBUG - 2023-09-07 17:22:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:43 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:43 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:43 --> Total execution time: 0.0679
DEBUG - 2023-09-07 17:22:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:43 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:43 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:43 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:43 --> Total execution time: 0.0966
DEBUG - 2023-09-07 17:22:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:43 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:43 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:43 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:43 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:43 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:43 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:43 --> Total execution time: 0.0911
DEBUG - 2023-09-07 17:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:43 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:43 --> Total execution time: 0.1054
DEBUG - 2023-09-07 17:22:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:43 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:43 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:43 --> Total execution time: 0.1075
DEBUG - 2023-09-07 17:22:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:43 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:43 --> Total execution time: 0.1089
DEBUG - 2023-09-07 17:22:43 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:43 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:43 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:43 --> Total execution time: 0.1224
DEBUG - 2023-09-07 17:22:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:43 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:43 --> Total execution time: 0.1132
DEBUG - 2023-09-07 17:22:43 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:43 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:43 --> Total execution time: 0.0876
DEBUG - 2023-09-07 17:22:43 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:43 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:43 --> Total execution time: 0.0848
DEBUG - 2023-09-07 17:22:43 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:43 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:43 --> Total execution time: 0.0908
DEBUG - 2023-09-07 17:22:43 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:43 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:43 --> Total execution time: 0.0909
DEBUG - 2023-09-07 17:22:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:43 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:43 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:43 --> Total execution time: 0.0906
DEBUG - 2023-09-07 17:22:43 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:43 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:43 --> Total execution time: 0.0894
DEBUG - 2023-09-07 17:22:43 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:43 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:43 --> Total execution time: 0.0841
DEBUG - 2023-09-07 17:22:43 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:43 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:43 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:43 --> Total execution time: 0.0798
DEBUG - 2023-09-07 17:22:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:43 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:43 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:43 --> Total execution time: 0.0899
DEBUG - 2023-09-07 17:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:43 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:43 --> Total execution time: 0.0892
DEBUG - 2023-09-07 17:22:43 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:43 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:43 --> Total execution time: 0.0867
DEBUG - 2023-09-07 17:22:43 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:43 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:43 --> Total execution time: 0.0821
DEBUG - 2023-09-07 17:22:43 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:43 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:43 --> Total execution time: 0.0835
DEBUG - 2023-09-07 17:22:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:43 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:43 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:43 --> Total execution time: 0.0743
DEBUG - 2023-09-07 17:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:43 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:43 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:43 --> Total execution time: 0.0765
DEBUG - 2023-09-07 17:22:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:43 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:43 --> Total execution time: 0.0746
DEBUG - 2023-09-07 17:22:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:43 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:44 --> Total execution time: 0.0744
DEBUG - 2023-09-07 17:22:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:44 --> Total execution time: 0.0745
DEBUG - 2023-09-07 17:22:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:44 --> Total execution time: 0.0751
DEBUG - 2023-09-07 17:22:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:46 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:46 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:46 --> Total execution time: 0.0647
DEBUG - 2023-09-07 17:22:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:46 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:46 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:46 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:46 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:46 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:46 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:46 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:46 --> Total execution time: 0.0788
DEBUG - 2023-09-07 17:22:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:46 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:46 --> Total execution time: 0.0750
DEBUG - 2023-09-07 17:22:46 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:46 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:46 --> Total execution time: 0.0838
DEBUG - 2023-09-07 17:22:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:46 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:46 --> Total execution time: 0.0984
DEBUG - 2023-09-07 17:22:46 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:46 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:46 --> Total execution time: 0.1145
DEBUG - 2023-09-07 17:22:46 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:46 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:46 --> Total execution time: 0.1292
DEBUG - 2023-09-07 17:22:46 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:46 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:46 --> Total execution time: 0.0878
DEBUG - 2023-09-07 17:22:46 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:46 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:46 --> Total execution time: 0.0804
DEBUG - 2023-09-07 17:22:46 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:46 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:46 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:46 --> Total execution time: 0.0842
DEBUG - 2023-09-07 17:22:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:46 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:46 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:46 --> Total execution time: 0.0849
DEBUG - 2023-09-07 17:22:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:46 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:46 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:46 --> Total execution time: 0.0850
DEBUG - 2023-09-07 17:22:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:47 --> Total execution time: 0.0836
DEBUG - 2023-09-07 17:22:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:47 --> Total execution time: 0.0839
DEBUG - 2023-09-07 17:22:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:47 --> Total execution time: 0.0784
DEBUG - 2023-09-07 17:22:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:47 --> Total execution time: 0.0924
DEBUG - 2023-09-07 17:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:47 --> Total execution time: 0.1012
DEBUG - 2023-09-07 17:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:47 --> Total execution time: 0.1199
DEBUG - 2023-09-07 17:22:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:47 --> Total execution time: 0.1160
DEBUG - 2023-09-07 17:22:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:47 --> Total execution time: 0.1164
DEBUG - 2023-09-07 17:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:47 --> Total execution time: 0.1129
DEBUG - 2023-09-07 17:22:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:47 --> Total execution time: 0.0952
DEBUG - 2023-09-07 17:22:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:47 --> Total execution time: 0.0716
DEBUG - 2023-09-07 17:22:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:47 --> Total execution time: 0.0743
DEBUG - 2023-09-07 17:22:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:47 --> Total execution time: 0.0727
DEBUG - 2023-09-07 17:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:47 --> Total execution time: 0.0708
DEBUG - 2023-09-07 17:22:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:47 --> Total execution time: 0.0679
DEBUG - 2023-09-07 17:22:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:47 --> Total execution time: 0.0798
DEBUG - 2023-09-07 17:22:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:50 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:50 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:50 --> Total execution time: 0.0665
DEBUG - 2023-09-07 17:22:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:51 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:51 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:51 --> Total execution time: 0.0856
DEBUG - 2023-09-07 17:22:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:51 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:51 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:51 --> Total execution time: 0.0647
DEBUG - 2023-09-07 17:22:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:51 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:51 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:51 --> Total execution time: 0.0638
DEBUG - 2023-09-07 17:22:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:51 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:51 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:51 --> Total execution time: 0.0648
DEBUG - 2023-09-07 17:22:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:51 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:51 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:51 --> Total execution time: 0.0733
DEBUG - 2023-09-07 17:22:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:52 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:52 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:52 --> Total execution time: 0.0827
DEBUG - 2023-09-07 17:22:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:52 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:52 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:52 --> Total execution time: 0.0672
DEBUG - 2023-09-07 17:22:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:52 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:52 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:52 --> Total execution time: 0.0626
DEBUG - 2023-09-07 17:22:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:55 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:55 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:55 --> Total execution time: 0.0651
DEBUG - 2023-09-07 17:22:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:55 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:55 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:55 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:55 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:55 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:55 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:55 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:55 --> Total execution time: 0.0827
DEBUG - 2023-09-07 17:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:55 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:55 --> Total execution time: 0.1001
DEBUG - 2023-09-07 17:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:55 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:55 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:55 --> Total execution time: 0.0775
DEBUG - 2023-09-07 17:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:55 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:55 --> Total execution time: 0.0903
DEBUG - 2023-09-07 17:22:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:55 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:55 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:55 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:55 --> Total execution time: 0.1150
DEBUG - 2023-09-07 17:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:55 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:55 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:55 --> Total execution time: 0.1304
DEBUG - 2023-09-07 17:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:55 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:55 --> Total execution time: 0.1010
DEBUG - 2023-09-07 17:22:55 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:55 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:55 --> Total execution time: 0.0832
DEBUG - 2023-09-07 17:22:55 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:55 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:55 --> Total execution time: 0.1195
DEBUG - 2023-09-07 17:22:55 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:55 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:55 --> Total execution time: 0.0854
DEBUG - 2023-09-07 17:22:55 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:55 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:55 --> Total execution time: 0.0848
DEBUG - 2023-09-07 17:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:55 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:55 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:55 --> Total execution time: 0.0825
DEBUG - 2023-09-07 17:22:55 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:55 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:55 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:55 --> Total execution time: 0.0830
DEBUG - 2023-09-07 17:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:55 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:55 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:55 --> Total execution time: 0.0824
DEBUG - 2023-09-07 17:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:55 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:55 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:55 --> Total execution time: 0.0763
DEBUG - 2023-09-07 17:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:55 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:55 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:55 --> Total execution time: 0.0884
DEBUG - 2023-09-07 17:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:55 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:55 --> Total execution time: 0.0873
DEBUG - 2023-09-07 17:22:55 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:55 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:55 --> Total execution time: 0.0891
DEBUG - 2023-09-07 17:22:55 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:55 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:55 --> Total execution time: 0.0839
DEBUG - 2023-09-07 17:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:55 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:55 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:55 --> Total execution time: 0.0829
DEBUG - 2023-09-07 17:22:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:55 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:55 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:55 --> Total execution time: 0.0722
DEBUG - 2023-09-07 17:22:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:55 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:55 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:55 --> Total execution time: 0.0715
DEBUG - 2023-09-07 17:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:55 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:55 --> Total execution time: 0.0724
DEBUG - 2023-09-07 17:22:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 17:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:55 --> No URI present. Default controller set.
DEBUG - 2023-09-07 17:22:55 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:55 --> Total execution time: 0.0691
DEBUG - 2023-09-07 17:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 17:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:55 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:55 --> Total execution time: 0.0678
DEBUG - 2023-09-07 17:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 17:22:55 --> initController - LoginPage.php
DEBUG - 2023-09-07 17:22:55 --> Total execution time: 0.0642
DEBUG - 2023-09-07 19:41:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:41:02 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:41:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:41:02 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:41:02 --> Total execution time: 0.0623
DEBUG - 2023-09-07 19:41:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:41:26 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:41:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:41:26 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:41:26 --> Total execution time: 0.0462
DEBUG - 2023-09-07 19:42:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:42:28 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:42:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:42:28 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:42:28 --> Total execution time: 0.0734
DEBUG - 2023-09-07 19:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:42:32 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:42:32 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:42:32 --> Total execution time: 0.0793
DEBUG - 2023-09-07 19:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:42:32 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:42:32 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:42:32 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:42:32 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:42:32 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:42:32 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:42:32 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:42:32 --> Total execution time: 0.1130
DEBUG - 2023-09-07 19:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:42:32 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:42:32 --> Total execution time: 0.1093
DEBUG - 2023-09-07 19:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:42:32 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:42:32 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:42:32 --> Total execution time: 0.1136
DEBUG - 2023-09-07 19:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:42:32 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:42:32 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:42:32 --> Total execution time: 0.1312
DEBUG - 2023-09-07 19:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:42:32 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:42:32 --> Total execution time: 0.1474
DEBUG - 2023-09-07 19:42:32 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:42:32 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:42:32 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:42:32 --> Total execution time: 0.1535
DEBUG - 2023-09-07 19:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:42:32 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:42:32 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:42:32 --> Total execution time: 0.0682
DEBUG - 2023-09-07 19:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:42:32 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:42:32 --> Total execution time: 0.0680
DEBUG - 2023-09-07 19:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:42:32 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:42:32 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:42:32 --> Total execution time: 0.0682
DEBUG - 2023-09-07 19:42:32 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:42:32 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:42:32 --> Total execution time: 0.0682
DEBUG - 2023-09-07 19:42:32 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:42:32 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:42:32 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:42:32 --> Total execution time: 0.0684
DEBUG - 2023-09-07 19:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:42:32 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:42:32 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:42:32 --> Total execution time: 0.0649
DEBUG - 2023-09-07 19:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:42:32 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:42:32 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:42:32 --> Total execution time: 0.0643
DEBUG - 2023-09-07 19:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:42:32 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:42:32 --> Total execution time: 0.0644
DEBUG - 2023-09-07 19:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:42:32 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:42:32 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:42:32 --> Total execution time: 0.0648
DEBUG - 2023-09-07 19:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:42:32 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:42:32 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:42:32 --> Total execution time: 0.0638
DEBUG - 2023-09-07 19:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:42:32 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:42:32 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:42:32 --> Total execution time: 0.0610
DEBUG - 2023-09-07 19:42:32 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:42:32 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:42:32 --> Total execution time: 0.0585
DEBUG - 2023-09-07 19:42:32 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:42:32 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:42:32 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:42:32 --> Total execution time: 0.0597
DEBUG - 2023-09-07 19:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:42:32 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:42:32 --> Total execution time: 0.0512
DEBUG - 2023-09-07 19:42:32 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:42:32 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:42:32 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:42:32 --> Total execution time: 0.0763
DEBUG - 2023-09-07 19:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:42:32 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:42:32 --> Total execution time: 0.0647
DEBUG - 2023-09-07 19:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:42:32 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:42:32 --> Total execution time: 0.0625
DEBUG - 2023-09-07 19:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:42:32 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:42:32 --> Total execution time: 0.0585
DEBUG - 2023-09-07 19:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:42:32 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:42:32 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:42:32 --> Total execution time: 0.0576
DEBUG - 2023-09-07 19:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:42:32 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:42:32 --> Total execution time: 0.0456
DEBUG - 2023-09-07 19:42:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:42:53 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:42:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:42:53 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:42:53 --> Total execution time: 0.0368
DEBUG - 2023-09-07 19:43:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:43:19 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:43:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:43:19 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:43:19 --> Total execution time: 0.0482
DEBUG - 2023-09-07 19:43:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:43:19 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:43:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:43:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:43:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:43:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:43:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:43:19 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:43:19 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:43:19 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:43:19 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:43:19 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:43:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:43:19 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:43:19 --> Total execution time: 0.0606
DEBUG - 2023-09-07 19:43:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:43:19 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:43:19 --> Total execution time: 0.0586
DEBUG - 2023-09-07 19:43:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:43:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:43:19 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:43:19 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:43:19 --> Total execution time: 0.0673
DEBUG - 2023-09-07 19:43:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:43:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:43:19 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:43:19 --> Total execution time: 0.0776
DEBUG - 2023-09-07 19:43:19 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:43:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:43:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:43:19 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:43:19 --> Total execution time: 0.0876
DEBUG - 2023-09-07 19:43:19 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:43:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:43:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:43:19 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:43:19 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:43:19 --> Total execution time: 0.1039
DEBUG - 2023-09-07 19:43:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:43:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:43:19 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:43:19 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:43:19 --> Total execution time: 0.0649
DEBUG - 2023-09-07 19:43:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:43:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:43:19 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:43:19 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:43:19 --> Total execution time: 0.0663
DEBUG - 2023-09-07 19:43:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:43:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:43:19 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:43:19 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:43:19 --> Total execution time: 0.0697
DEBUG - 2023-09-07 19:43:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:43:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:43:19 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:43:19 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:43:19 --> Total execution time: 0.0725
DEBUG - 2023-09-07 19:43:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:43:19 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:43:19 --> Total execution time: 0.0706
DEBUG - 2023-09-07 19:43:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:43:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:43:19 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:43:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:43:19 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:43:19 --> Total execution time: 0.0672
DEBUG - 2023-09-07 19:43:19 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:43:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:43:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:43:19 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:43:19 --> Total execution time: 0.0644
DEBUG - 2023-09-07 19:43:19 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:43:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:43:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:43:19 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:43:19 --> Total execution time: 0.0610
DEBUG - 2023-09-07 19:43:19 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:43:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:43:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:43:19 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:43:19 --> Total execution time: 0.0526
DEBUG - 2023-09-07 19:43:19 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:43:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:43:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:43:19 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:43:19 --> Total execution time: 0.0583
DEBUG - 2023-09-07 19:43:19 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:43:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:43:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:43:19 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:43:19 --> Total execution time: 0.0566
DEBUG - 2023-09-07 19:43:19 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:43:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:43:19 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:43:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:43:19 --> Total execution time: 0.0584
DEBUG - 2023-09-07 19:43:19 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:43:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:43:19 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:43:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:43:19 --> Total execution time: 0.0587
DEBUG - 2023-09-07 19:43:19 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:43:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:43:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:43:19 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:43:19 --> Total execution time: 0.0604
DEBUG - 2023-09-07 19:43:19 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:43:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:43:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:43:19 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:43:19 --> Total execution time: 0.0566
DEBUG - 2023-09-07 19:43:19 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:43:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:43:19 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:43:19 --> Total execution time: 0.0544
DEBUG - 2023-09-07 19:43:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:43:19 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:43:19 --> Total execution time: 0.0542
DEBUG - 2023-09-07 19:43:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:43:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:43:19 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:43:19 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:43:19 --> Total execution time: 0.0571
DEBUG - 2023-09-07 19:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:43:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:43:20 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:43:20 --> Total execution time: 0.0644
DEBUG - 2023-09-07 19:43:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:43:20 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:43:20 --> Total execution time: 0.0538
DEBUG - 2023-09-07 19:43:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:43:21 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:43:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:43:21 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:43:21 --> Total execution time: 0.0489
DEBUG - 2023-09-07 19:45:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:31 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:31 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:31 --> Total execution time: 0.0479
DEBUG - 2023-09-07 19:45:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:41 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:41 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:41 --> Total execution time: 0.0475
DEBUG - 2023-09-07 19:45:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:42 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:42 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:42 --> Total execution time: 0.0498
DEBUG - 2023-09-07 19:45:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:42 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:42 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:42 --> Total execution time: 0.0447
DEBUG - 2023-09-07 19:45:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:42 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:42 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:42 --> Total execution time: 0.0464
DEBUG - 2023-09-07 19:45:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:43 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:44 --> Total execution time: 0.0583
DEBUG - 2023-09-07 19:45:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:44 --> Total execution time: 0.0562
DEBUG - 2023-09-07 19:45:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:44 --> Total execution time: 0.0660
DEBUG - 2023-09-07 19:45:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:44 --> Total execution time: 0.0764
DEBUG - 2023-09-07 19:45:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:44 --> Total execution time: 0.0859
DEBUG - 2023-09-07 19:45:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:44 --> Total execution time: 0.0979
DEBUG - 2023-09-07 19:45:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:44 --> Total execution time: 0.1271
DEBUG - 2023-09-07 19:45:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:44 --> Total execution time: 0.0611
DEBUG - 2023-09-07 19:45:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:44 --> Total execution time: 0.0649
DEBUG - 2023-09-07 19:45:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:44 --> Total execution time: 0.0665
DEBUG - 2023-09-07 19:45:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:44 --> Total execution time: 0.0687
DEBUG - 2023-09-07 19:45:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:44 --> Total execution time: 0.0695
DEBUG - 2023-09-07 19:45:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:44 --> Total execution time: 0.0676
DEBUG - 2023-09-07 19:45:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:44 --> Total execution time: 0.0643
DEBUG - 2023-09-07 19:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:44 --> Total execution time: 0.0659
DEBUG - 2023-09-07 19:45:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:44 --> Total execution time: 0.0633
DEBUG - 2023-09-07 19:45:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:44 --> Total execution time: 0.0596
DEBUG - 2023-09-07 19:45:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:44 --> Total execution time: 0.0654
DEBUG - 2023-09-07 19:45:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:44 --> Total execution time: 0.0643
DEBUG - 2023-09-07 19:45:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:44 --> Total execution time: 0.0631
DEBUG - 2023-09-07 19:45:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:44 --> Total execution time: 0.0622
DEBUG - 2023-09-07 19:45:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:44 --> Total execution time: 0.0597
DEBUG - 2023-09-07 19:45:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:44 --> Total execution time: 0.0558
DEBUG - 2023-09-07 19:45:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:44 --> Total execution time: 0.0532
DEBUG - 2023-09-07 19:45:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:44 --> Total execution time: 0.0521
DEBUG - 2023-09-07 19:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:44 --> Total execution time: 0.0509
DEBUG - 2023-09-07 19:45:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:44 --> Total execution time: 0.0469
DEBUG - 2023-09-07 19:45:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:44 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:44 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:44 --> Total execution time: 0.0460
DEBUG - 2023-09-07 19:45:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:47 --> Total execution time: 0.0491
DEBUG - 2023-09-07 19:45:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:47 --> Total execution time: 0.0583
DEBUG - 2023-09-07 19:45:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:47 --> Total execution time: 0.0581
DEBUG - 2023-09-07 19:45:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:47 --> Total execution time: 0.0673
DEBUG - 2023-09-07 19:45:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:47 --> Total execution time: 0.0792
DEBUG - 2023-09-07 19:45:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:47 --> Total execution time: 0.0923
DEBUG - 2023-09-07 19:45:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:47 --> Total execution time: 0.1066
DEBUG - 2023-09-07 19:45:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:47 --> Total execution time: 0.0632
DEBUG - 2023-09-07 19:45:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:47 --> Total execution time: 0.0648
DEBUG - 2023-09-07 19:45:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:47 --> Total execution time: 0.0671
DEBUG - 2023-09-07 19:45:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:47 --> Total execution time: 0.0682
DEBUG - 2023-09-07 19:45:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:47 --> Total execution time: 0.0648
DEBUG - 2023-09-07 19:45:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:47 --> Total execution time: 0.0665
DEBUG - 2023-09-07 19:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:47 --> Total execution time: 0.0660
DEBUG - 2023-09-07 19:45:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:47 --> Total execution time: 0.0651
DEBUG - 2023-09-07 19:45:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:47 --> Total execution time: 0.0581
DEBUG - 2023-09-07 19:45:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:47 --> Total execution time: 0.0626
DEBUG - 2023-09-07 19:45:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:47 --> Total execution time: 0.0599
DEBUG - 2023-09-07 19:45:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:47 --> Total execution time: 0.0596
DEBUG - 2023-09-07 19:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:47 --> Total execution time: 0.0576
DEBUG - 2023-09-07 19:45:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:47 --> Total execution time: 0.0591
DEBUG - 2023-09-07 19:45:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:47 --> Total execution time: 0.0539
DEBUG - 2023-09-07 19:45:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:47 --> Total execution time: 0.0539
DEBUG - 2023-09-07 19:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:47 --> Total execution time: 0.0585
DEBUG - 2023-09-07 19:45:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:47 --> Total execution time: 0.0647
DEBUG - 2023-09-07 19:45:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:47 --> Total execution time: 0.0644
DEBUG - 2023-09-07 19:45:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:47 --> Total execution time: 0.0547
DEBUG - 2023-09-07 19:45:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:48 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:48 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:48 --> Total execution time: 0.0457
DEBUG - 2023-09-07 19:45:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:48 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:48 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:48 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:48 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:48 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:48 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:48 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:48 --> Total execution time: 0.0555
DEBUG - 2023-09-07 19:45:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:48 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:48 --> Total execution time: 0.0657
DEBUG - 2023-09-07 19:45:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:48 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:48 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:48 --> Total execution time: 0.0757
DEBUG - 2023-09-07 19:45:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:48 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:48 --> Total execution time: 0.0871
DEBUG - 2023-09-07 19:45:48 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:48 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:48 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:48 --> Total execution time: 0.1149
DEBUG - 2023-09-07 19:45:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:48 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:48 --> Total execution time: 0.1122
DEBUG - 2023-09-07 19:45:48 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:48 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:48 --> Total execution time: 0.0621
DEBUG - 2023-09-07 19:45:48 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:48 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:48 --> Total execution time: 0.0636
DEBUG - 2023-09-07 19:45:48 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:48 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:48 --> Total execution time: 0.0667
DEBUG - 2023-09-07 19:45:48 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:48 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:48 --> Total execution time: 0.0688
DEBUG - 2023-09-07 19:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:48 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:48 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:48 --> Total execution time: 0.0718
DEBUG - 2023-09-07 19:45:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:48 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:48 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:48 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:48 --> Total execution time: 0.0730
DEBUG - 2023-09-07 19:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:48 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:48 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:48 --> Total execution time: 0.0749
DEBUG - 2023-09-07 19:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:48 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:48 --> Total execution time: 0.0734
DEBUG - 2023-09-07 19:45:48 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:48 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:48 --> Total execution time: 0.0595
DEBUG - 2023-09-07 19:45:48 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:48 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:48 --> Total execution time: 0.0710
DEBUG - 2023-09-07 19:45:48 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:48 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:48 --> Total execution time: 0.0666
DEBUG - 2023-09-07 19:45:48 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:48 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:48 --> Total execution time: 0.0661
DEBUG - 2023-09-07 19:45:48 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:48 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:48 --> Total execution time: 0.0652
DEBUG - 2023-09-07 19:45:48 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:48 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:48 --> Total execution time: 0.0670
DEBUG - 2023-09-07 19:45:48 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:48 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:48 --> Total execution time: 0.0631
DEBUG - 2023-09-07 19:45:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:48 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:48 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:48 --> Total execution time: 0.0612
DEBUG - 2023-09-07 19:45:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:48 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:48 --> Total execution time: 0.0600
DEBUG - 2023-09-07 19:45:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:45:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:48 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:45:48 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:48 --> Total execution time: 0.0579
DEBUG - 2023-09-07 19:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:45:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:48 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:48 --> Total execution time: 0.0499
DEBUG - 2023-09-07 19:45:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:45:48 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:45:48 --> Total execution time: 0.0478
DEBUG - 2023-09-07 19:46:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:46:18 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:46:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:46:18 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:46:18 --> Total execution time: 0.0591
DEBUG - 2023-09-07 19:46:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:46:22 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:46:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:46:22 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:46:22 --> Total execution time: 0.0471
DEBUG - 2023-09-07 19:46:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:46:22 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:46:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:46:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:46:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:46:22 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:46:22 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:46:22 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:46:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:46:22 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:46:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:46:22 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:46:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:46:22 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:46:22 --> Total execution time: 0.0659
DEBUG - 2023-09-07 19:46:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:46:22 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:46:22 --> Total execution time: 0.0694
DEBUG - 2023-09-07 19:46:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:46:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:46:22 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:46:22 --> Total execution time: 0.0875
DEBUG - 2023-09-07 19:46:22 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:46:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:46:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:46:22 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:46:22 --> Total execution time: 0.1030
DEBUG - 2023-09-07 19:46:22 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:46:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:46:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:46:22 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:46:22 --> Total execution time: 0.0999
DEBUG - 2023-09-07 19:46:22 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:46:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:46:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:46:22 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:46:22 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:46:22 --> Total execution time: 0.0996
DEBUG - 2023-09-07 19:46:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:46:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:46:22 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:46:22 --> Total execution time: 0.0755
DEBUG - 2023-09-07 19:46:22 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:46:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:46:22 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:46:22 --> Total execution time: 0.0803
DEBUG - 2023-09-07 19:46:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:46:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:46:22 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:46:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:46:22 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:46:22 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:46:22 --> Total execution time: 0.0787
DEBUG - 2023-09-07 19:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:46:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:46:22 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:46:22 --> Total execution time: 0.0794
DEBUG - 2023-09-07 19:46:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:46:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:46:22 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:46:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:46:22 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:46:22 --> Total execution time: 0.0744
DEBUG - 2023-09-07 19:46:22 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:46:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:46:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:46:22 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:46:22 --> Total execution time: 0.0657
DEBUG - 2023-09-07 19:46:22 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:46:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:46:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:46:22 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:46:22 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:46:22 --> Total execution time: 0.0724
DEBUG - 2023-09-07 19:46:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:46:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:46:22 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:46:22 --> Total execution time: 0.0673
DEBUG - 2023-09-07 19:46:22 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:46:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:46:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:46:22 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:46:22 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:46:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:46:22 --> Total execution time: 0.0761
DEBUG - 2023-09-07 19:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:46:22 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:46:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:46:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:46:22 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:46:22 --> Total execution time: 0.1025
DEBUG - 2023-09-07 19:46:22 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:46:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:46:22 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:46:22 --> Total execution time: 0.1040
DEBUG - 2023-09-07 19:46:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:46:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:46:22 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:46:22 --> Total execution time: 0.1005
DEBUG - 2023-09-07 19:46:22 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:46:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:46:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:46:22 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:46:22 --> Total execution time: 0.0969
DEBUG - 2023-09-07 19:46:22 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:46:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:46:22 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:46:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:46:22 --> Total execution time: 0.0947
DEBUG - 2023-09-07 19:46:22 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:46:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:46:22 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:46:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:46:22 --> Total execution time: 0.0803
DEBUG - 2023-09-07 19:46:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:46:22 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:46:22 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:46:22 --> Total execution time: 0.0558
DEBUG - 2023-09-07 19:46:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:46:22 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:46:22 --> Total execution time: 0.0531
DEBUG - 2023-09-07 19:46:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:46:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:46:22 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:46:22 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:46:22 --> Total execution time: 0.0501
DEBUG - 2023-09-07 19:46:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:46:22 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:46:22 --> Total execution time: 0.0493
DEBUG - 2023-09-07 19:46:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:46:22 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:46:22 --> Total execution time: 0.0463
DEBUG - 2023-09-07 19:46:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:46:32 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:46:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:46:32 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:46:32 --> Total execution time: 0.0509
DEBUG - 2023-09-07 19:49:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:15 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:15 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:15 --> Total execution time: 0.0493
DEBUG - 2023-09-07 19:49:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:15 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:15 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:15 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:15 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:15 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:15 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:15 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:15 --> Total execution time: 0.0880
DEBUG - 2023-09-07 19:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:15 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:15 --> Total execution time: 0.0738
DEBUG - 2023-09-07 19:49:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:15 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:15 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:15 --> Total execution time: 0.0768
DEBUG - 2023-09-07 19:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:15 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:15 --> Total execution time: 0.0904
DEBUG - 2023-09-07 19:49:15 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:15 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:15 --> Total execution time: 0.0961
DEBUG - 2023-09-07 19:49:15 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:15 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:15 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:15 --> Total execution time: 0.0992
DEBUG - 2023-09-07 19:49:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:16 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:16 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:16 --> Total execution time: 0.1003
DEBUG - 2023-09-07 19:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:16 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:16 --> Total execution time: 0.0971
DEBUG - 2023-09-07 19:49:16 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:16 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:16 --> Total execution time: 0.1022
DEBUG - 2023-09-07 19:49:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:16 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:16 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:16 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:16 --> Total execution time: 0.1034
DEBUG - 2023-09-07 19:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:16 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:16 --> Total execution time: 0.0998
DEBUG - 2023-09-07 19:49:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:16 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:16 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:16 --> Total execution time: 0.0693
DEBUG - 2023-09-07 19:49:16 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:16 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:16 --> Total execution time: 0.0686
DEBUG - 2023-09-07 19:49:16 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:16 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:16 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:16 --> Total execution time: 0.0687
DEBUG - 2023-09-07 19:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:16 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:16 --> Total execution time: 0.0588
DEBUG - 2023-09-07 19:49:16 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:16 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:16 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:16 --> Total execution time: 0.0659
DEBUG - 2023-09-07 19:49:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:16 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:16 --> Total execution time: 0.0650
DEBUG - 2023-09-07 19:49:16 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:16 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:16 --> Total execution time: 0.0672
DEBUG - 2023-09-07 19:49:16 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:16 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:16 --> Total execution time: 0.0624
DEBUG - 2023-09-07 19:49:16 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:16 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:16 --> Total execution time: 0.0661
DEBUG - 2023-09-07 19:49:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:16 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:16 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:16 --> Total execution time: 0.0595
DEBUG - 2023-09-07 19:49:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:16 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:16 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:16 --> Total execution time: 0.0593
DEBUG - 2023-09-07 19:49:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:16 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:16 --> Total execution time: 0.0572
DEBUG - 2023-09-07 19:49:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:16 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:16 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:16 --> Total execution time: 0.0551
DEBUG - 2023-09-07 19:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:16 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:16 --> Total execution time: 0.0548
DEBUG - 2023-09-07 19:49:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:16 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:16 --> Total execution time: 0.0490
DEBUG - 2023-09-07 19:49:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:22 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:22 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:22 --> Total execution time: 0.0567
DEBUG - 2023-09-07 19:49:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:25 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:25 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:25 --> Total execution time: 0.0494
DEBUG - 2023-09-07 19:49:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:26 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:26 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:26 --> Total execution time: 0.0509
DEBUG - 2023-09-07 19:49:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:27 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:27 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:27 --> Total execution time: 0.0510
DEBUG - 2023-09-07 19:49:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:31 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:32 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:32 --> Total execution time: 0.0721
DEBUG - 2023-09-07 19:49:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:33 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:33 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:33 --> Total execution time: 0.0520
DEBUG - 2023-09-07 19:49:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:33 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:34 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:34 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:34 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:34 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:34 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:34 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:34 --> Total execution time: 0.0744
DEBUG - 2023-09-07 19:49:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:34 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:34 --> Total execution time: 0.0806
DEBUG - 2023-09-07 19:49:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:34 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:34 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:34 --> Total execution time: 0.1311
DEBUG - 2023-09-07 19:49:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:34 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:34 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:34 --> Total execution time: 0.1002
DEBUG - 2023-09-07 19:49:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:34 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:34 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:34 --> Total execution time: 0.1127
DEBUG - 2023-09-07 19:49:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:34 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:34 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:34 --> Total execution time: 0.1203
DEBUG - 2023-09-07 19:49:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:34 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:34 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:34 --> Total execution time: 0.0709
DEBUG - 2023-09-07 19:49:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:34 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:34 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:34 --> Total execution time: 0.0720
DEBUG - 2023-09-07 19:49:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:34 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:34 --> Total execution time: 0.0736
DEBUG - 2023-09-07 19:49:34 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:34 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:34 --> Total execution time: 0.0733
DEBUG - 2023-09-07 19:49:34 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:34 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:34 --> Total execution time: 0.0716
DEBUG - 2023-09-07 19:49:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:34 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:34 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:34 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:34 --> Total execution time: 0.0719
DEBUG - 2023-09-07 19:49:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:34 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:34 --> Total execution time: 0.0680
DEBUG - 2023-09-07 19:49:34 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:34 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:34 --> Total execution time: 0.0660
DEBUG - 2023-09-07 19:49:34 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:34 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:34 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:34 --> Total execution time: 0.0576
DEBUG - 2023-09-07 19:49:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:34 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:34 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:34 --> Total execution time: 0.0719
DEBUG - 2023-09-07 19:49:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:34 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:34 --> Total execution time: 0.0693
DEBUG - 2023-09-07 19:49:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:34 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:34 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:34 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:34 --> Total execution time: 0.0681
DEBUG - 2023-09-07 19:49:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:34 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:34 --> Total execution time: 0.0668
DEBUG - 2023-09-07 19:49:34 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:34 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:34 --> Total execution time: 0.0686
DEBUG - 2023-09-07 19:49:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:34 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:34 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:34 --> Total execution time: 0.0591
DEBUG - 2023-09-07 19:49:34 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:34 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:34 --> Total execution time: 0.0592
DEBUG - 2023-09-07 19:49:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:34 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:34 --> Total execution time: 0.0571
DEBUG - 2023-09-07 19:49:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:34 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:34 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:34 --> Total execution time: 0.0533
DEBUG - 2023-09-07 19:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:34 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:34 --> Total execution time: 0.0516
DEBUG - 2023-09-07 19:49:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:34 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:34 --> Total execution time: 0.0463
DEBUG - 2023-09-07 19:49:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-07 19:49:47 --> No URI present. Default controller set.
DEBUG - 2023-09-07 19:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-07 19:49:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-09-07 19:49:47 --> initController - LoginPage.php
DEBUG - 2023-09-07 19:49:47 --> Total execution time: 0.0457
