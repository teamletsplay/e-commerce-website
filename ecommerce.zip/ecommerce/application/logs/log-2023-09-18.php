<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-09-18 00:00:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:00:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:00:15 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-18 00:00:15 --> Total execution time: 0.0568
DEBUG - 2023-09-18 00:00:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:00:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:00:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:00:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:00:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:00:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:00:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:00:15 --> 404 Page Not Found: Register/assets
ERROR - 2023-09-18 00:00:15 --> 404 Page Not Found: Register/assets
ERROR - 2023-09-18 00:00:15 --> 404 Page Not Found: Register/5546YEEcss
ERROR - 2023-09-18 00:00:15 --> 404 Page Not Found: Register/js
DEBUG - 2023-09-18 00:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:00:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:00:15 --> 404 Page Not Found: Register/assets
ERROR - 2023-09-18 00:00:15 --> 404 Page Not Found: Register/assets
DEBUG - 2023-09-18 00:00:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:00:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:00:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:00:15 --> 404 Page Not Found: Register/assets
ERROR - 2023-09-18 00:00:15 --> 404 Page Not Found: Register/js
DEBUG - 2023-09-18 00:00:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:00:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:00:15 --> 404 Page Not Found: Register/js
DEBUG - 2023-09-18 00:00:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:00:19 --> initController - LoginPage.php
DEBUG - 2023-09-18 00:00:19 --> Total execution time: 0.0500
DEBUG - 2023-09-18 00:00:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:00:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:00:19 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 00:00:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:00:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:00:27 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-18 00:00:27 --> Total execution time: 0.0476
DEBUG - 2023-09-18 00:00:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:00:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:00:27 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 00:01:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:01:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:01:19 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-18 00:01:19 --> Total execution time: 0.0503
DEBUG - 2023-09-18 00:01:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:01:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:01:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:01:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:01:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:01:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:01:19 --> 404 Page Not Found: Register/assets
DEBUG - 2023-09-18 00:01:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:01:19 --> 404 Page Not Found: Register/5546YEEcss
DEBUG - 2023-09-18 00:01:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:01:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:01:19 --> 404 Page Not Found: Register/assets
DEBUG - 2023-09-18 00:01:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:01:19 --> 404 Page Not Found: Register/js
ERROR - 2023-09-18 00:01:19 --> 404 Page Not Found: Register/assets
DEBUG - 2023-09-18 00:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:01:19 --> UTF-8 Support Enabled
ERROR - 2023-09-18 00:01:19 --> 404 Page Not Found: Register/assets
DEBUG - 2023-09-18 00:01:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:01:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:01:19 --> 404 Page Not Found: Register/js
ERROR - 2023-09-18 00:01:19 --> 404 Page Not Found: Register/assets
DEBUG - 2023-09-18 00:01:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:01:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:01:19 --> 404 Page Not Found: Register/js
DEBUG - 2023-09-18 00:01:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:01:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:01:56 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-18 00:01:56 --> Total execution time: 0.0499
DEBUG - 2023-09-18 00:01:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:01:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:01:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:01:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:01:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:01:56 --> UTF-8 Support Enabled
ERROR - 2023-09-18 00:01:56 --> 404 Page Not Found: Register/5546YEEcss
ERROR - 2023-09-18 00:01:56 --> 404 Page Not Found: Register/assets
DEBUG - 2023-09-18 00:01:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:01:56 --> 404 Page Not Found: Register/assets
DEBUG - 2023-09-18 00:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:01:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:01:56 --> 404 Page Not Found: Register/assets
ERROR - 2023-09-18 00:01:56 --> 404 Page Not Found: Register/js
ERROR - 2023-09-18 00:01:56 --> 404 Page Not Found: Register/assets
DEBUG - 2023-09-18 00:01:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:01:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:01:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:01:56 --> 404 Page Not Found: Register/js
ERROR - 2023-09-18 00:01:56 --> 404 Page Not Found: Register/assets
DEBUG - 2023-09-18 00:01:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:01:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:01:56 --> 404 Page Not Found: Register/js
DEBUG - 2023-09-18 00:03:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:03:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:03:25 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-18 00:03:25 --> Total execution time: 0.0531
DEBUG - 2023-09-18 00:03:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:03:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:03:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:03:25 --> UTF-8 Support Enabled
ERROR - 2023-09-18 00:03:25 --> 404 Page Not Found: Register/assets
DEBUG - 2023-09-18 00:03:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:03:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:03:25 --> 404 Page Not Found: Register/5546YEEcss
DEBUG - 2023-09-18 00:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:03:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:03:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:03:25 --> 404 Page Not Found: Register/js
ERROR - 2023-09-18 00:03:26 --> 404 Page Not Found: Register/assets
ERROR - 2023-09-18 00:03:26 --> 404 Page Not Found: Register/assets
DEBUG - 2023-09-18 00:03:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:03:26 --> 404 Page Not Found: Register/assets
DEBUG - 2023-09-18 00:03:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:03:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:03:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:03:26 --> 404 Page Not Found: Register/js
DEBUG - 2023-09-18 00:03:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:03:26 --> 404 Page Not Found: Register/assets
DEBUG - 2023-09-18 00:03:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:03:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:03:26 --> 404 Page Not Found: Register/js
DEBUG - 2023-09-18 00:03:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:03:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:03:45 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-18 00:03:45 --> Total execution time: 0.0524
DEBUG - 2023-09-18 00:03:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:03:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:03:45 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 00:03:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:03:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:03:51 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-18 00:03:51 --> Total execution time: 0.0562
DEBUG - 2023-09-18 00:03:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:03:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:03:51 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 00:03:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:03:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:03:52 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-18 00:03:52 --> Total execution time: 0.0450
DEBUG - 2023-09-18 00:03:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:03:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:03:52 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 00:03:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:03:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:03:52 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-18 00:03:52 --> Total execution time: 0.0475
DEBUG - 2023-09-18 00:03:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:03:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:03:52 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 00:03:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:03:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:03:53 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-18 00:03:53 --> Total execution time: 0.0453
DEBUG - 2023-09-18 00:03:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:03:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:03:53 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 00:07:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:07:31 --> Total execution time: 0.0507
DEBUG - 2023-09-18 00:07:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:07:52 --> Total execution time: 0.0449
DEBUG - 2023-09-18 00:28:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:28:07 --> Total execution time: 0.0206
DEBUG - 2023-09-18 00:28:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:28:21 --> Total execution time: 0.0198
DEBUG - 2023-09-18 00:30:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:30:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:30:00 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-18 00:30:00 --> Total execution time: 0.0191
DEBUG - 2023-09-18 00:30:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:30:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:30:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:30:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:30:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:30:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:30:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:30:00 --> 404 Page Not Found: Register/assets
ERROR - 2023-09-18 00:30:00 --> 404 Page Not Found: Register/5546YEEcss
ERROR - 2023-09-18 00:30:00 --> 404 Page Not Found: Register/assets
ERROR - 2023-09-18 00:30:00 --> 404 Page Not Found: Register/assets
DEBUG - 2023-09-18 00:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:30:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:30:00 --> 404 Page Not Found: Register/assets
ERROR - 2023-09-18 00:30:00 --> 404 Page Not Found: Register/js
DEBUG - 2023-09-18 00:30:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:30:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:30:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:30:00 --> 404 Page Not Found: Register/assets
ERROR - 2023-09-18 00:30:00 --> 404 Page Not Found: Register/js
DEBUG - 2023-09-18 00:30:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:30:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:30:00 --> 404 Page Not Found: Register/js
DEBUG - 2023-09-18 00:30:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:30:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:30:14 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-18 00:30:14 --> Total execution time: 0.0218
DEBUG - 2023-09-18 00:30:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:30:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:30:14 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 00:31:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:31:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:31:20 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-18 00:31:20 --> Total execution time: 0.0207
DEBUG - 2023-09-18 00:31:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:31:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:31:20 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 00:31:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:31:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:31:26 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-18 00:31:26 --> Total execution time: 0.0216
DEBUG - 2023-09-18 00:31:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:31:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:31:26 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 00:31:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:31:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:31:40 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-18 00:31:40 --> Total execution time: 0.0214
DEBUG - 2023-09-18 00:31:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:31:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:31:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:31:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:31:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:31:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:31:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:31:40 --> 404 Page Not Found: Register/assets
ERROR - 2023-09-18 00:31:40 --> 404 Page Not Found: Register/5546YEEcss
ERROR - 2023-09-18 00:31:40 --> 404 Page Not Found: Register/assets
ERROR - 2023-09-18 00:31:40 --> 404 Page Not Found: Register/assets
ERROR - 2023-09-18 00:31:40 --> 404 Page Not Found: Register/js
ERROR - 2023-09-18 00:31:40 --> 404 Page Not Found: Register/assets
DEBUG - 2023-09-18 00:31:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:31:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:31:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:31:40 --> 404 Page Not Found: Register/assets
ERROR - 2023-09-18 00:31:40 --> 404 Page Not Found: Register/js
DEBUG - 2023-09-18 00:31:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:31:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:31:40 --> 404 Page Not Found: Register/js
DEBUG - 2023-09-18 00:31:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:31:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:31:48 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-18 00:31:48 --> Total execution time: 0.0226
DEBUG - 2023-09-18 00:31:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:31:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:31:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:31:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:31:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:31:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:31:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:31:48 --> 404 Page Not Found: Register/5546YEEcss
ERROR - 2023-09-18 00:31:48 --> 404 Page Not Found: Register/assets
ERROR - 2023-09-18 00:31:48 --> 404 Page Not Found: Register/assets
ERROR - 2023-09-18 00:31:48 --> 404 Page Not Found: Register/assets
ERROR - 2023-09-18 00:31:48 --> 404 Page Not Found: Register/assets
ERROR - 2023-09-18 00:31:48 --> 404 Page Not Found: Register/js
DEBUG - 2023-09-18 00:31:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:31:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:31:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:31:48 --> 404 Page Not Found: Register/js
ERROR - 2023-09-18 00:31:48 --> 404 Page Not Found: Register/assets
DEBUG - 2023-09-18 00:31:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:31:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:31:48 --> 404 Page Not Found: Register/js
DEBUG - 2023-09-18 00:39:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:39:17 --> initController - LoginPage.php
DEBUG - 2023-09-18 00:39:17 --> Total execution time: 0.0190
DEBUG - 2023-09-18 00:39:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:39:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:39:17 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 00:53:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:53:07 --> initController - LoginPage.php
DEBUG - 2023-09-18 00:53:07 --> Total execution time: 0.0197
DEBUG - 2023-09-18 00:53:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:53:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:53:07 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 00:56:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:56:00 --> initController - LoginPage.php
DEBUG - 2023-09-18 00:56:00 --> Total execution time: 0.0200
DEBUG - 2023-09-18 00:56:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:56:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:56:00 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 00:56:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:56:05 --> No URI present. Default controller set.
DEBUG - 2023-09-18 00:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:56:05 --> initController - LoginPage.php
DEBUG - 2023-09-18 00:56:05 --> Total execution time: 0.0202
DEBUG - 2023-09-18 00:56:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:56:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:56:05 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 00:57:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:57:07 --> No URI present. Default controller set.
DEBUG - 2023-09-18 00:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:57:07 --> initController - LoginPage.php
DEBUG - 2023-09-18 00:57:07 --> Total execution time: 0.0203
DEBUG - 2023-09-18 00:57:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:57:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:57:07 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 00:57:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:57:08 --> No URI present. Default controller set.
DEBUG - 2023-09-18 00:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:57:08 --> initController - LoginPage.php
DEBUG - 2023-09-18 00:57:08 --> Total execution time: 0.0198
DEBUG - 2023-09-18 00:57:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:57:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:57:08 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 00:57:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:57:08 --> No URI present. Default controller set.
DEBUG - 2023-09-18 00:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:57:08 --> initController - LoginPage.php
DEBUG - 2023-09-18 00:57:08 --> Total execution time: 0.0194
DEBUG - 2023-09-18 00:57:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:57:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:57:08 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 00:57:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:57:51 --> No URI present. Default controller set.
DEBUG - 2023-09-18 00:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:57:51 --> initController - LoginPage.php
DEBUG - 2023-09-18 00:57:51 --> Total execution time: 0.0204
DEBUG - 2023-09-18 00:57:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:57:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:57:51 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 00:57:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:57:53 --> initController - LoginPage.php
DEBUG - 2023-09-18 00:57:53 --> Total execution time: 0.0236
DEBUG - 2023-09-18 00:57:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:57:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:57:54 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 00:59:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 00:59:33 --> initController - LoginPage.php
DEBUG - 2023-09-18 00:59:33 --> Total execution time: 0.0190
DEBUG - 2023-09-18 00:59:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 00:59:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 00:59:33 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 01:03:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 01:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 01:03:17 --> initController - LoginPage.php
DEBUG - 2023-09-18 01:03:17 --> Total execution time: 0.0187
DEBUG - 2023-09-18 01:03:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 01:03:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 01:03:17 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 01:05:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 01:05:47 --> No URI present. Default controller set.
DEBUG - 2023-09-18 01:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 01:05:47 --> initController - LoginPage.php
DEBUG - 2023-09-18 01:05:47 --> Total execution time: 0.0216
DEBUG - 2023-09-18 01:05:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 01:05:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 01:05:47 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 01:09:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 01:09:53 --> No URI present. Default controller set.
DEBUG - 2023-09-18 01:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 01:09:53 --> initController - LoginPage.php
DEBUG - 2023-09-18 01:09:53 --> Total execution time: 0.0353
DEBUG - 2023-09-18 01:09:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 01:09:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 01:09:53 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 01:09:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 01:09:55 --> No URI present. Default controller set.
DEBUG - 2023-09-18 01:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 01:09:55 --> initController - LoginPage.php
DEBUG - 2023-09-18 01:09:55 --> Total execution time: 0.0364
DEBUG - 2023-09-18 01:09:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 01:09:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 01:09:55 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 01:10:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 01:10:07 --> No URI present. Default controller set.
DEBUG - 2023-09-18 01:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 01:10:07 --> initController - LoginPage.php
DEBUG - 2023-09-18 01:10:07 --> Total execution time: 0.0466
DEBUG - 2023-09-18 01:10:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 01:10:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 01:10:07 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 01:12:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 01:12:24 --> No URI present. Default controller set.
DEBUG - 2023-09-18 01:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 01:12:24 --> initController - LoginPage.php
DEBUG - 2023-09-18 01:12:24 --> Total execution time: 0.0398
DEBUG - 2023-09-18 01:12:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 01:12:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 01:12:24 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 01:12:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 01:12:34 --> No URI present. Default controller set.
DEBUG - 2023-09-18 01:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 01:12:34 --> initController - LoginPage.php
DEBUG - 2023-09-18 01:12:34 --> Total execution time: 0.0464
DEBUG - 2023-09-18 01:12:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 01:12:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 01:12:34 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 01:15:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 01:15:02 --> No URI present. Default controller set.
DEBUG - 2023-09-18 01:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 01:15:02 --> initController - LoginPage.php
DEBUG - 2023-09-18 01:15:02 --> Total execution time: 0.0449
DEBUG - 2023-09-18 01:15:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 01:15:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 01:15:02 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 01:15:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 01:15:12 --> No URI present. Default controller set.
DEBUG - 2023-09-18 01:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 01:15:12 --> initController - LoginPage.php
ERROR - 2023-09-18 01:15:12 --> Severity: error --> Exception: Unknown column 'error' in 'field list' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 264
DEBUG - 2023-09-18 01:18:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 01:18:57 --> No URI present. Default controller set.
DEBUG - 2023-09-18 01:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 01:18:57 --> initController - LoginPage.php
DEBUG - 2023-09-18 01:18:57 --> Total execution time: 0.0404
DEBUG - 2023-09-18 01:18:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 01:18:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 01:18:57 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 01:19:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 01:19:05 --> No URI present. Default controller set.
DEBUG - 2023-09-18 01:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 01:19:05 --> initController - LoginPage.php
ERROR - 2023-09-18 01:19:05 --> Severity: error --> Exception: Unknown column 'error' in 'field list' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 264
DEBUG - 2023-09-18 01:20:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 01:20:51 --> No URI present. Default controller set.
DEBUG - 2023-09-18 01:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 01:20:51 --> initController - LoginPage.php
ERROR - 2023-09-18 01:20:51 --> Severity: error --> Exception: Unknown column 'error' in 'field list' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 264
DEBUG - 2023-09-18 01:25:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 01:25:28 --> No URI present. Default controller set.
DEBUG - 2023-09-18 01:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 01:25:28 --> initController - LoginPage.php
DEBUG - 2023-09-18 01:25:28 --> Total execution time: 0.0411
DEBUG - 2023-09-18 01:25:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 01:25:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 01:25:28 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 01:25:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 01:25:36 --> No URI present. Default controller set.
DEBUG - 2023-09-18 01:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 01:25:36 --> initController - LoginPage.php
DEBUG - 2023-09-18 01:25:36 --> Total execution time: 0.0487
DEBUG - 2023-09-18 01:25:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 01:25:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 01:25:36 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 01:27:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 01:27:10 --> No URI present. Default controller set.
DEBUG - 2023-09-18 01:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 01:27:10 --> initController - LoginPage.php
DEBUG - 2023-09-18 01:27:10 --> Total execution time: 0.0425
DEBUG - 2023-09-18 01:27:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 01:27:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 01:27:10 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 01:27:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 01:27:12 --> No URI present. Default controller set.
DEBUG - 2023-09-18 01:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 01:27:12 --> initController - LoginPage.php
DEBUG - 2023-09-18 01:27:12 --> Total execution time: 0.0336
DEBUG - 2023-09-18 01:27:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 01:27:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 01:27:12 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 01:27:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 01:27:21 --> No URI present. Default controller set.
DEBUG - 2023-09-18 01:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 01:27:21 --> initController - LoginPage.php
DEBUG - 2023-09-18 01:27:21 --> Total execution time: 0.0444
DEBUG - 2023-09-18 01:27:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 01:27:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 01:27:21 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 01:31:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 01:31:18 --> No URI present. Default controller set.
DEBUG - 2023-09-18 01:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 01:31:18 --> initController - LoginPage.php
DEBUG - 2023-09-18 01:31:18 --> Total execution time: 0.0473
DEBUG - 2023-09-18 01:31:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 01:31:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 01:31:19 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 01:31:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 01:31:44 --> No URI present. Default controller set.
DEBUG - 2023-09-18 01:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 01:31:44 --> initController - LoginPage.php
ERROR - 2023-09-18 01:31:44 --> Severity: error --> Exception: Unknown column 'error' in 'field list' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 264
DEBUG - 2023-09-18 01:32:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 01:32:49 --> No URI present. Default controller set.
DEBUG - 2023-09-18 01:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 01:32:49 --> initController - LoginPage.php
DEBUG - 2023-09-18 01:32:49 --> Total execution time: 0.0468
DEBUG - 2023-09-18 01:32:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 01:32:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 01:32:49 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 01:32:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 01:32:57 --> No URI present. Default controller set.
DEBUG - 2023-09-18 01:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 01:32:57 --> initController - LoginPage.php
ERROR - 2023-09-18 01:32:57 --> Severity: error --> Exception: Unknown column 'error' in 'field list' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 264
DEBUG - 2023-09-18 14:17:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 14:17:41 --> No URI present. Default controller set.
DEBUG - 2023-09-18 14:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 14:17:41 --> initController - LoginPage.php
ERROR - 2023-09-18 14:17:41 --> Severity: error --> Exception: Unknown column 'error' in 'field list' C:\xampp\htdocs\WebProject\system\database\drivers\mysqli\mysqli_driver.php 264
DEBUG - 2023-09-18 14:33:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 14:33:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 14:33:12 --> Severity: error --> Exception: syntax error, unexpected token ";", expecting ")" C:\xampp\htdocs\WebProject\application\controllers\InitController.php 32
DEBUG - 2023-09-18 14:38:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 14:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 14:38:20 --> initController - LoginPage.php
DEBUG - 2023-09-18 14:38:20 --> Total execution time: 0.0245
DEBUG - 2023-09-18 14:38:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 14:38:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 14:38:20 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 14:38:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 14:38:37 --> No URI present. Default controller set.
DEBUG - 2023-09-18 14:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 14:38:37 --> initController - LoginPage.php
DEBUG - 2023-09-18 14:38:37 --> Total execution time: 0.0285
DEBUG - 2023-09-18 14:38:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 14:38:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 14:38:37 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 14:44:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 14:44:14 --> No URI present. Default controller set.
DEBUG - 2023-09-18 14:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 14:44:14 --> initController - LoginPage.php
DEBUG - 2023-09-18 14:44:14 --> Total execution time: 0.0273
DEBUG - 2023-09-18 14:44:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 14:44:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 14:44:14 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 14:44:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 14:44:26 --> No URI present. Default controller set.
DEBUG - 2023-09-18 14:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 14:44:26 --> initController - LoginPage.php
DEBUG - 2023-09-18 14:44:26 --> Total execution time: 0.0243
DEBUG - 2023-09-18 14:44:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 14:44:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 14:44:26 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 14:46:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 14:46:12 --> No URI present. Default controller set.
DEBUG - 2023-09-18 14:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 14:46:12 --> initController - LoginPage.php
DEBUG - 2023-09-18 14:46:12 --> Total execution time: 0.0263
DEBUG - 2023-09-18 14:46:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 14:46:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 14:46:12 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 14:46:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 14:46:24 --> No URI present. Default controller set.
DEBUG - 2023-09-18 14:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 14:46:24 --> initController - LoginPage.php
DEBUG - 2023-09-18 14:46:24 --> Total execution time: 0.0294
DEBUG - 2023-09-18 14:46:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 14:46:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 14:46:24 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 14:46:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 14:46:58 --> No URI present. Default controller set.
DEBUG - 2023-09-18 14:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 14:46:58 --> initController - LoginPage.php
DEBUG - 2023-09-18 14:46:58 --> Total execution time: 0.0253
DEBUG - 2023-09-18 14:46:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 14:46:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 14:46:58 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 14:48:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 14:48:45 --> No URI present. Default controller set.
DEBUG - 2023-09-18 14:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 14:48:45 --> initController - LoginPage.php
DEBUG - 2023-09-18 14:48:45 --> Total execution time: 0.0281
DEBUG - 2023-09-18 14:48:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 14:48:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 14:48:45 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 14:49:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 14:49:07 --> No URI present. Default controller set.
DEBUG - 2023-09-18 14:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 14:49:07 --> initController - LoginPage.php
DEBUG - 2023-09-18 14:49:07 --> Total execution time: 0.0241
DEBUG - 2023-09-18 14:49:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 14:49:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 14:49:08 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 14:49:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 14:49:22 --> No URI present. Default controller set.
DEBUG - 2023-09-18 14:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 14:49:22 --> initController - LoginPage.php
DEBUG - 2023-09-18 14:49:22 --> Total execution time: 0.0277
DEBUG - 2023-09-18 14:49:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 14:49:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 14:49:22 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 14:50:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 14:50:41 --> No URI present. Default controller set.
DEBUG - 2023-09-18 14:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 14:50:42 --> initController - LoginPage.php
DEBUG - 2023-09-18 14:50:42 --> Total execution time: 0.0262
DEBUG - 2023-09-18 14:50:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 14:50:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 14:50:42 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 14:51:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 14:51:43 --> No URI present. Default controller set.
DEBUG - 2023-09-18 14:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 14:51:43 --> initController - LoginPage.php
DEBUG - 2023-09-18 14:51:43 --> Total execution time: 0.0260
DEBUG - 2023-09-18 14:51:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 14:51:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 14:51:43 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 14:52:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 14:52:25 --> No URI present. Default controller set.
DEBUG - 2023-09-18 14:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 14:52:25 --> initController - LoginPage.php
DEBUG - 2023-09-18 14:52:25 --> Total execution time: 0.0277
DEBUG - 2023-09-18 14:52:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 14:52:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 14:52:25 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 14:53:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 14:53:23 --> No URI present. Default controller set.
DEBUG - 2023-09-18 14:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 14:53:23 --> initController - LoginPage.php
DEBUG - 2023-09-18 14:53:23 --> Total execution time: 0.0321
DEBUG - 2023-09-18 14:53:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 14:53:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 14:53:23 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 14:54:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 14:54:41 --> No URI present. Default controller set.
DEBUG - 2023-09-18 14:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 14:54:41 --> initController - LoginPage.php
DEBUG - 2023-09-18 14:54:41 --> Total execution time: 0.0262
DEBUG - 2023-09-18 14:54:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 14:54:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 14:54:41 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 14:57:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 14:57:35 --> No URI present. Default controller set.
DEBUG - 2023-09-18 14:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 14:57:35 --> initController - LoginPage.php
DEBUG - 2023-09-18 14:57:35 --> Total execution time: 0.0268
DEBUG - 2023-09-18 14:57:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 14:57:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 14:57:35 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 14:57:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 14:57:59 --> No URI present. Default controller set.
DEBUG - 2023-09-18 14:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 14:57:59 --> initController - LoginPage.php
DEBUG - 2023-09-18 14:57:59 --> Total execution time: 0.0262
DEBUG - 2023-09-18 14:57:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 14:57:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 14:57:59 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 15:00:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 15:00:15 --> No URI present. Default controller set.
DEBUG - 2023-09-18 15:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 15:00:15 --> initController - LoginPage.php
DEBUG - 2023-09-18 15:00:15 --> Total execution time: 0.0263
DEBUG - 2023-09-18 15:00:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 15:00:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 15:00:15 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 15:01:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 15:01:08 --> No URI present. Default controller set.
DEBUG - 2023-09-18 15:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 15:01:08 --> initController - LoginPage.php
DEBUG - 2023-09-18 15:01:08 --> Total execution time: 0.0394
DEBUG - 2023-09-18 15:01:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 15:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 15:01:08 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 15:01:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 15:01:19 --> No URI present. Default controller set.
DEBUG - 2023-09-18 15:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 15:01:19 --> initController - LoginPage.php
DEBUG - 2023-09-18 15:01:19 --> Total execution time: 0.0256
DEBUG - 2023-09-18 15:01:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 15:01:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 15:01:19 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 15:03:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 15:03:57 --> No URI present. Default controller set.
DEBUG - 2023-09-18 15:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 15:03:57 --> initController - LoginPage.php
DEBUG - 2023-09-18 15:03:57 --> Total execution time: 0.0258
DEBUG - 2023-09-18 15:03:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 15:03:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 15:03:57 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 15:04:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 15:04:04 --> No URI present. Default controller set.
DEBUG - 2023-09-18 15:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 15:04:04 --> initController - LoginPage.php
DEBUG - 2023-09-18 15:04:04 --> Total execution time: 0.0259
DEBUG - 2023-09-18 15:04:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 15:04:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 15:04:04 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 15:06:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 15:06:17 --> No URI present. Default controller set.
DEBUG - 2023-09-18 15:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 15:06:17 --> initController - LoginPage.php
DEBUG - 2023-09-18 15:06:17 --> Total execution time: 0.0245
DEBUG - 2023-09-18 15:06:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 15:06:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 15:06:17 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 15:06:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 15:06:27 --> No URI present. Default controller set.
DEBUG - 2023-09-18 15:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 15:06:27 --> initController - LoginPage.php
DEBUG - 2023-09-18 15:06:27 --> Total execution time: 0.0268
DEBUG - 2023-09-18 15:06:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 15:06:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 15:06:27 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 15:09:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 15:09:03 --> No URI present. Default controller set.
DEBUG - 2023-09-18 15:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 15:09:03 --> initController - LoginPage.php
DEBUG - 2023-09-18 15:09:03 --> Total execution time: 0.0248
DEBUG - 2023-09-18 15:09:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 15:09:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 15:09:03 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 15:10:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 15:10:31 --> No URI present. Default controller set.
DEBUG - 2023-09-18 15:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 15:10:32 --> initController - LoginPage.php
DEBUG - 2023-09-18 15:10:32 --> Total execution time: 0.0286
DEBUG - 2023-09-18 15:10:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 15:10:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 15:10:32 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 15:10:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 15:10:49 --> No URI present. Default controller set.
DEBUG - 2023-09-18 15:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 15:10:49 --> initController - LoginPage.php
DEBUG - 2023-09-18 15:10:49 --> Total execution time: 0.0352
DEBUG - 2023-09-18 15:10:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 15:10:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 15:10:49 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 16:49:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 16:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 16:49:55 --> initController - LoginPage.php
DEBUG - 2023-09-18 16:49:55 --> Total execution time: 0.0245
DEBUG - 2023-09-18 16:49:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 16:49:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 16:49:55 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-18 16:50:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 16:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-18 16:50:10 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-18 16:50:10 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-18 16:50:10 --> Total execution time: 0.0275
DEBUG - 2023-09-18 16:50:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-18 16:50:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-18 16:50:10 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
