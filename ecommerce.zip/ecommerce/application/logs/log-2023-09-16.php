<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-09-16 09:37:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 09:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 09:37:39 --> Total execution time: 0.0449
DEBUG - 2023-09-16 09:37:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 09:37:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 09:37:40 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 09:37:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 09:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 09:37:40 --> Total execution time: 0.0386
DEBUG - 2023-09-16 09:37:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 09:37:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 09:37:40 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 09:37:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 09:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 09:37:40 --> Total execution time: 0.0413
DEBUG - 2023-09-16 09:37:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 09:37:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 09:37:40 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 09:37:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 09:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 09:37:40 --> Total execution time: 0.0416
DEBUG - 2023-09-16 09:37:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 09:37:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 09:37:40 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 09:37:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 09:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 09:37:40 --> Total execution time: 0.0664
DEBUG - 2023-09-16 09:37:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 09:37:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 09:37:40 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 09:37:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 09:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 09:37:40 --> Total execution time: 0.0382
DEBUG - 2023-09-16 09:37:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 09:37:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 09:37:41 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 10:01:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 10:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 10:01:18 --> Total execution time: 0.0165
DEBUG - 2023-09-16 10:01:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 10:01:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 10:01:18 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 10:51:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 10:51:26 --> No URI present. Default controller set.
DEBUG - 2023-09-16 10:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 10:51:26 --> initController - LoginPage.php
DEBUG - 2023-09-16 10:51:26 --> Total execution time: 0.0468
DEBUG - 2023-09-16 10:51:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 10:51:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 10:51:26 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 11:04:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 11:04:59 --> No URI present. Default controller set.
DEBUG - 2023-09-16 11:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 11:04:59 --> initController - LoginPage.php
DEBUG - 2023-09-16 11:04:59 --> Total execution time: 0.0353
DEBUG - 2023-09-16 11:04:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 11:04:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 11:04:59 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 11:32:23 --> UTF-8 Support Enabled
ERROR - 2023-09-16 11:32:23 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\WebProject\application\config\routes.php 68
DEBUG - 2023-09-16 11:33:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 11:33:19 --> No URI present. Default controller set.
DEBUG - 2023-09-16 11:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 11:33:19 --> initController - LoginPage.php
DEBUG - 2023-09-16 11:33:19 --> Total execution time: 0.0377
DEBUG - 2023-09-16 11:33:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 11:33:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 11:33:19 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 11:33:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 11:33:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 11:33:22 --> Severity: error --> Exception: syntax error, unexpected token "public", expecting end of file C:\xampp\htdocs\WebProject\application\controllers\admin.php 13
DEBUG - 2023-09-16 13:17:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:17:24 --> No URI present. Default controller set.
DEBUG - 2023-09-16 13:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:17:24 --> initController - LoginPage.php
DEBUG - 2023-09-16 13:17:24 --> Total execution time: 0.0762
DEBUG - 2023-09-16 13:17:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:17:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:17:24 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:17:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:17:26 --> initController - LoginPage.php
DEBUG - 2023-09-16 13:17:26 --> Total execution time: 0.0374
DEBUG - 2023-09-16 13:17:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:17:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:17:26 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:17:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:17:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:17:28 --> Severity: error --> Exception: syntax error, unexpected token "}" C:\xampp\htdocs\WebProject\application\controllers\admin.php 35
DEBUG - 2023-09-16 13:22:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:22:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:22:47 --> Severity: error --> Exception: syntax error, unexpected token "}" C:\xampp\htdocs\WebProject\application\controllers\admin.php 35
DEBUG - 2023-09-16 13:22:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:22:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:22:48 --> Severity: error --> Exception: syntax error, unexpected token "}" C:\xampp\htdocs\WebProject\application\controllers\admin.php 35
DEBUG - 2023-09-16 13:22:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:22:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:22:49 --> Severity: error --> Exception: syntax error, unexpected token "}" C:\xampp\htdocs\WebProject\application\controllers\admin.php 35
DEBUG - 2023-09-16 13:22:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:22:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:22:49 --> Severity: error --> Exception: syntax error, unexpected token "}" C:\xampp\htdocs\WebProject\application\controllers\admin.php 35
DEBUG - 2023-09-16 13:22:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:22:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:22:49 --> Severity: error --> Exception: syntax error, unexpected token "}" C:\xampp\htdocs\WebProject\application\controllers\admin.php 35
DEBUG - 2023-09-16 13:22:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:22:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:22:49 --> Severity: error --> Exception: syntax error, unexpected token "}" C:\xampp\htdocs\WebProject\application\controllers\admin.php 35
DEBUG - 2023-09-16 13:22:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:22:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:22:49 --> Severity: error --> Exception: syntax error, unexpected token "}" C:\xampp\htdocs\WebProject\application\controllers\admin.php 35
DEBUG - 2023-09-16 13:22:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:22:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:22:49 --> Severity: error --> Exception: syntax error, unexpected token "}" C:\xampp\htdocs\WebProject\application\controllers\admin.php 35
DEBUG - 2023-09-16 13:22:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:22:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:22:50 --> Severity: error --> Exception: syntax error, unexpected token "}" C:\xampp\htdocs\WebProject\application\controllers\admin.php 35
DEBUG - 2023-09-16 13:22:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:22:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:22:50 --> Severity: error --> Exception: syntax error, unexpected token "}" C:\xampp\htdocs\WebProject\application\controllers\admin.php 35
DEBUG - 2023-09-16 13:22:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:22:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:22:50 --> Severity: error --> Exception: syntax error, unexpected token "}" C:\xampp\htdocs\WebProject\application\controllers\admin.php 35
DEBUG - 2023-09-16 13:22:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:22:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:22:51 --> Severity: error --> Exception: syntax error, unexpected token "}" C:\xampp\htdocs\WebProject\application\controllers\admin.php 35
DEBUG - 2023-09-16 13:22:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:22:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:22:52 --> Severity: error --> Exception: syntax error, unexpected token "}" C:\xampp\htdocs\WebProject\application\controllers\admin.php 35
DEBUG - 2023-09-16 13:22:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:22:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:22:52 --> Severity: error --> Exception: syntax error, unexpected token "}" C:\xampp\htdocs\WebProject\application\controllers\admin.php 35
DEBUG - 2023-09-16 13:22:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:22:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:22:52 --> Severity: error --> Exception: syntax error, unexpected token "}" C:\xampp\htdocs\WebProject\application\controllers\admin.php 35
DEBUG - 2023-09-16 13:25:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:25:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:25:12 --> Severity: error --> Exception: Call to undefined method CI_Loader::help() C:\xampp\htdocs\WebProject\application\controllers\admin.php 33
DEBUG - 2023-09-16 13:25:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:25:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:25:13 --> Severity: error --> Exception: Call to undefined method CI_Loader::help() C:\xampp\htdocs\WebProject\application\controllers\admin.php 33
DEBUG - 2023-09-16 13:26:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:26:14 --> Total execution time: 0.0471
DEBUG - 2023-09-16 13:26:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:26:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:26:14 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:26:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:26:15 --> Total execution time: 0.0454
DEBUG - 2023-09-16 13:26:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:26:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:26:15 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:26:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:26:16 --> Total execution time: 0.0417
DEBUG - 2023-09-16 13:26:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:26:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:26:16 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:26:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:26:16 --> Total execution time: 0.0454
DEBUG - 2023-09-16 13:26:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:26:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:26:16 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:26:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:26:16 --> Total execution time: 0.0402
DEBUG - 2023-09-16 13:26:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:26:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:26:16 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:26:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:26:16 --> Total execution time: 0.0457
DEBUG - 2023-09-16 13:26:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:26:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:26:16 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:26:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:26:16 --> Total execution time: 0.0410
DEBUG - 2023-09-16 13:26:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:26:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:26:17 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:26:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:26:17 --> Total execution time: 0.0416
DEBUG - 2023-09-16 13:26:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:26:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:26:17 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:26:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:26:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:26:40 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:26:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:26:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:26:41 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:26:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:26:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:26:42 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:26:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:26:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:26:43 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:26:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:26:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:26:43 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:26:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:26:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:26:44 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:26:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:26:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:26:44 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:26:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:26:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:26:44 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:26:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:26:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:26:44 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:26:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:26:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:26:44 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:26:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:26:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:26:44 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:26:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:26:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:26:45 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:26:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:26:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:26:45 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:26:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:26:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:26:45 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:28:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:28:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:28:24 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:28:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:28:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:28:25 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:28:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:28:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:28:25 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:28:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:28:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:28:25 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:28:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:28:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:28:26 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:28:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:28:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:28:26 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:28:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:28:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:28:26 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:28:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:28:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:28:26 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:28:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:28:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:28:26 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:28:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:28:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:28:49 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:28:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:28:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:28:49 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:28:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:28:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:28:49 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:28:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:28:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:28:50 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:28:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:28:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:28:50 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:28:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:28:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:28:50 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:28:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:28:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:28:50 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:30:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:30:58 --> Total execution time: 0.0432
DEBUG - 2023-09-16 13:30:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:30:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:30:58 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:30:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:30:59 --> Total execution time: 0.0488
DEBUG - 2023-09-16 13:30:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:30:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:30:59 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:31:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:31:00 --> Total execution time: 0.0411
DEBUG - 2023-09-16 13:31:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:31:00 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:31:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:31:00 --> Total execution time: 0.0409
DEBUG - 2023-09-16 13:31:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:31:00 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:31:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:31:00 --> Total execution time: 0.0433
DEBUG - 2023-09-16 13:31:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:31:00 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:31:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:31:00 --> Total execution time: 0.0484
DEBUG - 2023-09-16 13:31:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:31:00 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:31:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:31:01 --> Total execution time: 0.0382
DEBUG - 2023-09-16 13:31:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:31:01 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:31:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:31:01 --> Total execution time: 0.0425
DEBUG - 2023-09-16 13:31:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:31:01 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:31:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:31:01 --> Total execution time: 0.0389
DEBUG - 2023-09-16 13:31:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:31:01 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:31:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:31:01 --> Total execution time: 0.0411
DEBUG - 2023-09-16 13:31:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:31:01 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:31:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:31:02 --> Total execution time: 0.0379
DEBUG - 2023-09-16 13:31:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:31:02 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:31:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:31:02 --> Total execution time: 0.0370
DEBUG - 2023-09-16 13:31:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:31:02 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:31:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:31:02 --> Total execution time: 0.0402
DEBUG - 2023-09-16 13:31:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:31:02 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:31:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:31:02 --> Total execution time: 0.0417
DEBUG - 2023-09-16 13:31:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:31:02 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:31:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:31:03 --> Total execution time: 0.0434
DEBUG - 2023-09-16 13:31:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:31:03 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:31:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:31:03 --> Total execution time: 0.0455
DEBUG - 2023-09-16 13:31:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:31:03 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:31:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:31:03 --> Total execution time: 0.0573
DEBUG - 2023-09-16 13:31:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:31:03 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:31:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:31:03 --> Total execution time: 0.0400
DEBUG - 2023-09-16 13:31:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:31:03 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:31:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:31:03 --> Total execution time: 0.0434
DEBUG - 2023-09-16 13:31:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:31:04 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:31:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:31:04 --> Total execution time: 0.0423
DEBUG - 2023-09-16 13:31:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:31:04 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:31:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:31:04 --> Total execution time: 0.0478
DEBUG - 2023-09-16 13:31:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:31:04 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:31:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:31:04 --> Total execution time: 0.0644
DEBUG - 2023-09-16 13:31:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:31:04 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:31:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:31:04 --> Total execution time: 0.0366
DEBUG - 2023-09-16 13:31:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:31:04 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:31:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:31:05 --> Total execution time: 0.0414
DEBUG - 2023-09-16 13:31:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:31:05 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:31:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:31:05 --> Total execution time: 0.0379
DEBUG - 2023-09-16 13:31:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:31:05 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:31:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:31:05 --> Total execution time: 0.0380
DEBUG - 2023-09-16 13:31:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:31:05 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:31:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:31:05 --> Total execution time: 0.0376
DEBUG - 2023-09-16 13:31:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:31:05 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:31:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:31:05 --> Total execution time: 0.0432
DEBUG - 2023-09-16 13:31:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:31:06 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:31:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:31:06 --> Total execution time: 0.0541
DEBUG - 2023-09-16 13:31:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:31:06 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:31:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:31:06 --> Total execution time: 0.0443
DEBUG - 2023-09-16 13:31:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:31:06 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:31:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:31:06 --> Total execution time: 0.0402
DEBUG - 2023-09-16 13:31:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:31:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:31:06 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:38:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:38:45 --> Total execution time: 0.0470
DEBUG - 2023-09-16 13:38:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:38:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:38:45 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:38:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:38:46 --> Total execution time: 0.0425
DEBUG - 2023-09-16 13:38:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:38:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:38:46 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:38:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:38:46 --> Total execution time: 0.0426
DEBUG - 2023-09-16 13:38:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:38:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:38:46 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:38:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:38:46 --> Total execution time: 0.0447
DEBUG - 2023-09-16 13:38:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:38:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:38:46 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:38:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:38:46 --> Total execution time: 0.0402
DEBUG - 2023-09-16 13:38:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:38:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:38:46 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:38:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:38:46 --> Total execution time: 0.0420
DEBUG - 2023-09-16 13:38:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:38:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:38:46 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:38:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:38:47 --> Total execution time: 0.0476
DEBUG - 2023-09-16 13:38:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:38:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:38:47 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:38:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:38:47 --> Total execution time: 0.0378
DEBUG - 2023-09-16 13:38:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:38:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:38:47 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:38:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:38:47 --> Total execution time: 0.0383
DEBUG - 2023-09-16 13:38:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:38:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:38:47 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:38:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:38:47 --> Total execution time: 0.0550
DEBUG - 2023-09-16 13:38:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:38:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:38:47 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:38:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:38:47 --> Total execution time: 0.0448
DEBUG - 2023-09-16 13:38:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:38:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:38:48 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:38:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:38:48 --> Total execution time: 0.0396
DEBUG - 2023-09-16 13:38:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:38:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:38:48 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:38:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 13:38:48 --> Total execution time: 0.0462
DEBUG - 2023-09-16 13:38:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:38:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:38:48 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 13:40:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:40:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:40:31 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:40:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:40:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:40:32 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:40:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:40:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:40:33 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:40:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:40:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:40:33 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:40:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:40:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:40:33 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:40:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:40:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:40:33 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:40:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:40:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:40:33 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:40:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:40:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:40:33 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:40:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:40:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:40:34 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:40:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:40:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:40:34 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:40:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:40:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:40:34 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:40:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:40:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:40:34 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:44:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:44:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:44:06 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:44:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:44:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:44:07 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:44:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:44:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:44:07 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:44:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:44:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:44:07 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:44:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:44:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:44:07 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:44:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:44:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:44:07 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:46:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:46:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:46:03 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:49:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:49:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:49:07 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:49:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:49:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:49:08 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:49:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:49:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:49:08 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:49:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:49:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:49:08 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:49:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:49:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:49:08 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:49:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:49:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:49:08 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:49:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:49:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:49:09 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:49:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:49:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:49:09 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:49:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:49:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:49:09 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:49:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:49:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:49:09 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:49:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:49:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:49:09 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:49:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:49:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:49:10 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:49:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:49:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:49:10 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:49:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:49:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:49:10 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:49:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:49:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:49:10 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:49:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:49:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:49:10 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:49:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:49:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:49:11 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:49:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:49:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:49:11 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:49:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:49:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:49:11 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:49:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:49:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:49:12 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:49:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:49:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:49:12 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:49:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:49:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:49:13 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:49:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:49:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:49:13 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:49:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:49:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:49:13 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:49:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:49:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:49:13 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:49:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:49:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:49:14 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:49:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:49:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:49:14 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:49:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:49:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:49:15 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:50:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:50:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:50:19 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:50:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:50:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:50:19 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:50:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:50:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:50:20 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:50:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:50:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:50:20 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:50:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:50:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:50:20 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:52:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:52:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:52:21 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:52:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:52:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:52:22 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:52:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:52:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:52:22 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:52:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:52:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:52:22 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:52:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:52:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:52:22 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:52:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:52:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:52:23 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:52:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:52:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:52:23 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:52:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:52:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:52:23 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:52:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:52:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:52:23 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:52:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:52:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:52:23 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:52:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:52:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:52:42 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:52:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:52:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:52:43 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:52:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:52:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:52:43 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:53:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:53:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:53:54 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:53:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:53:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:53:54 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:53:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:53:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:53:56 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:53:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:53:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:53:57 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 13:54:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 13:54:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 13:54:38 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:00:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:00:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:00:00 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:00:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:00:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:00:01 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:00:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:00:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:00:01 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:00:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:00:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:00:01 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:00:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:00:02 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:00:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:00:02 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:00:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:00:02 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:14:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:14:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:14:26 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:14:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:14:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:14:27 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:14:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:14:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:14:27 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:14:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:14:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:14:27 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:26:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:26:56 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:26:56 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:26:56 --> Total execution time: 0.0247
DEBUG - 2023-09-16 14:26:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:26:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:26:56 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 14:27:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:27:06 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:27:06 --> Total execution time: 0.0426
DEBUG - 2023-09-16 14:27:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:27:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:27:06 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 14:27:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:27:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:27:08 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:29:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:29:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:29:57 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:29:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:29:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:29:57 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:29:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:29:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:29:58 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:29:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:29:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:29:58 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:29:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:29:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:29:58 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:30:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:30:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:30:16 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:30:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:30:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:30:16 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:30:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:30:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:30:16 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:30:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:30:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:30:17 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:30:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:30:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:30:17 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:30:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:30:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:30:17 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:31:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:31:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:31:57 --> Severity: error --> Exception: syntax error, unexpected variable "$this", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\controllers\admin.php 21
DEBUG - 2023-09-16 14:33:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:33:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:33:17 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:33:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:33:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:33:19 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:33:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:33:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:33:19 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:33:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:33:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:33:19 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:33:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:33:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:33:20 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:33:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:33:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:33:20 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:33:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:33:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:33:20 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:33:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:33:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:33:20 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:33:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:33:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:33:21 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:33:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:33:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:33:21 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:33:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:33:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:33:21 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:33:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:33:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:33:21 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:33:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:33:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:33:22 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:33:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:33:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:33:22 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:33:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:33:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:33:22 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:33:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:33:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:33:22 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:33:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:33:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:33:23 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:33:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:33:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:33:23 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:33:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:33:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:33:23 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 14:33:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:33:34 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:33:34 --> Total execution time: 0.0352
DEBUG - 2023-09-16 14:33:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:33:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:33:34 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 14:34:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:34:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:34:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:34:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:34:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:34:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:34:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:34:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:34:41 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 14:34:41 --> Total execution time: 0.0507
DEBUG - 2023-09-16 14:34:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:34:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:34:41 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 14:34:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:34:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:34:42 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 14:34:42 --> Total execution time: 0.0337
DEBUG - 2023-09-16 14:34:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:34:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:34:42 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 14:34:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:34:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:34:42 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 14:34:42 --> Total execution time: 0.0336
DEBUG - 2023-09-16 14:34:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:34:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 14:34:42 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 14:37:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:37:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:37:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:38:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:39:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:42:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:42:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:44:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:44:27 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:44:27 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:44:27 --> Total execution time: 0.0368
DEBUG - 2023-09-16 14:44:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:44:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:44:27 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:44:27 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:44:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:44:27 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:44:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:44:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:44:27 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:44:27 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:44:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:44:27 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:44:27 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:44:27 --> Total execution time: 0.0530
DEBUG - 2023-09-16 14:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:44:27 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:44:27 --> Total execution time: 0.0581
DEBUG - 2023-09-16 14:44:27 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:44:27 --> Total execution time: 0.0464
DEBUG - 2023-09-16 14:44:27 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:44:27 --> Total execution time: 0.0518
DEBUG - 2023-09-16 14:44:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:44:27 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:44:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:44:27 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:44:27 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:44:27 --> Total execution time: 0.0786
DEBUG - 2023-09-16 14:44:27 --> Total execution time: 0.0572
DEBUG - 2023-09-16 14:44:27 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:44:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:44:27 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:44:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:44:27 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:44:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:44:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:44:27 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:44:27 --> Total execution time: 0.0470
DEBUG - 2023-09-16 14:44:27 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:44:27 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:44:27 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:44:27 --> Total execution time: 0.0516
DEBUG - 2023-09-16 14:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:44:27 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:44:27 --> Total execution time: 0.0505
DEBUG - 2023-09-16 14:44:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:44:27 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:44:27 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:44:27 --> Total execution time: 0.0581
DEBUG - 2023-09-16 14:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:44:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:44:27 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:44:27 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:44:27 --> Total execution time: 0.0514
DEBUG - 2023-09-16 14:44:27 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:44:27 --> Total execution time: 0.0543
DEBUG - 2023-09-16 14:44:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:44:27 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:44:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:44:27 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:44:27 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:44:27 --> Total execution time: 0.0502
DEBUG - 2023-09-16 14:44:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:44:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:44:27 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:44:27 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:44:27 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:44:27 --> Total execution time: 0.0484
DEBUG - 2023-09-16 14:44:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:44:27 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:44:27 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:44:27 --> Total execution time: 0.0433
DEBUG - 2023-09-16 14:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:44:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:44:27 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:44:27 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:44:27 --> Total execution time: 0.0404
DEBUG - 2023-09-16 14:44:27 --> Total execution time: 0.0417
DEBUG - 2023-09-16 14:44:27 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:44:27 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:44:27 --> Total execution time: 0.0659
DEBUG - 2023-09-16 14:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:44:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:44:27 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:44:27 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:44:27 --> Total execution time: 0.0400
DEBUG - 2023-09-16 14:44:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:44:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:44:27 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:44:27 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:44:27 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:44:27 --> Total execution time: 0.0466
DEBUG - 2023-09-16 14:44:27 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:44:27 --> Total execution time: 0.0416
DEBUG - 2023-09-16 14:44:27 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:44:27 --> Total execution time: 0.0400
DEBUG - 2023-09-16 14:44:27 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:44:27 --> Total execution time: 0.0669
DEBUG - 2023-09-16 14:45:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:45:18 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:45:18 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:45:18 --> Total execution time: 0.0383
DEBUG - 2023-09-16 14:45:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:45:18 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:45:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:45:18 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:45:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:45:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:45:18 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:45:18 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:45:18 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:45:18 --> Total execution time: 0.0482
DEBUG - 2023-09-16 14:45:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:45:18 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:45:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:45:18 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:45:18 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:45:18 --> Total execution time: 0.0526
DEBUG - 2023-09-16 14:45:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:45:18 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:45:18 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:45:18 --> Total execution time: 0.0637
DEBUG - 2023-09-16 14:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:45:18 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:45:18 --> Total execution time: 0.0876
DEBUG - 2023-09-16 14:45:18 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:45:18 --> Total execution time: 0.0515
DEBUG - 2023-09-16 14:45:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:45:18 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:45:18 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:45:18 --> Total execution time: 0.0663
DEBUG - 2023-09-16 14:45:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:45:18 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:45:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:45:18 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:45:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:45:18 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:45:18 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:45:18 --> Total execution time: 0.0598
DEBUG - 2023-09-16 14:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:45:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:45:18 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:45:18 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:45:18 --> Total execution time: 0.0582
DEBUG - 2023-09-16 14:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:45:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:45:18 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:45:18 --> Total execution time: 0.0574
DEBUG - 2023-09-16 14:45:18 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:45:18 --> Total execution time: 0.0492
DEBUG - 2023-09-16 14:45:18 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:45:18 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:45:18 --> Total execution time: 0.0557
DEBUG - 2023-09-16 14:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:45:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:45:18 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:45:18 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:45:18 --> Total execution time: 0.0527
DEBUG - 2023-09-16 14:45:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:45:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:45:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:45:18 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:45:18 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:45:18 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:45:18 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:45:18 --> Total execution time: 0.0457
DEBUG - 2023-09-16 14:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:45:18 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:45:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:45:18 --> Total execution time: 0.0504
DEBUG - 2023-09-16 14:45:18 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:45:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:45:18 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:45:18 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:45:18 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:45:18 --> Total execution time: 0.0519
DEBUG - 2023-09-16 14:45:18 --> Total execution time: 0.0539
DEBUG - 2023-09-16 14:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:45:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:45:18 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:45:18 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:45:18 --> Total execution time: 0.0665
DEBUG - 2023-09-16 14:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:45:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:45:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:45:18 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:45:18 --> Total execution time: 0.0594
DEBUG - 2023-09-16 14:45:18 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:45:18 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:45:18 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:45:18 --> Total execution time: 0.0504
DEBUG - 2023-09-16 14:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:45:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:45:18 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:45:18 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:45:18 --> Total execution time: 0.0417
DEBUG - 2023-09-16 14:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:45:18 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:45:18 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:45:18 --> Total execution time: 0.0375
DEBUG - 2023-09-16 14:45:18 --> Total execution time: 0.0381
DEBUG - 2023-09-16 14:45:18 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:45:18 --> Total execution time: 0.0357
DEBUG - 2023-09-16 14:49:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:49:39 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:49:39 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:49:39 --> Total execution time: 0.0426
DEBUG - 2023-09-16 14:49:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:49:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:49:39 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:49:39 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:49:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:49:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:49:39 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:49:39 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:49:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:49:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:49:39 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:49:39 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:49:39 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:49:39 --> Total execution time: 0.0681
DEBUG - 2023-09-16 14:49:39 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:49:39 --> Total execution time: 0.0676
DEBUG - 2023-09-16 14:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:49:39 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:49:39 --> Total execution time: 0.0829
DEBUG - 2023-09-16 14:49:39 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:49:39 --> Total execution time: 0.0900
DEBUG - 2023-09-16 14:49:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:49:39 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:49:39 --> Total execution time: 0.0691
DEBUG - 2023-09-16 14:49:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:49:39 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:49:39 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:49:39 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:49:39 --> Total execution time: 0.0674
DEBUG - 2023-09-16 14:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:49:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:49:39 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:49:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:49:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:49:39 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:49:39 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:49:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:49:39 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:49:39 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:49:39 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:49:39 --> Total execution time: 0.0601
DEBUG - 2023-09-16 14:49:39 --> Total execution time: 0.0580
DEBUG - 2023-09-16 14:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:49:39 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:49:39 --> Total execution time: 0.0649
DEBUG - 2023-09-16 14:49:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:49:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:49:39 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:49:39 --> Total execution time: 0.0630
DEBUG - 2023-09-16 14:49:39 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:49:39 --> Total execution time: 0.0638
DEBUG - 2023-09-16 14:49:39 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:49:39 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:49:39 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:49:39 --> Total execution time: 0.0604
DEBUG - 2023-09-16 14:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:49:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:49:39 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:49:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:49:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:49:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:49:39 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:49:39 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:49:39 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:49:39 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:49:39 --> Total execution time: 0.0533
DEBUG - 2023-09-16 14:49:39 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:49:39 --> Total execution time: 0.0542
DEBUG - 2023-09-16 14:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:49:39 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:49:39 --> Total execution time: 0.0546
DEBUG - 2023-09-16 14:49:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:49:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:49:39 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:49:39 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:49:39 --> Total execution time: 0.0529
DEBUG - 2023-09-16 14:49:39 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:49:39 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:49:39 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:49:39 --> Total execution time: 0.0533
DEBUG - 2023-09-16 14:49:39 --> Total execution time: 0.0519
DEBUG - 2023-09-16 14:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:49:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:49:39 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:49:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:49:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 14:49:39 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:49:39 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:49:39 --> No URI present. Default controller set.
DEBUG - 2023-09-16 14:49:39 --> Total execution time: 0.0490
DEBUG - 2023-09-16 14:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 14:49:39 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:49:39 --> Total execution time: 0.0448
DEBUG - 2023-09-16 14:49:39 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:49:39 --> Total execution time: 0.0714
DEBUG - 2023-09-16 14:49:39 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:49:39 --> Total execution time: 0.0430
DEBUG - 2023-09-16 14:49:39 --> initController - LoginPage.php
DEBUG - 2023-09-16 14:49:39 --> Total execution time: 0.0427
DEBUG - 2023-09-16 15:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:09:47 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:09:47 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:09:47 --> Total execution time: 0.0466
DEBUG - 2023-09-16 15:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:09:47 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:09:47 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:09:47 --> Total execution time: 0.0552
DEBUG - 2023-09-16 15:10:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:07 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:07 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:07 --> Total execution time: 0.0481
DEBUG - 2023-09-16 15:10:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:07 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:07 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:07 --> Total execution time: 0.0494
DEBUG - 2023-09-16 15:10:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:13 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:13 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:13 --> Total execution time: 0.0407
DEBUG - 2023-09-16 15:10:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:13 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:13 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:13 --> Total execution time: 0.0426
DEBUG - 2023-09-16 15:10:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:14 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:14 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:14 --> Total execution time: 0.0428
DEBUG - 2023-09-16 15:10:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:14 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:14 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:14 --> Total execution time: 0.0407
DEBUG - 2023-09-16 15:10:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:15 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:15 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:15 --> Total execution time: 0.0405
DEBUG - 2023-09-16 15:10:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:15 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:15 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:15 --> Total execution time: 0.0413
DEBUG - 2023-09-16 15:10:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:16 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:16 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:16 --> Total execution time: 0.0390
DEBUG - 2023-09-16 15:10:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:16 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:16 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:16 --> Total execution time: 0.0460
DEBUG - 2023-09-16 15:10:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:32 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:32 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:32 --> Total execution time: 0.0426
DEBUG - 2023-09-16 15:10:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:32 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:32 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:32 --> Total execution time: 0.0513
DEBUG - 2023-09-16 15:10:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:35 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:35 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:35 --> Total execution time: 0.0430
DEBUG - 2023-09-16 15:10:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:35 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:35 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:35 --> Total execution time: 0.0585
DEBUG - 2023-09-16 15:10:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:36 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:36 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:36 --> Total execution time: 0.0467
DEBUG - 2023-09-16 15:10:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:36 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:36 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:36 --> Total execution time: 0.0476
DEBUG - 2023-09-16 15:10:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:37 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:37 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:37 --> Total execution time: 0.0421
DEBUG - 2023-09-16 15:10:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:37 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:37 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:37 --> Total execution time: 0.0486
DEBUG - 2023-09-16 15:10:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:37 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:37 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:37 --> Total execution time: 0.0417
DEBUG - 2023-09-16 15:10:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:37 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:37 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:37 --> Total execution time: 0.0438
DEBUG - 2023-09-16 15:10:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:37 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:37 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:37 --> Total execution time: 0.0401
DEBUG - 2023-09-16 15:10:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:37 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:37 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:37 --> Total execution time: 0.0456
DEBUG - 2023-09-16 15:10:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:38 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:38 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:38 --> Total execution time: 0.0470
DEBUG - 2023-09-16 15:10:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:38 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:38 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:38 --> Total execution time: 0.0519
DEBUG - 2023-09-16 15:10:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:38 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:38 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:38 --> Total execution time: 0.0653
DEBUG - 2023-09-16 15:10:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:38 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:38 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:38 --> Total execution time: 0.0488
DEBUG - 2023-09-16 15:10:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:39 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:39 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:39 --> Total execution time: 0.0575
DEBUG - 2023-09-16 15:10:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:39 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:39 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:39 --> Total execution time: 0.0512
DEBUG - 2023-09-16 15:10:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:39 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:39 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:39 --> Total execution time: 0.0523
DEBUG - 2023-09-16 15:10:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:39 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:39 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:39 --> Total execution time: 0.0675
DEBUG - 2023-09-16 15:10:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:41 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:41 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:41 --> Total execution time: 0.0458
DEBUG - 2023-09-16 15:10:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:41 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:41 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:41 --> Total execution time: 0.0469
DEBUG - 2023-09-16 15:10:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:42 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:42 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:42 --> Total execution time: 0.0568
DEBUG - 2023-09-16 15:10:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:42 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:42 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:42 --> Total execution time: 0.0539
DEBUG - 2023-09-16 15:10:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:42 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:42 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:42 --> Total execution time: 0.0422
DEBUG - 2023-09-16 15:10:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:42 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:42 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:42 --> Total execution time: 0.0447
DEBUG - 2023-09-16 15:10:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:43 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:43 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:43 --> Total execution time: 0.0441
DEBUG - 2023-09-16 15:10:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:43 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:43 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:43 --> Total execution time: 0.0478
DEBUG - 2023-09-16 15:10:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:43 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:43 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:43 --> Total execution time: 0.0685
DEBUG - 2023-09-16 15:10:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:43 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:43 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:43 --> Total execution time: 0.0638
DEBUG - 2023-09-16 15:10:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:44 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:44 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:44 --> Total execution time: 0.0410
DEBUG - 2023-09-16 15:10:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:44 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:44 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:44 --> Total execution time: 0.0541
DEBUG - 2023-09-16 15:10:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:44 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:44 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:44 --> Total execution time: 0.0431
DEBUG - 2023-09-16 15:10:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:44 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:44 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:44 --> Total execution time: 0.0416
DEBUG - 2023-09-16 15:10:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:44 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:44 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:44 --> Total execution time: 0.0411
DEBUG - 2023-09-16 15:10:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:44 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:44 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:44 --> Total execution time: 0.0440
DEBUG - 2023-09-16 15:10:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:45 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:45 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:45 --> Total execution time: 0.0431
DEBUG - 2023-09-16 15:10:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:45 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:45 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:45 --> Total execution time: 0.0438
DEBUG - 2023-09-16 15:10:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:45 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:45 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:45 --> Total execution time: 0.0430
DEBUG - 2023-09-16 15:10:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:45 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:45 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:45 --> Total execution time: 0.0416
DEBUG - 2023-09-16 15:10:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:46 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:46 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:46 --> Total execution time: 0.0420
DEBUG - 2023-09-16 15:10:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:46 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:46 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:46 --> Total execution time: 0.0515
DEBUG - 2023-09-16 15:10:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:46 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:46 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:46 --> Total execution time: 0.0429
DEBUG - 2023-09-16 15:10:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:10:46 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:10:46 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:10:46 --> Total execution time: 0.0444
DEBUG - 2023-09-16 15:11:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:11:37 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:11:37 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:11:37 --> Total execution time: 0.0482
DEBUG - 2023-09-16 15:11:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:11:37 --> No URI present. Default controller set.
DEBUG - 2023-09-16 15:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:11:37 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:11:37 --> Total execution time: 0.0591
DEBUG - 2023-09-16 15:12:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:12:57 --> initController - LoginPage.php
DEBUG - 2023-09-16 15:12:57 --> Total execution time: 0.0465
DEBUG - 2023-09-16 15:12:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:12:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:12:57 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 15:13:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:13:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:13:10 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 15:13:10 --> Total execution time: 0.0516
DEBUG - 2023-09-16 15:13:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:13:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:13:10 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 15:13:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:17:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:17:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:17:35 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 15:17:35 --> Total execution time: 0.0482
DEBUG - 2023-09-16 15:17:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:17:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:17:35 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 15:18:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:19:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:19:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:19:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:19:56 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 15:19:56 --> Total execution time: 0.0176
DEBUG - 2023-09-16 15:19:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:19:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:19:56 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 15:19:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:19:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:19:58 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 15:19:58 --> Total execution time: 0.0178
DEBUG - 2023-09-16 15:19:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:19:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:19:58 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 15:19:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:19:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:19:59 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 15:19:59 --> Total execution time: 0.0172
DEBUG - 2023-09-16 15:19:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:19:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:19:59 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 15:19:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:19:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:19:59 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 15:19:59 --> Total execution time: 0.0178
DEBUG - 2023-09-16 15:19:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:19:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:19:59 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 15:20:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:20:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:20:00 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 15:20:00 --> Total execution time: 0.0170
DEBUG - 2023-09-16 15:20:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:20:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:20:00 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 15:20:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:20:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:20:00 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 15:20:00 --> Total execution time: 0.0181
DEBUG - 2023-09-16 15:20:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:20:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:20:00 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 15:21:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:21:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:21:42 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 15:21:42 --> Total execution time: 0.0186
DEBUG - 2023-09-16 15:21:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:21:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:21:42 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 15:22:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 15:23:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:23:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:23:05 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 15:23:05 --> Total execution time: 0.0191
DEBUG - 2023-09-16 15:23:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:23:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:23:06 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 15:23:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:23:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:23:27 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 15:23:27 --> Total execution time: 0.0184
DEBUG - 2023-09-16 15:23:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:23:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:23:27 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 15:30:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:30:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:30:08 --> Severity: error --> Exception: define() expects at least 2 arguments, 1 given C:\xampp\htdocs\WebProject\application\models\ProductModel.php 2
DEBUG - 2023-09-16 15:32:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:32:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:32:47 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 15:32:47 --> Total execution time: 0.0222
DEBUG - 2023-09-16 15:32:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:32:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:32:47 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 15:32:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:32:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:32:50 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 15:32:50 --> Total execution time: 0.0200
DEBUG - 2023-09-16 15:32:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:32:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:32:50 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 15:33:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:33:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:33:18 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 15:33:18 --> Total execution time: 0.0189
DEBUG - 2023-09-16 15:33:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:33:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:33:18 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 15:44:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:44:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:44:05 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 15:44:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:44:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:44:31 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 15:44:31 --> Total execution time: 0.0196
DEBUG - 2023-09-16 15:44:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:44:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:44:31 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 15:44:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:44:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:44:50 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 15:44:50 --> Total execution time: 0.0189
DEBUG - 2023-09-16 15:44:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:44:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:44:50 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 15:44:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:44:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:44:58 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 15:44:58 --> Total execution time: 0.0195
DEBUG - 2023-09-16 15:44:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:44:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:44:58 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 15:46:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:46:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:46:19 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 15:46:19 --> Total execution time: 0.0202
DEBUG - 2023-09-16 15:46:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:46:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:46:19 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 15:46:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:46:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:46:20 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 15:46:20 --> Total execution time: 0.0191
DEBUG - 2023-09-16 15:46:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:46:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:46:20 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 15:46:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:46:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:46:20 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 15:46:20 --> Total execution time: 0.0193
DEBUG - 2023-09-16 15:46:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:46:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:46:20 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 15:46:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:46:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:46:21 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 15:46:21 --> Total execution time: 0.0190
DEBUG - 2023-09-16 15:46:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:46:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:46:21 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 15:46:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:46:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:46:21 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 15:46:21 --> Total execution time: 0.0197
DEBUG - 2023-09-16 15:46:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:46:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:46:21 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 15:46:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:46:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:46:21 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 15:46:21 --> Total execution time: 0.0183
DEBUG - 2023-09-16 15:46:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:46:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:46:21 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 15:46:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:46:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:46:22 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 15:46:22 --> Total execution time: 0.0187
DEBUG - 2023-09-16 15:46:22 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 15:46:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 15:46:22 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 16:09:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 16:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 16:09:23 --> initController - LoginPage.php
DEBUG - 2023-09-16 16:09:23 --> Total execution time: 0.0193
DEBUG - 2023-09-16 16:09:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 16:09:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 16:09:23 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 16:09:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 16:09:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 16:09:31 --> 404 Page Not Found: Frontend/admin
DEBUG - 2023-09-16 16:12:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 16:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 16:12:07 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 16:12:07 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 16:12:07 --> Total execution time: 0.0205
DEBUG - 2023-09-16 16:12:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 16:12:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 16:12:07 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 16:12:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 16:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 16:12:38 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 16:12:38 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 16:12:38 --> Total execution time: 0.0199
DEBUG - 2023-09-16 16:12:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 16:12:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 16:12:38 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 16:12:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 16:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 16:12:39 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 16:12:39 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 16:12:39 --> Total execution time: 0.0199
DEBUG - 2023-09-16 16:12:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 16:12:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 16:12:39 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 16:12:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 16:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 16:12:39 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 16:12:39 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 16:12:39 --> Total execution time: 0.0200
DEBUG - 2023-09-16 16:12:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 16:12:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 16:12:39 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 16:12:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 16:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 16:12:48 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 16:12:48 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 16:12:48 --> Total execution time: 0.0197
DEBUG - 2023-09-16 16:12:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 16:12:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 16:12:48 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 16:12:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 16:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 16:12:49 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 16:12:49 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 16:12:49 --> Total execution time: 0.0191
DEBUG - 2023-09-16 16:12:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 16:12:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 16:12:49 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 16:12:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 16:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 16:12:50 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 16:12:50 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 16:12:50 --> Total execution time: 0.0191
DEBUG - 2023-09-16 16:12:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 16:12:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 16:12:50 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 16:12:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 16:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 16:12:50 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 16:12:50 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 16:12:50 --> Total execution time: 0.0194
DEBUG - 2023-09-16 16:12:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 16:12:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 16:12:50 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 16:13:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 16:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 16:13:00 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 16:13:00 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 16:13:00 --> Total execution time: 0.0234
DEBUG - 2023-09-16 16:13:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 16:13:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 16:13:00 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 16:13:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 16:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 16:13:16 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 16:13:16 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 16:13:16 --> Total execution time: 0.0195
DEBUG - 2023-09-16 16:13:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 16:13:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 16:13:16 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 16:27:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 16:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 16:27:07 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 16:27:07 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 16:27:07 --> Total execution time: 0.0209
DEBUG - 2023-09-16 16:27:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 16:27:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 16:27:07 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 16:27:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 16:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 16:27:31 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 16:27:31 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 16:27:31 --> Total execution time: 0.0198
DEBUG - 2023-09-16 16:27:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 16:27:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 16:27:31 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 16:30:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 16:30:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 16:30:40 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 16:32:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 16:32:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 16:32:16 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 16:32:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 16:32:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 16:32:17 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 16:32:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 16:32:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 16:32:17 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 16:32:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 16:32:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 16:32:17 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 17:33:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:33:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 17:33:56 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 17:33:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:33:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 17:33:57 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 17:33:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:33:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 17:33:58 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 17:33:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:33:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 17:33:58 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 17:33:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:33:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 17:33:58 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 17:33:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:33:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 17:33:58 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 17:33:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:33:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 17:33:58 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 17:33:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:33:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 17:33:59 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 17:34:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:34:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 17:34:27 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 17:34:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:34:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 17:34:28 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 17:34:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:34:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 17:34:28 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 17:34:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:34:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 17:34:28 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 17:34:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:34:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 17:34:28 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 17:34:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:34:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 17:34:29 --> 404 Page Not Found: Admin/index
DEBUG - 2023-09-16 17:34:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 17:34:42 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 17:34:42 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 17:34:42 --> Total execution time: 0.0389
DEBUG - 2023-09-16 17:34:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:34:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 17:34:42 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 17:35:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 17:35:05 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 17:35:05 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 17:35:05 --> Total execution time: 0.0440
DEBUG - 2023-09-16 17:35:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:35:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 17:35:05 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 17:37:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 17:37:50 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 17:37:50 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 17:37:50 --> Total execution time: 0.0418
DEBUG - 2023-09-16 17:37:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:37:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 17:37:50 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 17:37:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 17:37:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 17:37:51 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 17:37:51 --> Total execution time: 0.0391
DEBUG - 2023-09-16 17:37:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:37:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 17:37:51 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 17:37:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 17:37:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 17:37:51 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 17:37:51 --> Total execution time: 0.0354
DEBUG - 2023-09-16 17:37:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:37:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 17:37:51 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 17:37:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 17:37:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 17:37:52 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 17:37:52 --> Total execution time: 0.0416
DEBUG - 2023-09-16 17:37:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:37:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 17:37:52 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 17:37:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 17:37:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 17:37:52 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 17:37:52 --> Total execution time: 0.0339
DEBUG - 2023-09-16 17:37:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:37:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 17:37:52 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 17:37:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 17:37:53 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 17:37:53 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 17:37:53 --> Total execution time: 0.0585
DEBUG - 2023-09-16 17:37:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:37:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 17:37:53 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 17:38:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 17:38:10 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 17:38:10 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 17:38:10 --> Total execution time: 0.0375
DEBUG - 2023-09-16 17:38:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:38:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 17:38:10 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 17:38:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 17:38:15 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 17:38:15 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 17:38:15 --> Total execution time: 0.0614
DEBUG - 2023-09-16 17:38:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:38:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 17:38:15 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 17:38:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 17:38:16 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 17:38:16 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 17:38:16 --> Total execution time: 0.0393
DEBUG - 2023-09-16 17:38:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:38:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 17:38:16 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 17:39:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 17:39:23 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 17:39:23 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 17:39:23 --> Total execution time: 0.0428
DEBUG - 2023-09-16 17:39:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:39:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 17:39:23 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 17:39:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 17:39:24 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 17:39:24 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 17:39:24 --> Total execution time: 0.0413
DEBUG - 2023-09-16 17:39:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:39:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 17:39:25 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 17:39:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 17:39:25 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 17:39:25 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 17:39:25 --> Total execution time: 0.0351
DEBUG - 2023-09-16 17:39:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:39:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 17:39:25 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 17:39:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 17:39:44 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 17:39:44 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 17:39:44 --> Total execution time: 0.0369
DEBUG - 2023-09-16 17:39:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 17:39:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 17:39:44 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 18:02:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 18:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 18:02:02 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 18:02:02 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-16 18:02:02 --> Severity: Warning --> Undefined property: CI_Loader::$session C:\xampp\htdocs\WebProject\application\views\product\create.php 5
ERROR - 2023-09-16 18:02:02 --> Severity: error --> Exception: Call to a member function flashdata() on null C:\xampp\htdocs\WebProject\application\views\product\create.php 5
DEBUG - 2023-09-16 18:02:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 18:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 18:02:34 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 18:02:34 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-16 18:02:34 --> Severity: error --> Exception: syntax error, unexpected token "endif", expecting end of file C:\xampp\htdocs\WebProject\application\views\product\create.php 9
DEBUG - 2023-09-16 18:05:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 18:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 18:05:17 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 18:05:17 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-16 18:05:17 --> Severity: Warning --> Undefined property: CI_Loader::$session C:\xampp\htdocs\WebProject\application\views\product\create.php 5
ERROR - 2023-09-16 18:05:17 --> Severity: error --> Exception: Call to a member function flashdata() on null C:\xampp\htdocs\WebProject\application\views\product\create.php 5
DEBUG - 2023-09-16 18:07:17 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 18:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 18:07:17 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 18:07:17 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-16 18:07:17 --> Severity: Warning --> Undefined property: CI_Loader::$session C:\xampp\htdocs\WebProject\application\views\product\create.php 5
ERROR - 2023-09-16 18:07:17 --> Severity: error --> Exception: Call to a member function flashdata() on null C:\xampp\htdocs\WebProject\application\views\product\create.php 5
DEBUG - 2023-09-16 18:08:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 18:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 18:08:53 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 18:08:53 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-16 18:08:53 --> Severity: Warning --> Undefined property: CI_Loader::$session C:\xampp\htdocs\WebProject\application\views\product\create.php 5
ERROR - 2023-09-16 18:08:53 --> Severity: error --> Exception: Call to a member function flashdata() on null C:\xampp\htdocs\WebProject\application\views\product\create.php 5
DEBUG - 2023-09-16 18:10:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 18:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 18:10:39 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 18:10:39 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-16 18:10:39 --> Severity: Warning --> Undefined property: CI_Loader::$session C:\xampp\htdocs\WebProject\application\views\product\create.php 5
ERROR - 2023-09-16 18:10:39 --> Severity: error --> Exception: Call to a member function flashdata() on null C:\xampp\htdocs\WebProject\application\views\product\create.php 5
DEBUG - 2023-09-16 18:25:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 18:25:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 18:25:28 --> Severity: error --> Exception: syntax error, unexpected token ";", expecting "function" or "const" C:\xampp\htdocs\WebProject\application\controllers\admin.php 35
DEBUG - 2023-09-16 18:26:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 18:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 18:26:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 18:26:06 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-16 18:26:07 --> Severity: Warning --> Undefined property: CI_Loader::$session C:\xampp\htdocs\WebProject\application\views\product\create.php 5
ERROR - 2023-09-16 18:26:07 --> Severity: error --> Exception: Call to a member function flashdata() on null C:\xampp\htdocs\WebProject\application\views\product\create.php 5
DEBUG - 2023-09-16 18:28:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 18:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 18:28:41 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 18:28:41 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-16 18:28:41 --> Severity: Warning --> Undefined property: CI_Loader::$session C:\xampp\htdocs\WebProject\application\views\product\create.php 5
ERROR - 2023-09-16 18:28:41 --> Severity: error --> Exception: Call to a member function flashdata() on null C:\xampp\htdocs\WebProject\application\views\product\create.php 5
DEBUG - 2023-09-16 18:32:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 18:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 18:32:14 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 18:32:14 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 18:32:14 --> Total execution time: 0.0560
DEBUG - 2023-09-16 18:32:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 18:32:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 18:32:14 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 18:32:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 18:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 18:32:44 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 18:32:44 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 18:32:44 --> Total execution time: 0.0477
DEBUG - 2023-09-16 18:32:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 18:32:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 18:32:44 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 18:32:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 18:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 18:32:50 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 18:32:50 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 18:32:50 --> Total execution time: 0.0797
DEBUG - 2023-09-16 18:32:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 18:32:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 18:32:50 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 18:48:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 18:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 18:48:50 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 18:48:50 --> Severity: Warning --> include_once(database.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\controllers\admin.php 14
ERROR - 2023-09-16 18:48:50 --> Severity: Warning --> include_once(): Failed opening 'database.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\controllers\admin.php 14
ERROR - 2023-09-16 18:48:50 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 18:48:50 --> Total execution time: 0.0582
DEBUG - 2023-09-16 18:48:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 18:48:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 18:48:50 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 18:49:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 18:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 18:49:41 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 18:49:41 --> Severity: Warning --> include_once(database.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\controllers\admin.php 14
ERROR - 2023-09-16 18:49:41 --> Severity: Warning --> include_once(): Failed opening 'database.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\controllers\admin.php 14
ERROR - 2023-09-16 18:49:41 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 18:49:41 --> Total execution time: 0.0636
DEBUG - 2023-09-16 18:49:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 18:49:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 18:49:41 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 18:52:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 18:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-16 18:52:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-16 18:52:06 --> Severity: Warning --> include_once(database.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\controllers\admin.php 14
ERROR - 2023-09-16 18:52:06 --> Severity: Warning --> include_once(): Failed opening 'database.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\controllers\admin.php 14
ERROR - 2023-09-16 18:52:06 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-16 18:52:06 --> Total execution time: 0.0653
DEBUG - 2023-09-16 18:52:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 18:52:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 18:52:06 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-16 23:43:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 23:43:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 23:43:42 --> 404 Page Not Found: Crud/savedata
DEBUG - 2023-09-16 23:43:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 23:43:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 23:43:54 --> 404 Page Not Found: Crud/savedata
DEBUG - 2023-09-16 23:44:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 23:44:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 23:44:11 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-16 23:44:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 23:44:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 23:44:27 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-16 23:44:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 23:44:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 23:44:32 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-16 23:46:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 23:46:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 23:46:28 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-16 23:46:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 23:46:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 23:46:29 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-16 23:46:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 23:46:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 23:46:29 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-16 23:46:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 23:46:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 23:46:30 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-16 23:46:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 23:46:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 23:46:30 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-16 23:46:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 23:46:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 23:46:30 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-16 23:46:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 23:46:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 23:46:30 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-16 23:46:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 23:46:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 23:46:30 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-16 23:46:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 23:46:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 23:46:31 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-16 23:46:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 23:46:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 23:46:52 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-16 23:46:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 23:46:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 23:46:58 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-16 23:47:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 23:47:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 23:47:27 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-16 23:47:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 23:47:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 23:47:28 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-16 23:47:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 23:47:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 23:47:28 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-16 23:47:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 23:47:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 23:47:28 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-16 23:47:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 23:47:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 23:47:28 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-16 23:48:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 23:48:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 23:48:45 --> 404 Page Not Found: Crud/index
DEBUG - 2023-09-16 23:59:14 --> UTF-8 Support Enabled
ERROR - 2023-09-16 23:59:14 --> Severity: error --> Exception: syntax error, unexpected token "public", expecting end of file C:\xampp\htdocs\WebProject\system\core\URI.php 57
DEBUG - 2023-09-16 23:59:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-16 23:59:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-16 23:59:36 --> 404 Page Not Found: Crud/index
