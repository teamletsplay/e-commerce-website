<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-09-29 15:59:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 15:59:39 --> No URI present. Default controller set.
DEBUG - 2023-09-29 15:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 15:59:39 --> initController - LoginPage.php
DEBUG - 2023-09-29 15:59:39 --> Total execution time: 0.0303
DEBUG - 2023-09-29 15:59:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 15:59:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 15:59:39 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 15:59:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 15:59:45 --> No URI present. Default controller set.
DEBUG - 2023-09-29 15:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 15:59:45 --> initController - LoginPage.php
DEBUG - 2023-09-29 15:59:45 --> Total execution time: 0.0207
DEBUG - 2023-09-29 15:59:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 15:59:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 15:59:45 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 15:59:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 15:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 15:59:46 --> initController - LoginPage.php
DEBUG - 2023-09-29 15:59:46 --> Total execution time: 0.0187
DEBUG - 2023-09-29 15:59:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 15:59:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 15:59:46 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 15:59:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 15:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 15:59:55 --> initController - LoginPage.php
DEBUG - 2023-09-29 15:59:55 --> Total execution time: 0.0195
DEBUG - 2023-09-29 15:59:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 15:59:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 15:59:55 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 15:59:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 15:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 15:59:55 --> initController - LoginPage.php
DEBUG - 2023-09-29 15:59:55 --> Total execution time: 0.0195
DEBUG - 2023-09-29 15:59:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 15:59:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 15:59:55 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 15:59:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 15:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 15:59:56 --> initController - LoginPage.php
DEBUG - 2023-09-29 15:59:56 --> Total execution time: 0.0196
DEBUG - 2023-09-29 15:59:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 15:59:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 15:59:56 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 15:59:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 15:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 15:59:56 --> initController - LoginPage.php
DEBUG - 2023-09-29 15:59:56 --> Total execution time: 0.0214
DEBUG - 2023-09-29 15:59:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 15:59:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 15:59:56 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 15:59:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 15:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 15:59:56 --> initController - LoginPage.php
DEBUG - 2023-09-29 15:59:56 --> Total execution time: 0.0192
DEBUG - 2023-09-29 15:59:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 15:59:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 15:59:56 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 15:59:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 15:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 15:59:57 --> initController - LoginPage.php
DEBUG - 2023-09-29 15:59:57 --> Total execution time: 0.0193
DEBUG - 2023-09-29 15:59:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 15:59:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 15:59:57 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 15:59:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 15:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 15:59:57 --> initController - LoginPage.php
DEBUG - 2023-09-29 15:59:57 --> Total execution time: 0.0195
DEBUG - 2023-09-29 15:59:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 15:59:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 15:59:57 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 16:00:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 16:00:30 --> initController - LoginPage.php
DEBUG - 2023-09-29 16:00:30 --> Total execution time: 0.0242
DEBUG - 2023-09-29 16:00:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:00:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 16:00:30 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 16:00:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 16:00:38 --> initController - LoginPage.php
DEBUG - 2023-09-29 16:00:38 --> Total execution time: 0.0323
DEBUG - 2023-09-29 16:00:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:00:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 16:00:38 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 16:01:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 16:01:15 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 16:01:15 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 16:01:15 --> Total execution time: 0.0493
DEBUG - 2023-09-29 16:01:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:01:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 16:01:15 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 16:01:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 16:01:27 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 16:01:27 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-29 16:01:27 --> Severity: Notice --> session_start(): Ignoring session_start() because a session is already active C:\xampp\htdocs\WebProject\application\views\insert.php 2
ERROR - 2023-09-29 16:01:27 --> Severity: Warning --> include(./templates/top.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 7
ERROR - 2023-09-29 16:01:27 --> Severity: Warning --> include(): Failed opening './templates/top.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 7
ERROR - 2023-09-29 16:01:27 --> Severity: Warning --> include(./templates/navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 11
ERROR - 2023-09-29 16:01:27 --> Severity: Warning --> include(): Failed opening './templates/navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 11
ERROR - 2023-09-29 16:01:27 --> Severity: Warning --> include(./templates/sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 16
ERROR - 2023-09-29 16:01:27 --> Severity: Warning --> include(): Failed opening './templates/sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 16
ERROR - 2023-09-29 16:01:27 --> Severity: Warning --> include(./templates/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 47
ERROR - 2023-09-29 16:01:27 --> Severity: Warning --> include(): Failed opening './templates/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 47
DEBUG - 2023-09-29 16:01:27 --> Total execution time: 0.0293
DEBUG - 2023-09-29 16:44:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:44:19 --> No URI present. Default controller set.
DEBUG - 2023-09-29 16:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 16:44:19 --> initController - LoginPage.php
DEBUG - 2023-09-29 16:44:19 --> Total execution time: 0.0197
DEBUG - 2023-09-29 16:44:19 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:44:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 16:44:19 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 16:44:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 16:44:29 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 16:44:29 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 16:44:29 --> Total execution time: 0.0252
DEBUG - 2023-09-29 16:44:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:44:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 16:44:29 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 16:44:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 16:44:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-29 16:44:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 16:44:54 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 16:44:54 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 16:44:54 --> Total execution time: 0.0445
DEBUG - 2023-09-29 16:44:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:44:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 16:44:54 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 16:44:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 16:44:58 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 16:44:58 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-29 16:44:58 --> Severity: Notice --> session_start(): Ignoring session_start() because a session is already active C:\xampp\htdocs\WebProject\application\views\insert.php 2
ERROR - 2023-09-29 16:44:58 --> Severity: Warning --> include(./templates/top.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 7
ERROR - 2023-09-29 16:44:58 --> Severity: Warning --> include(): Failed opening './templates/top.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 7
ERROR - 2023-09-29 16:44:58 --> Severity: Warning --> include(./templates/navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 11
ERROR - 2023-09-29 16:44:58 --> Severity: Warning --> include(): Failed opening './templates/navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 11
ERROR - 2023-09-29 16:44:58 --> Severity: Warning --> include(./templates/sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 16
ERROR - 2023-09-29 16:44:58 --> Severity: Warning --> include(): Failed opening './templates/sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 16
ERROR - 2023-09-29 16:44:58 --> Severity: Warning --> include(./templates/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 47
ERROR - 2023-09-29 16:44:58 --> Severity: Warning --> include(): Failed opening './templates/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 47
DEBUG - 2023-09-29 16:44:58 --> Total execution time: 0.0516
DEBUG - 2023-09-29 16:45:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 16:45:28 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 16:45:28 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 16:45:28 --> Total execution time: 0.0223
DEBUG - 2023-09-29 16:45:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 16:45:39 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 16:45:39 --> Severity: Warning --> Undefined property: stdClass::$username C:\xampp\htdocs\WebProject\application\controllers\login.php 99
DEBUG - 2023-09-29 16:45:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 16:45:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-29 16:45:39 --> Total execution time: 0.0203
DEBUG - 2023-09-29 16:48:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 16:48:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-29 16:48:50 --> Total execution time: 0.0211
DEBUG - 2023-09-29 16:49:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 16:49:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 16:49:51 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\WebProject\system\libraries\Session\Session_driver.php 102
DEBUG - 2023-09-29 16:49:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:49:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 16:49:51 --> 404 Page Not Found: Welcome/login
DEBUG - 2023-09-29 16:50:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 16:50:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-29 16:50:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 16:50:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-29 16:50:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 16:50:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-29 16:50:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 16:50:43 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 16:50:43 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 16:50:43 --> Total execution time: 0.0432
DEBUG - 2023-09-29 16:50:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 16:50:44 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 16:50:44 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 16:50:44 --> Total execution time: 0.0481
DEBUG - 2023-09-29 16:50:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 16:50:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-29 16:50:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 16:51:00 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 16:51:00 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 16:51:00 --> Total execution time: 0.0446
DEBUG - 2023-09-29 16:51:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:51:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 16:51:00 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 16:51:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 16:51:26 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 16:51:26 --> Severity: Warning --> Undefined property: stdClass::$username C:\xampp\htdocs\WebProject\application\controllers\login.php 99
DEBUG - 2023-09-29 16:51:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 16:51:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-29 16:51:26 --> Total execution time: 0.0424
DEBUG - 2023-09-29 16:51:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 16:51:30 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 16:51:30 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\WebProject\system\libraries\Session\Session_driver.php 102
DEBUG - 2023-09-29 16:51:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 16:51:30 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 16:51:30 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 16:51:30 --> Total execution time: 0.0325
DEBUG - 2023-09-29 16:51:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:51:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 16:51:30 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 16:54:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:54:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 16:54:58 --> Severity: error --> Exception: Call to undefined function base_url() C:\xampp\htdocs\WebProject\application\controllers\login.php 156
DEBUG - 2023-09-29 16:57:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 16:57:59 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 16:57:59 --> Severity: Warning --> Undefined property: stdClass::$username C:\xampp\htdocs\WebProject\application\controllers\login.php 99
DEBUG - 2023-09-29 16:57:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 16:57:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-29 16:57:59 --> Total execution time: 0.0196
DEBUG - 2023-09-29 16:58:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 16:58:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-29 16:58:02 --> Total execution time: 0.0223
DEBUG - 2023-09-29 16:58:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 16:58:03 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 16:58:03 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 16:58:03 --> Total execution time: 0.0231
DEBUG - 2023-09-29 16:58:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 16:58:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-29 16:58:04 --> Total execution time: 0.0217
DEBUG - 2023-09-29 16:58:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 16:58:05 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 16:58:05 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 16:58:05 --> Total execution time: 0.0234
DEBUG - 2023-09-29 16:58:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 16:58:05 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 16:58:05 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 16:58:05 --> Total execution time: 0.0231
DEBUG - 2023-09-29 16:58:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 16:58:25 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 16:58:25 --> Severity: Warning --> Undefined property: stdClass::$username C:\xampp\htdocs\WebProject\application\controllers\login.php 99
DEBUG - 2023-09-29 16:58:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 16:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 16:58:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-29 16:58:25 --> Total execution time: 0.0202
DEBUG - 2023-09-29 17:04:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:04:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-29 17:04:30 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:04:30 --> Total execution time: 0.0242
DEBUG - 2023-09-29 17:04:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:04:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:04:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:04:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:04:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:04:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:04:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:04:30 --> 404 Page Not Found: Login/5546YEEcss
ERROR - 2023-09-29 17:04:30 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:04:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:04:30 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:04:30 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:04:30 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:04:30 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:04:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:04:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:04:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:04:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:04:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:04:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:04:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:04:30 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:04:30 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:04:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:04:30 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:04:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:04:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:04:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:04:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:04:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:04:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:04:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:04:30 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:04:30 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:04:30 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:04:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:04:30 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:04:30 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:04:30 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:04:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:04:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:04:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:04:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:04:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:04:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:04:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:04:30 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:04:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:04:30 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:04:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:04:30 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:04:30 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:04:30 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:04:30 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:04:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:04:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:04:30 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:04:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:04:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:04:30 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:06:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:05 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:06:05 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:06:05 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:06:05 --> Total execution time: 0.0228
DEBUG - 2023-09-29 17:06:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:06:05 --> 404 Page Not Found: Login/5546YEEcss
ERROR - 2023-09-29 17:06:05 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:06:05 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:05 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:05 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:05 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:06:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:06:05 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:06:05 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:06:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:06:06 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:06:06 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:06:06 --> Total execution time: 0.0231
DEBUG - 2023-09-29 17:06:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:06:06 --> 404 Page Not Found: Login/5546YEEcss
ERROR - 2023-09-29 17:06:06 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:06 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:06 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:06:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:06:06 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:06:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:06:06 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:06:06 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:06 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:06:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:06:06 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:06:07 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:06:07 --> Total execution time: 0.0232
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/5546YEEcss
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:07 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:06:07 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:06:07 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:06:07 --> Total execution time: 0.0239
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/5546YEEcss
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:07 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:06:07 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:06:07 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:06:07 --> Total execution time: 0.0233
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/5546YEEcss
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:07 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:06:07 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:06:07 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:06:07 --> Total execution time: 0.0221
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/5546YEEcss
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:07 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:06:07 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:06:07 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:06:07 --> Total execution time: 0.0214
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/5546YEEcss
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:06:07 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:08 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:06:08 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:06:08 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:06:08 --> Total execution time: 0.0235
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/5546YEEcss
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:08 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:06:08 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:06:08 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:06:08 --> Total execution time: 0.0235
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/5546YEEcss
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:08 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:06:08 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:06:08 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:06:08 --> Total execution time: 0.0229
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/5546YEEcss
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:08 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:06:08 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:06:08 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:06:08 --> Total execution time: 0.0238
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/5546YEEcss
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:08 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:06:08 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:06:08 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:06:08 --> Total execution time: 0.0248
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/5546YEEcss
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:08 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:06:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:09 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:06:09 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:06:09 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:06:09 --> Total execution time: 0.0232
DEBUG - 2023-09-29 17:06:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:06:09 --> 404 Page Not Found: Login/5546YEEcss
ERROR - 2023-09-29 17:06:09 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:09 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:09 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:09 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:06:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:06:09 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:06:09 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:06:09 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:06:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:09 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:06:09 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:06:09 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:06:09 --> Total execution time: 0.0235
DEBUG - 2023-09-29 17:06:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:06:09 --> 404 Page Not Found: Login/5546YEEcss
ERROR - 2023-09-29 17:06:09 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:09 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:09 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:09 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:06:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:06:09 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:09 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:06:09 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:06:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:09 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:06:09 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:06:09 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:06:09 --> Total execution time: 0.0235
DEBUG - 2023-09-29 17:06:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:06:09 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:09 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:09 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:09 --> 404 Page Not Found: Login/5546YEEcss
ERROR - 2023-09-29 17:06:09 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:06:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:06:09 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:09 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:06:09 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:06:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:09 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:06:09 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:06:09 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:06:09 --> Total execution time: 0.0229
DEBUG - 2023-09-29 17:06:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:06:09 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:09 --> 404 Page Not Found: Login/5546YEEcss
ERROR - 2023-09-29 17:06:09 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:09 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:09 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:06:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:06:09 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:06:09 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:06:09 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:06:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:10 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:06:10 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:06:10 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:06:10 --> Total execution time: 0.0238
DEBUG - 2023-09-29 17:06:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:06:10 --> 404 Page Not Found: Login/5546YEEcss
ERROR - 2023-09-29 17:06:10 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:10 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:10 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:10 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:06:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:10 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:06:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:06:10 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:06:10 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:06:10 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:07:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:35 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:07:35 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:07:35 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:07:35 --> Total execution time: 0.0229
DEBUG - 2023-09-29 17:07:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:35 --> 404 Page Not Found: Login/5546YEEcss
DEBUG - 2023-09-29 17:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:35 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:35 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:35 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:35 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:07:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:35 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:07:35 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:35 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:07:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:35 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:35 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:07:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:35 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:07:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:35 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:36 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:07:36 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:07:36 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:07:36 --> Total execution time: 0.0227
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/5546YEEcss
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:36 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:07:36 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:07:36 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:07:36 --> Total execution time: 0.0229
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/5546YEEcss
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:36 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:07:36 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:07:36 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:07:36 --> Total execution time: 0.0237
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/5546YEEcss
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:36 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:07:36 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:07:36 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:07:36 --> Total execution time: 0.0240
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/5546YEEcss
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:36 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:37 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:37 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:37 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:07:37 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:07:37 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:07:37 --> Total execution time: 0.0263
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:37 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:37 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:37 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:37 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:37 --> 404 Page Not Found: Login/5546YEEcss
ERROR - 2023-09-29 17:07:37 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:37 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:07:37 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:37 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:37 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:37 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:37 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:37 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:07:37 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:07:37 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:07:37 --> Total execution time: 0.0231
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:37 --> 404 Page Not Found: Login/5546YEEcss
ERROR - 2023-09-29 17:07:37 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:37 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:37 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:37 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:37 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:37 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:07:37 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:37 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:37 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:37 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:37 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:37 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:07:37 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:07:37 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:07:37 --> Total execution time: 0.0234
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:37 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:37 --> 404 Page Not Found: Login/5546YEEcss
ERROR - 2023-09-29 17:07:37 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:37 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:37 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:37 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:37 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:07:37 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:37 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:37 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:37 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:37 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:07:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:38 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:07:38 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:07:38 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:07:38 --> Total execution time: 0.0233
DEBUG - 2023-09-29 17:07:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:38 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:38 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:38 --> 404 Page Not Found: Login/5546YEEcss
ERROR - 2023-09-29 17:07:38 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:38 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:38 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:07:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:38 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:07:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:38 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:07:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:38 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:38 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:07:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:38 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:07:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:38 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:07:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:38 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:07:38 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:07:38 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:07:38 --> Total execution time: 0.0460
DEBUG - 2023-09-29 17:07:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:38 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:38 --> 404 Page Not Found: Login/5546YEEcss
ERROR - 2023-09-29 17:07:38 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:38 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:38 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:38 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:07:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:38 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:07:38 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:07:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:07:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:38 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:07:38 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:07:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:38 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:07:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:07:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:07:38 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:08:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:08:30 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:08:30 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\header.php 42
DEBUG - 2023-09-29 17:08:30 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:08:30 --> Total execution time: 0.0228
DEBUG - 2023-09-29 17:08:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:08:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:08:30 --> 404 Page Not Found: Login/5546YEEcss
DEBUG - 2023-09-29 17:08:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:08:30 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:08:30 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:08:30 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:08:30 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:08:30 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:08:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:08:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:08:30 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:08:30 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:08:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:08:30 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:08:30 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\header.php 42
DEBUG - 2023-09-29 17:08:30 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:08:30 --> Total execution time: 0.0240
DEBUG - 2023-09-29 17:08:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:08:30 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:08:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:08:30 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:08:30 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:08:30 --> 404 Page Not Found: Login/5546YEEcss
ERROR - 2023-09-29 17:08:30 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:08:30 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:08:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:08:30 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:08:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:08:30 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:08:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:08:30 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:08:30 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\header.php 42
DEBUG - 2023-09-29 17:08:30 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:08:30 --> Total execution time: 0.0234
DEBUG - 2023-09-29 17:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:08:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:08:31 --> 404 Page Not Found: Login/5546YEEcss
ERROR - 2023-09-29 17:08:31 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:08:31 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:08:31 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:08:31 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:08:31 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:08:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:08:31 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:08:31 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:08:31 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:08:31 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\header.php 42
DEBUG - 2023-09-29 17:08:31 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:08:31 --> Total execution time: 0.0224
DEBUG - 2023-09-29 17:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:08:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:08:31 --> 404 Page Not Found: Login/5546YEEcss
DEBUG - 2023-09-29 17:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:08:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:08:31 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:08:31 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:08:31 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:08:31 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:08:31 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:08:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:08:31 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:08:31 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:08:31 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:08:31 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\header.php 42
DEBUG - 2023-09-29 17:08:31 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:08:31 --> Total execution time: 0.0228
DEBUG - 2023-09-29 17:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:08:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:08:31 --> 404 Page Not Found: Login/5546YEEcss
ERROR - 2023-09-29 17:08:31 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:08:31 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:08:31 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:08:31 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:08:31 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:08:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:08:31 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:08:31 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:08:31 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:08:31 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\header.php 42
DEBUG - 2023-09-29 17:08:31 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:08:31 --> Total execution time: 0.0225
DEBUG - 2023-09-29 17:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:08:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:08:31 --> 404 Page Not Found: Login/5546YEEcss
ERROR - 2023-09-29 17:08:31 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:08:31 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:08:31 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:08:31 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:08:31 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:08:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:08:31 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:08:31 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:09:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:46 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:09:46 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\header.php 42
DEBUG - 2023-09-29 17:09:46 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:09:46 --> Total execution time: 0.0241
DEBUG - 2023-09-29 17:09:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:09:46 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:09:46 --> 404 Page Not Found: Login/5546YEEcss
DEBUG - 2023-09-29 17:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:09:46 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:09:46 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:09:46 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:09:46 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:09:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:09:46 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:09:46 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:09:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:47 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:09:47 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\header.php 42
DEBUG - 2023-09-29 17:09:47 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:09:47 --> Total execution time: 0.0273
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/5546YEEcss
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:47 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:09:47 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\header.php 42
DEBUG - 2023-09-29 17:09:47 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:09:47 --> Total execution time: 0.0231
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/5546YEEcss
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:47 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:09:47 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\header.php 42
DEBUG - 2023-09-29 17:09:47 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:09:47 --> Total execution time: 0.0251
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/5546YEEcss
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:47 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:09:47 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\header.php 42
DEBUG - 2023-09-29 17:09:47 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:09:47 --> Total execution time: 0.0248
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/5546YEEcss
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:47 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:09:47 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\header.php 42
DEBUG - 2023-09-29 17:09:47 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:09:47 --> Total execution time: 0.0241
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/5546YEEcss
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:09:47 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:09:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:48 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:09:48 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\header.php 42
DEBUG - 2023-09-29 17:09:48 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:09:48 --> Total execution time: 0.0565
DEBUG - 2023-09-29 17:09:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:09:48 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:09:48 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:09:48 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:09:48 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:09:48 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:09:48 --> 404 Page Not Found: Login/5546YEEcss
DEBUG - 2023-09-29 17:09:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:09:48 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:09:48 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:09:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:48 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:09:48 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\header.php 42
DEBUG - 2023-09-29 17:09:48 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:09:48 --> Total execution time: 0.0231
DEBUG - 2023-09-29 17:09:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:09:48 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:09:48 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:09:48 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:09:48 --> 404 Page Not Found: Login/5546YEEcss
ERROR - 2023-09-29 17:09:48 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:09:48 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:09:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:48 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:09:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:09:48 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:09:48 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:10:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:10:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-29 17:10:58 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:10:58 --> Total execution time: 0.0425
DEBUG - 2023-09-29 17:10:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:10:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:10:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:10:59 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:10:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:10:59 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:10:59 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:10:59 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:10:59 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:11:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:11:06 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:11:06 --> Total execution time: 0.0197
DEBUG - 2023-09-29 17:11:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:11:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:11:06 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:11:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:11:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-29 17:11:08 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:11:08 --> Total execution time: 0.0456
DEBUG - 2023-09-29 17:14:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:14:15 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:14:15 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-29 17:14:15 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:14:15 --> Total execution time: 0.0228
DEBUG - 2023-09-29 17:14:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:14:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:14:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:14:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:14:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:14:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:14:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:14:15 --> 404 Page Not Found: Login/5546YEEcss
DEBUG - 2023-09-29 17:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:14:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:14:15 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:14:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:14:15 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:14:15 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:14:15 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-29 17:14:15 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-29 17:14:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:14:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:14:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:14:15 --> 404 Page Not Found: Login/js
ERROR - 2023-09-29 17:14:15 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-29 17:20:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:20:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-29 17:20:32 --> Total execution time: 0.0218
DEBUG - 2023-09-29 17:20:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:20:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-29 17:20:33 --> Total execution time: 0.0214
DEBUG - 2023-09-29 17:20:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:20:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-29 17:20:33 --> Total execution time: 0.0214
DEBUG - 2023-09-29 17:20:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:20:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-29 17:20:34 --> Total execution time: 0.0214
DEBUG - 2023-09-29 17:20:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:20:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-29 17:20:34 --> Total execution time: 0.0390
DEBUG - 2023-09-29 17:20:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:20:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-29 17:20:34 --> Total execution time: 0.0210
DEBUG - 2023-09-29 17:20:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:20:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-29 17:20:34 --> Total execution time: 0.0213
DEBUG - 2023-09-29 17:20:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:20:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-29 17:20:35 --> Total execution time: 0.0212
DEBUG - 2023-09-29 17:20:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:20:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-29 17:20:35 --> Total execution time: 0.0449
DEBUG - 2023-09-29 17:20:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:20:36 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:20:36 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:20:36 --> Total execution time: 0.0238
DEBUG - 2023-09-29 17:20:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:20:55 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:20:55 --> Severity: Warning --> Undefined property: stdClass::$username C:\xampp\htdocs\WebProject\application\controllers\login.php 99
DEBUG - 2023-09-29 17:20:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:20:55 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:20:55 --> Total execution time: 0.0189
DEBUG - 2023-09-29 17:20:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:20:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:20:55 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:21:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:21:12 --> Total execution time: 0.0368
DEBUG - 2023-09-29 17:21:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:21:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:21:12 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:21:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:21:12 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:21:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:21:12 --> 404 Page Not Found: Img/women-3.jpg
ERROR - 2023-09-29 17:21:12 --> 404 Page Not Found: Img/watch-3.jpg
DEBUG - 2023-09-29 17:21:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:21:23 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:21:23 --> Total execution time: 0.0199
DEBUG - 2023-09-29 17:21:23 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:21:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:21:23 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:23:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:23:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:23:44 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-29 17:23:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:23:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:23:44 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-29 17:23:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:23:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:23:45 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-29 17:23:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:23:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:23:45 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-29 17:23:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:23:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:23:45 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-29 17:23:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:23:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:23:45 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-29 17:23:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:23:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:23:45 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-29 17:24:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:24:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:24:06 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-29 17:24:06 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:24:06 --> Total execution time: 0.0229
DEBUG - 2023-09-29 17:24:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:24:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:24:06 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:26:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:26:03 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:26:03 --> Total execution time: 0.0195
DEBUG - 2023-09-29 17:26:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:26:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:26:03 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:26:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:26:05 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:26:05 --> Total execution time: 0.0395
DEBUG - 2023-09-29 17:26:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:26:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:26:05 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:26:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:26:05 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:26:05 --> Total execution time: 0.0195
DEBUG - 2023-09-29 17:26:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:26:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:26:05 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:26:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:26:06 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:26:06 --> Total execution time: 0.0217
DEBUG - 2023-09-29 17:26:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:26:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:26:06 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:26:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:26:06 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:26:06 --> Total execution time: 0.0197
DEBUG - 2023-09-29 17:26:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:26:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:26:06 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:27:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:27:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:27:30 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-29 17:27:30 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:27:30 --> Total execution time: 0.0208
DEBUG - 2023-09-29 17:27:30 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:27:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:27:30 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:27:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:27:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:27:34 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-29 17:27:34 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:27:34 --> Total execution time: 0.0204
DEBUG - 2023-09-29 17:27:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:27:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:27:34 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:27:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:27:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:27:35 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-29 17:27:35 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:27:35 --> Total execution time: 0.0205
DEBUG - 2023-09-29 17:27:35 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:27:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:27:35 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:27:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:27:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:27:36 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-29 17:27:36 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:27:36 --> Total execution time: 0.0204
DEBUG - 2023-09-29 17:27:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:27:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:27:36 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:28:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:28:07 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:28:07 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:28:07 --> Total execution time: 0.0259
DEBUG - 2023-09-29 17:28:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:28:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:28:07 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:42:32 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:42:32 --> Total execution time: 0.0199
DEBUG - 2023-09-29 17:42:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:42:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:42:32 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:42:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:42:37 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:42:37 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:42:37 --> Total execution time: 0.0242
DEBUG - 2023-09-29 17:42:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:42:40 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:42:40 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:42:40 --> Total execution time: 0.0432
DEBUG - 2023-09-29 17:42:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:42:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:42:40 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:42:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:42:41 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:42:41 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:42:41 --> Total execution time: 0.0231
DEBUG - 2023-09-29 17:42:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:42:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:42:41 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:42:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:42:42 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:42:42 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:42:42 --> Total execution time: 0.0238
DEBUG - 2023-09-29 17:42:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:42:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:42:42 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:42:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:42:42 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:42:42 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:42:42 --> Total execution time: 0.0244
DEBUG - 2023-09-29 17:42:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:42:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:42:42 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:42:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:42:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:42:46 --> 404 Page Not Found: Login1/index
DEBUG - 2023-09-29 17:43:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:43:32 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:43:32 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-29 17:43:32 --> Severity: Warning --> Undefined array key "usernameemail" C:\xampp\htdocs\WebProject\application\views\loggedin.php 174
DEBUG - 2023-09-29 17:43:32 --> Total execution time: 0.0239
DEBUG - 2023-09-29 17:43:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:43:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:43:32 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:45:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:45:20 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:45:20 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:45:20 --> Total execution time: 0.0429
DEBUG - 2023-09-29 17:45:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:45:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:45:20 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:51:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:51:11 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:51:11 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:51:11 --> Total execution time: 0.0235
DEBUG - 2023-09-29 17:51:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:51:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:51:11 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:51:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:51:13 --> initController - LoginPage.php
DEBUG - 2023-09-29 17:51:13 --> Total execution time: 0.0388
DEBUG - 2023-09-29 17:51:13 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:51:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:51:13 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:51:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:51:28 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:51:28 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:51:28 --> Total execution time: 0.0233
DEBUG - 2023-09-29 17:51:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:51:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:51:28 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:51:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:51:41 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:51:41 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:51:41 --> Total execution time: 0.0230
DEBUG - 2023-09-29 17:53:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:53:03 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:53:03 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:53:03 --> Total execution time: 0.0412
DEBUG - 2023-09-29 17:53:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:53:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:53:03 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:53:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:53:04 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:53:04 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:53:04 --> Total execution time: 0.0465
DEBUG - 2023-09-29 17:53:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:53:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:53:04 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:53:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:53:04 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:53:04 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:53:04 --> Total execution time: 0.0231
DEBUG - 2023-09-29 17:53:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:53:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:53:04 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:53:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:53:04 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:53:04 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:53:04 --> Total execution time: 0.0235
DEBUG - 2023-09-29 17:53:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:53:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:53:04 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:53:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:53:04 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:53:04 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:53:04 --> Total execution time: 0.0228
DEBUG - 2023-09-29 17:53:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:53:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:53:04 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:53:04 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:53:05 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:53:05 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:53:05 --> Total execution time: 0.0227
DEBUG - 2023-09-29 17:53:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:53:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:53:05 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:53:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:53:05 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:53:05 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:53:05 --> Total execution time: 0.0407
DEBUG - 2023-09-29 17:53:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:53:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:53:05 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:53:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:53:05 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:53:05 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:53:05 --> Total execution time: 0.0230
DEBUG - 2023-09-29 17:53:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:53:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:53:05 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:53:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:53:05 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:53:05 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:53:05 --> Total execution time: 0.0227
DEBUG - 2023-09-29 17:53:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:53:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:53:05 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:53:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:53:05 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:53:05 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:53:05 --> Total execution time: 0.0396
DEBUG - 2023-09-29 17:53:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:53:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:53:05 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:53:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:53:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:53:06 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:53:06 --> Total execution time: 0.0347
DEBUG - 2023-09-29 17:53:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:53:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:53:06 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:53:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:53:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:53:06 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:53:06 --> Total execution time: 0.0218
DEBUG - 2023-09-29 17:53:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:53:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:53:06 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:53:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:53:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:53:06 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:53:06 --> Total execution time: 0.0237
DEBUG - 2023-09-29 17:53:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:53:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:53:06 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:53:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:53:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:53:06 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:53:06 --> Total execution time: 0.0249
DEBUG - 2023-09-29 17:53:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:53:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:53:06 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:53:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:53:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:53:06 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:53:06 --> Total execution time: 0.0231
DEBUG - 2023-09-29 17:53:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:53:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:53:06 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:53:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:53:07 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:53:07 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:53:07 --> Total execution time: 0.0466
DEBUG - 2023-09-29 17:53:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:53:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:53:07 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:54:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:54:49 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:54:49 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:54:49 --> Total execution time: 0.0238
DEBUG - 2023-09-29 17:54:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:54:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:54:49 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 17:55:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 17:55:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 17:55:51 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 17:55:51 --> Total execution time: 0.0431
DEBUG - 2023-09-29 17:55:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 17:55:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 17:55:51 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:02:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:02:53 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:02:53 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 18:02:53 --> Total execution time: 0.0446
DEBUG - 2023-09-29 18:02:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:02:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:02:53 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:02:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:02:54 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:02:54 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 18:02:54 --> Total execution time: 0.0228
DEBUG - 2023-09-29 18:02:54 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:02:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:02:54 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:02:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:02:55 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:02:55 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\WebProject\system\libraries\Session\Session_driver.php 102
DEBUG - 2023-09-29 18:02:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:02:55 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:02:55 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 18:02:55 --> Total execution time: 0.0412
DEBUG - 2023-09-29 18:02:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:02:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:02:55 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:07:24 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:07:24 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:07:24 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-29 18:07:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\WebProject\application\views\loggedin.php 178
DEBUG - 2023-09-29 18:07:24 --> Total execution time: 0.0242
DEBUG - 2023-09-29 18:07:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:07:25 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:07:25 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 18:07:25 --> Total execution time: 0.0244
DEBUG - 2023-09-29 18:07:26 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:07:26 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:07:26 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-29 18:07:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\WebProject\application\views\loggedin.php 178
DEBUG - 2023-09-29 18:07:26 --> Total execution time: 0.0243
DEBUG - 2023-09-29 18:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:07:36 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:07:36 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\WebProject\system\libraries\Session\Session_driver.php 102
DEBUG - 2023-09-29 18:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:07:36 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:07:36 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 18:07:36 --> Total execution time: 0.0439
DEBUG - 2023-09-29 18:07:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:07:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:07:36 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:09:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:09:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-29 18:09:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:09:37 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:09:37 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 18:09:37 --> Total execution time: 0.0473
DEBUG - 2023-09-29 18:09:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:09:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:09:37 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:10:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:10:00 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:10:00 --> Severity: Warning --> Undefined property: stdClass::$username C:\xampp\htdocs\WebProject\application\controllers\login.php 99
DEBUG - 2023-09-29 18:10:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:10:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:10:00 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-29 18:10:00 --> initController - LoginPage.php
DEBUG - 2023-09-29 18:10:00 --> Total execution time: 0.0425
DEBUG - 2023-09-29 18:10:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:10:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:10:00 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:10:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:10:02 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:10:02 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-29 18:10:02 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\WebProject\application\views\loggedin.php 177
DEBUG - 2023-09-29 18:10:02 --> Total execution time: 0.0231
DEBUG - 2023-09-29 18:10:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:10:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:10:02 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:11:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:11:14 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:11:14 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-29 18:11:14 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\WebProject\application\views\loggedin.php 177
DEBUG - 2023-09-29 18:11:14 --> Total execution time: 0.0237
DEBUG - 2023-09-29 18:11:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:11:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:11:14 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:11:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:11:15 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:11:15 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-29 18:11:15 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\WebProject\application\views\loggedin.php 177
DEBUG - 2023-09-29 18:11:15 --> Total execution time: 0.0234
DEBUG - 2023-09-29 18:11:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:11:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:11:15 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:11:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:11:15 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:11:15 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-29 18:11:15 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\WebProject\application\views\loggedin.php 177
DEBUG - 2023-09-29 18:11:15 --> Total execution time: 0.0230
DEBUG - 2023-09-29 18:11:15 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:11:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:11:15 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:12:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:12:36 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:12:36 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-29 18:12:36 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\WebProject\application\views\loggedin.php 177
DEBUG - 2023-09-29 18:12:36 --> Total execution time: 0.0238
DEBUG - 2023-09-29 18:12:36 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:12:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:12:36 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:15:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:15:45 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:15:45 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-29 18:15:45 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\WebProject\application\views\loggedin.php 177
DEBUG - 2023-09-29 18:15:45 --> Total execution time: 0.0246
DEBUG - 2023-09-29 18:15:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:15:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:15:45 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:18:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:18:08 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:18:08 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-29 18:18:08 --> Severity: Warning --> Undefined variable $udata C:\xampp\htdocs\WebProject\application\views\loggedin.php 178
ERROR - 2023-09-29 18:18:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\WebProject\application\views\loggedin.php 178
DEBUG - 2023-09-29 18:18:08 --> Total execution time: 0.0232
DEBUG - 2023-09-29 18:18:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:18:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:18:08 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:18:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:18:09 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:18:09 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-29 18:18:09 --> Severity: Warning --> Undefined variable $udata C:\xampp\htdocs\WebProject\application\views\loggedin.php 178
ERROR - 2023-09-29 18:18:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\WebProject\application\views\loggedin.php 178
DEBUG - 2023-09-29 18:18:09 --> Total execution time: 0.0237
DEBUG - 2023-09-29 18:18:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:18:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:18:09 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:18:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:18:09 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:18:09 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-29 18:18:09 --> Severity: Warning --> Undefined variable $udata C:\xampp\htdocs\WebProject\application\views\loggedin.php 178
ERROR - 2023-09-29 18:18:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\WebProject\application\views\loggedin.php 178
DEBUG - 2023-09-29 18:18:09 --> Total execution time: 0.0239
DEBUG - 2023-09-29 18:18:09 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:18:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:18:09 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:18:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:18:11 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:18:11 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-29 18:18:11 --> Severity: Warning --> Undefined variable $udata C:\xampp\htdocs\WebProject\application\views\loggedin.php 178
ERROR - 2023-09-29 18:18:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\WebProject\application\views\loggedin.php 178
DEBUG - 2023-09-29 18:18:11 --> Total execution time: 0.0243
DEBUG - 2023-09-29 18:18:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:18:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:18:11 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:19:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:19:11 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:19:11 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 18:19:11 --> Total execution time: 0.0235
DEBUG - 2023-09-29 18:19:11 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:19:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:19:11 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:21:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:21:34 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:21:34 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-29 18:21:34 --> Severity: Warning --> Undefined variable $udata C:\xampp\htdocs\WebProject\application\views\loggedin.php 178
ERROR - 2023-09-29 18:21:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\WebProject\application\views\loggedin.php 178
DEBUG - 2023-09-29 18:21:34 --> Total execution time: 0.0243
DEBUG - 2023-09-29 18:21:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:21:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:21:34 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:21:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:21:45 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:21:45 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 18:21:45 --> Total execution time: 0.0235
DEBUG - 2023-09-29 18:21:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:21:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:21:45 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:22:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:22:39 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:22:39 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 18:22:39 --> Total execution time: 0.0239
DEBUG - 2023-09-29 18:22:39 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:22:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:22:39 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:22:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:22:40 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:22:40 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 18:22:40 --> Total execution time: 0.0231
DEBUG - 2023-09-29 18:22:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:22:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:22:40 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:22:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:22:40 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:22:40 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 18:22:40 --> Total execution time: 0.0468
DEBUG - 2023-09-29 18:22:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:22:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:22:40 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:22:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:22:41 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:22:41 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 18:22:41 --> Total execution time: 0.0234
DEBUG - 2023-09-29 18:22:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:22:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:22:41 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:22:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:22:41 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:22:41 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 18:22:41 --> Total execution time: 0.0231
DEBUG - 2023-09-29 18:22:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:22:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:22:41 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:22:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:22:41 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:22:41 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 18:22:41 --> Total execution time: 0.0485
DEBUG - 2023-09-29 18:22:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:22:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:22:41 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:22:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:22:42 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:22:42 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 18:22:42 --> Total execution time: 0.0225
DEBUG - 2023-09-29 18:22:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:22:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:22:42 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:22:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:22:42 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:22:42 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 18:22:42 --> Total execution time: 0.0406
DEBUG - 2023-09-29 18:22:42 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:22:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:22:42 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:22:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:22:43 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:22:43 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 18:22:43 --> Total execution time: 0.0232
DEBUG - 2023-09-29 18:22:43 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:22:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:22:43 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:23:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:23:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:23:06 --> Severity: Warning --> Undefined property: stdClass::$username C:\xampp\htdocs\WebProject\application\controllers\login.php 99
DEBUG - 2023-09-29 18:23:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:23:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:23:06 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-29 18:23:06 --> initController - LoginPage.php
DEBUG - 2023-09-29 18:23:06 --> Total execution time: 0.0430
DEBUG - 2023-09-29 18:23:06 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:23:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:23:06 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:23:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:23:08 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:23:08 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-29 18:23:08 --> Severity: Warning --> Undefined variable $udata C:\xampp\htdocs\WebProject\application\views\loggedin.php 178
ERROR - 2023-09-29 18:23:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\WebProject\application\views\loggedin.php 178
DEBUG - 2023-09-29 18:23:08 --> Total execution time: 0.0240
DEBUG - 2023-09-29 18:23:08 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:23:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:23:08 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:24:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:24:38 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:24:38 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-29 18:24:38 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\WebProject\application\views\loggedin.php 177
DEBUG - 2023-09-29 18:24:38 --> Total execution time: 0.0237
DEBUG - 2023-09-29 18:24:38 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:24:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:24:38 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:30:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:30:49 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:30:49 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 18:30:49 --> Total execution time: 0.0236
DEBUG - 2023-09-29 18:30:49 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:30:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:30:49 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:32:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:32:07 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:32:07 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 18:32:07 --> Total execution time: 0.0229
DEBUG - 2023-09-29 18:32:07 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:32:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:32:07 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:32:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:32:20 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:32:20 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\WebProject\system\libraries\Session\Session_driver.php 102
DEBUG - 2023-09-29 18:32:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:32:20 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:32:20 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 18:32:20 --> Total execution time: 0.0485
DEBUG - 2023-09-29 18:32:20 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:32:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:32:20 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:32:41 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:32:41 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:32:41 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-29 18:32:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\WebProject\application\views\loggedin.php 178
DEBUG - 2023-09-29 18:32:41 --> Total execution time: 0.0243
DEBUG - 2023-09-29 18:32:44 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:32:44 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:32:44 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 18:32:44 --> Total execution time: 0.0244
DEBUG - 2023-09-29 18:33:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:33:01 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:33:01 --> Severity: Warning --> Undefined property: stdClass::$username C:\xampp\htdocs\WebProject\application\controllers\login.php 99
DEBUG - 2023-09-29 18:33:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:33:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:33:01 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-29 18:33:01 --> initController - LoginPage.php
DEBUG - 2023-09-29 18:33:01 --> Total execution time: 0.0194
DEBUG - 2023-09-29 18:33:01 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:33:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:33:01 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:33:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:33:03 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:33:03 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 18:33:03 --> Total execution time: 0.0231
DEBUG - 2023-09-29 18:33:03 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:33:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:33:03 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:33:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:33:34 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:33:34 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-29 18:33:34 --> Severity: Notice --> session_start(): Ignoring session_start() because a session is already active C:\xampp\htdocs\WebProject\application\views\insert.php 2
ERROR - 2023-09-29 18:33:34 --> Severity: Warning --> include(./templates/top.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 7
ERROR - 2023-09-29 18:33:34 --> Severity: Warning --> include(): Failed opening './templates/top.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 7
ERROR - 2023-09-29 18:33:34 --> Severity: Warning --> include(./templates/navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 11
ERROR - 2023-09-29 18:33:34 --> Severity: Warning --> include(): Failed opening './templates/navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 11
ERROR - 2023-09-29 18:33:34 --> Severity: Warning --> include(./templates/sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 16
ERROR - 2023-09-29 18:33:34 --> Severity: Warning --> include(): Failed opening './templates/sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 16
ERROR - 2023-09-29 18:33:34 --> Severity: Warning --> include(./templates/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 47
ERROR - 2023-09-29 18:33:34 --> Severity: Warning --> include(): Failed opening './templates/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 47
DEBUG - 2023-09-29 18:33:34 --> Total execution time: 0.0290
DEBUG - 2023-09-29 18:33:37 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:33:37 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:33:37 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 18:33:37 --> Total execution time: 0.0237
DEBUG - 2023-09-29 18:33:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:33:51 --> initController - LoginPage.php
DEBUG - 2023-09-29 18:33:51 --> Total execution time: 0.0196
DEBUG - 2023-09-29 18:33:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:33:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:33:51 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:33:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:33:53 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:33:53 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 18:33:53 --> Total execution time: 0.0224
DEBUG - 2023-09-29 18:33:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:33:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:33:53 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:33:56 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:33:56 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:33:56 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 18:33:56 --> Total execution time: 0.0235
DEBUG - 2023-09-29 18:33:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:33:58 --> initController - LoginPage.php
DEBUG - 2023-09-29 18:33:58 --> Total execution time: 0.0404
DEBUG - 2023-09-29 18:33:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:33:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:33:58 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:34:00 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:34:00 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:34:00 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-29 18:34:00 --> Total execution time: 0.0241
DEBUG - 2023-09-29 18:35:55 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:35:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-29 18:36:32 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:36:33 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:36:33 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-29 18:36:33 --> Total execution time: 0.0232
DEBUG - 2023-09-29 18:36:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:36:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:36:33 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:37:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:37:50 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:37:50 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-29 18:37:50 --> Severity: Notice --> session_start(): Ignoring session_start() because a session is already active C:\xampp\htdocs\WebProject\application\views\insert.php 2
ERROR - 2023-09-29 18:37:50 --> Severity: Warning --> include(./templates/top.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 7
ERROR - 2023-09-29 18:37:50 --> Severity: Warning --> include(): Failed opening './templates/top.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 7
ERROR - 2023-09-29 18:37:50 --> Severity: Warning --> include(./templates/navbar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 11
ERROR - 2023-09-29 18:37:50 --> Severity: Warning --> include(): Failed opening './templates/navbar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 11
ERROR - 2023-09-29 18:37:50 --> Severity: Warning --> include(./templates/sidebar.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 16
ERROR - 2023-09-29 18:37:50 --> Severity: Warning --> include(): Failed opening './templates/sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 16
ERROR - 2023-09-29 18:37:50 --> Severity: Warning --> include(./templates/footer.php): Failed to open stream: No such file or directory C:\xampp\htdocs\WebProject\application\views\insert.php 47
ERROR - 2023-09-29 18:37:50 --> Severity: Warning --> include(): Failed opening './templates/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\WebProject\application\views\insert.php 47
DEBUG - 2023-09-29 18:37:50 --> Total execution time: 0.0299
DEBUG - 2023-09-29 18:37:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:37:53 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:37:53 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-29 18:37:53 --> Total execution time: 0.0235
DEBUG - 2023-09-29 18:38:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-29 18:38:05 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-29 18:38:05 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-29 18:38:05 --> Total execution time: 0.0222
DEBUG - 2023-09-29 18:38:05 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:38:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:38:05 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-29 18:52:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:52:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:52:40 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\includes\navbar1.php 42
DEBUG - 2023-09-29 18:52:40 --> initController - LoginPage.php
DEBUG - 2023-09-29 18:52:40 --> Total execution time: 0.0215
DEBUG - 2023-09-29 18:52:40 --> UTF-8 Support Enabled
DEBUG - 2023-09-29 18:52:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-29 18:52:40 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
