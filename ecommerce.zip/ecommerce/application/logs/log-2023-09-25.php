<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-09-25 13:06:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:06:14 --> No URI present. Default controller set.
DEBUG - 2023-09-25 13:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-25 13:06:14 --> initController - LoginPage.php
DEBUG - 2023-09-25 13:06:14 --> Total execution time: 0.0375
DEBUG - 2023-09-25 13:06:14 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:06:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-25 13:06:14 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-25 13:06:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-25 13:06:16 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-25 13:06:16 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-25 13:06:16 --> Total execution time: 0.0368
DEBUG - 2023-09-25 13:06:16 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:06:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-25 13:06:16 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-25 13:06:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:06:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-25 13:06:21 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-25 13:06:21 --> Total execution time: 0.0203
DEBUG - 2023-09-25 13:06:21 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:06:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-25 13:06:21 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-25 13:06:58 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:06:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-25 13:06:58 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-25 13:06:58 --> Severity: Warning --> Undefined property: Customers::$session C:\xampp\htdocs\WebProject\application\controllers\Customers.php 38
ERROR - 2023-09-25 13:06:58 --> Severity: error --> Exception: Call to a member function set_flashdata() on null C:\xampp\htdocs\WebProject\application\controllers\Customers.php 38
DEBUG - 2023-09-25 13:07:29 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-25 13:07:29 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-25 13:07:29 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-25 13:07:29 --> Total execution time: 0.0456
DEBUG - 2023-09-25 13:09:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-25 13:09:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 13:09:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-25 13:09:34 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-25 13:09:34 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-25 13:09:34 --> Total execution time: 0.0215
DEBUG - 2023-09-25 13:09:34 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:09:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-25 13:09:34 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-25 13:12:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:12:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-25 13:12:02 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-25 13:12:02 --> Total execution time: 0.0198
DEBUG - 2023-09-25 13:12:02 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:12:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-25 13:12:02 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-25 13:12:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:12:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-25 13:12:18 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-25 13:12:18 --> Severity: error --> Exception: Call to undefined function set_flashdata() C:\xampp\htdocs\WebProject\application\controllers\Customers.php 38
DEBUG - 2023-09-25 13:15:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:15:33 --> No URI present. Default controller set.
DEBUG - 2023-09-25 13:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-25 13:15:33 --> initController - LoginPage.php
DEBUG - 2023-09-25 13:15:33 --> Total execution time: 0.0553
DEBUG - 2023-09-25 13:15:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:15:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-25 13:15:33 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-25 13:24:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-25 13:24:46 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-25 13:24:46 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-25 13:24:46 --> Total execution time: 0.0549
DEBUG - 2023-09-25 13:24:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:24:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-25 13:24:46 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-25 13:24:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:24:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-25 13:24:52 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-25 13:24:52 --> Total execution time: 0.0803
DEBUG - 2023-09-25 13:24:52 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:24:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-25 13:24:52 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-25 13:25:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-25 13:25:50 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-25 13:25:50 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-25 13:25:50 --> Total execution time: 0.0589
DEBUG - 2023-09-25 13:25:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:25:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-25 13:25:50 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-25 13:33:51 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:33:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-25 13:33:51 --> Severity: error --> Exception: Unmatched '}' C:\xampp\htdocs\WebProject\application\controllers\login.php 134
DEBUG - 2023-09-25 13:34:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-25 13:34:25 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-25 13:34:25 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-25 13:34:25 --> Total execution time: 0.0519
DEBUG - 2023-09-25 13:34:25 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:34:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-25 13:34:25 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-25 13:38:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-25 13:38:28 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-25 13:38:28 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-25 13:38:28 --> Total execution time: 0.0610
DEBUG - 2023-09-25 13:38:28 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:38:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-25 13:38:28 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-25 13:38:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:38:53 --> No URI present. Default controller set.
DEBUG - 2023-09-25 13:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-25 13:38:53 --> initController - LoginPage.php
DEBUG - 2023-09-25 13:38:53 --> Total execution time: 0.0528
DEBUG - 2023-09-25 13:38:53 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:38:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-25 13:38:53 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-25 13:41:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-25 13:41:27 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-25 13:41:27 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-25 13:41:27 --> Total execution time: 0.0656
DEBUG - 2023-09-25 13:41:27 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:41:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-25 13:41:27 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-25 13:41:50 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-25 13:41:50 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-25 13:41:50 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
ERROR - 2023-09-25 13:41:50 --> Severity: Warning --> Undefined property: login::$help_model C:\xampp\htdocs\WebProject\application\controllers\login.php 35
ERROR - 2023-09-25 13:41:50 --> Severity: error --> Exception: Call to a member function saverecords() on null C:\xampp\htdocs\WebProject\application\controllers\login.php 35
DEBUG - 2023-09-25 13:43:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-25 13:43:18 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-25 13:43:18 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-25 13:43:18 --> Total execution time: 0.0764
DEBUG - 2023-09-25 13:43:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:43:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:43:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:43:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:43:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-25 13:43:18 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-25 13:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-25 13:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-25 13:43:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-25 13:43:18 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-25 13:43:18 --> 404 Page Not Found: Login/5546YEEcss
ERROR - 2023-09-25 13:43:18 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-25 13:43:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:43:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-25 13:43:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-25 13:43:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:43:18 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:43:18 --> UTF-8 Support Enabled
ERROR - 2023-09-25 13:43:18 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-25 13:43:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-25 13:43:18 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-25 13:43:18 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-25 13:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-25 13:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-25 13:43:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-25 13:43:18 --> 404 Page Not Found: Login/js
ERROR - 2023-09-25 13:43:18 --> 404 Page Not Found: Login/images
ERROR - 2023-09-25 13:43:18 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-25 13:43:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-25 13:43:33 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-25 13:43:33 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-25 13:43:33 --> Total execution time: 0.0580
DEBUG - 2023-09-25 13:43:33 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:43:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-25 13:43:33 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
DEBUG - 2023-09-25 13:43:45 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-25 13:43:45 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-25 13:43:45 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-25 13:43:45 --> Total execution time: 0.0594
DEBUG - 2023-09-25 13:43:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:43:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:43:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:43:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:43:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-25 13:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-25 13:43:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-25 13:43:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-25 13:43:46 --> 404 Page Not Found: Login/5546YEEcss
ERROR - 2023-09-25 13:43:46 --> 404 Page Not Found: Login/js
ERROR - 2023-09-25 13:43:46 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-25 13:43:46 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-25 13:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-25 13:43:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-25 13:43:46 --> 404 Page Not Found: Login/assets
ERROR - 2023-09-25 13:43:46 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-25 13:43:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:43:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:43:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:43:46 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-25 13:43:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-25 13:43:46 --> 404 Page Not Found: Login/js
ERROR - 2023-09-25 13:43:46 --> 404 Page Not Found: Login/assets
DEBUG - 2023-09-25 13:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-25 13:43:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-25 13:43:46 --> 404 Page Not Found: Login/images
ERROR - 2023-09-25 13:43:46 --> 404 Page Not Found: Login/js
DEBUG - 2023-09-25 13:44:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-25 13:44:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-09-25 13:44:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-09-25 13:44:57 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2023-09-25 13:44:57 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\WebProject\application\views\template\header.php 44
DEBUG - 2023-09-25 13:44:57 --> Total execution time: 0.0632
DEBUG - 2023-09-25 13:44:57 --> UTF-8 Support Enabled
DEBUG - 2023-09-25 13:44:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-09-25 13:44:57 --> 404 Page Not Found: 5546YEEcss/themify-icons.css
