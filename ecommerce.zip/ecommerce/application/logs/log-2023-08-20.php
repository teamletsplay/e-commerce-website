<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-08-20 06:44:16 --> UTF-8 Support Enabled
DEBUG - 2023-08-20 06:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-20 06:44:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2023-08-20 06:44:16 --> Severity: error --> Exception: Unable to locate the model you have specified: BillingModel C:\xampp\htdocs\WebProject\system\core\Loader.php 314
DEBUG - 2023-08-20 06:44:36 --> UTF-8 Support Enabled
DEBUG - 2023-08-20 06:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-20 06:44:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-20 06:44:37 --> initController - LoginPage.php
DEBUG - 2023-08-20 06:44:37 --> Total execution time: 0.1840
DEBUG - 2023-08-20 06:44:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-20 06:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-20 06:44:37 --> UTF-8 Support Enabled
ERROR - 2023-08-20 06:44:37 --> 404 Page Not Found: Css/photoswipe.css
DEBUG - 2023-08-20 06:44:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-20 06:44:37 --> 404 Page Not Found: Images/logogoa.png
DEBUG - 2023-08-20 06:44:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-20 06:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-20 06:44:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-20 06:44:37 --> UTF-8 Support Enabled
DEBUG - 2023-08-20 06:44:37 --> UTF-8 Support Enabled
ERROR - 2023-08-20 06:44:37 --> 404 Page Not Found: Images/1.jpg
DEBUG - 2023-08-20 06:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-20 06:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-20 06:44:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-20 06:44:37 --> 404 Page Not Found: Images/2.jpg
ERROR - 2023-08-20 06:44:37 --> 404 Page Not Found: Images/4.jpg
ERROR - 2023-08-20 06:44:37 --> 404 Page Not Found: Images/3.jpg
DEBUG - 2023-08-20 06:44:38 --> UTF-8 Support Enabled
DEBUG - 2023-08-20 06:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-20 06:44:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-20 06:44:39 --> initController - LoginPage.php
DEBUG - 2023-08-20 06:44:39 --> Total execution time: 0.2240
DEBUG - 2023-08-20 06:44:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-20 06:44:39 --> UTF-8 Support Enabled
DEBUG - 2023-08-20 06:44:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-20 06:44:39 --> 404 Page Not Found: Css/photoswipe.css
DEBUG - 2023-08-20 06:44:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-20 06:44:39 --> 404 Page Not Found: Images/logogoa.png
DEBUG - 2023-08-20 06:44:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-20 06:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-20 06:44:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-20 06:44:40 --> initController - LoginPage.php
DEBUG - 2023-08-20 06:44:40 --> Total execution time: 0.3090
DEBUG - 2023-08-20 06:44:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-20 06:44:40 --> UTF-8 Support Enabled
DEBUG - 2023-08-20 06:44:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-20 06:44:40 --> 404 Page Not Found: Css/photoswipe.css
DEBUG - 2023-08-20 06:44:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-20 06:44:40 --> 404 Page Not Found: Images/logogoa.png
DEBUG - 2023-08-20 06:44:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-20 06:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-20 06:44:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2023-08-20 06:44:41 --> initController - LoginPage.php
DEBUG - 2023-08-20 06:44:41 --> Total execution time: 0.2930
DEBUG - 2023-08-20 06:44:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-20 06:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-20 06:44:41 --> UTF-8 Support Enabled
ERROR - 2023-08-20 06:44:41 --> 404 Page Not Found: Images/1.jpg
DEBUG - 2023-08-20 06:44:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-20 06:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-20 06:44:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-20 06:44:41 --> 404 Page Not Found: Images/logogoa.png
ERROR - 2023-08-20 06:44:41 --> 404 Page Not Found: Css/photoswipe.css
DEBUG - 2023-08-20 06:44:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-20 06:44:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-20 06:44:41 --> 404 Page Not Found: Images/2.jpg
DEBUG - 2023-08-20 06:44:41 --> UTF-8 Support Enabled
DEBUG - 2023-08-20 06:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-08-20 06:44:41 --> UTF-8 Support Enabled
ERROR - 2023-08-20 06:44:41 --> 404 Page Not Found: Images/4.jpg
DEBUG - 2023-08-20 06:44:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-08-20 06:44:41 --> 404 Page Not Found: Images/3.jpg
