<?php
class login_model extends CI_Model 
{
	
	function savereg($data)
	{
        $this->db->insert('customer',$data);
        return true;
	}
	
}