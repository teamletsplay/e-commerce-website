<?php
if (!   defined('BASEPATH') ) exit('No direct script access allowed');

class contact_model extends CI_Model {
    
    
        
        function saverecords($data)
        {
            $this->db->insert('help',$data);
            return true;
        }
        
    }
?>