<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ProductModel extends CI_Model
{
    public function insertProduct($data)
    {
 $this->db->insert('product',$data);
 return true;

}
}
?>