<?php
class cart_model extends CI_Model 
{
	function saverecords($name,$count)
	{
		$query="INSERT INTO `cart`( `name`, `qty`) 
		VALUES ('$name','$count')";
		$this->db->query($query);
	}
};