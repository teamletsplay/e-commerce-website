<?php
class Customers_model extends CI_Model 
{
	
	function saverecords($data)
	{
        $this->db->insert('user_info',$data);
        return true;
	}
	
}